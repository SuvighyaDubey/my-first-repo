function resetMySolutionsVariables()
{
    var mainlife = null;
    var seclife = null;
    var thirdlife = null;
    var prod_choice = null;
    var ben_select = null;
    var ben_select_bundle=null;
    var loading_res = null;
    var prod_choice_res = null;
    var minmax = null;
    var hideshow = null;
    var hideshow_bundle=null;
    var loading_data = null;
    var hideshow_data = null;
    var mck_data = null;
    var handshaking_case = null;
    var handshake_res = null;
    var ylp_id_for_sqs=null;
    var mailIdObjectSetBlank="";
    var solutionsPlanClearData=null;
    var referral_data=null;
    var clearCancerFund=null;
    
    var bundleFundRes=null;
    var bundleProdRes=null;
    var calbundleRes=null;
    var bundleRiderRes=null;
    var isbundleFlag=null;
    var bundlePrevFileNameEmail=null;
     var language_option=null;
    var cal_data_string_bundle=null;
    //Added by Paromita for Defect 6616 and 6044
    
    client_ylp_type_mlife="";
    client_ylp_type_slife="";
    client_ylp_type_tlife="";
    //added by ankita on 30 dec 2022 for defect 646
    relationship_mlife="";
    obj_priority=[];
    arrayBundleProduct=[];
    campaign_code_benefit_screen="";//Added for Jan 2024 CR campaign by Sachin.
    //var ds_agentId="";
    js_get_var("LoginAgentId",function(agent_id)
               {
//ds_agentId=agent_id;
    var queryCheck = fnMsDummyQuery(agent_id);
    
    queryCheck.execute(function(response)
    {
        document.getElementById("naviagtionBtnTable").style.display="block";
        js_set_var("mck_client_id",JSON.stringify(mck_data),function()
        {
        js_set_var("proposal_required_info",JSON.stringify(mck_data),function()
        {
            //array for indicating whether has visited the subsequent pages in sqs module.
            //array is refreshed here each time when the user clicks on the  My Solutions button on the left hand navigation.
         //   arrMySolutionsVisitedFlag = [0,0,0];//original code committed for tap menu.
                  arrMySolutionsVisitedFlag = [0,0,0,0,0];//Added refresh tab button on date 24-2-2020.
                js_set_var("language_option",JSON.stringify(language_option),function()
                {
                js_set_var("bunldle_output_response",JSON.stringify(isbundleFlag),function()
                {
                js_set_var("bundle_product_response",JSON.stringify(bundleFundRes),function()
                {
                              
                js_set_var("bundle_product_detail_response",JSON.stringify(bundleProdRes),function()
                {
                js_set_var("bundlePrevFileNameEmail",JSON.stringify(bundlePrevFileNameEmail),function()
                {
                                      
                    js_set_var("cal_bundle_product_details_response",JSON.stringify(calbundleRes),function()
                {
                        js_set_var("bundle_rider_string",JSON.stringify(bundleRiderRes),function()
                {
    
                js_set_var("cancer_loading_clear",JSON.stringify(clearCancerFund),function()
                {
                js_set_var("referral_details_response", JSON.stringify(referral_data), function()
                {
                   
                js_set_var("buttons_plans_response", JSON.stringify(solutionsPlanClearData), function()
                {

                js_set_var("main_life_response",JSON.stringify(mainlife),function()
                {
                js_set_var("sec_life_response",JSON.stringify(seclife),function()
                {			
                js_set_var("third_life_response",JSON.stringify(thirdlife),function()
                {
                js_set_var("prod_choice_response",JSON.stringify(prod_choice),function()
                {
                js_set_var("prod_choice_res",JSON.stringify(prod_choice_res),function()
                {
                js_set_var("MinMaxBudget",JSON.stringify(minmax),function()
                {
                js_set_var("hideshowrider",JSON.stringify(hideshow),function()
                {
                js_set_var("hideshowrider_bundle",JSON.stringify(hideshow_bundle),function()
                {
                js_set_var("cal_data_string_bundle",JSON.stringify(cal_data_string_bundle),function()
                {
                js_set_var("beneft_selection_response",JSON.stringify(ben_select),function()
                {
                js_set_var("beneft_selection_response_bundle",JSON.stringify(ben_select_bundle),function()
                {
                js_set_var("loading_details_response",JSON.stringify(loading_data),function()
                {
                js_set_var("hideshowloadingrider",JSON.stringify(hideshow_data),function()
                {
                js_set_var("engineloadingstring",JSON.stringify(loading_res),function()
                {
                js_set_var("personal_update_flags_database",JSON.stringify(loading_res),function()
                {
                js_set_var("product_update_flags_database",JSON.stringify(loading_res),function()
                {

                js_set_var("benefit_update_flags_database",JSON.stringify(loading_res),function()
                {

                js_set_var("loading_update_flags_database",JSON.stringify(loading_res),function()
                {
                js_set_var("handshaking_fresh_case",handshaking_case,function()
                {
                js_set_var("personid_database_without_handshaking",JSON.stringify(handshake_res),function()
                {

                js_set_var("ms_sqs_id",JSON.stringify(handshake_res),function()
                {

                js_set_var("isSQSFromProposal","No",function()
                {
                js_set_var("isPreviewFromROA","No",function()
                      {
                           js_set_var("mlife_DOB_changed","No",function()
                                      {
                                      js_set_var("slife_DOB_changed","No",function()
                                                 {
                                                 js_set_var("tlife_DOB_changed","No",function()
                                                            {
																js_set_var("mlife_gender_changed","No",function()
																	{
																	js_set_var("slife_gender_changed","No",function()
																		{
																		js_set_var("tlife_gender_changed","No",function()
																			{
                                                            js_set_var("mck_to_ms_ylp",JSON.stringify(mainlife),function()
                                                                       {
                                                                       js_set_var("ylp_id_for_sqs",JSON.stringify(ylp_id_for_sqs),function()
                                                                                  {
                                                                                  js_set_var("isSQSFromAL", "NO", function() {
                                                                                             
                                                                                  js_set_var("emailListObject", mailIdObjectSetBlank, function() {
                                                                       menuController.loadPage("top_mysolutions_maindetails",0);
                });
                                                                                             });
                                                                                  
                });
                });
                });
                });
                });
                });
                });
                });
                });
                });
                });
                });
                });
                });
                });
                });
                });
                });
                });
                });
                });
                           });
                });
                });
                });
                });
                });
                });
                });
                });
                });//
                           });//
                                   });
                                   });
                                   });
                               });
                           });
                           });
                           });
                   });
                           });
                   ///
        });
        });
    });
    });
}

function fnMsDummyQuery(ds_agentId)
{
    try
    {
        var loadQuery = new DbUtil();
        loadQuery.query()
        .select()
        .column('*')
        .from()
        .table('al_agent_details')
        .where()
        .clause('agent_id','=',ds_agentId);//Added by Pallavi for device sharing
        
        return loadQuery;
    }
    catch(e)
    {
        console.log("Agent Check Error - - >"+ e);
        return;
    }
}
