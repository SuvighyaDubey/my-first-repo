
var bundleproduct={"PRUSignature Optimiser":"PRUSignature Booster"};
var bundle_obj_mlife="";
var bundle_obj_slife="";
var bundle_obj_prochoice="";
var productName="";
 var obj_global_engine_bundle="";
var bundle_prod_res_data="";
var bundleChangeScreenFlag="0";
function onloadBundleProduct()
{
    
    bundle_prod_res_data="";
    bundleChangeScreenFlag="0";
    
	disableCutCopyPaste();
    placeholderToSelect();
    document.getElementById("naviagtionBtnTable").style.display="block";

    
    js_get_var("main_life_response", function(mainlife_res)
               {
               if(mainlife_res != "" && mainlife_res != null && mainlife_res != "null"  && mainlife_res != "(null)")
               {
               bundle_obj_mlife = JSON.parse(mainlife_res);
               
               if(bundle_obj_mlife["al_sqs_details.sec_parti_flag"]=="Yes")
               {
               js_get_var("sec_life_response", function(seclife_res)
                          {
                          if(seclife_res != "" && seclife_res != null && seclife_res != "null"  && seclife_res != "(null)")
                          {
                          bundle_obj_slife = JSON.parse(seclife_res);
                          
                          if(bundle_obj_slife["al_sqs_details.third_parti_flg"]=="Yes")
                          {
                          fnMsLoadBundleProductLoading();
                          }else
                          {
                          fnMsLoadBundleProductLoading();
                          }
                          }
                          });
               }else
               {
               fnMsLoadBundleProductLoading();
               }
               }
               });

   
}

function fnMsLoadBundleProductLoading()
{

    js_get_var("prod_choice_response", function(prod_choice_res)
               {
               if(prod_choice_res != "" && prod_choice_res != null && prod_choice_res != "null"  && prod_choice_res != "(null)")
               {
               bundle_obj_prochoice= JSON.parse(prod_choice_res);
               
               productName=bundle_obj_prochoice["al_sqs_details.product_name"];
                //productName="PRUaspire";
                console.log("Bundle product Name"+productName);
                console.log("@Bundle"+bundleproduct[productName]);
                document.getElementById("bundleproductNameHeading").innerHTML=productNameModifier(bundleproduct[productName]).bold();
               document.getElementById("al_rider_sqs.bundle_basic.rider_value").readOnly=true;
               $( ".bundleFund" ).prop( "disabled", true );
              // document.getElementById("bundleproductNameHeading").innerHTML="SB Accumulator";
              document.getElementById("al_rider_sqs.bundle_basic.id.rider_nm").innerHTML=productNameModifier(bundleproduct[productName]).bold();
               
               if(bundleproduct[productName]=="PRUSignature Booster")
               {
               document.getElementById("local_equity_fund").style.display='none';
               document.getElementById("newGlobalFund").style.display='block'
               
               
               }
               
               
               
               }
               
               
               });
    
}

function switchToBundleProduct()
{
     $("#benefitPage").hide();
    ben_sel_set_detail("","","","","","","","");
    $("#laodingPage").load('mysolutions_bundle_product.html',function()
                           {
                           onloadBundleProduct();
                           
                            });



}




function fnMsbundleLoadingonSaveButton()
{

    var loading_flag_update="0";
    var loading_flag_noupdate = "0";
    js_get_var("bundle_product_details_response", function(bundle_res)
               {
               if(bundle_res != "" && bundle_res != null && bundle_res != "null"  && bundle_res != "(null)")
               {
               var result = $.parseJSON(bundle_res);
               $.each(result, function(k, v)
                      {
                      console.log("loading issued"+v+"-----"+k);
                      if(!(v == document.getElementById(k).value))
                      {
                      loading_flag_update = "1";
                      }else
                      {
                      loading_flag_noupdate = "0";
                      }
                      });
               
               fnMsBundleProductValidateData(loading_flag_update,loading_flag_noupdate);
               }else
               {
                fnMsBundleProductValidateData(loading_flag_update,loading_flag_noupdate);
               }
               
               
               });
    
    
}

function fnMsBundleProductValidateData(flagupdate,flagnoupdate)
{
    if(flagupdate=="0" || flagupdate==0)
    {
        flagupdate="1";
    }
    
    if(fnMsBundleLoadingvalidateData())
    {
       
        
       var bundle_product_update_data_flags = {
            "bundle_flag_update": flagupdate,
            "bundle_flag_noupdate": flagnoupdate
        }
        
        
        js_set_var("bundle_product_update_flags",JSON.stringify(bundle_product_update_data_flags),function()
                   {
                  
                              fnMsBundleProductSetDataonExit();
                   
                   });
        
        
    }

 
}





function fnMsBundleLoadingvalidateData()
{

    
    
    if(document.getElementById("al_rider_sqs.bundle_basic.id").checked  && document.getElementById("total_allocation_value").innerHTML!="100")
    {
        
        alert("214");
        return false;
        
    }else if(!document.getElementById("al_rider_sqs.bundle_basic.id").checked && (document.getElementById("total_allocation_value").innerHTML!="" || document.getElementById("total_allocation_value").innerHTML!="null"))
    {
            alert("770")
              return false;
    
    
    }
    
    

    return true;

}




function fnMsBundleProductSetDataonExit()
{
    var fund_allocation_val=document.getElementById("total_allocation_value").innerHTML;
    
    var bundle_product_response = {
        "al_rider_sqs.bundle_basic.name":bundleproduct[productName],
        "al_rider_sqs.bundle_basic.id" : document.getElementById("al_rider_sqs.bundle_basic.id").checked,
        "al_rider_sqs.bundle_basic.rider_premium" : document.getElementById("al_rider_sqs.bundle_basic.rider_premium").value,
        "al_rider_sqs.bundle_basic.rider_term" : document.getElementById("al_rider_sqs.bundle_basic.rider_term").value,
        "al_rider_sqs.bundle_basic.rider_value" : document.getElementById("al_rider_sqs.bundle_basic.rider_value").value
        
           };
    
    var cal_bundle_product_details_response={
    "al_sqs_details.totals_premium_accumulator":document.getElementById("al_rider_sqs.bundle_basic.rider_premium").value
    
    };
    
    
    inputs= document.getElementById("bundleBlock").getElementsByTagName('input');
    var bundleRiderString="";
    for (var i = 0; i < inputs.length; i++)
    {
        
        if (inputs[i].type == "checkbox")
        {
            if(inputs[i].id=="al_rider_sqs.bundle_basic.id")
            {
                bundleRiderString=bundleRiderString+"al_rider_sqs.bundle_basic.name="+"basic_plan"
                +";;"+"al_rider_sqs.bundle_basic.rider_term="+document.getElementById("al_rider_sqs.bundle_basic.rider_term").value+";;"
                +"al_rider_sqs.bundle_basic.rider_expiry_age=0;;"+"al_rider_sqs.bundle_basic.rider_value="+document.getElementById("al_rider_sqs.bundle_basic.rider_value").value+";;"+"al_rider_sqs.bundle_basic.rider_premium="+document.getElementById("al_rider_sqs.bundle_basic.rider_premium").value+";;"+"al_rider_sqs.bundle_basic..hidden_rider=No;;"+"::";
                
                
                
            }
            
        }
        
    }
    
    
    
    if(bundle_obj_prochoice["al_sqs_details.mlife.il_anb"]<=69)
    {
        
        bundleRiderString=bundleRiderString+"al_rider_sqs.total_and_permanent_disability.rider_name=total_and_permanent_disability;;"
        +"al_rider_sqs.total_and_permanent_disability.rider_term="+document.getElementById("al_rider_sqs.basic_plans.rider_term").value+";;"+"al_rider_sqs.total_and_permanent_disability.rider_expiry_age=0;;"+"al_rider_sqs.total_and_permanent_disability.rider_value="+document.getElementById("al_rider_sqs.basic_plans.rider_premium").value+";;"+"al_rider_sqs.total_and_permanent_disability.rider_contribution=0;;"+"al_rider_sqs.total_and_permanent_disability.hidden_rider=Yes;;"+"::";
    }

    
    
    
    var bundleFreq="SP";
    var bundleMethod="Cash/Cheque";
    var fund_allocation_val=document.getElementById("total_allocation_value").innerHTML;
    
    
    var bundle_prod_fund = {
        "al_sqs_details.product_name":bundleproduct[productName],
        "al_sqs_details.payment_backdate" : bundle_obj_prochoice["al_sqs_details.payment_backdate"],
        "al_sqs_details.tot_fund_val":fund_allocation_val.toString(),
        "al_sqs_details.Inception_dt" : bundle_obj_prochoice["al_sqs_details.Inception_dt"],
        "al_sqs_details.payment_frequency" : bundleFreq,
        "al_sqs_details.payment_mode" :  bundle_obj_prochoice["al_sqs_details.payment_mode"],
        "al_sqs_details.fund_choice1" : bundle_obj_prochoice["al_sqs_details.fund_choice1"],
        "al_sqs_details.fund_choice2" : bundle_obj_prochoice["al_sqs_details.fund_choice2"],
        "al_sqs_details.equity_fund" : document.getElementById("al_sqs_details.equity_fund").value,
        "al_sqs_details.managed_fund2" : document.getElementById("al_sqs_details.managed_fund2").value,
        "al_sqs_details.bond_fund" : document.getElementById("al_sqs_details.bond_fund").value,
        "al_sqs_details.dana_unggul" : document.getElementById("al_sqs_details.dana_unggul").value,
        "al_sqs_details.dana_urus2" : document.getElementById("al_sqs_details.dana_urus2").value,
        "al_sqs_details.dana_aman" : document.getElementById("al_sqs_details.dana_aman").value,
        "al_sqs_details.asia_property" : document.getElementById("al_sqs_details.asia_property").value,
        "al_sqs_details.asia_managed_fund" : document.getElementById("al_sqs_details.asia_managed_fund").value,
        "al_sqs_details.asia_local_bond_fund" : document.getElementById("al_sqs_details.asia_local_bond_fund").value,
        "al_sqs_details.global_market_naviga" : document.getElementById("al_sqs_details.global_market_naviga").value,
        "al_sqs_details.dragon_peacock" : document.getElementById("al_sqs_details.dragon_peacock").value,
        "al_sqs_details.asia_equity_fund" : document.getElementById("al_sqs_details.asia_equity_fund").value,
        "al_sqs_details.equity_focus_fund" : document.getElementById("al_sqs_details.equity_focus_fund").value,
        "al_sqs_details.equity_income_fund" : document.getElementById("al_sqs_details.equity_income_fund").value,
        "al_sqs_details.global_leaders_fund" : document.getElementById("al_sqs_details.global_leaders_fund").value,
        "al_sqs_details.asian_high_yield_bond_fund" : document.getElementById("al_sqs_details.asian_high_yield_bond_fund").value,
        "al_sqs_details.japan_dynamic_fund" : document.getElementById("al_sqs_details.japan_dynamic_fund").value,
        "al_sqs_details.euro_equity_fund" : document.getElementById("al_sqs_details.euro_equity_fund").value,
        "al_sqs_details.multi_asset_fund" : document.getElementById("al_sqs_details.multi_asset_fund").value,
        "al_sqs_details.asia_select_focus_fund" : document.getElementById("al_sqs_details.asia_select_focus_fund").value,
        "al_sqs_details.flexi_vantage_fund" : document.getElementById("al_sqs_details.flexi_vantage_fund").value,
        "al_sqs_details.asia_opportunities_fund" : document.getElementById("al_sqs_details.asia_opportunities_fund").value,
        "al_sqs_details.global_managed_fund" : document.getElementById("al_sqs_details.global_managed_fund").value,
        "al_sqs_details.global_opportunities_fund" : document.getElementById("al_sqs_details.global_opportunities_fund").value,
        "al_sqs_details.strategic_managed_fund" : document.getElementById("al_sqs_details.strategic_managed_fund").value,
        "al_sqs_details.expiry_age":bundle_obj_prochoice["al_sqs_details.expiry_age"],
        "al_sqs_details.mlife.il_anb":bundle_obj_prochoice["al_sqs_details.mlife.il_anb"],
        "al_sqs_details.slife.il_anb":bundle_obj_prochoice["al_sqs_details.slife.il_anb"],
        "al_sqs_details.tlife.il_anb":bundle_obj_prochoice["al_sqs_details.tlife.il_anb"],
        "al_sqs_details.product_code":"SP02",
        "al_sqs_details.product_type":"IL"
       
    };
    
    
    js_set_var("bundle_product_response",JSON.stringify(bundle_prod_fund),function()
               {
               
               js_set_var("bundle_product_detail_response",JSON.stringify(bundle_product_response),function()
                          {
                          js_set_var("cal_bundle_product_details_response",JSON.stringify(cal_bundle_product_details_response),function()
                                     {
                                     js_set_var("bundle_rider_string",JSON.stringify(bundleRiderString),function()
                                                {
                                                
                                                js_get_var("bunldle_product_flag", function(bundle_flag)
                                                           {
//                                                            if(bundle_flag=="Yes")
//                                                           {
//                                                               bundleChangeScreenFlag="1";
//                                                           
//                                                           }
                                                            bundleChangeScreenFlag="1";
                                     
                                                           $("#laodingPage").hide();
                                                           menuController.loadPage("top_mysolutions_benefit_selection",0);
                                            
                                            
                                            
                                                           })
                                            
                                                });
                                     
                                     });
                          
                          
                          });

               
               
               });
    
    
    
    
    

}





function SetBundleRiderEntry(RiderIdPart,RiderIdPart1,RiderIdPart2,RiderIdPart3,RiderIdPart4)
{
    
   

    var ridersel = RiderIdPart + ".id" ;
    var ridervalue = RiderIdPart + ".rider_value" ;
    var riderterm = RiderIdPart + ".rider_term" ;
    var riderexpiryage = RiderIdPart + ".rider_expiry_age" ;
    var ridercontri = RiderIdPart + ".rider_premium" ;

    
    if(ridersel=="al_rider_sqs.bundle_basic.id")
    {
    if(document.getElementById(ridersel).checked)
    {
      document.getElementById(ridercontri).value="4000.00";
      document.getElementById(ridervalue).disabled=true;
        
//      document.getElementById(riderterm).value="32";
//      document.getElementById(ridercontri).value="12280";
       
        
    }else
    {
        document.getElementById(ridervalue).value="";
        document.getElementById(riderterm).value="";
        document.getElementById(ridercontri).value="";
        
        
        fnClearbundleResponse();
        
        
        
        
        
    }
        
        
    
    }
    
    
    
    
}


function calculateBundleContriVal()
{

    console.log("CAlculation purpose");
    
    
    
   
    //
      var bundleFreq="SP";
      var bundleMethod="Cash/Cheque";
      var fund_allocation_val=document.getElementById("total_allocation_value").innerHTML;
      var bundle_prod_fund = {
        "al_sqs_details.product_name":bundleproduct[productName],
        "al_sqs_details.payment_backdate" : bundle_obj_prochoice["al_sqs_details.payment_backdate"],
        "al_sqs_details.tot_fund_val":fund_allocation_val.toString(),
        "al_sqs_details.Inception_dt" : bundle_obj_prochoice["al_sqs_details.Inception_dt"],
        "al_sqs_details.payment_frequency" : bundleFreq,
        "al_sqs_details.payment_mode" :  bundle_obj_prochoice["al_sqs_details.payment_mode"],
        "al_sqs_details.fund_choice1" : bundle_obj_prochoice["al_sqs_details.fund_choice1"],
        "al_sqs_details.fund_choice2" : bundle_obj_prochoice["al_sqs_details.fund_choice2"],
        "al_sqs_details.equity_fund" : document.getElementById("al_sqs_details.equity_fund").value,
        "al_sqs_details.managed_fund2" : document.getElementById("al_sqs_details.managed_fund2").value,
        "al_sqs_details.bond_fund" : document.getElementById("al_sqs_details.bond_fund").value,
        "al_sqs_details.dana_unggul" : document.getElementById("al_sqs_details.dana_unggul").value,
        "al_sqs_details.dana_urus2" : document.getElementById("al_sqs_details.dana_urus2").value,
        "al_sqs_details.dana_aman" : document.getElementById("al_sqs_details.dana_aman").value,
        "al_sqs_details.asia_property" : document.getElementById("al_sqs_details.asia_property").value,
        "al_sqs_details.asia_managed_fund" : document.getElementById("al_sqs_details.asia_managed_fund").value,
        "al_sqs_details.asia_local_bond_fund" : document.getElementById("al_sqs_details.asia_local_bond_fund").value,
        "al_sqs_details.global_market_naviga" : document.getElementById("al_sqs_details.global_market_naviga").value,
        "al_sqs_details.dragon_peacock" : document.getElementById("al_sqs_details.dragon_peacock").value,
        "al_sqs_details.asia_equity_fund" : document.getElementById("al_sqs_details.asia_equity_fund").value,
        "al_sqs_details.equity_focus_fund" : document.getElementById("al_sqs_details.equity_focus_fund").value,
        "al_sqs_details.equity_income_fund" : document.getElementById("al_sqs_details.equity_income_fund").value,
        "al_sqs_details.global_leaders_fund" : document.getElementById("al_sqs_details.global_leaders_fund").value,
        "al_sqs_details.asian_high_yield_bond_fund" : document.getElementById("al_sqs_details.asian_high_yield_bond_fund").value,
        "al_sqs_details.japan_dynamic_fund" : document.getElementById("al_sqs_details.japan_dynamic_fund").value,
        "al_sqs_details.euro_equity_fund" : document.getElementById("al_sqs_details.euro_equity_fund").value,
        "al_sqs_details.multi_asset_fund" : document.getElementById("al_sqs_details.multi_asset_fund").value,
        "al_sqs_details.asia_select_focus_fund" : document.getElementById("al_sqs_details.asia_select_focus_fund").value,
        "al_sqs_details.flexi_vantage_fund" : document.getElementById("al_sqs_details.flexi_vantage_fund").value,
        "al_sqs_details.asia_opportunities_fund" : document.getElementById("al_sqs_details.asia_opportunities_fund").value,
        "al_sqs_details.global_managed_fund" : document.getElementById("al_sqs_details.global_managed_fund").value,
        "al_sqs_details.global_opportunities_fund" : document.getElementById("al_sqs_details.global_opportunities_fund").value,
        "al_sqs_details.strategic_managed_fund" : document.getElementById("al_sqs_details.strategic_managed_fund").value,
        "al_sqs_details.expiry_age":bundle_obj_prochoice["al_sqs_details.expiry_age"],
        "al_sqs_details.mlife.il_anb":bundle_obj_prochoice["al_sqs_details.mlife.il_anb"],
        "al_sqs_details.slife.il_anb":bundle_obj_prochoice["al_sqs_details.slife.il_anb"],
        "al_sqs_details.tlife.il_anb":bundle_obj_prochoice["al_sqs_details.tlife.il_anb"],
          "al_sqs_details.product_code":"SP02",
          "al_sqs_details.product_type":"IL"
        
    };

    
    
    
    
  //
    js_set_var("bundle_product_response",JSON.stringify(bundle_prod_fund),function()
               {

    
    //js_set_var("bundle_rider_string",JSON.stringify(bundleRiderString),function()
               //{
               
               if(document.getElementById("al_rider_sqs.bundle_basic.id").checked)
               {
                 $( ".bundleFund" ).prop( "disabled", false);
               fnGenerateInputforCalculation(bundleproduct[productName],"","bundle_product");
               }else{
               
               $( ".bundleFund" ).val(0);
               document.getElementById("total_allocation_value").innerHTML="";
               $( ".bundleFund" ).prop( "disabled", true );
               document.getElementById("al_sqs_details.totals_premium_accumulator").value="0.0";
              
               
               }
               
            //   fnGenerateInputforCalculation(flag_cals,loadingflag_generate,callfrom)
               
               
               //});
               });
    
    
    
    
    
    
    
    
}






//Added function for Preview output of SB accumulator on date on Date 11-2-2019.
function fnPreviewBundleProductOutput()
{
    var obj_mlife_bundle = "";
    var obj_global_mlife_bundle="";
    var obj_slife_bundle="";
    var obj_global_slife_bundle="";
    var obj_tlife_bundle="";
    var obj_global_tlife_bundle="";
    var obj_prochoice_bundle= "";
    var obj_global_prochoice_bundle="";
    var obj_global_rider_bundle="";
    var cal_obj_global_rider_bundle="";
    
   var  bundle_product_detail="";
   
    var  bundleOutPutData="";
    
    js_get_var("main_life_response", function(mainlife_res)
               {
               
               if(mainlife_res != "" && mainlife_res != null && mainlife_res != "null"  && mainlife_res != "(null)")
               {
               obj_mlife_bundle = JSON.parse(mainlife_res);
               obj_global_mlife_bundle=obj_mlife_bundle;
               
               console.log("main life response  "+ obj_mlife_bundle);
               }
               
               js_get_var("sec_life_response", function(seclife_res)
                          {
                          
                          
                          if(seclife_res != "" && seclife_res != null && seclife_res != "null"  && seclife_res != "(null)")
                          {
                          obj_slife_bundle = JSON.parse(seclife_res);
                          obj_global_slife=obj_slife_bundle;
                          }else
                          {
                          obj_global_slife_bundle="";
                          }
                          
                          
                          js_get_var("third_life_response", function(thirdlife_res)
                                     {
                                     
                                     
                                     
                                     if(thirdlife_res != "" && thirdlife_res != null && thirdlife_res != "null"  && thirdlife_res != "(null)")
                                     {
                                     obj_tlife_bundle = JSON.parse(thirdlife_res);
                                     obj_global_tlife_bundle=obj_tlife_bundle;
                                     }else
                                     {
                                     obj_global_tlife_bundle="";
                                     }
                                     js_get_var("bundle_product_response", function(prod_choice_res)
                                                {
                                                
                                                
                                                if(prod_choice_res != "" && prod_choice_res != null && prod_choice_res != "null"  && prod_choice_res != "(null)")
                                                {
                                                obj_prochoice_bundle= JSON.parse(prod_choice_res);
                                                obj_global_prochoice_bundle=obj_prochoice_bundle;
                                                }
                                                
                                                js_get_var("beneft_selection_response", function(ben_selection_res)
                                                           {
                                                           
                                                           if(ben_selection_res != "" && ben_selection_res != null && ben_selection_res != "null"  && ben_selection_res != "(null)")
                                                           {
                                                           var obj_ben_sel = JSON.parse(ben_selection_res);
                                                           obj_global_rider_bundle=obj_ben_sel;
                                                           
                                                           }
                                                           
                                                           
                                                           js_get_var("cal_data_string",function(response_cal)
                                                                      {
                                                                      
                                                                      if(response_cal != "" && response_cal != null && response_cal != "null"  && response_cal != "(null)")
                                                                      {
                                                                      var obj_ben_sel = JSON.parse(response_cal);
                                                                      cal_obj_global_rider_bundle=obj_ben_sel;
                                                                      
                                                                      // "bunldle_output_response"
                                                                      
                                                                      
                                                                      }
                                                                      
                                                                      js_get_var("bunldle_output_response",function(bundle_outputOject)
                                                                                 {
                                                                                 
                                                                                 if(bundle_outputOject != "" && bundle_outputOject != null && bundle_outputOject != "null"  && bundle_outputOject != "(null)")
                                                                                 {
                                                                                 var obj_ben_sel = JSON.parse(bundle_outputOject);
                                                                                 bundleOutPutData=obj_ben_sel;
                                                                                 //obj_global_engine_bundle=obj_ben_sel;
                                                                                 
                                                                                 // "bunldle_output_response"
                                                                                 //bundle_rider_string
                                                                                 
                                                                                 
                                                                               //
                                                                                 
                                                                                 
                                                                                 }
                                                                                 
                                                                                 
                                                                                 
                                                                                 js_get_var("rider_data_string_bundle",function(bundle_output_Object_string)
                                                                                            {
                                                                                            
                                                                                            if(bundle_output_Object_string != "" && bundle_output_Object_string != null && bundle_output_Object_string != "null"  && bundle_output_Object_string != "(null)")
                                                                                            {
                                                                                            var obj_ben_sel = JSON.parse(bundle_output_Object_string);
                                                                                            bundle_prod_res_data=obj_ben_sel;
                                                                                            
                                                                                            // "bunldle_output_response"
                                                                                            //bundle_rider_string
                                                                                            
                                                                                            
                                                                                            }

                                                                                            js_get_var("beneft_selection_response_bundle",function(bundle_prod_res)
                                                                                                       {
                                                                                                       
                                                                                                       if(bundle_prod_res != "" && bundle_prod_res != null && bundle_prod_res != "null"  && bundle_prod_res != "(null)")
                                                                                                       {
                                                                                                       var obj_ben_sel = JSON.parse(bundle_prod_res);
                                                                                                       bundle_product_detail=obj_ben_sel;
                                                                                                      // obj_global_engine_bundle=obj_ben_sel;
                                                                                                       
                                                                                                       // "bunldle_output_response"
                                                                                                       //bundle_rider_string
                                                                                                       
                                                                                                       }
                                                                                                       
                                                                    //obj_global_prochoice_bundle["al_sqs_details.product_name"]="PRUSignature Harvest Plus";
                                                                                                            fnSqs_SiExt_Output(obj_global_mlife_bundle,obj_global_slife,"",obj_global_prochoice_bundle,bundle_product_detail,bundleOutPutData,"");
                                                                                                       });
                                                                                            });
                                                                                 
                                                                                 });
                                                                      
                                                                      });
                                                           });
                                                
                                                });
                                     
                                     });
                          
                          });
               
               
               
               
               });
}

