
var mainLifeDataObject="";

var thirdLifeDataObject="";
var selectedPlanName="";
var nonSelectedPlan=false;
var buttonPlansObject="";
var medicialPlansDetails="";
var diabetsDuration="";
var hba1c_level="";
var benfitMedicalPlanName="";
var ben_select_data_clear = null;
var benefitRespnseData=false;
var loading_res_clear=null;
var prod_choice_rs_clear=null;
var screenVisibility="";
var screenVisibilityFlag=true;
var hlevelCheckFlag=false;
var diabetesDurationCheck=false;
var bothDiabetesAndHlev=false;
var PRUcancerProductCer=false;
var buttonClickResonse=false;
var solutionExpire=[];
var documentDirectoryPath = "";
var documentDirectoryPath1 = "";
var solutionCSVVersion = "";
var prenatalFlag=false;
var ArrayOfImagesPath=[];
var ArrayOfvaridDiv=[];
var maxSolutionSelected="";
var productCertifiedPRUwith_you="";
var slider_one = "";
var slider_two = "";

var css_indicator=true; solutionEligible1=["al_sqs_buttons_container.prumy_child_plus","al_sqs_buttons_container.education_solution","al_sqs_buttons_container.cancer_solution","al_sqs_buttons_container.tailor_your_solution","al_sqs_buttons_container.savings_solution","al_sqs_buttons_container.prubest_gift","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.pruelite_invest","al_sqs_buttons_container.pruwealth_enrich"];//Added new solution for may Release //gift of love
var solutionEligible2=["al_sqs_buttons_container.tailor_your_solution","al_sqs_buttons_container.cancer_solution","al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.savings_solution","al_sqs_buttons_container.prubest_gift","al_sqs_buttons_container.prumy_critical_care","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.prubiz_protect","al_sqs_buttons_container.pruterm_premier","al_sqs_buttons_container.pruelite_invest","al_sqs_buttons_container.pruwealth_enrich","al_sqs_buttons_container.pruman","al_sqs_buttons_container.prulady"];
var solutionEligible3=["al_sqs_buttons_container.tailor_your_solution","al_sqs_buttons_container.cancer_solution","al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.legacy_solution","al_sqs_buttons_container.savings_solution","al_sqs_buttons_container.pruprotect_xtra","al_sqs_buttons_container.prumy_critical_care","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.prubiz_protect","al_sqs_buttons_container.pruterm_premier","al_sqs_buttons_container.pruelite_invest","al_sqs_buttons_container.pruwealth_enrich","al_sqs_buttons_container.pruman","al_sqs_buttons_container.prulady"];

//var ribbenProduct=["prumy_child_plus","education_solution","cancer_solution","tailor_your_solution","legacy_solution"];
var ribbenProductFinal=[];

var solutionEligible4=["al_sqs_buttons_container.tailor_your_solution","al_sqs_buttons_container.cancer_solution","al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.legacy_solution","al_sqs_buttons_container.prumy_diabetes_care","al_sqs_buttons_container.savings_solution","al_sqs_buttons_container.pruprotect_xtra","al_sqs_buttons_container.pruprotect_xtra","al_sqs_buttons_container.prumy_critical_care","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.prubiz_protect","al_sqs_buttons_container.pruterm_premier","al_sqs_buttons_container.pruelite_invest","al_sqs_buttons_container.pruwealth_enrich"];

var solutionEligible5=["al_sqs_buttons_container.prufirst"];



var hideBusiness=["al_sqs_buttons_container.cancer_solution","al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.legacy_solution","al_sqs_buttons_container.prumy_diabetes_care","al_sqs_buttons_container.pruprotect_xtra","al_sqs_buttons_container.pruprotect_xtra","al_sqs_buttons_container.prumy_critical_care","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.prumy_child_plus","al_sqs_buttons_container.prubest_gift","al_sqs_buttons_container.prufirst","al_sqs_buttons_container.pruwealth_enrich","al_sqs_buttons_container.pruman","al_sqs_buttons_container.prulady"]; // Removed "al_sqs_buttons_container.savings_solution" by shivani for employee

var hideBusiness_keyman=["al_sqs_buttons_container.cancer_solution","al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.legacy_solution","al_sqs_buttons_container.prumy_diabetes_care","al_sqs_buttons_container.savings_solution","al_sqs_buttons_container.pruprotect_xtra","al_sqs_buttons_container.pruprotect_xtra","al_sqs_buttons_container.prumy_critical_care","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.prumy_child_plus","al_sqs_buttons_container.prubest_gift","al_sqs_buttons_container.prubiz_protect","al_sqs_buttons_container.prufirst","al_sqs_buttons_container.pruelite_invest","al_sqs_buttons_container.pruwealth_enrich","al_sqs_buttons_container.pruman","al_sqs_buttons_container.prulady"]; // Added by Shivani for PRUterm Premier Keyman


var pruwealthplusCertified="Yes"//Added for agent qualifiacation for new product pruwealth plus for may release on date 04-4-2019
var pruwealthmaxCertified="Yes"
var nqaptProductList=["PRUWealth Plus","PRUWealth Max","PRUgrowth","PRUcash","PRUcancer X","PRULink Cover","PRUcash double reward","PRUwith you","PRUCash Enrich","PRUTerm Premier","PRUSignature Assure"];//NQAPT Solution Available product check.

//[1, 2, 3].includes(2);     // true

var displaySolutions=[];
var productMasterData=[];
var available_prod_name=[];
var unavailable_prod_name=[];
var unavailable_prod_cert=[];

var available_solution={"PRUwith you":["al_sqs_buttons_container.prumy_child_plus","al_sqs_buttons_container.education_solution","al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.prumy_diabetes_care","al_sqs_buttons_container.prumy_critical_care","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.prubiz_protect"],"PRUcancer X":["al_sqs_buttons_container.cancer_solution"],"PRULink Cover":["al_sqs_buttons_container.prumy_child_plus","al_sqs_buttons_container.education_solution","al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.prumy_diabetes_care","al_sqs_buttons_container.prumy_critical_care"],"PRUTerm Premier":["al_sqs_buttons_container.pruterm_premier"],"PRUSignature Assure":["al_sqs_buttons_container.prumy_child_plus","al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.prumy_critical_care"],"PRUWealth Enrich":["al_sqs_buttons_container.pruwealth_enrich"]}







function fnMsButtonsOnLoad()
{
    
  //startSpinner("Please wait..");
    
    
    ribbenProductFinal=[];
    solutionExpire=[];
    diabetsDuration="";
    hba1c_level="";
    benfitMedicalPlanName="";
    benefitRespnseData=false;
    buttonPlansObject="";
    PRUcancerProductCer=false;
    available_prod_name=[];
    unavailable_prod_name=[];
    unavailable_prod_cert=[];
    secondLifeDataObject="";//Added temp for defect 7073 on date 29-3-2019
    thirdLifeDataObject="";//Added temp for defect 7073 on date 29-3-2019
    prenatalFlag=false;
    maxSolutionSelected="";
    productCertifiedPRUwith_you="";
    (arrMySolutionsVisitedFlag[1]==1?arrMySolutionsVisitedFlag[1]=1:arrMySolutionsVisitedFlag[1]=2);
    arrMySolutionsVisitedFlag[0]=1;
    SQSmarkTopMenus(1);
    
    
    
    var solutionsPlanData=toSolutionObject(solutions_result);
    var solutionsPlanSequance=toSolutionObjectSequance(solutions_sequence);
    
    console.log("solutionsPlanData"+solutionsPlanData);
    console.log("solutionsPlanData"+solutionsPlanSequance);
    
    
    
   
    
    //Following condition added for for NQAP Validation product Solutions
  
             
    var productAvaliableData=getProductsFromDevice(Channel);
    
          productAvaliableData.execute(function(res_product_list)
            {
                    if (res_product_list != "{}" && res_product_list != "") {
                         productMasterData = JSON.parse(res_product_list);
                            
                        for(var iCounter=0; iCounter<=nqaptProductList.length-1;iCounter++)
                        {
                                       
                        var nqaptData=_.where(productMasterData,{"product_name":nqaptProductList[iCounter]});
                        if(nqaptData!="" && nqaptData!=undefined && nqaptData!="undefined" && nqaptData!='undefined')
                        {
                        if(fnCheckProductCertification(globalDtAppointmentDate, globalDtCertificationDate, nqaptData[0].cert_code,productCertified,""))
                        {
                                       if(nqaptProductList[iCounter]=="PRUWealth Plus" || nqaptProductList[iCounter]=="PRUWealth Max") {
                                             pruwealthplusCertified="Yes"
                                       }
                                       
                                       console.log("@product name-->"+nqaptData[0].product_name)
                                       
                                       if(mainLifeDataObject["pamb_channel"]=="UOB" && (referral_Database.length!="0" || referral_Database.length!=0)){
                                       
                                       if(!referral_Database.includes(nqaptData[0].cert_code)){
                                       unavailable_prod_name.push(nqaptData[0].product_name)
                                       
                                       }
                                       
                                       }
                                       
                                       
                        }else
                                       
                        {
                            console.log("@nqapt product"+nqaptProductList[iCounter] +"CERT Code"+nqaptData[0].cert_code)
                                       unavailable_prod_cert.push(nqaptProductList[iCounter])
                            if(nqaptProductList[iCounter]=="PRUWealth Plus")
                                {
                                    pruwealthplusCertified="No"
                                       
                                }
                                       if(nqaptProductList[iCounter]=="PRUWealth Max"){
                                     pruwealthmaxCertified="No"
                                       
                                       
                                       }
                                       
                                       if(nqaptProductList[iCounter]=="PRUwith you"){
                                         productCertifiedPRUwith_you="No"
                                       
                                       
                                       }
                                       
                                       

                                       
                        }//
                        }
                                       
                        }
                               
                    for (sub in productMasterData)
                            {
                                   
                                       
                                var currentTime = new Date();
                                var incDay = parseInt(currentTime.getDate());
                                var incMonth = parseInt(currentTime.getMonth())+1; //January is 0!
                                var incYear = parseInt(currentTime.getFullYear());
                                var inception_date=incDay+"/"+incMonth+"/"+incYear;
                                       
                            if (checkProductforExp(productMasterData[sub]["product_effect_date"], productMasterData[sub]["product_expiry_date"], inception_date))
                                {
                                       
                                    available_prod_name.push(productMasterData[sub]["product_name"]);//Original code
                                       }else{
                                       unavailable_prod_name.push(productMasterData[sub]["product_name"])
                                       
                                       }
                                       
                                       
                                       
                                       
                            }
                                      
                                       
                                       
                    }
                   
   
                                       
                                       
                                       
                                       
                                       
                                       
    
    var querySelectCSVVersion=new DbUtil();
    querySelectCSVVersion.query()
    querySelectCSVVersion.select()
    querySelectCSVVersion.column('version')
    querySelectCSVVersion.from()
    querySelectCSVVersion.table('al_solution_csv_files_version');
    querySelectCSVVersion.execute(function(response)
                                  {
                                      if(response!="{}"&&response!="")
                                      {
                                          var obj=JSON.parse(response);
                                          for(sub in obj)
                                          {
                                            solutionCSVVersion = obj[sub]['version'] ;
                                          }
                                       }
                                  
                      var MSQGIndicator="";
                      var MsQGInd=fnMSGetMSQGindicator();
                      MsQGInd.execute(function(responseMsqg)
                                      {
                                      if (responseMsqg != "{}" && responseMsqg != "")
                                      {
                                      var MSQGMedIndicatorObj = JSON.parse(responseMsqg);
                                      MSQGIndicator=MSQGMedIndicatorObj['0']['msqg_suspense_ind']
                                      
                                      }
   // solutionsPlan  Cancer Solution,PRUmy medical plus,Education Solution,PRUmy child Plus,PRUmy Diabetes care,Tailor your solution,Legacy Solution
    
    
    // SEG:solutionsPlanData Legacy Solution,Tailor your solution,PRUmy Diabetes care,PRUmy child Plus,Education Solution,PRUmy medical plus,cancer solution
//    if(response!="{}"&&response!="" && solutionCSVVersion!="1.0" && solutionsPlanSequance!=[] && solutionsPlanData!=[]  && solutionPlanCsv !=[] && solutionPlanDataCsv != [] && solutions_loading != [] && solutions_result != [])// original condition.
                                  
                                  // SEG:solutionsPlanData Legacy Solution,Tailor your solution,PRUmy Diabetes care,PRUmy child Plus,Education Solution,PRUmy medical plus,cancer solution
    if(response!="{}"&&response!="" && solutionCSVVersion!="1.0" &&  solutionPlanCsv.length !=0 && solutionPlanDataCsv.length != 0 && solutions_loading.length != 0 && solutions_result.length != 0 && solutions_sequence.length != 0)// original condition.

        {
                                  
                              
                                  
    for(var i=0;i<=ribbenProduct.length-1;i++)
    {
        var ribbenData=ribbenProduct[i].replace(/ /g, "_").toLowerCase();
        ribbenProductFinal.push(ribbenData);
        
        
    }
    
    ArrayOfImagesPath=[];
    ArrayOfvaridDiv=[];
    for(var i=0;i<=solutionsPlanSequance.length-1;i++)
    {
        var solutionNm="";
        var rec="";
        var imPath="";
        var solutionDetail=solutionsPlanSequance[i];
        var result = solutionsPlanSequance[i].replace(/ /g, "_").toLowerCase();
        console.log("result obtained",result);
        
        
        
        var varidDiv="al_sqs_buttons_container"+"."+result;
        displaySolutions.push(varidDiv);
            
        var buttonID="al_sqs_buttons"+"."+result;
        var imId="plans_image"+"."+result;
        documentDirectoryPath ="";
        documentDirectoryPath = documentDirectoryPathSolutionButton+"/SolutionButton/"+solutionCSVVersion+"/"
        console.log("documentDirectoryPath--->"+documentDirectoryPath)
                                      
        documentDirectoryPath1 = "/SolutionButton/"+solutionCSVVersion+"/";
                                      console.log("documentDirectoryPath1--->"+documentDirectoryPath1);
                                      
        if((mainLifeDataObject["pamb_channel"]=="Banca" || Channel=="Banca")){//Added for priority based product selection CR by sachin.
            if(ribbenProductFinal.indexOf(result)>=0)
            {
                  imPath=documentDirectoryPath1+"Images/"+result+"_rec"+"."+"png";
            }
            else
            {
              if(ribbenProductFinal.length==0)
                {
              imPath=documentDirectoryPath1+"Images/"+result+"."+"png";
                }
            
            }
                                      
        }else
        {
                                      
        if(ribbenProductFinal.indexOf(result)>=0)
        {
              imPath=documentDirectoryPath1+"Images/"+result+"_rec"+"."+"png";
        }
        else
        {
          imPath=documentDirectoryPath1+"Images/"+result+"."+"png";
        
        }
        }
        
       
        
        solutionNm=solutionDetail;
        console.log("@solution Name"+solutionNm);
                                  
    if((mainLifeDataObject["pamb_channel"]=="UOB"|| Channel=="UOB")&& (solutionNm=="PRUmy child Plus" || solutionNm=="PRUmy medical plus" || solutionNm=="PRUmy Diabetes care"))
    {
        if(solutionNm=="PRUmy child Plus")
        {
            solutionNm="Child Plus Solution"
            console.log("content 1")
                                  
        }else if(solutionNm=="PRUmy medical plus")
            {
                solutionNm="Medical Plus Solution"
                      console.log("content 2")
                                  
           }else if(solutionNm=="PRUmy Diabetes care")
            {
                                  
                   solutionNm="Diabetes Care Solution"
                           console.log("content 3")
            }
                                  
                                  
                                  
            }
            else if((mainLifeDataObject["pamb_channel"]=="Banca" || Channel=="Banca")&& (solutionNm=="PRUmy child Plus" || solutionNm=="PRUmy medical plus" || solutionNm=="PRUmy Diabetes care" || solutionNm=="PRUMy Critical Care" || solutionNm=="Tailor Your Solution"))
                                         {
                                             if(solutionNm=="PRUmy child Plus")
                                             {
                                                 solutionNm="Child Solution"
                                                 console.log("content 1")
                                                                       
                                             }else if(solutionNm=="PRUmy medical plus")
                                                 {
                                                     solutionNm="Medical Solution"
                                                           console.log("content 2")
                                                                       
                                                }else if(solutionNm=="PRUMy Critical Care")
                                                 {
                                                                       
                                                        solutionNm="Critical Illness Solution"
                                                                console.log("content 3")
                                      }
                                                 }
                                      
       console.log("@@solution Name"+solutionNm);
                                  
                                  
        var pruFlag = solutionDetail.includes("PRU");
        var pruVal="";
        if(pruFlag && (mainLifeDataObject["pamb_channel"]!="UOB" && Channel!="UOB" && mainLifeDataObject["pamb_channel"]!="Banca" && Channel!="Banca"))
        {
            var solName="";
            pruVal="PRU";
            solutionNm = solutionNm.replace(/PRU/g,'').toLowerCase();
          
             var capitalWord=solutionNm.charAt(0).toUpperCase() + solutionNm.slice(1);
                
              
            var splitSolutionName=solutionNm.split(" ")
                                      
            
                splitSolutionName.forEach(function(element){
                      
                                   solName=solName+element.charAt(0).toUpperCase() + element.slice(1)+" ";
                                          
                            });
                                      
                                      
                                      solutionNm=solName;
            
        }
        
        console.log("Final solution name",solutionNm)
        console.log("Image path"+imPath);
        
                                     /* if(solutionNm.includes("Signature Assure –<br>child Solution")){
                                     solutionNm=solutionNm.replace("child Solution","Child Solution")
                                      }else if(solutionNm.includes("Signature Assure –<br>medical Solution ")){
                                     solutionNm=solutionNm.replace("medical Solution ","Medical Solution")
                                      }else if(solutionNm.includes("Signature Assure – <br>critical Illness Solution")){
                                      solutionNm=solutionNm.replace("critical Illness Solution","Critical Illness Solution")
                                      }***/
        
//        var solutionTemplate="<div class='column' id='"+varidDiv+"' style='display:none'>"+
//        "<div style='padding-left: 25px'>"+"<p style='color:red;bold'>"+"<b>"+pruVal+"</b>"+"<b style='color:black;'>"+solutionNm+"</b>"+"</p>"+"</div>"+
//        "<button class='button' id='"+buttonID+"' onclick='fnMsOnClickPlansButton(id)'>"+
//        "<img src='"+imPath+"'  id='"+imId+"' height='190' width:'190' /></button>"+
//        "</button>"+"</div>";
                                     
                                      ArrayOfImagesPath.push(imPath);
                                      ArrayOfvaridDiv.push(imId);
                                      //ribbenProductFinal.push(ribbenProduct[i]);
                                      
                                      /*
                                      var solutionTemplate="<div class='column' id='"+varidDiv+"' style='display:none'>"+
                                      "<div style='padding-left: 40px'>"+"<p style='color:red;bold'>"+"<b>"+pruVal+"</b>"+"<span style='color:black;'>"+solutionNm+"</span>"+"</p>"+"</div>"+
                                      "<button class='button' id='"+buttonID+"' onclick='fnMsOnClickPlansButton(id)'>"+
                                      "<img src='"+imPath+"'  id='"+imId+"' height='190' width:'190' /></button>"+
                                      "</button>"+"</div>";
                                       */
                                      
                                      var nameData=solutionDetail.toLowerCase();
                                     
                                      var solutionTemplate="<div class='column' id='"+varidDiv+"' style='display:none'>"+
                                      "<div style='padding-left: 40px'>"+"<p style='color:red;bold'>"+"<b>"+pruVal+"</b>"+"<span style='color:black;'>"+solutionNm+"</span>"+"</p>"+"</div>"+
                                      "<button class='button' id='"+buttonID+"' name='"+nameData+"' onclick='fnMsOnClickPlansButton(id)'>"+
                                      "<img src=''  id='"+imId+"' height='190' width:'190' /></button>"+
                                      "</button>"+"</div>";
                                     
        
                                    $('#solutions_container').append(solutionTemplate);
        
        
//                                      if((mainLifeDataObject["pamb_channel"]=="Banca" || Channel=="Banca")&&(solutionNm=="Tailor Your Solution")){
//
//                                       $(escape_jq("al_sqs_buttons.tailor_your_solution")).css("margin-top", "19px");
//                                      }
//
                                      
                                      
    
    }
    
    
    
    
    
    for(var i=0;i<=solutionsPlanData.length-1;i++)
    {
       
        var result = solutionsPlanData[i].replace(/ /g, "_").toLowerCase();
        
        var varidDiv="al_sqs_buttons_container"+"."+result;
        solutionExpire.push(varidDiv);
        
        
    }

    
    
    console.log("solution Expire"+solutionExpire);
     console.log("--ArrayOfImagesPath-->"+ArrayOfImagesPath);
     console.log("--ArrayOfvaridDiv-->"+ArrayOfvaridDiv);
    //documentDirectoryPathSolutionButton+"/SolutionButton/"+solutionCSVVersion+"/"
//                                      console.log("--ArrayOfImagesPath-->"+ArrayOfImagesPath);
//      var pagedata_imgPath = {
//                                            "image_path": ArrayOfImagesPath
//      }
//
     //js_call_native_func("ArrayOfImagesPath", pagedata_imgPath, function(response) {
        
    
    //selectedPlanName="";
    js_get_var("buttons_plans_response", function(buttons_plans_res)
    {
           if (buttons_plans_res != "" && buttons_plans_res != null && buttons_plans_res != "null" && buttons_plans_res != "(null)")
           {
           buttonPlansObject = JSON.parse(buttons_plans_res);
           
           }else
           {
           selectedPlanName="";
           
           }

           var productCertifiedString=productCertified.split(",");
               console.log("productCertifiedString"+productCertifiedString[1])
           //Following condition added to check data
          //  productCertifiedString[1]="PRUcancer X_No"
         //   productCertifiedString[0]="No"
           
       
               if(productCertifiedPRUwith_you=="No"){
               
               productCertifiedString[0]="No"
               
               }
           
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                  
           if(productCertifiedString[1]==undefined || productCertifiedString[1]=='undefined' || productCertifiedString[1]=="" || productCertifiedString[1]==null)
           {
                    PRUcancerProductCer=true;
           }
           
           /**************Following condition for new configuaration may Release for PRUwealth plus product for angency*****************/
           
        /*   if(productCertified.includes("NQAPT_Yes")) //Commeted for defect 7334
           {
             pruwealthplusCertified="Yes"
           console.log("NQPT TRUE")
           
           }else
           {
           pruwealthplusCertified="No"
            console.log("NQPT false")
           
           }***/
           
           
           /******************************/
           css_indicator=true;
           if(productCertified.includes("CSS_Yes"))//Added for defect 7992 on date 20-09-2019
           {
           css_indicator=false;
           
           
           }

js_get_var("main_life_response", function(mainlife_res)
               
{
           if (mainlife_res != "" && mainlife_res != null && mainlife_res != "null" && mainlife_res != "(null)")
           {
           mainLifeDataObject = JSON.parse(mainlife_res);
               
           
           }
           
          
           
            if(mainLifeDataObject["pamb_channel"]=="UOB" || mainLifeDataObject["pamb_channel"]=="Banca")
           {
           mainLifeDataObject["pvm_qualification_check"]="Yes"
          // mainLifeDataObject["rider_certified_check"]="PruMillionMed_Yes"
           mainLifeDataObject["rider_certified_check"]="PruMillionMed_No"
           productCertifiedString[0]="Yes"
           productCertifiedString[1]="PRUcancer X_Yes"
           PRUcancerProductCer=false;
           
           if(referralValueMed=="" && (referral_Database.length!=0 || referral_Database.length!='0')){
           
            mainLifeDataObject["pvm_qualification_check"]="No"
           }
           
           if(referralMillionMed=="" && (referral_Database.length!=0 || referral_Database.length!='0')){
           mainLifeDataObject["rider_certified_check"]="PruMillionMed_No"
           
           }
           
           
           }
           
           
           
           
           
        js_get_var("sec_life_response", function(scnd_res)
            {
                 
                   if (scnd_res != "" && scnd_res != null && scnd_res != "null" && scnd_res != "(null)")
                   {
                   secondLifeDataObject = JSON.parse(scnd_res);
                   
                   }
                 
                   js_get_var("third_life_response", function(thrd_res)
                              {
                   
                              if (thrd_res != "" && thrd_res != null && thrd_res != "null" && thrd_res != "(null)")
                              {
                              thirdLifeDataObject = JSON.parse(thrd_res);
                              
                              }
                              
                              
                             
                              
                              if(/*mainLifeDataObject["pamb_channel"]!="UOB" && */mainLifeDataObject["pamb_channel"]!="SCB")
                              {
                              
                              
                               if(mainLifeDataObject["al_person_details.pre_natal_child_flg"]=="Yes")
                                {
                              
                              mainLifeDataObject["al_person_details.mlife.anb"]=0;
                              mainLifeDataObject["al_person_details.mlife.anb_il_monthly_product"]=0;
                              prenatalFlag=true
                              mainLifeDataObject["al_person_details.mlife.anb_il_product"]=0;
                              
                                }
                              
                              
                              
                              
                              
                              if((mainLifeDataObject["al_person_details.mlife.anb"] <= 15 || mainLifeDataObject["al_person_details.mlife.anb_il_monthly_product"] <= 15 || mainLifeDataObject["al_person_details.mlife.anb_il_product"] <= 15) || prenatalFlag)
                              {
                              
                             
                            //  ilProductList.indexOf(obj_prochoice["al_sqs_details.product_name"])>=0
                              
                              
                              for(var i=0;i<=solutionExpire.length-1;i++)
                              {
                              
                              if(solutionEligible1.indexOf(solutionExpire[i])>=0)
                              {
                               console.log("Display Id Less than 15"+solutionExpire[i]);
                               document.getElementById(solutionExpire[i]).style.display='block';
                              
                              }
                            
                              }
                              
                             
                              
                              //comment for configuration.
//                              document.getElementById("al_sqs_buttons_container.prumy_child_plus").style.display='block';
//                              document.getElementById("al_sqs_buttons_container.education_solution").style.display='block';
//                              document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none';
//                              document.getElementById("al_sqs_buttons_container.tailor_your_solution").style.display='block';
                              
                             if(mainLifeDataObject["al_person_details.pre_natal_child_flg"]=="Yes")
                              {
                              
                              var solutionContent=["al_sqs_buttons_container.cancer_solution","al_sqs_buttons_container.savings_solution","al_sqs_buttons_container.prubest_gift","al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.prumy_critical_care","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.pruelite_invest","al_sqs_buttons_container.pruwealth_enrich"]
                              
                              for(var i=0;i<=solutionContent.length-1;i++)
                              {
                              
                              console.log("@RER"+solutionContent[i])
                              console.log("displaySolutions"+displaySolutions[i])
                              if(displaySolutions.indexOf(solutionContent[i])>=0)
                              {
                              console.log("PRENatal case"+displaySolutions[i]);
                              document.getElementById(solutionContent[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                               //document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none'; //Commeted for defect type error .this is original code
                               //document.getElementById("al_sqs_buttons_container.savings_solution").style.display='none';//Commeted for defect type error .this is original code
                              }
                              
                              
                              if((mainLifeDataObject["pvm_qualification_check"]=="No" && mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="No") ||(productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer)  && mainLifeDataObject["pvm_qualification_check"]=="Yes" && mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && pruwealthplusCertified=="Yes")|| (productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer)  && mainLifeDataObject["pvm_qualification_check"]=="Yes" && mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && pruwealthplusCertified=="Yes"))
                              {//1.
                            
                            
                              
                              var solutionContent1=["al_sqs_buttons_container.prumy_child_plus","al_sqs_buttons_container.education_solution","al_sqs_buttons_container.cancer_solution","al_sqs_buttons_container.savings_solution","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.prubiz_protect"]
                              
                              for(var i=0;i<=solutionContent1.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContent1[i])>=0)
                              {
                              console.log("Display Id"+solutionContent1[i]);
                              document.getElementById(solutionContent1[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                             // document.getElementById("al_sqs_buttons_container.prumy_child_plus").style.display='none';//Commeted for defect type error .this is original code
                            //  document.getElementById("al_sqs_buttons_container.education_solution").style.display='none';//Commeted for defect type error .this is original code
                            //  document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none';//Commeted for defect type error .this is original code
                            //  document.getElementById("al_sqs_buttons_container.savings_solution").style.display='none';//Added for may Release on date 4-4-2019.
                              
                              
                              
                              
                              
                              
                              
                              }else if((mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="Yes" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes") || (mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="Yes" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes")) //Added pruwealthplusCertified for may release on date 4-04-2019
                              {
                              //2.
                            //  document.getElementById("al_sqs_buttons_container.prumy_child_plus").style.display='none';//commented for new Solution br.
                                console.log("Display All Solution");
                              
                              
                              }
                              else if((mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="Yes" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes") || (mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="No" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes"))//Added pruwealthplusCertified for may release on date 4-04-2019
                              {
                              //3..
                              //document.getElementById("al_sqs_buttons_container.prumy_child_plus").style.display='block';
                              console.log("Display All Solution")
                              
                              
                              }else if((mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="Yes" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="No"))//Added for may Release 2019 on date 5-4-2019
                              {
                              
                              
                              
                              var solutionContent2=["al_sqs_buttons_container.prubest_gift"]
                              
                              for(var i=0;i<=solutionContent2.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContent2[i])>=0)
                              {
                              console.log("Display Id"+solutionContent2[i]);
                              document.getElementById(solutionContent2[i]).style.display='none';
                              
                              }
                              
                              }
                              
                          
                              
                             //  document.getElementById("al_sqs_buttons_container.gift_of_love").style.display='none';//commented for new Solution br.////Commeted for defect type error .this is original code
                              
                             
                            }
                              
                              else if((mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="No" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes") || (mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="No" && mainLifeDataObject["pvm_qualification_check"]=="Yes" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes") || (mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="No" && mainLifeDataObject["pvm_qualification_check"]=="No" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes") || (mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="No" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="No") || (mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="No" && mainLifeDataObject["pvm_qualification_check"]=="Yes" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="No")) //Added condition "pruwealthplusCertified" for may Release on date
                              {
                              
                                                          //2 4...
                              
                              
                              
                              var solutionContent3=["al_sqs_buttons_container.prumy_child_plus","al_sqs_buttons_container.education_solution","al_sqs_buttons_container.savings_solution","al_sqs_buttons_container.prubest_gift","al_sqs_buttons_container.pruprotect_xtra","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.prubiz_protect"]
                              
                              for(var i=0;i<=solutionContent3.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContent3[i])>=0)
                              {
                              console.log("Display Id"+solutionContent3[i]);
                              document.getElementById(solutionContent3[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              
                             // document.getElementById("al_sqs_buttons_container.prumy_child_plus").style.display='none';//Commeted for defect type error .this is original code
                             // document.getElementById("al_sqs_buttons_container.education_solution").style.display='none';//Commeted for defect type error .this is original code
                              //document.getElementById("al_sqs_buttons_container.savings_solution").style.display='none';//Commeted for defect type error .this is original code
                             // document.getElementById("al_sqs_buttons_container.savings_solution").style.display='none'; ////Commeted for defect type error .this is original code
                             // document.getElementById("al_sqs_buttons_container.gift_of_love").style.display='none'; ////Commeted for defect type error .this is original code
                             // document.getElementById("al_sqs_buttons_container.your_coomitment").style.display='none';////Commeted for defect type error .this is original code
                              
                              
                              }
                              
                              else if((mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="Yes") || (mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[1]=="PRUcancer X_No" && mainLifeDataObject["pvm_qualification_check"]=="Yes" && productCertifiedString[0]=="Yes" && pruwealthplusCertified=="Yes") || (mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="Yes"))
                              {
                              //3..5
                              
                              
                              
                              
                               // document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none';
                              
                              }
                              
                              else if((mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="Yes"))
                              {
                              
                              //4..6
//                              document.getElementById("al_sqs_buttons_container.prumy_child_plus").style.display='none';//Added for Solution configuration
//                              document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none';
                              
                              /*******************************/
                              
                              var solutionContent4=["al_sqs_buttons_container.cancer_solution"]
                              
                              for(var i=0;i<=solutionContent4.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContent4[i])>=0)
                              {
                              console.log("Display Id"+solutionContent4[i]);
                              document.getElementById(solutionContent4[i]).style.display='none';
                              
                              }
                              
                              }
                              /*****************************************/
                              
                              
                              
                              // document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none';//Commeted for defect type error .this is original code
                              
                              }
                              
                              else if((mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_Yes" ||  PRUcancerProductCer) && pruwealthplusCertified=="No") || (mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_Yes" ||  PRUcancerProductCer) && pruwealthplusCertified=="No") || (mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_Yes" ||  PRUcancerProductCer) && pruwealthplusCertified=="No") || (mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="No"))//Added for may Release 2019 by Sachin tupe on date 5-4-2019
                              {
                              //Mark : Continue
                              
                            //  document.getElementById("al_sqs_buttons_container.gift_of_love").style.display='none'; //Commeted for defect type error .this is original code
                              //document.getElementById("al_sqs_buttons_container.your_commitment").style.display='none'; //Commeted for defect type error .this is original code
                              
                              
                              
                              
                              var solutionContent5=["al_sqs_buttons_container.prubest_gift","al_sqs_buttons_container.pruprotect_xtra"]
                              
                              for(var i=0;i<=solutionContent5.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContent5[i])>=0)
                              {
                              console.log("Display Id"+solutionContent5[i]);
                              document.getElementById(solutionContent5[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              
                              
                              
                              
                              }else if((mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="No")) //added for may release on date 5-4-2019 by Sachin Tupe.
                              {
                            //  document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none'; //Commeted for defect type error .this is original code
                              
                              
                              
                              var solutionContent6=["al_sqs_buttons_container.cancer_solution"]
                              
                              for(var i=0;i<=solutionContent6.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContent6[i])>=0)
                              {
                              console.log("Display Id"+solutionContent6[i]);
                              document.getElementById(solutionContent6[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              
                              }
                              else if((mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="No")) //added for may release on date 5-4-2019 by Sachin Tupe.
                              {
                            //  document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none';
                              //2 4...
                             // document.getElementById("al_sqs_buttons_container.prumy_child_plus").style.display='none';
                            //  document.getElementById("al_sqs_buttons_container.education_solution").style.display='none';
                              //document.getElementById("al_sqs_buttons_container.savings_solution").style.display='none';
                             // document.getElementById("al_sqs_buttons_container.gift_of_love").style.display='none'; //
                             // document.getElementById("al_sqs_buttons_container.your_commitment").style.display='none';//
                              
                              
                              var solutionContent7=["al_sqs_buttons_container.cancer_solution","al_sqs_buttons_container.prumy_child_plus","al_sqs_buttons_container.education_solution","al_sqs_buttons_container.savings_solution","al_sqs_buttons_container.savings_solution","al_sqs_buttons_container.prubest_gift","al_sqs_buttons_container.pruprotect_xtra","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.prubiz_protect"]
                              
                              for(var i=0;i<=solutionContent7.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContent7[i])>=0)
                              {
                              console.log("Display Id"+solutionContent7[i]);
                              document.getElementById(solutionContent7[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              
                              
                              
                              }
                              
                              if(productCertifiedString[0]=="No"){
                              
                              
                               var solutionContentProduct=["al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.prumy_critical_care","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.prumy_child_plus","al_sqs_buttons_container.prubiz_protect"]
                              
                              for(var i=0;i<=solutionContentProduct.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentProduct[i])>=0)
                              {
                              console.log("Display Id"+solutionContentProduct[i]);
                              document.getElementById(solutionContentProduct[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              }
                              
                              
                              
                             }
                              
                             // if(mainLifeDataObject["al_person_details.mlife.anb"] > 15)
                             if(((mainLifeDataObject["al_person_details.mlife.anb"] >= 16 && mainLifeDataObject["al_person_details.mlife.anb"] <= 18) || (mainLifeDataObject["al_person_details.mlife.anb_il_monthly_product"] >= 16 && mainLifeDataObject["al_person_details.mlife.anb_il_monthly_product"] <= 18) || (mainLifeDataObject["al_person_details.mlife.anb_il_product"] >= 16 && mainLifeDataObject["al_person_details.mlife.anb_il_product"] <= 18)) && !prenatalFlag)
                             
                              {
                              
                              
                              for(var i=0;i<=solutionExpire.length-1;i++)
                              {
                              
                              if(solutionEligible2.indexOf(solutionExpire[i])>=0)
                              {
                               console.log("Display Id"+solutionExpire[i]);
                              
                              document.getElementById(solutionExpire[i]).style.display='block';
                              
                              }
                              
                              }
                                  
                                  
                                  
                              
                              //comment for configuration.
//                                document.getElementById("al_sqs_buttons_container.tailor_your_solution").style.display='block';
//                                document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none';
//                                document.getElementById("al_sqs_buttons_container.prumy_medical_plus").style.display='block';
                              
                              
                              if((mainLifeDataObject["pvm_qualification_check"]=="No" && mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="Yes") || (productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_No" || PRUcancerProductCer)  && mainLifeDataObject["pvm_qualification_check"]=="Yes" && mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && pruwealthplusCertified=="Yes") )
                              {
                              
                              
                              
                             // document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none';////Commeted for defect type error .this is original code
                             // document.getElementById("al_sqs_buttons_container.prumy_medical_plus").style.display='none';////Commeted for defect type error .this is original code
                              
                              
                              var solutionContent8=["al_sqs_buttons_container.cancer_solution","al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.prumy_critical_care","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.prubiz_protect"]
                              
                              for(var i=0;i<=solutionContent7.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContent8[i])>=0)
                              {
                              console.log("Display Id"+solutionContent8[i]);
                              document.getElementById(solutionContent8[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              
                              }
                              else if(((mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="No" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes") ||(mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="No" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes")) || (mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="No" &&productCertifiedString[0]=="Yes" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes") || (mainLifeDataObject["pvm_qualification_check"]=="No" && productCertifiedString[0]=="No" && mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes"))
                              {
                              
                            //  document.getElementById("al_sqs_buttons_container.prumy_medical_plus").style.display='none';//Commeted for defect type error .this is original code
                              
                              
                              var solutionContent9=["al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.prumy_critical_care",,"al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.prubiz_protect"]
                              
                              for(var i=0;i<=solutionContent9.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContent9[i])>=0)
                              {
                              console.log("Display Id"+solutionContent9[i]);
                              document.getElementById(solutionContent9[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              }
                              else if((mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="Yes" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes") || ((mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="Yes" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes") || (mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="Yes" && productCertifiedString[1]=="PRUcancer X_Yes")))
                              {
                              
                              //document.getElementById("al_sqs_buttons_container.prumy_child_plus").style.display='block';
                              console.log("Display All Solution")
                              
                              
                              }
                              else if((mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="Yes") || (mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && (productCertifiedString[1]=="PRUcancer X_No"|| PRUcancerProductCer) &&  mainLifeDataObject["pvm_qualification_check"]=="Yes" && productCertifiedString[0]=="Yes" && pruwealthplusCertified=="Yes") || (mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="Yes"))
                              {
                              //3,,
                            //  document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none'; //Commeted for defect type error .this is original code
                              
                              
                              
                              var solutionContentA=["al_sqs_buttons_container.cancer_solution"]
                              
                              for(var i=0;i<=solutionContentA.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentA[i])>=0)
                              {
                              console.log("Display Id"+solutionContentA[i]);
                              document.getElementById(solutionContentA[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              }
                              else if((mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="Yes") || (mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="Yes"))
                              {
                              
                              //4..
                            //  document.getElementById("al_sqs_buttons_container.prumy_medical_plus").style.display='none'; //Commeted for defect type error .this is original code
                             // document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none'; //Commeted for defect type error .this is original code
                              
                              
                              
                              var solutionContentB=["al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.cancer_solution","al_sqs_buttons_container.prumy_critical_care","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.prubiz_protect"]
                              
                              for(var i=0;i<=solutionContentB.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentB[i])>=0)
                              {
                              console.log("Display Id"+solutionContentB[i]);
                              document.getElementById(solutionContentB[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              }else if((mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="Yes"))
                              {
                              
                              // document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none'; //Commeted for defect type error .this is original code
                              
                              
                              var solutionContentC=["al_sqs_buttons_container.cancer_solution"]
                              
                              for(var i=0;i<=solutionContentC.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentC[i])>=0)
                              {
                              console.log("Display Id"+solutionContentC[i]);
                              document.getElementById(solutionContentC[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              }
                              
                              else if((mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="No") || (mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="No"))//Added for May Release solution CR on Date 5-4-2019.
                              {
                              //Mark : Continue
                              
                              //document.getElementById("al_sqs_buttons_container.gift_of_love").style.display='none';//Commeted for defect type error .this is original code
                              
                              //document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none';//Commeted for defect type error .this is original code
                              
                              
                              var solutionContentD=["al_sqs_buttons_container.prubest_gift","al_sqs_buttons_container.cancer_solution"]
                              
                              for(var i=0;i<=solutionContentD.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentD[i])>=0)
                              {
                              console.log("Display Id"+solutionContentD[i]);
                              document.getElementById(solutionContentD[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              
                              }else if((mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_Yes" ||  PRUcancerProductCer) && pruwealthplusCertified=="No") || (mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_Yes" ||  PRUcancerProductCer) && pruwealthplusCertified=="No") || (mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_Yes" ||  PRUcancerProductCer) && pruwealthplusCertified=="No")) //Added for new may Release solution on date 5-4-2019.
                              {
                             // document.getElementById("al_sqs_buttons_container.gift_of_love").style.display='none';//Commeted for defect type error .this is original code
                              
                              
                              
                              var solutionContentE=["al_sqs_buttons_container.prubest_gift"]
                              
                              for(var i=0;i<=solutionContentE.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentE[i])>=0)
                              {
                              console.log("Display Id"+solutionContentE[i]);
                              document.getElementById(solutionContentE[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              }
                              
                            
                              else if((mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_Yes" ||  PRUcancerProductCer) && pruwealthplusCertified=="No") || (mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_Yes" ||  PRUcancerProductCer) && pruwealthplusCertified=="No") || (mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_Yes" ||  PRUcancerProductCer) && pruwealthplusCertified=="No"))//Added for may Release solution configuration
                              {
                              
                             // document.getElementById("al_sqs_buttons_container.savings_solution").style.display='none'; //Commeted for defect type error .this is original code
                              //document.getElementById("al_sqs_buttons_container.gift_of_love").style.display='none'; // //Commeted for defect type error .this is original code
                              //document.getElementById("al_sqs_buttons_container.prumy_medical_plus").style.display='none'; //Commeted for defect type error .this is original code
                              
                              
                              
                              var solutionContentF=["al_sqs_buttons_container.savings_solution","al_sqs_buttons_container.prubest_gift","al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.prumy_critical_care","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.prubiz_protect"]
                              
                              for(var i=0;i<=solutionContentF.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentF[i])>=0)
                              {
                              console.log("Display Id"+solutionContentF[i]);
                              document.getElementById(solutionContentF[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              
                              }else if((mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="No"))//Added for may Release on date 5-4-2019
                              {
                              
                               //document.getElementById("al_sqs_buttons_container.savings_solution").style.display='none'; //Commeted for defect type error .this is original code
                               //document.getElementById("al_sqs_buttons_container.gift_of_love").style.display='none'; // //Commeted for defect type error .this is original code
                               //document.getElementById("al_sqs_buttons_container.prumy_medical_plus").style.display='none'; //Commeted for defect type error .this is original code
                               //document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none'; //Commeted for defect type error .this is original code
                              
                              
                              var solutionContentG=["al_sqs_buttons_container.savings_solution","al_sqs_buttons_container.prubest_gift","al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.cancer_solution","al_sqs_buttons_container.prumy_critical_care","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.prubiz_protect"]
                              
                              for(var i=0;i<=solutionContentG.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentG[i])>=0)
                              {
                              console.log("Display Id"+solutionContentG[i]);
                              document.getElementById(solutionContentG[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              }
                              
                              
                              
                              }
                              
                              if(((mainLifeDataObject["al_person_details.mlife.anb"] >= 19 && mainLifeDataObject["al_person_details.mlife.anb"] <= 39) || (mainLifeDataObject["al_person_details.mlife.anb_il_monthly_product"] >= 19 && mainLifeDataObject["al_person_details.mlife.anb_il_monthly_product"] <= 39) || (mainLifeDataObject["al_person_details.mlife.anb_il_product"] >= 19 && mainLifeDataObject["al_person_details.mlife.anb_il_product"] <= 39)) && !prenatalFlag)
                            
                              {
                              
                              for(var i=0;i<=solutionExpire.length-1;i++)
                              {
                              
                              if(solutionEligible3.indexOf(solutionExpire[i])>=0)
                              {
                              
                              console.log("Display Id"+solutionExpire[i]);
                              document.getElementById(solutionExpire[i]).style.display='block';
                              
                              }
                              
                              }
                              
                              
                       
                              //comment for solution configration
                              
//                              document.getElementById("al_sqs_buttons_container.tailor_your_solution").style.display='block';
//                              document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none';
//                              document.getElementById("al_sqs_buttons_container.prumy_medical_plus").style.display='block';
//                              
//                              document.getElementById("al_sqs_buttons_container.legacy_solution").style.display='none';
                              
                              
                              
                              
                              
                              if((mainLifeDataObject["pvm_qualification_check"]=="No" && mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_No" || PRUcancerProductCer) && pruwealthplusCertified=="Yes") ||(productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer)  && mainLifeDataObject["pvm_qualification_check"]=="Yes" && mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && pruwealthplusCertified=="Yes") || (productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer)  && mainLifeDataObject["pvm_qualification_check"]=="Yes" && mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && pruwealthplusCertified=="Yes") || (productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && mainLifeDataObject["pvm_qualification_check"]=="No" && mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && pruwealthplusCertified=="Yes"))
                              {//1.
                              
                           //   document.getElementById("al_sqs_buttons_container.prumy_medical_plus").style.display='none'; //Commeted for defect type error .this is original code
                             // document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none'; //Commeted for defect type error .this is original code
                              
                              
                              var solutionContentH=["al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.cancer_solution","al_sqs_buttons_container.prumy_critical_care","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.prubiz_protect"]
                              
                              for(var i=0;i<=solutionContentH.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentH[i])>=0)
                              {
                              console.log("Display Id"+solutionContentH[i]);
                              document.getElementById(solutionContentH[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              
                              }
                              else if((mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="No" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes") || (mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="No" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes") || (mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="No" && mainLifeDataObject["pvm_qualification_check"]=="Yes" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes") || (mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="No" && mainLifeDataObject["pvm_qualification_check"]=="No" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes"))
                              {
                              
                             // document.getElementById("al_sqs_buttons_container.prumy_medical_plus").style.display='none'; ////Commeted for defect type error .this is original code
                              
                              
                              var solutionContentI=["al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.prumy_critical_care","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.prubiz_protect"]
                              
                              for(var i=0;i<=solutionContentI.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentI[i])>=0)
                              {
                              console.log("Display Id"+solutionContentI[i]);
                              document.getElementById(solutionContentI[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              
                              }
                              else if((mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="Yes" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes") || (mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="Yes" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes") || (mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="Yes" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes"))
                              {
                              //3..
                              //document.getElementById("al_sqs_buttons_container.prumy_child_plus").style.display='block';
                              console.log("Display All Solution")
                              
                              
                              }
                              
                              else if((mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="Yes") || (mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && mainLifeDataObject["pvm_qualification_check"]=="Yes" && productCertifiedString[0]=="Yes" && pruwealthplusCertified=="Yes") || (productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && mainLifeDataObject["pvm_qualification_check"]=="No" && mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && pruwealthplusCertified=="Yes"))
                              {
                              //3..5
                             // document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none'; ////Commeted for defect type error .this is original code
                              
                              var solutionContentJ=["al_sqs_buttons_container.cancer_solution"]
                              
                              for(var i=0;i<=solutionContentJ.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentJ[i])>=0)
                              {
                              console.log("Display Id"+solutionContentJ[i]);
                              document.getElementById(solutionContentJ[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              
                              }
                              else if((mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_No"||  PRUcancerProductCer) && pruwealthplusCertified=="Yes") )
                              {
                              
                              //4..6
//                              document.getElementById("al_sqs_buttons_container.prumy_medical_plus").style.display='none';//Commented for solution CR.
//                              document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none';
                              
                              //document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none';//Commeted for defect type error .this is original code
                              
                              
                              
                              var solutionContentK=["al_sqs_buttons_container.cancer_solution"]
                              
                              for(var i=0;i<=solutionContentK.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentK[i])>=0)
                              {
                              console.log("Display Id"+solutionContentK[i]);
                              document.getElementById(solutionContentK[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              }
                              
                              
                              else if((mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_Yes" ||  PRUcancerProductCer) && pruwealthplusCertified=="No") || (mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_Yes" ||  PRUcancerProductCer) && pruwealthplusCertified=="No") || (mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_Yes" ||  PRUcancerProductCer) && pruwealthplusCertified=="No"))
                              {
                              //Mark : Continue for may Release
                              
                               // document.getElementById("al_sqs_buttons_container.gift_of_love").style.display='none';
                                //document.getElementById("al_sqs_buttons_container.your_commitment").style.display='none';
                              
                              
                              var solutionContentK=["al_sqs_buttons_container.prubest_gift","al_sqs_buttons_container.pruprotect_xtra"]
                              
                              for(var i=0;i<=solutionContentK.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentK[i])>=0)
                              {
                              console.log("Display Id"+solutionContentK[i]);
                              document.getElementById(solutionContentK[i]).style.display='none';
                              
                              }
                              
                              }
                       
                              
                              
                              
                              }else if((mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="No") || (mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="No"))//Added for may Release for solution button on date 5-4-2019.
                              {
                              
                             // document.getElementById("al_sqs_buttons_container.gift_of_love").style.display='none';
                              //document.getElementById("al_sqs_buttons_container.your_commitment").style.display='none';
                              //document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none';
                              
                              var solutionContentK=["al_sqs_buttons_container.prubest_gift","al_sqs_buttons_container.pruprotect_xtra","al_sqs_buttons_container.cancer_solution"]
                              
                              for(var i=0;i<=solutionContentK.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentK[i])>=0)
                              {
                              console.log("Display Id"+solutionContentK[i]);
                              document.getElementById(solutionContentK[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              
                                  }else if((mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_Yes" ||  PRUcancerProductCer) && pruwealthplusCertified=="No") || (mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_Yes" ||  PRUcancerProductCer) && pruwealthplusCertified=="No") || (mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_Yes" ||  PRUcancerProductCer) && pruwealthplusCertified=="No") || (mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="No"))//Added for may Release for solution button on Date 5-4-2019.
                              {
                              
                              
                              
                             //  document.getElementById("al_sqs_buttons_container.gift_of_love").style.display='none';
                              // document.getElementById("al_sqs_buttons_container.your_commitment").style.display='none';
                              // document.getElementById("al_sqs_buttons_container.savings_solution").style.display='none';
                              // document.getElementById("al_sqs_buttons_container.prumy_medical_plus").style.display='none';
                              
                              
                              var solutionContentK=["al_sqs_buttons_container.prubest_gift","al_sqs_buttons_container.pruprotect_xtra","al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.savings_solution","al_sqs_buttons_container.prumy_critical_care","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.prubiz_protect"]
                              
                              for(var i=0;i<=solutionContentK.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentK[i])>=0)
                              {
                              console.log("Display Id"+solutionContentK[i]);
                              document.getElementById(solutionContentK[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              
                              }
                              
                            
                              
                              }
                              
                               //Added for new solution buttion for sept. release by sachin
                              if(mainLifeDataObject["al_person_details.mlife.anb"] >= 19 && mainLifeDataObject["al_person_details.mlife.anb"] <= 30){
                                                      for(var i=0;i<=solutionExpire.length-1;i++)
                                                                                   {
                                                                                   
                                                                                   console.log("index::",solutionEligible5.indexOf(solutionExpire[i]));
                                                                                  if(solutionEligible5.indexOf(solutionExpire[i])>=0)
                                                                                   {
                                                                                    console.log("Display Id"+solutionExpire[i]);
                                                                                   
                                                                                   document.getElementById(solutionExpire[i]).style.display='block';
                                                                                   
                                                                                   }
                                                     
                                                                                   
                                                                                   
                                                                                   }
                                                        
                              }
                              //Added for new solution buttion for sept. release by sachin
                              if((mainLifeDataObject["al_person_details.mlife.anb"] >= 19 && mainLifeDataObject["al_person_details.mlife.anb"] <= 30) && (secondLifeDataObject["al_person_details.slife.relationship"]=="Parent" || thirdLifeDataObject["al_person_details.tlife.relationship"]=="Parent")){
                                                      for(var i=0;i<=solutionExpire.length-1;i++)
                                                                                   {
                                                                                   
                                                                                   console.log("index::",solutionEligible5.indexOf(solutionExpire[i]));
                                                                                  if(solutionEligible5.indexOf(solutionExpire[i])>=0)
                                                                                   {
                                                                                    console.log("Display Id"+solutionExpire[i]);
                                                                                   
                                                                                   document.getElementById(solutionExpire[i]).style.display='none';
                                                                                   
                                                                                   }
                                                     
                                                                                   
                                                                                   
                                                                                   }
                                                        
                              }
                              //Added for new solution buttion for sept. release by sachin
                              if(productCertifiedString[0]=="No"){
                              for(var i=0;i<=solutionExpire.length-1;i++)
                                    {
                                                                                                                
                                    console.log("index::",solutionEligible5.indexOf(solutionExpire[i]));
                                    if(solutionEligible5.indexOf(solutionExpire[i])>=0)
                                    {
                                        console.log("Display Id"+solutionExpire[i]);
                                                                                                                
                                     document.getElementById(solutionExpire[i]).style.display='none';
                                                                                                                
                                    }
                                                                                  
                                                                                                                
                                                                                                                
                                }
                              
                              }
                              
                              
                              
                              
                              
                             if(((mainLifeDataObject["al_person_details.mlife.anb"] >= 40 && mainLifeDataObject["al_person_details.mlife.anb"] <= 70) || (mainLifeDataObject["al_person_details.mlife.anb_il_monthly_product"] >= 40 && mainLifeDataObject["al_person_details.mlife.anb_il_monthly_product"] <= 70) || (mainLifeDataObject["al_person_details.mlife.anb_il_product"] >= 40 && mainLifeDataObject["al_person_details.mlife.anb_il_product"] <= 70)) && !prenatalFlag)
                           
                              {
                              
                              
                              for(var i=0;i<=solutionExpire.length-1;i++)
                              {
                              
                              console.log("index::",solutionEligible4.indexOf(solutionExpire[i]));
                             if(solutionEligible4.indexOf(solutionExpire[i])>=0)
                              {
                               console.log("Display Id"+solutionExpire[i]);
                              
                              document.getElementById(solutionExpire[i]).style.display='block';
                              
                              }
                              
//                              for(var j=0; j<=solutionEligible4.length-1;j++)
//                              {
//                              
//                              console.log("solutionExpire-->"+solutionExpire[i]+"-->> "+"solutionEligible4"+solutionEligible4[j]);
//                                if(solutionEligible4[j]==solutionExpire[i])
//                              {
//                               document.getElementById(solutionEligible4[j]).style.display='block';
//                              
//                              }
//                              
//                              }
                              
                              
                              }

                              
                              
                              
                              //comment for solution configuration.
                             
//                              document.getElementById("al_sqs_buttons_container.tailor_your_solution").style.display='block';
//                              document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none';
//                              document.getElementById("al_sqs_buttons_container.prumy_medical_plus").style.display='block';
//                              
//                              document.getElementById("al_sqs_buttons_container.legacy_solution").style.display='none';
//                              document.getElementById("al_sqs_buttons_container.prumy_diabetes_care").style.display='block';
                              
                              
                              if((mainLifeDataObject["pvm_qualification_check"]=="No" && mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="Yes") ||(productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_No"||  PRUcancerProductCer)  && mainLifeDataObject["pvm_qualification_check"]=="Yes" && mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && pruwealthplusCertified=="Yes") ||(mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="Yes") || (mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="Yes") || (mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="Yes" && mainLifeDataObject["pvm_qualification_check"]=="No" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="Yes"))
                              {//1.
                              
                            //  document.getElementById("al_sqs_buttons_container.prumy_diabetes_care").style.display='none';
                              //document.getElementById("al_sqs_buttons_container.prumy_medical_plus").style.display='none';
                              //document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none';
                              
                              
                              var solutionContentK=["al_sqs_buttons_container.prumy_diabetes_care","al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.cancer_solution","al_sqs_buttons_container.prumy_critical_care","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.prubiz_protect"]
                              
                              for(var i=0;i<=solutionContentK.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentK[i])>=0)
                              {
                              console.log("Display Id"+solutionContentK[i]);
                              document.getElementById(solutionContentK[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              
                              }
                              else if((mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="No" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes") || (mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="No" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes") || (mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="No" && mainLifeDataObject["pvm_qualification_check"]=="Yes" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes") || (mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="No" && mainLifeDataObject["pvm_qualification_check"]=="No" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes") || (mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="No" && mainLifeDataObject["pvm_qualification_check"]=="Yes" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer)&& pruwealthplusCertified=="Yes"))
                              {
                              //2.
                            //  document.getElementById("al_sqs_buttons_container.prumy_diabetes_care").style.display='none';
                             // document.getElementById("al_sqs_buttons_container.prumy_medical_plus").style.display='none';
                              
                              
                              var solutionContentK=["al_sqs_buttons_container.prumy_diabetes_care","al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.prumy_critical_care","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.prubiz_protect"]
                              
                              for(var i=0;i<=solutionContentK.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentK[i])>=0)
                              {
                              console.log("Display Id"+solutionContentK[i]);
                              document.getElementById(solutionContentK[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              
                              }
                              
                              else if((mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="Yes" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes") || (mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="Yes" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes") || (mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="Yes" && productCertifiedString[1]=="PRUcancer X_Yes" && pruwealthplusCertified=="Yes"))
                              {
                              //3..
                              //document.getElementById("al_sqs_buttons_container.prumy_child_plus").style.display='block';
                              console.log("Display All Solution")
                              
                              
                              }
                              
                              else if((mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="Yes") || (mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && mainLifeDataObject["pvm_qualification_check"]=="Yes" && productCertifiedString[0]=="Yes" && pruwealthplusCertified=="Yes") || (mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer)&& pruwealthplusCertified=="Yes"))
                              {
                              //3..5
                              //document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none';
                              
                              
                              var solutionContentK=["al_sqs_buttons_container.cancer_solution"]
                              
                              for(var i=0;i<=solutionContentK.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentK[i])>=0)
                              {
                              console.log("Display Id"+solutionContentK[i]);
                              document.getElementById(solutionContentK[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              }
                              
                              
                              
                              else if((mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_Yes" ||  PRUcancerProductCer) && pruwealthplusCertified=="No") || (mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_Yes" ||  PRUcancerProductCer) && pruwealthplusCertified=="No") || (mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_Yes" ||  PRUcancerProductCer) && pruwealthplusCertified=="No"))
                              {
                              
                                console.log("Display All Solution")
                              
                              }
                              else if((mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="No") || (mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="Yes" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="No"))//Added for Solution may Release CR on Date 5-4-2019.
                              {
                              
                                   // document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none';
                              
                              
                              var solutionContentK=["al_sqs_buttons_container.cancer_solution"]
                              
                              for(var i=0;i<=solutionContentK.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentK[i])>=0)
                              {
                              console.log("Display Id"+solutionContentK[i]);
                              document.getElementById(solutionContentK[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              }else if((mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_Yes" ||  PRUcancerProductCer) && pruwealthplusCertified=="No") || (mainLifeDataObject["pvm_qualification_check"]=="No"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_Yes" ||  PRUcancerProductCer) && pruwealthplusCertified=="No") || (mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_Yes" ||  PRUcancerProductCer) && pruwealthplusCertified=="No"))//Added Solution BR may Release on date 5-4-2019
                              {
                              
                              
                             
                             // document.getElementById("al_sqs_buttons_container.prumy_medical_plus").style.display='none';
                             // document.getElementById("al_sqs_buttons_container.prumy_diabetes_care").style.display='none';
                             // document.getElementById("al_sqs_buttons_container.savings_solution").style.display='none';
                             // document.getElementById("al_sqs_buttons_container.your_commitment").style.display='none';
                             // document.getElementById("al_sqs_buttons_container.your_legacy").style.display='none';
                              
                              
                              var solutionContentK=["al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.prumy_diabetes_care","al_sqs_buttons_container.savings_solution","al_sqs_buttons_container.pruprotect_xtra","al_sqs_buttons_container.your_legacy","al_sqs_buttons_container.prumy_critical_care","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.prubiz_protect"]
                              
                              for(var i=0;i<=solutionContentK.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentK[i])>=0)
                              {
                              console.log("Display Id"+solutionContentK[i]);
                              document.getElementById(solutionContentK[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              }else if((mainLifeDataObject["pvm_qualification_check"]=="Yes"  &&  mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && productCertifiedString[0]=="No" && (productCertifiedString[1]=="PRUcancer X_No" ||  PRUcancerProductCer) && pruwealthplusCertified=="No"))//Added for may Release solution button on date 5-4-2019.
                              {
                              
                             // document.getElementById("al_sqs_buttons_container.prumy_medical_plus").style.display='none';
                             // document.getElementById("al_sqs_buttons_container.prumy_diabetes_care").style.display='none';
                            //  document.getElementById("al_sqs_buttons_container.savings_solution").style.display='none';
                             // document.getElementById("al_sqs_buttons_container.your_commitment").style.display='none';//
                             // document.getElementById("al_sqs_buttons_container.your_legacy").style.display='none';
                            //  document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none';
                              
                              
                              var solutionContentK=["al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.prumy_diabetes_care","al_sqs_buttons_container.savings_solution","al_sqs_buttons_container.pruprotect_xtra","al_sqs_buttons_container.your_legacy","al_sqs_buttons_container.cancer_solution","al_sqs_buttons_container.prumy_critical_care","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.prubiz_protect"]
                              
                              for(var i=0;i<=solutionContentK.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentK[i])>=0)
                              {
                              console.log("Display Id"+solutionContentK[i]);
                              document.getElementById(solutionContentK[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              }
                              
                              
                              
                              
                              
                              
                              
                              }
                              
                            /*  if(((mainLifeDataObject["al_person_details.mlife.anb_il_monthly_product"] >= 51 ||  mainLifeDataObject["al_person_details.mlife.anb_il_product"] >= 51) && (mainLifeDataObject["al_person_details.mlife.anb_il_monthly_product"] <= 60 ||  mainLifeDataObject["al_person_details.mlife.anb_il_product"] <=60)))
                              {
                              
                              
                              var  solutionContentK=["al_sqs_buttons_container.prutriple_100"]
                              
                              for(var i=0;i<=solutionContentK.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentK[i])>=0)
                              {
                              console.log("Display Id"+solutionContentK[i]);
                              document.getElementById(solutionContentK[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              
                              
                              }*/
                              
                              
                              
                              
                              if(mainLifeDataObject["al_person_details.mlife.anb_il_monthly_product"] >= 71 ||  mainLifeDataObject["al_person_details.mlife.anb_il_product"] >= 71)
                              {

                             
                             // document.getElementById("al_sqs_buttons_container.tailor_your_solution").style.display='block';
                              
                              
                           //   document.getElementById("al_sqs_buttons_container.education_solution").style.display='none';
                              
                            //  document.getElementById("al_sqs_buttons_container.prumy_medical_plus").style.display='none';
                              
                              
                            //  document.getElementById("al_sqs_buttons_container.prumy_diabetes_care").style.display='none';
                           //   document.getElementById("al_sqs_buttons_container.savings_solution").style.display='none';
                              
                           //  document.getElementById("al_sqs_buttons_container.gift_of_love").style.display='none';
                           //  document.getElementById("al_sqs_buttons_container.your_commitment").style.display='none';
                              
                              
                              
                              
                              var  solutionContentK=["al_sqs_buttons_container.education_solution","al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.prumy_diabetes_care","al_sqs_buttons_container.savings_solution","al_sqs_buttons_container.prubest_gift","al_sqs_buttons_container.pruprotect_xtra","al_sqs_buttons_container.prumy_critical_care","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.prubiz_protect"]
                              
                              for(var i=0;i<=solutionContentK.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentK[i])>=0)
                              {
                              console.log("Display Id"+solutionContentK[i]);
                              document.getElementById(solutionContentK[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              
                              
                              }
                            
                             if(mainLifeDataObject["al_person_details.mlife.anb_il_monthly_product"] <= 39 ||  mainLifeDataObject["al_person_details.mlife.anb_il_product"] <= 39)
                              {
                              
                             
                               // document.getElementById("al_sqs_buttons_container.prumy_diabetes_care").style.display='none';
                              //document.getElementById("al_sqs_buttons_container.gift_of_love").style.display='none';
                              
                              var  solutionContentH=["al_sqs_buttons_container.prumy_diabetes_care"]
                              
                              for(var i=0;i<=solutionContentH.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentH[i])>=0)
                              {
                              console.log("Display Id"+solutionContentH[i]);
                              document.getElementById(solutionContentH[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              }
                              
                              if(mainLifeDataObject["al_person_details.mlife.anb_il_monthly_product"] >= 16 ||  mainLifeDataObject["al_person_details.mlife.anb_il_product"] >= 16)
                              {
                               // document.getElementById("al_sqs_buttons_container.prumy_child_plus").style.display='none';
                              //  document.getElementById("al_sqs_buttons_container.education_solution").style.display='none';
                              // document.getElementById("al_sqs_buttons_container.gift_of_love").style.display='none';
                              // document.getElementById("al_sqs_buttons_container.your_legacy").style.display='none';
                             //  document.getElementById("al_sqs_buttons_container.your_commitment").style.display='none';
                              
                              
                              var  solutionContentK=["al_sqs_buttons_container.prumy_child_plus","al_sqs_buttons_container.education_solution","al_sqs_buttons_container.your_legacy"]
                              
                              for(var i=0;i<=solutionContentK.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentK[i])>=0)
                              {
                              console.log("Display Id"+solutionContentK[i]);
                              document.getElementById(solutionContentK[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              }
                              
                              if((mainLifeDataObject["al_person_details.pre_natal_child_flg"]=="Yes" && (( secondLifeDataObject !="" && (secondLifeDataObject["al_person_details.slife.anb_il_product"] >= 46 || secondLifeDataObject["al_person_details.slife.anb_il_monthly_product"] >= 46))) && (secondLifeDataObject["al_person_details.slife.gender"]=="Female" &&secondLifeDataObject!="")) || (mainLifeDataObject["al_person_details.pre_natal_child_flg"]=="Yes" && ((thirdLifeDataObject!="" && (thirdLifeDataObject["al_person_details.tlife.anb_il_product"] >= 46 || thirdLifeDataObject["al_person_details.tlife.anb_il_monthly_product"] >= 46))) && thirdLifeDataObject["al_person_details.tlife.gender"]=="Female") )
                              {
                              
                               // document.getElementById("al_sqs_buttons_container.prumy_medical_plus").style.display='none';
                               // document.getElementById("al_sqs_buttons_container.education_solution").style.display='none';
                              
                              var  solutionContentK=["al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.education_solution","al_sqs_buttons_container.prubest_gift","al_sqs_buttons_container.prumy_critical_care"]
                              
                              for(var i=0;i<=solutionContentK.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentK[i])>=0)
                              {
                              console.log("Display Id"+solutionContentK[i]);
                              document.getElementById(solutionContentK[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              }
                              
                              
                              
                              
                              
                              
                              
                              if( mainLifeDataObject["al_person_details.mlife.anb_il_monthly_product"] >= 18 ||  mainLifeDataObject["al_person_details.mlife.anb_il_product"] >= 18)
                              {
                              
                              
                              
                               // document.getElementById("al_sqs_buttons_container.legacy_solution").style.display='none';
                              
                              var  solutionContentK=["al_sqs_buttons_container.legacy_solution"]
                              
                              for(var i=0;i<=solutionContentK.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentK[i])>=0)
                              {
                              console.log("Display Id"+solutionContentK[i]);
                              document.getElementById(solutionContentK[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              }
                              
                              if(mainLifeDataObject["al_person_details.mlife.anb_il_monthly_product"] >= 61 ||  mainLifeDataObject["al_person_details.mlife.anb_il_product"] >= 61)
                              {
                              //  document.getElementById("al_sqs_buttons_container.cancer_solution").style.display='none';//
                              // document.getElementById("al_sqs_buttons_container.gift_of_love").style.display='none';
                              //  document.getElementById("al_sqs_buttons_container.savings_solution").style.display='none';
                              
                              
                              
                              var  solutionContentK=["al_sqs_buttons_container.cancer_solution","al_sqs_buttons_container.prubest_gift"]//,"al_sqs_buttons_container.savings_solution"]
                              
                              for(var i=0;i<=solutionContentK.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentK[i])>=0)
                              {
                              console.log("Display Id"+solutionContentK[i]);
                              document.getElementById(solutionContentK[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              }
                              
                            
//                              if((mainLifeDataObject["al_person_details.mlife.anb"] == 18 || mainLifeDataObject["al_person_details.mlife.anb_il_monthly_product"] == 18 ||  mainLifeDataObject["al_person_details.mlife.anb_il_product"] == 18)  && ((secondLifeDataObject=="" || (secondLifeDataObject!="" && secondLifeDataObject["al_person_details.slife.relationship"]!="Parent" ))|| (thirdLifeDataObject=="" || (thirdLifeDataObject!="" && thirdLifeDataObject["al_person_details.tlife.relationship"]!="Parent")))) //Added for defect 7073
//                              {
//                              
//                           
//                              
//                              document.getElementById("al_sqs_buttons_container.prumy_medical_plus").style.display='none';
//                              }
                              
                              
                              
                              // remove condition of pruterm premier for DEF - 10730
                              if(((mainLifeDataObject["al_person_details.mlife.anb"] >= 16 && mainLifeDataObject["al_person_details.mlife.anb"] <= 18) || (mainLifeDataObject["al_person_details.mlife.anb_il_monthly_product"] >= 16 && mainLifeDataObject["al_person_details.mlife.anb_il_monthly_product"] <= 18) || (mainLifeDataObject["al_person_details.mlife.anb_il_product"] >= 16 && mainLifeDataObject["al_person_details.mlife.anb_il_product"] <= 18)) && !prenatalFlag)
                              
                              {
                              var  solutionContentMD=["al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.prubest_gift","al_sqs_buttons_container.prumy_critical_care","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.prubiz_protect","al_sqs_buttons_container.pruelite_invest","al_sqs_buttons_container.pruwealth_enrich"] //Added invest for defect 857 by Sachin T.
                              if(secondLifeDataObject=="")
                              {
                              
                              
                              for(var i=0;i<=solutionContentMD.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentMD[i])>=0)
                              {
                              console.log("Display Id"+solutionContentMD[i]);
                              document.getElementById(solutionContentMD[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                                   // document.getElementById("al_sqs_buttons_container.prumy_medical_plus").style.display='none';
                                   // document.getElementById("al_sqs_buttons_container.prubest_gift").style.display='none';
                              
                              
                              
                              }else
                              {
                              if(secondLifeDataObject["al_person_details.slife.relationship"]=="Spouse")
                              {
                              for(var i=0;i<=solutionContentMD.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentMD[i])>=0)
                              {
                              console.log("Display Id"+solutionContentMD[i]);
                              document.getElementById(solutionContentMD[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              }
                              
                              
                              }
                              
                              if(thirdLifeDataObject!="")
                              {
                            
                              
                              if(secondLifeDataObject["al_person_details.slife.relationship"]=="Spouse" && thirdLifeDataObject["al_person_details.tlife.relationship"]!="Spouse")
                              {
                              for(var i=0;i<=solutionContentMD.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentMD[i])>=0)
                              {
                              console.log("Display Id"+solutionContentMD[i]);
                              document.getElementById(solutionContentMD[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              }else if(thirdLifeDataObject["al_person_details.tlife.relationship"]=="Parent")
                              {
                              for(var i=0;i<=solutionContentMD.length-1;i++)
                              {
                              
                              //Following code commited for defect 1161.by Sachin T.
//                              if(displaySolutions.indexOf(solutionContentMD[i])>=0)
//                              {
//                              console.log("Display Id"+solutionContentMD[i]);
//                              document.getElementById(solutionContentMD[i]).style.display='block';
//
//                              }
                              //Added for defect 1161 by Sachin T.
                              if(solutionExpire.indexOf(solutionContentMD[i])>=0)
                                   {
                                   console.log("Display Id"+solutionContentMD[i]);
                                   document.getElementById(solutionContentMD[i]).style.display='block';
                                   
                                   }
                              
                              }
                              
                              }
                              
                              
                              }
                              
                              
                              }
                              
                              
                             if((mainLifeDataObject["al_person_details.mlife.anb"] <=18 || mainLifeDataObject["al_person_details.mlife.anb_il_monthly_product"]<=18) && (thirdLifeDataObject["al_person_details.tlife.relationship"]=="Parent"))//To 27-05-2020
                              {
                              
                              var  solutionContentHide=["al_sqs_buttons_container.prubest_gift","al_sqs_buttons_container.pruterm_premier","al_sqs_buttons_container.pruelite_invest"]//Added invest for defect 857 by Sachin T.
                              
                              for(var i=0;i<=solutionContentHide.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentHide[i])>=0)
                              {
                              console.log("Hide PRUBEST"+solutionContentHide[i]);
                              document.getElementById(solutionContentHide[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              }
                            
                              
                              
                              
                              if(checkDateDiff<=29) {
                              
                              var  solutionContentM=["al_sqs_buttons_container.prubest_gift"]
                              
                              for(var i=0;i<=solutionContentM.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentM[i])>=0)
                              {
                              console.log("Hide PRUBEST"+solutionContentM[i]);
                              document.getElementById(solutionContentM[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              
                              }
   /*******************************Added for defect 7406 ********************************************************************************************************************************/
                              
    if(mainLifeDataObject["al_person_details.mlife.anb"] >= 17 && mainLifeDataObject["al_person_details.mlife.anb"] <= 30){
           if((secondLifeDataObject["al_person_details.slife.anb"] < 20 || secondLifeDataObject["al_person_details.slife.anb"] > 40) && secondLifeDataObject["al_person_details.slife.relationship"]=="Spouse")
            {
                // hide prucash /pcdr
                              
                if(displaySolutions.indexOf("al_sqs_buttons_container.savings_solution")>=0)
                    {
                              
                              document.getElementById("pcdrDiv").style.display='none';
                              document.getElementById("pcDiv").style.display='none';
                              
                    }
                              
                              
                              
           
            }
                              
                              
    }else if(mainLifeDataObject["al_person_details.mlife.anb"] >= 31 && mainLifeDataObject["al_person_details.mlife.anb"] <= 70)
        {
                
                            
                              if ((secondLifeDataObject["al_person_details.slife.anb"] >= 31 || secondLifeDataObject["al_person_details.slife.anb"] <= 50))
                              {
                              if((secondLifeDataObject["al_person_details.slife.anb"] - mainLifeDataObject["al_person_details.mlife.anb"]) > 10)
                              {
                              if(displaySolutions.indexOf("al_sqs_buttons_container.savings_solution")>=0)
                              {
                              
                              document.getElementById("pcdrDiv").style.display='none';
                              document.getElementById("pcDiv").style.display='none';
                              
                              }
                              }
                              }
                              
                              
    }
    else if(mainLifeDataObject["al_person_details.mlife.anb"] <= 16 && secondLifeDataObject["al_person_details.slife.relationship"]=="Spouse")
    {
                              
                              if(displaySolutions.indexOf("al_sqs_buttons_container.savings_solution")>=0)
                              {
                              
                              document.getElementById("pcdrDiv").style.display='none';
                              document.getElementById("pcDiv").style.display='none';
                              
                              }
                              
                              
                              
    }
            
                              
                              
                              
                              
                              
/***********************************************************************as**********************************************************************************/
                              
                           if(mainLifeDataObject["al_person_details.mlife.anb"] <= 16 && mainLifeDataObject["al_person_details.mlife.parent_consent"] == "Yes")
                              {
                              
                            
                              var  solutionContentK=["al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.prubest_gift","al_sqs_buttons_container.prumy_critical_care","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prutriple_care","al_sqs_buttons_container.prutriple_med","al_sqs_buttons_container.prulite_med","al_sqs_buttons_container.prubiz_protect","al_sqs_buttons_container.pruterm_premier","al_sqs_buttons_container.pruwealth_enrich"]
                              
                              for(var i=0;i<=solutionContentK.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentK[i])>=0)
                              {
                              console.log("Display Id"+solutionContentK[i]);
                              document.getElementById(solutionContentK[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              }else if((mainLifeDataObject["al_person_details.mlife.anb"] <= 15 && (thirdLifeDataObject["al_person_details.tlife.relationship"]=="Parent" ||secondLifeDataObject["al_person_details.slife.relationship"]=="Parent")) && (prenatalFlag))
                                       {
                              
                                       var  solutionContentK=["al_sqs_buttons_container.cancer_solution","al_sqs_buttons_container.savings_solution","al_sqs_buttons_container.pruterm_premier","al_sqs_buttons_container.pruelite_invest","al_sqs_buttons_container.pruwealth_enrich"]//Added invest for defect 857 by Sachin T.
                              
                                      
                                       
                                       for(var i=0;i<=solutionContentK.length-1;i++)
                                       {
                                       
                                       if(displaySolutions.indexOf(solutionContentK[i])>=0)
                                       {
                                       console.log("Display Id"+solutionContentK[i]);
                                       document.getElementById(solutionContentK[i]).style.display='none';
                                       
                                       }
                                       
                                       }
                              
                              
                              }
                              
                              else if((mainLifeDataObject["al_person_details.mlife.anb"] >= 16 && (thirdLifeDataObject["al_person_details.tlife.relationship"]=="Parent" )))
                                       {
                              //
                                       var  solutionContentK=["al_sqs_buttons_container.cancer_solution","al_sqs_buttons_container.savings_solution","al_sqs_buttons_container.pruterm_premier","al_sqs_buttons_container.pruelite_invest"]//Added invest for defect 857 by Sachin T.
                              
                                      
                                       
                                       for(var i=0;i<=solutionContentK.length-1;i++)
                                       {
                                       
                                       if(displaySolutions.indexOf(solutionContentK[i])>=0)
                                       {
                                       console.log("Display Id"+solutionContentK[i]);
                                       document.getElementById(solutionContentK[i]).style.display='none';
                                       
                                       }
                                       
                                       }
                              
                              
                              }
                              //added by ankita on 2 feb 2022
                              //changed by ankita on 4 march 2022 for defect 151
                              /*if(mainLifeDataObject["al_person_details.mlife.anb"] >= 19 && secondLifeDataObject["al_person_details.slife.relationship"]==="Parent")
                              {
                                 var arrResult=_.union(solutionEligible1,solutionEligible2,solutionEligible3,solutionEligible4);
                                  console.log("Combine array:"+arrResult);
                                  for(var i=0;i<=arrResult.length-1;i++)
                                  {
                                  
                                  if(displaySolutions.indexOf(arrResult[i])>=0)
                                  {
                                  console.log("Display Id"+solutionContentK[i]);
                                  document.getElementById(arrResult[i]).style.display='none';
                                  
                                  }
                                  
                                  }
                                  document.getElementById("al_sqs_buttons_container.tailor_your_solution").style.display='block';
                              }*/
                              //added by ankita for modern family CR
                              //second or condition added by ankita to extend child case to all products CR i.e to show only tailor your solution button
                              if((mainLifeDataObject["al_person_details.mlife.anb"] >= 17 && secondLifeDataObject["al_person_details.slife.relationship"]!=="Parent") || (mainLifeDataObject["al_person_details.mlife.anb"] >= 19 && secondLifeDataObject["al_person_details.slife.relationship"]==="Parent"))
                              {
                              //var arrCombineRelation=fnSelectAllRelationShipList();
                              var arrCombine=fnSelectAllRelationShipList();
                              
                              if(arrCombine.hasOwnProperty(secondLifeDataObject["al_person_details.slife.relationship"]))
                              {
                                 var arrResult=_.union(solutionEligible1,solutionEligible2,solutionEligible3,solutionEligible4,solutionEligible5);
                                  console.log("Combine array:"+arrResult);
                                  for(var i=0;i<=arrResult.length-1;i++)
                                  {
                                  
                                  if(displaySolutions.indexOf(arrResult[i])>=0)
                                  {
                                  console.log("Display Id"+solutionContentK[i]);
                                  document.getElementById(arrResult[i]).style.display='none';
                                  
                                  }
                                  
                                  }
                                  document.getElementById("al_sqs_buttons_container.tailor_your_solution").style.display='block';
                              }
                              }
                              
                              
                              // Added "Legal Guardian" for PRUTERM PREMIER
                              else if((mainLifeDataObject["al_person_details.mlife.anb"] >= 16 && (thirdLifeDataObject["al_person_details.tlife.relationship"]=="Parent" ||secondLifeDataObject["al_person_details.slife.relationship"]=="Legal Guardian" || secondLifeDataObject["al_person_details.slife.relationship"]=="Parent" || thirdLifeDataObject["al_person_details.tlife.relationship"]=="Legal Guardian")))
                                       {
                              //
                                    //   var  solutionContentK=["al_sqs_buttons_container.pruterm_premier","al_sqs_buttons_container.savings_solution"];//Commeted for defect 469 for saving solution.
                              
                                      var  solutionContentK=["al_sqs_buttons_container.pruterm_premier"];
                                       
                                       for(var i=0;i<=solutionContentK.length-1;i++)
                                       {
                                       
                                       if(displaySolutions.indexOf(solutionContentK[i])>=0)
                                       {
                                       console.log("Display Id"+solutionContentK[i]);
                                       document.getElementById(solutionContentK[i]).style.display='none';
                                       
                                       }
                                       
                                       }
                              
                              
                              }
                              
                             //Added for internal defect fixed by sachin tupe.
                             if((mainLifeDataObject["al_person_details.mlife.anb"] >= 16 && (thirdLifeDataObject["al_person_details.tlife.relationship"]=="Parent" || secondLifeDataObject["al_person_details.slife.relationship"]=="Legal Guardian" || thirdLifeDataObject["al_person_details.tlife.relationship"]=="Legal Guardian")))
                                                                    {
                                                           //
                                                                    var  solutionContentK=["al_sqs_buttons_container.savings_solution","al_sqs_buttons_container.pruelite_invest"];//Commeted for defect 469 for saving solution.
                                                           
                                                                 //  var  solutionContentK=["al_sqs_buttons_container.pruterm_premier"];
                                                                    
                                                                    for(var i=0;i<=solutionContentK.length-1;i++)
                                                                    {
                                                                    
                                                                    if(displaySolutions.indexOf(solutionContentK[i])>=0)
                                                                    {
                                                                    console.log("Display Id"+solutionContentK[i]);
                                                                    document.getElementById(solutionContentK[i]).style.display='none';
                                                                    
                                                                    }
                                                                    
                                                                    }
                                                           
                                                           
                                                           }
                              
                              
                              
                              
                            if(css_indicator && (mainLifeDataObject["pamb_channel"]!="Banca")){
                              
                              var  solutionContentK=["al_sqs_buttons_container.prumy_critical_care","al_sqs_buttons_container.prutriple_100","al_sqs_buttons_container.prubiz_protect"]
                              
                              for(var i=0;i<=solutionContentK.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentK[i])>=0)
                              {
                              console.log("Display Id"+solutionContentK[i]);
                              document.getElementById(solutionContentK[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              }
                              
                              
                       
                              
                              if(mainLifeDataObject["al_person_details.mlife.insu_type"]=="employee" && mainLifeDataObject["al_person_details.mlife.insu_type_header"]=="business_purpose"){
                              
                              
                              for(var i=0;i<=hideBusiness.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(hideBusiness[i])>=0)
                              {
                              console.log("Display Id"+hideBusiness[i]);
                              document.getElementById(hideBusiness[i]).style.display='none';
                              
                              }
                              
                              }
                              

                              
                              
                              }
                              
                              //// Added for PRUTerm Premier keyman
                              if((mainLifeDataObject["pamb_channel"]!="Banca" && mainLifeDataObject["pamb_channel"]!="UOB") && mainLifeDataObject["al_person_details.mlife.insu_type"]=="keyman" && mainLifeDataObject["al_person_details.mlife.insu_type_header"]=="business_purpose"){
                                                          
                                                          
                                                          for(var i=0;i<=hideBusiness_keyman.length-1;i++)
                                                          {
                                                          
                                                          if(displaySolutions.indexOf(hideBusiness_keyman[i])>=0)
                                                          {
                                                          console.log("Display Id"+hideBusiness_keyman[i]);
                                                          document.getElementById(hideBusiness_keyman[i]).style.display='none';
                                                          
                                                          }
                                                          
                                                          }
                                                          

                                                          
                                                          
                                                          }
                              
                              
                              //Condition for prehealth added by sachin T.
//                                 if(/*mainLifeDataObject["pamb_channel"]=="UOB" || */ mainLifeDataObject["pamb_channel"]=="Banca"){
//                                     
//                                    document.getElementById("area_of_pruhealth").style.display = 'block';
//                                 }
                           
                              //Following code commented for defect 401 by sachin T.
                            /*
                              if(mainLifeDataObject["pamb_channel"]=="Agency" || mainLifeDataObject["pamb_channel"]=="FA"){
                                  
                              
                                                 var current_date = fnGetDateTimeStamp();
                                                console.log("@Current Date",current_date);
                                                 var blocking_date="2099-06-11 00:00:00";
                                                  
                                                
                                                  if(current_date >= blocking_date)
                                                  {
                                                         
                                                      
                                                     document.getElementById("area_of_pruhealth").style.display = 'none';
                                                      
                                                       
                                                }else{
                                                      document.getElementById("area_of_pruhealth").style.display = 'block';
                              
                                                    }
                              }*/
                              
                              
                              
                              //Condition for prehealth added by sachin T.
                              if(mainLifeDataObject["pamb_channel"]=="Agency" || mainLifeDataObject["pamb_channel"]=="FA" || mainLifeDataObject["pamb_channel"]=="UOB" || mainLifeDataObject["pamb_channel"]=="SCB"){
                                  
                                 document.getElementById("area_of_pruhealth").style.display = 'none';
                              }
                              
                              
                              //Keyman // employee// saving //
                              
//                              if((mainLifeDataObject["al_person_details.mlife.insu_type"]=="employee" || mainLifeDataObject["al_person_details.mlife.insu_type"]=="keyman") && mainLifeDataObject["al_person_details.mlife.insu_type_header"]=="business_purpose")
//                              {
//
//
//                              var solutionContentPTP = ["al_sqs_buttons_container.savings_solution","al_sqs_buttons_container.pruterm_premier"]
//                              for(var i=0;i<=solutionContentPTP.length-1;i++)
//                              {
//
//                              if(displaySolutions.indexOf(solutionContentPTP[i])>=0)
//                              {
//                              console.log("Display Id"+solutionContentPTP[i]);
//                              document.getElementById(solutionContentPTP[i]).style.display='none';
//
//                              }
//
//                              }
//
//
//                              }
//
                     
                              
                      /*  if(mainLifeDataObject["pvm_qualification_check"]=="Yes" ||                               mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" || productCertifiedString[1]=="PRUcancer X_Yes"  || pruwealthplusCertified=="Yes" || productCertifiedString[0]=="No"){
                              
                              var  solutionContentBiz=["al_sqs_buttons_container.prubiz_protect"]
                              
                              for(var i=0;i<=solutionContentBiz.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentBiz[i])>=0)
                              {
                              console.log("Display Id"+solutionContentBiz[i]);
                              document.getElementById(solutionContentBiz[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              
                              }*/
                              
   
                              
                              if ((available_prod_name.indexOf("PRUTerm Premier") < 0 && available_prod_name.indexOf("PRUTerm Premier") < 0) || (unavailable_prod_cert.indexOf("PRUTerm Premier")>=0 && unavailable_prod_cert.indexOf("PRUTerm Premier")>=0)){
                              
                              var solutionContentMax=["al_sqs_buttons_container.pruterm_premier"]
                              
                              for(var i=0;i<=solutionContentMax.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentMax[i])>=0)
                              {
                              console.log("Display Id"+solutionContentMax[i]);
                              document.getElementById(solutionContentMax[i]).style.display='none';
                              
                              }
                              
                              }
                              

                              
                              
                              
                              }
                              
                         if (((available_prod_name.indexOf("PRUSignature Assure") < 0 && available_prod_name.indexOf("PRUSignature Assure") < 0) || (unavailable_prod_cert.indexOf("PRUSignature Assure")>=0 && unavailable_prod_cert.indexOf("PRUSignature Assure")>=0)) && (mainLifeDataObject["pamb_channel"]=="Banca" || Channel=="Banca")){
                              
                              var solutionContentMax=["al_sqs_buttons_container.prumy_child_plus","al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.prumy_critical_care"]
                              
                              for(var i=0;i<=solutionContentMax.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentMax[i])>=0)
                              {
                              console.log("Display Id"+solutionContentMax[i]);
                              document.getElementById(solutionContentMax[i]).style.display='none';
                              
                              }
                              
                              }
                              

                              
                              
                              
                              }
                              
                              
                              
                              
                              
                              if ((available_prod_name.indexOf("PRUWealth Max") < 0 && available_prod_name.indexOf("PRUWealth Plus") < 0) || (unavailable_prod_cert.indexOf("PRUWealth Plus")>=0 && unavailable_prod_cert.indexOf("PRUWealth Max")>=0)) {
                              
                                console.log("Checked")
                                //document.getElementById("al_sqs_buttons_container.prubest_gift").style.display='none';
                                //document.getElementById("al_sqs_buttons_container.pruprotect_xtra").style.display='none';
                              
                              var solutionContentMax=["al_sqs_buttons_container.prubest_gift","al_sqs_buttons_container.pruprotect_xtra"]
                              
                              for(var i=0;i<=solutionContentMax.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentMax[i])>=0)
                              {
                              console.log("Display Id"+solutionContentMax[i]);
                              document.getElementById(solutionContentMax[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                                  
                              }else if((available_prod_name.indexOf("PRUWealth Plus") < 0 || available_prod_name.indexOf("PRUWealth Max") < 0) || (unavailable_prod_cert.indexOf("PRUWealth Plus")>=0 || unavailable_prod_cert.indexOf("PRUWealth Max")>=0)) {
                              
                              if (available_prod_name.indexOf("PRUWealth Max")<0 || unavailable_prod_cert.indexOf("PRUWealth Max")>=0){
                                  // iswealthAvaible=false
                                document.getElementById("wealthPlusDiv").style.display='none';
                              
                              
                              }
                              if (available_prod_name.indexOf("PRUWealth Plus")<0 || unavailable_prod_cert.indexOf("PRUWealth Plus")>=0){
                             // isMaxAvaible=false
                                $(".wmax").css("display", "none");
                             // document.getElementById("wealthPlusDiv").style.display='none';
                              
                              }
                              
                              }
                              
                              if ((available_prod_name.indexOf("PRUgrowth") < 0 && available_prod_name.indexOf("PRUcash") < 0 && available_prod_name.indexOf("PRUcash double reward") < 0 && available_prod_name.indexOf("PRUCash Enrich") < 0) || (unavailable_prod_cert.indexOf("PRUgrowth")>=0 && unavailable_prod_cert.indexOf("PRUcash")>=0 && unavailable_prod_cert.indexOf("PRUcash double reward")>=0 &&  unavailable_prod_cert.indexOf("PRUCash Enrich")>=0)) {
                              
                                console.log("Checked")
                               // document.getElementById("al_sqs_buttons_container.savings_solution").style.display='none';
                              //document.getElementById("al_sqs_buttons_container.pruprotect_xtra").style.display='none';
                              
                              var solutionContentSaving=["al_sqs_buttons_container.savings_solution"]
                              
                              for(var i=0;i<=solutionContentSaving.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentSaving[i])>=0)
                              {
                              console.log("Display Id"+solutionContentSaving[i]);
                              document.getElementById(solutionContentSaving[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              }else if((available_prod_name.indexOf("PRUgrowth") < 0 || available_prod_name.indexOf("PRUcash") < 0 || available_prod_name.indexOf("PRUcash double reward") < 0 || available_prod_name.indexOf("PRUCash Enrich") < 0) || (unavailable_prod_cert.indexOf("PRUgrowth")>=0 || unavailable_prod_cert.indexOf("PRUcash")>=0 || unavailable_prod_cert.indexOf("PRUcash double reward")>=0 || unavailable_prod_cert.indexOf("PRUCash Enrich")>=0)) {
                              
                              if (available_prod_name.indexOf("PRUgrowth")<0 || unavailable_prod_cert.indexOf("PRUgrowth")>=0){
                              // iswealthAvaible=false
                             
                              
                               $(".dgrowth").css("display", "none");
                              }
                              if (available_prod_name.indexOf("PRUcash")<0  || unavailable_prod_cert.indexOf("PRUcash")>=0){
                              // isMaxAvaible=false
                              $("#pcDiv").css("display", "none");
                              // document.getElementById("wealthPlusDiv").style.display='none';
                              
                              }
                              if (available_prod_name.indexOf("PRUcash double reward")<0 || unavailable_prod_cert.indexOf("PRUcash double reward")>=0){
                              // isMaxAvaible=false
                              $("#pcdrDiv").css("display", "none");
                              // document.getElementById("wealthPlusDiv").style.display='none';
                              
                              }
                              
                              if (available_prod_name.indexOf("PRUCash Enrich")<0 || unavailable_prod_cert.indexOf("PRUCash Enrich")>=0){
                                                           // isMaxAvaible=false
                                                           $(".denrich").css("display", "none");
                                                           // document.getElementById("wealthPlusDiv").style.display='none';
                                                           
                                                           }
                              
                              
                             
                             
                              
                              
                              }
                              
                              
                             if(pruwealthplusCertified=="No" && pruwealthmaxCertified=="No")
                              {
                              
                              var solutionContentW=["al_sqs_buttons_container.prubest_gift","al_sqs_buttons_container.pruprotect_xtra"]
                              
                              for(var i=0;i<=solutionContentW.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentW[i])>=0)
                              {
                              console.log("Display Id"+solutionContentW[i]);
                              document.getElementById(solutionContentW[i]).style.display='none';
                              
                              }
                              
                              }

                              //document.getElementById("al_sqs_buttons_container.prubest_gift").style.display='none';
                              //document.getElementById("al_sqs_buttons_container.pruprotect_xtra").style.display='none';
                              
                              }
                              
                              if(productCertifiedString[1]=="PRUcancer X_No"){
                              var solutionContentSave=["al_sqs_buttons_container.cancer_solution"]
                              
                              for(var i=0;i<=solutionContentSave.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(solutionContentSave[i])>=0)
                              {
                              console.log("Display Id"+solutionContentSave[i]);
                              document.getElementById(solutionContentSave[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              }
                          
                              if(unavailable_prod_cert.indexOf("PRULink Cover")>=0){
                              
                              var link_cover_solution=["al_sqs_buttons_container.prumy_child_plus","al_sqs_buttons_container.education_solution","al_sqs_buttons_container.prumy_medical_plus","al_sqs_buttons_container.prumy_diabetes_care","al_sqs_buttons_container.prumy_critical_care"];
                              for(var i=0;i<=link_cover_solution.length-1;i++)
                              {
                              
                              if(displaySolutions.indexOf(link_cover_solution[i])>=0)
                              {
                              console.log("Display Id"+link_cover_solution[i]);
                              document.getElementById(link_cover_solution[i]).style.display='none';
                              
                              }
                              
                              }
                              
                              
                              
                              }
                              
                              if(available_prod_name.length==1 && unavailable_prod_name.length==0){
                              
                              var forname=  _.where(solutionPlanCsv,{Basic_plan:available_prod_name[0]});
                              console.log("forname"+forname)
                              if(forname==0){
                              
                              
                              for(var i=0;i<=solutionPlanCsv.length-1;i++)
                              {
                              unavailable_prod_name[i]=solutionPlanCsv[i]["Basic_plan"]
                              console.log("unavailable_prod_name"+unavailable_prod_name)
                              }
                              
                              }/*else{
                                for(var i=0;i<=solutionPlanCsv.length-1;i++)
                                {
                                if(solutionPlanCsv[i]["Basic_plan"]!=available_prod_name[0]){
                                unavailable_prod_name[i]=solutionPlanCsv[i]["Basic_plan"]
                                console.log("unavailable_prod_name"+unavailable_prod_name)
                                
                                
                                
                                }
                                }
                                
                                }*/
                              
                              }
                              
                              
                             if (available_prod_name.indexOf("PRUCash Enrich")>=0 && unavailable_prod_cert.indexOf("PRUCash Enrich")>=0){
                                                                                                                   // isMaxAvaible=false
                                $(".denrich").css("display", "none");
                                                                                                                   // document.getElementById("wealthPlusDiv").style.display='none';
                                                                                                                   
                                }
                              
                              
                           
                              
                              if(mainLifeDataObject["al_person_details.mlife.anb"] >=51){
                                   document.getElementById("pcDiv").style.display='none';
                              }
                              
                              

                              if((mainLifeDataObject["al_person_details.mlife.anb"] >=61 && (unavailable_prod_name.indexOf("PRUCash Enrich")>=0)) || ($("#pcDiv").css("display")=="none" && $(".denrich").css("display")=="none" &&  $(".dgrowth").css("display")=="none" &&  $("#pcdrDiv").css("display")=="none"))
                                      {
                                          var solutionContentSaving=["al_sqs_buttons_container.savings_solution"]
                                          
                                          for(var i=0;i<=solutionContentSaving.length-1;i++)
                                          {
                                          
                                          if(displaySolutions.indexOf(solutionContentSaving[i])>=0)
                                          {
                                          console.log("Display Id"+solutionContentSaving[i]);
                                          document.getElementById(solutionContentSaving[i]).style.display='none';
                                          
                                          }
                                          
                                          }
                              
                              
                                      }
                                      
                              
                              
                              
                              
                              
                              for(var p=0;p<=unavailable_prod_name.length-1;p++) {
                              
                              console.log("@available_solution"+available_solution[unavailable_prod_name[p]])
                              if(available_solution[unavailable_prod_name[p]]!=undefined && available_solution[unavailable_prod_name[p]]!='undefined' && available_solution[unavailable_prod_name[p]]!='null'  && available_solution[unavailable_prod_name[p]]!=null){
                              
                              
                              fnHideExpireProductSoln(available_solution[unavailable_prod_name[p]]);
                              
                              
                              
                              }
                              
                              
                              
                              }
                                  
                                  var prumanSolution=["al_sqs_buttons_container.pruman"];
                                  var pruladySolutiion=["al_sqs_buttons_container.prulady"];
                                  
                                  
                                  
                                  //Added for solution button CR for jan  2024 release
                                  if(mainLifeDataObject["al_person_details.mlife.gender"]!="Female")
                                  {
                                      for(var i=0;i<=pruladySolutiion.length-1;i++)
                                      {
                                      
                                      if(displaySolutions.indexOf(pruladySolutiion[i])>=0)
                                      {
                                      console.log("Display Id"+pruladySolutiion[i]);
                                      document.getElementById(pruladySolutiion[i]).style.display='none';
                                      
                                      }
                                      
                                      }
                                      
                                  }else{
                                     
                                      for(var i=0;i<=prumanSolution.length-1;i++)
                                      {
                                      
                                      if(displaySolutions.indexOf(prumanSolution[i])>=0)
                                      {
                                      console.log("Display Id"+prumanSolution[i]);
                                      document.getElementById(prumanSolution[i]).style.display='none';
                                      
                                      }
                                      
                                      }
                                      
                                  }
                                  
                              
                              
                              
                              
                              
                              
                              
                            var buttonPlansIDs=document.getElementById("mysolutions_buttons_subcontainer").getElementsByTagName('button');
                              ArrayOfImagesPath=[];// sachin sourabh got sign off for array blank
                              ArrayOfvaridDiv=[];//// sachin sourabh got sign off for array blank
                              for (var i = 0; i < buttonPlansIDs.length; ++i)
                              {
                              
                              if(buttonPlansIDs[i].id==buttonPlansObject["al_sqs_buttons_plan"])
                              {
                              
                              console.log("buttonPlansIDs"+buttonPlansIDs[i].id);
                             screenVisibility= document.getElementById(buttonPlansIDs[i].id).style.display
                             // screenVisibilityFlag=false;
                              console.log("screenVisibility"+ screenVisibility);
                              
                              var plansName=(buttonPlansIDs[i].id).split(".")
                              console.log("@plansName"+plansName[1]);
                              var plansImageId="plans_image"+"."+plansName[1];
                              
                              diabetsDuration=buttonPlansObject["duration_with_diabets"];
                              hba1c_level=buttonPlansObject["hba1c_level"];
                              benfitMedicalPlanName=buttonPlansObject["pru_my_medical_plus_solutions.medicals_benefit"];
                              
                              if(ribbenProductFinal.indexOf(plansName[1])>=0)
                              {
                              plansName[1]=plansName[1]+"_rec";
                              }

                              
                              
                            //  document.getElementById(plansImageId).src="Images/blinking1.gif";
                              //  document.getElementById(plansImageId).src=documentDirectoryPath + "Images/"+plansName[1]+".png"; //Commeted this original code for solution cr for may release on date 3-4-2019
                             // document.getElementById(plansImageId).src=documentDirectoryPath + "Images/"+plansName[1]+"_star.png"; // Shrikant and sr
                              ArrayOfImagesPath.push(documentDirectoryPath1 + "Images/"+plansName[1]+"_star.png");
                              ArrayOfvaridDiv.push(plansImageId);
                              document.getElementById(buttonPlansIDs[i].id).classList.add('button_selected');
                              
                              if(benfitMedicalPlanName !="")
                              {
                              document.getElementById(benfitMedicalPlanName).checked=true;
                              
                              }
                              
                              }else
                              {
                              
                              console.log("buttonPlansIDs else"+buttonPlansIDs[i].id);
                              var plansName=(buttonPlansIDs[i].id).split(".");
                              console.log("@plansName else-->"+plansName[1]);
                              var plansImageId="plans_image"+"."+plansName[1];
                              
                              if(buttonPlansObject !="" && buttonPlansObject["al_sqs_buttons_plan"]!="")
                              {
                             
                             
                            // document.getElementById(plansImageId).src="Images/action_1.1.png";
                              if(ribbenProductFinal.indexOf(plansName[1])>=0)
                              {
                              plansName[1]=plansName[1]+"_rec";
                              }
                               //document.getElementById(plansImageId).src=documentDirectoryPath+"Images/"+plansName[1]+"_dim.png";//This is original code for cmted for solution may Release on date 3-4-2-2019
                               //document.getElementById(buttonPlansIDs[i].id).disabled=true;
                              
                              
                             //document.getElementById(plansImageId).src=documentDirectoryPath+"Images/"+plansName[1]+".png";//This is original code for cmted for solution may Release on date 3-4-2-2019 //SR and shrikant
                              ArrayOfImagesPath.push(documentDirectoryPath1 +"Images/"+plansName[1]+".png");
                              ArrayOfvaridDiv.push(plansImageId);
                             // document.getElementById(buttonPlansIDs[i].id).disabled=true;todo for defect 7248 on date 1-07-2019
                              }else
                              {
                              console.log("@plansName final"+plansName[1]);
                              if(ribbenProductFinal.indexOf(plansName[1])>=0)
                              {
                              plansName[1]=plansName[1]+"_rec";
                              }
                              // document.getElementById(plansImageId).src=documentDirectoryPath + "Images/"+plansName[1]+".png"; //SR and shrikant
                              ArrayOfImagesPath.push(documentDirectoryPath1 +"Images/"+plansName[1]+".png");
                              ArrayOfvaridDiv.push(plansImageId);
                              
                              }
                              
                              }
                              
                              
                              }
                        
                              //Shrikant
//                              if(ArrayOfImagesPath.length > 0)
//                              {
//                              fnMPGetImageFileData(0,ArrayOfImagesPath,ArrayOfvaridDiv);
//                              }
                        
                              }else
                              {
                              
                               document.getElementById("al_sqs_buttons_container.tailor_your_solution").style.display='block';
                              
                              
                              }
                              
                              
                              //Addde by sayali for msqg.
                              if(MSQGIndicator=="SUSPENSE" || MSQGIndicator=="SUSPENDED")
                              {
                                document.getElementById("al_sqs_buttons_container.prumy_medical_plus").style.display='none';
                              }
      /********************************************Piyush: Added this if block for MBM changes on 18/11/2019********************************************/
                              
                              if(is_block_MBM_checking=="Yes" && checkMBMEffectiveDate(effectiveDayMBM))
                              {
                                  if(arrMBMSolution.length >0){
                                      for(var i=0;i<arrMBMSolution.length;i++){
                                        var temp = document.getElementById("al_sqs_buttons_container."+arrMBMSolution[i])
                                          if(temp != null && temp != ""){
                                            document.getElementById("al_sqs_buttons_container."+arrMBMSolution[i]).style.display='none';
                                          }
                                      }
                                  }
                              }
      /**************************************************Piyush:code Ended to make MBM solution Button Configurable**************************************/
                              //end
                                if(ArrayOfImagesPath.length > 0)
                                {
                                    fnMPGetImageFileData(0,ArrayOfImagesPath,ArrayOfvaridDiv,"GetClearImage")
                                }
                              
                              
                             
                              
                              
                              
                              
                              
                              
                              });
            });
    
    });
});
                       //  });// shrikant closed
                                  }
                                  else
                                  {
                                    alert("44");
                                  }
});
});
});
             
}


function fnHideExpireProductSoln(arrayData) {
    
    for(var i=0;i<=arrayData.length-1;i++)
    {
        
        if(displaySolutions.indexOf(arrayData[i])>=0)
        {
            console.log("Display Id"+arrayData[i]);
            document.getElementById(arrayData[i]).style.display='none';
            
        }
        
    }
    
    
}




function fnMsOnClickPlansButton(plansID)
{
    startSpinner("Please wait..")
    buttonClickResonse=false;
    maxSolutionSelected="";
    var buttonPlansIDs=document.getElementById("mysolutions_buttons_subcontainer").getElementsByTagName('button');
    
    var setImgPathArray = [];
    var setImgDivArray = []
    
    
    
    for (var i = 0; i < buttonPlansIDs.length; ++i)
    {
       
            if(buttonPlansIDs[i].id==plansID)
            {
                selectedPlanName=buttonPlansIDs[i].id;
               
                 document.getElementById(buttonPlansIDs[i].id).disabled=false;
                var className= document.getElementById(buttonPlansIDs[i].id).classList;
                var valiadClassLength=className.length;
                var valiadClassName=className[1];
                
                
                if(valiadClassName=="button_selected1") //"button_selected" old condition but checked for defect 7248 on date 8-7-2019
                {
                    nonSelectedPlan=true;
                    document.getElementById(buttonPlansIDs[i].id).classList.remove('button_selected');
                    
                    for (var i = 0; i < buttonPlansIDs.length; ++i)
                    {
                        console.log("buttonPlansIDs"+buttonPlansIDs[i].id);
                         document.getElementById(buttonPlansIDs[i].id).disabled=false;
                        
                        
                        var plansName=(buttonPlansIDs[i].id).split(".")
                        var plansImageId="plans_image"+"."+plansName[1];
                        
                        if(ribbenProductFinal.indexOf(plansName[1])>=0)
                        {
                            plansName[1]=plansName[1]+"_rec";
                        }
                        
                        
//                        document.getElementById(plansImageId).src=documentDirectoryPath+"Images/"+plansName[1]+".png"; // Shrikant
                        
                        setImgPathArray.push(documentDirectoryPath1+"Images/"+plansName[1]+".png");
                        setImgDivArray.push(plansImageId);
                        
                        selectedPlanName="";
                        
                        

                    }
                   
                }else
                {
                    
                    console.log("buttonPlansIDs Else"+buttonPlansIDs[i].id);
                    var plansName=(buttonPlansIDs[i].id).split(".")
                    var plansImageId="plans_image"+"."+plansName[1];
                    
                    
                    if(ribbenProductFinal.indexOf(plansName[1])>=0)
                    {
                        plansName[1]=plansName[1]+"_rec";
                    }
             //    document.getElementById(plansImageId).src=documentDirectoryPath+"Images/"+plansName[1]+".png";
                    
//                    document.getElementById(plansImageId).src=documentDirectoryPath+"Images/"+plansName[1]+"_star.png"; // Shrikant
                    
                    setImgPathArray.push(documentDirectoryPath1+"Images/"+plansName[1]+"_star.png");
                    setImgDivArray.push(plansImageId);
                    
                 document.getElementById(buttonPlansIDs[i].id).classList.add('button_selected');
                    
                    benefitRespnseData=true;
                
                    
                if((buttonPlansIDs[i].id=="al_sqs_buttons.prumy_medical_plus" /*|| buttonPlansIDs[i].id=="al_sqs_buttons.prumy_first_policy"*/) && (mainLifeDataObject["pamb_channel"]!="Banca" || Channel!="Banca"))
                {
                    if(mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && mainLifeDataObject["pvm_qualification_check"]=="Yes")
                    {
                        
                        //  mainLifeDataObject["pvm_qualification_check"]
                        
                        //  document.getElementById("pru_million_med_benefit").disabled=true;
                        //  document.getElementById("millionMedDiv").style.display='none';
                        $(".blvan").css("display", "block");
                        //document.getElementById("pru_value_med_benefit").checked=true;
                        canSwipe=1;
                        buttonClickResonse=false;
                        benfitMedicalPlanName="pru_value_med_benefit";
                        
                        
                    }else if(mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && mainLifeDataObject["pvm_qualification_check"]=="No")
                    {
                        $(".blvan").css("display", "none");
                        //  document.getElementById("millionMedDiv").style.display='block';
                        
                        document.getElementById("pru_million_med_benefit").checked=true;
                        canSwipe=1;
                        buttonClickResonse=false;
                        benfitMedicalPlanName="pru_million_med_benefit";
                        
                    }
                    else if(mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && mainLifeDataObject["pvm_qualification_check"]=="No")
                    {
                        // document.getElementById("millionMedDiv").style.display='none';
                        $(".blvan").css("display", "none");
                        document.getElementById("pruhealth_medical_benefit").checked=true;
                        
                    }
                    else if(mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && mainLifeDataObject["pvm_qualification_check"]=="Yes")
                    {
                        
                        // canSwipe=0;
                        // buttonClickResonse=true;
                        //  document.getElementById("pru_value_med_benefit").checked=true;
                        // $("#pmp_popup,.mask").fadeIn();
                        
                    }else{
                        console.log("Reserved for upcomming riders");
                    }
                    
                    if(mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No")
                    {
                        // document.getElementById("millionMedDiv").style.display='none';
                        
                        
                    }
                    //                    if(productCertified.includes("MC47_No") || productCertified.includes("MC46_No")){
                    //
                    //                       if(productCertified.includes("MC47_No"))
                    //                       {
                    //                           document.getElementById("millionMed2").style.display='none';
                    //                       }
                    //                        if(productCertified.includes("MC46_No"))
                    //                        {
                    //                            document.getElementById("millionMedactive").style.display='none';
                    //                        }
                    //
                    //
                    //                    }
                    //
                    
                    //                    if(productCertified.includes("MC44_No") || productCertified.includes("MC43_No")){
                    //
                    //                       if(productCertified.includes("MC44_No"))
                    //                       {
                    //                           document.getElementById("millionMed2").style.display='none';
                    //                       }
                    //                        if(productCertified.includes("MC43_No"))
                    //                        {
                    //                            document.getElementById("millionMedactive").style.display='none';
                    //                        }
                    //
                    //
                    //                    }
                    //
                    
                    
                    
                    if(mainLifeDataObject["pamb_channel"]=="Agency" || mainLifeDataObject["pamb_channel"]=="FA")
                    {
                    if((productCertified.includes("MC40_Yes") && productCertified.includes("MC41_Yes"))  && mainLifeDataObject["pvm_qualification_check"]=="Yes") //Pradnya: added for may24 release
                    {
                        
                        document.getElementById("pru_million_med_active").checked=true;
                        
                        $(".blvan").css("display", "block");
                        
                        canSwipe=1;
                        buttonClickResonse=false;
                        benfitMedicalPlanName="pru_million_med_active";
                        $("#pmp_popup,.mask").fadeIn();
                        
                    }
                    if((productCertified.includes("MC40_Yes") && productCertified.includes("MC41_Yes")) && mainLifeDataObject["pvm_qualification_check"]=="Yes") //Pradnya: added for may24 release
                    {
                        
                        document.getElementById("pru_million_med_active").checked=true;
                        
                        $(".blvan").css("display", "block");
                        
                        canSwipe=1;
                        buttonClickResonse=false;
                        benfitMedicalPlanName="pru_million_med_active";
                        $("#pmp_popup,.mask").fadeIn();
                        
                    }
                    
                    
                    if((productCertified.includes("MC40_No") || productCertified.includes("MC41_No"))  && mainLifeDataObject["pvm_qualification_check"]=="Yes"){
                        
                        document.getElementById("pru_value_med_benefit").checked=true;
                        document.getElementById("pru_million_med_active").checked=false;
                        $(".blvan").css("display", "block");
                        
                        canSwipe=1;
                        buttonClickResonse=false;
                        benfitMedicalPlanName="pru_value_med_benefit";
                        
                        
                    }
                    
                    
                    
                    if((productCertified.includes("MC40_Yes") && productCertified.includes("MC41_Yes"))&& mainLifeDataObject["pvm_qualification_check"]=="No"){
                        
                        document.getElementById("pru_million_med_active").checked=true;
                        document.getElementById("pru_value_med_benefit").checked=false;
                        $(".blvan").css("display", "block");
                        
                        canSwipe=1;
                        buttonClickResonse=false;
                        benfitMedicalPlanName="pru_million_med_active";
                        
                    }
                    if((!productCertified.includes("MC40") && !productCertified.includes("MC41")) && mainLifeDataObject["pvm_qualification_check"]=="Yes"){
                        
                        canSwipe=1;
                        buttonClickResonse=false;
                        benfitMedicalPlanName="pru_value_med_benefit";
                        document.getElementById("pru_million_med_active").checked=false;
                        document.getElementById("millionMedactive").style.display="none";
                        document.getElementById("millionMed2").style.display="none";
                        
                    }
                        
                        if((!productCertified.includes("MC41") && !productCertified.includes("MC40"))){
                            
                            canSwipe=1;
                            buttonClickResonse=false;
                            benfitMedicalPlanName="pru_value_med_benefit";
                            document.getElementById("pru_million_med_active").checked=false;
                            document.getElementById("millionMedactive").style.display="none";
                            document.getElementById("millionMed2").style.display="none";
                            
                        }
                        
                        if((productCertified.includes("MC41_No"))){
                            
                            canSwipe=1;
                            buttonClickResonse=false;
                            benfitMedicalPlanName="pru_value_med_benefit";
                            document.getElementById("pru_million_med_active").checked=false;
                           document.getElementById("millionMedactive").style.display="none";
                            //document.getElementById("millionMed2").style.display="none";
                            
                        }
                        if((productCertified.includes("MC40_No"))){
                            
                            canSwipe=1;
                            buttonClickResonse=false;
                            benfitMedicalPlanName="pru_value_med_benefit";
                            document.getElementById("pru_million_med_active").checked=false;
                          // document.getElementById("millionMedactive").style.display="none";
                            document.getElementById("millionMed2").style.display="none";
                            
                        }
                        
                        if(productCertified.includes("MC40") && productCertified.includes("MC41") && mainLifeDataObject["pvm_qualification_check"]=="No"){
                            document.getElementById("al_sqs_buttons_container.prumy_medical_plus").style.display="none";
                        }
                        
                        if(!productCertified.includes("MC40")){
                            canSwipe=1;
                            buttonClickResonse=false;
                            benfitMedicalPlanName="pru_value_med_benefit";
                            document.getElementById("pru_million_med_active").checked=false;
                          // document.getElementById("millionMedactive").style.display="none";
                            document.getElementById("millionMed2").style.display="none";
                            
                        }
                        
                        
                        if(!productCertified.includes("MC41")){
                            canSwipe=1;
                            buttonClickResonse=false;
                            benfitMedicalPlanName="pru_value_med_benefit";
                            document.getElementById("pru_million_med_active").checked=false;
                           document.getElementById("millionMedactive").style.display="none";
                            
                        }
                        
                        if(productCertified.includes("MC41") &&  !productCertified.includes("MC41")){
                            
                            document.getElementById("pru_million_med_active").checked=true;
                            
                            $(".blvan").css("display", "block");
                            
                            canSwipe=1;
                            buttonClickResonse=false;
                            benfitMedicalPlanName="pru_million_med_active";
                            $("#pmp_popup,.mask").fadeIn();
                            
                            
                        }
                        
                        if(productCertified.includes("MC40_Yes") &&  (!productCertified.includes("MC41") ||productCertified.includes("MC41_No"))){
                            
                            
                           
                            
                            canSwipe=1;
                            buttonClickResonse=false;
                            benfitMedicalPlanName="pru_million_med_2_0";
                            document.getElementById("pru_million_med_2_0").checked=true;
                          // document.getElementById("millionMedactive").style.display="none";
                            document.getElementById("millionMed2").style.display="block";
                            $("#pmp_popup,.mask").fadeIn();
                            
                        }
                        if(productCertified.includes("MC41_Yes") &&  (!productCertified.includes("MC40") || productCertified.includes("MC40_No"))){
                            
                            
                            document.getElementById("pru_million_med_active").checked=true;
                            
                            $(".blvan").css("display", "block");
                            
                            canSwipe=1;
                            buttonClickResonse=false;
                            benfitMedicalPlanName="pru_million_med_active";
                            $("#pmp_popup,.mask").fadeIn();
                            
                        }
                        
                        
                        
                }
                    /*********************/
                    if(mainLifeDataObject["pamb_channel"]=="UOB")
                    {
                    if((productCertified.includes("MC47_Yes") || productCertified.includes("MC46_Yes"))  && mainLifeDataObject["pvm_qualification_check"]=="Yes") //Pradnya: added for may24 release
                    {
                        
                        document.getElementById("pru_million_med_active").checked=true;
                        
                        $(".blvan").css("display", "block");
                        
                        canSwipe=1;
                        buttonClickResonse=false;
                        benfitMedicalPlanName="pru_million_med_active";
                        $("#pmp_popup,.mask").fadeIn();
                        
                    }
                    if((productCertified.includes("MC47_Yes") && productCertified.includes("MC46_Yes")) && mainLifeDataObject["pvm_qualification_check"]=="Yes") //Pradnya: added for may24 release
                    {
                        
                        document.getElementById("pru_million_med_active").checked=true;
                        
                        $(".blvan").css("display", "block");
                        
                        canSwipe=1;
                        buttonClickResonse=false;
                        benfitMedicalPlanName="pru_million_med_active";
                        $("#pmp_popup,.mask").fadeIn();
                        
                    }
                    
                    
                    if((productCertified.includes("MC47_No") && productCertified.includes("MC46_No"))  && mainLifeDataObject["pvm_qualification_check"]=="Yes"){
                        
                        document.getElementById("pru_value_med_benefit").checked=true;
                        document.getElementById("pru_million_med_active").checked=false;
                        $(".blvan").css("display", "block");
                        
                        canSwipe=1;
                        buttonClickResonse=false;
                        benfitMedicalPlanName="pru_value_med_benefit";
                        
                        
                    }
                    
                    
                    
                    if((productCertified.includes("MC47_Yes") && productCertified.includes("MC46_Yes"))&& mainLifeDataObject["pvm_qualification_check"]=="No"){
                        
                        document.getElementById("pru_million_med_active").checked=true;
                        document.getElementById("pru_value_med_benefit").checked=false;
                        $(".blvan").css("display", "block");
                        
                        canSwipe=1;
                        buttonClickResonse=false;
                        benfitMedicalPlanName="pru_million_med_active";
                        
                    }
                    if((!productCertified.includes("MC47") && !productCertified.includes("MC46")) && mainLifeDataObject["pvm_qualification_check"]=="Yes"){
                        
                        canSwipe=1;
                        buttonClickResonse=false;
                        benfitMedicalPlanName="pru_value_med_benefit";
                        document.getElementById("pru_million_med_active").checked=false;
                        document.getElementById("millionMedactive").style.display="none";
                        document.getElementById("millionMed2").style.display="none";
                        
                    }
                        
                        
                        if((!productCertified.includes("MC47") && !productCertified.includes("MC46"))){
                            
                            canSwipe=1;
                            buttonClickResonse=false;
                            benfitMedicalPlanName="pru_value_med_benefit";
                            document.getElementById("pru_million_med_active").checked=false;
                            document.getElementById("millionMedactive").style.display="none";
                            document.getElementById("millionMed2").style.display="none";
                            
                        }
                        
                        if((productCertified.includes("MC47_No"))){
                            
                            canSwipe=1;
                            buttonClickResonse=false;
                            benfitMedicalPlanName="pru_value_med_benefit";
                            document.getElementById("pru_million_med_active").checked=false;
                           document.getElementById("millionMedactive").style.display="none";
                            //document.getElementById("millionMed2").style.display="none";
                            
                        }
                        if((productCertified.includes("MC46_No"))){
                            
                            canSwipe=1;
                            buttonClickResonse=false;
                            benfitMedicalPlanName="pru_value_med_benefit";
                            document.getElementById("pru_million_med_active").checked=false;
                          // document.getElementById("millionMedactive").style.display="none";
                            document.getElementById("millionMed2").style.display="none";
                            
                        }
                        if(productCertified.includes("MC46_No") && productCertified.includes("MC47_No") && mainLifeDataObject["pvm_qualification_check"]=="No"){
                            document.getElementById("al_sqs_buttons_container.prumy_medical_plus").style.display="none";
                        }
                        
                        if(!productCertified.includes("MC46")){
                            canSwipe=1;
                            buttonClickResonse=false;
                            benfitMedicalPlanName="pru_value_med_benefit";
                            document.getElementById("pru_million_med_active").checked=false;
                          // document.getElementById("millionMedactive").style.display="none";
                            document.getElementById("millionMed2").style.display="none";
                            
                        }
                        
                        
                        if(!productCertified.includes("MC47")){
                            canSwipe=1;
                            buttonClickResonse=false;
                            benfitMedicalPlanName="pru_value_med_benefit";
                            document.getElementById("pru_million_med_active").checked=false;
                           document.getElementById("millionMedactive").style.display="none";
                            
                        }
                        
                      //
                        
                        if(productCertified.includes("MC46_Yes") &&  (!productCertified.includes("MC47") ||productCertified.includes("MC47_No"))){
                            
                            
                           
                            
                            canSwipe=1;
                            buttonClickResonse=false;
                            benfitMedicalPlanName="pru_million_med_2_0";
                            document.getElementById("pru_million_med_2_0").checked=true;
                          // document.getElementById("millionMedactive").style.display="none";
                            document.getElementById("millionMed2").style.display="block";
                            $("#pmp_popup,.mask").fadeIn();
                            
                        }
                        if(productCertified.includes("MC47_Yes") &&  (!productCertified.includes("MC46") || productCertified.includes("MC46_No"))){
                            
                            
                            document.getElementById("pru_million_med_active").checked=true;
                            
                            $(".blvan").css("display", "block");
                            
                            canSwipe=1;
                            buttonClickResonse=false;
                            benfitMedicalPlanName="pru_million_med_active";
                            $("#pmp_popup,.mask").fadeIn();
                            
                        }
                        
                        
                        
                }
             
                   /**********************/

                    
                    /*****************/
                    
                    
//                    if(mainLifeDataObject["pamb_channel"]=="UOB"){
//                        document.getElementById("pru_million_med_active").checked=true;//Pradnya: added for 1407 for may24 release
//                        canSwipe=0;
//                        buttonClickResonse=true;
//                        $("#pmp_popup,.mask").fadeIn();
//                        benfitMedicalPlanName="pru_million_med_active";
//                    }
//                    
                    
                    
                  //  $("#pmp_popup,.mask").fadeIn();
                   // document.getElementById(buttonPlansIDs[i].id).disabled=true; commeted for defect 7248 temp on date 1-07-2019
                   
//                     canSwipe=0;
//                    buttonClickResonse=true;
//                    
                    
                   // $("#pmp_popup,.mask").fadeIn();
                   
                    //return false;
                
                }
                    
                    
                           if((mainLifeDataObject["pamb_channel"]=="Banca" || Channel=="Banca") && buttonPlansIDs[i].id=="al_sqs_buttons.prumy_medical_plus"){
                               if((productCertified.includes("MC44_Yes") || productCertified.includes("MC43_Yes"))) //Pradnya: added for may24 release
                               {
                                   
                                   document.getElementById("pru_million_med_active").checked=true;
                                   
                                   $(".blvan").css("display", "block");
                                   
                                   canSwipe=1;
                                   buttonClickResonse=false;
                                   benfitMedicalPlanName="pru_million_med_active";
                                   $("#pmp_popup,.mask").fadeIn();
                                   
                               }
                              
                               
                               if((productCertified.includes("MC44_No") && productCertified.includes("MC43_No"))  && mainLifeDataObject["pvm_qualification_check"]=="Yes"){
                                   
                                   document.getElementById("pru_value_med_benefit").checked=true;
                                   document.getElementById("pru_million_med_active").checked=false;
                                   $(".blvan").css("display", "block");
                                   
                                   canSwipe=1;
                                   buttonClickResonse=false;
                                   benfitMedicalPlanName="pru_value_med_benefit";
                                   
                                   
                               }
                               
                               
                               
                               if((productCertified.includes("MC44_Yes") && productCertified.includes("MC43_Yes"))&& mainLifeDataObject["pvm_qualification_check"]=="No"){
                                   
                                   document.getElementById("pru_million_med_active").checked=true;
                                   document.getElementById("pru_value_med_benefit").checked=false;
                                   $(".blvan").css("display", "block");
                                   
                                   canSwipe=1;
                                   buttonClickResonse=false;
                                   benfitMedicalPlanName="pru_million_med_active";
                                   
                               }
                               if((!productCertified.includes("MC44") && !productCertified.includes("MC43"))){
                                   
                                   canSwipe=1;
                                   buttonClickResonse=false;
                                   benfitMedicalPlanName="pru_value_med_benefit";
                                   document.getElementById("pru_million_med_active").checked=false;
                                   document.getElementById("millionMedactive").style.display="none";
                                   document.getElementById("millionMed2").style.display="none";
                                   
                               }
                               if((productCertified.includes("MC44_No"))){
                                   
                                   canSwipe=1;
                                   buttonClickResonse=false;
                                   benfitMedicalPlanName="pru_value_med_benefit";
                                   document.getElementById("pru_million_med_active").checked=false;
                                  document.getElementById("millionMedactive").style.display="none";
                                   //document.getElementById("millionMed2").style.display="none";
                                   
                               }
                               if((productCertified.includes("MC43_No"))){
                                   
                                   canSwipe=1;
                                   buttonClickResonse=false;
                                   benfitMedicalPlanName="pru_value_med_benefit";
                                   document.getElementById("pru_million_med_active").checked=false;
                                 // document.getElementById("millionMedactive").style.display="none";
                                   document.getElementById("millionMed2").style.display="none";
                                   
                               }
                               
                               
                               if(productCertified.includes("MC43_No") && productCertified.includes("MC44_No") && mainLifeDataObject["pvm_qualification_check"]=="No"){
                                   document.getElementById("al_sqs_buttons_container.prumy_medical_plus").style.display="none";
                               }
                               
                               if(mainLifeDataObject["pamb_channel"]=="Banca"){
                                   document.getElementById("pru_million_med_active").checked=true;//Pradnya: added for 1407 for may24 release
                                   canSwipe=0;
                                   buttonClickResonse=true;
                                   $("#pmp_popup,.mask").fadeIn();
                                   benfitMedicalPlanName="pru_million_med_active";
                               }
                               
                               if(!productCertified.includes("MC43")){
                                   canSwipe=1;
                                   buttonClickResonse=false;
                                   benfitMedicalPlanName="pru_value_med_benefit";
                                   document.getElementById("pru_million_med_active").checked=false;
                                 // document.getElementById("millionMedactive").style.display="none";
                                   document.getElementById("millionMed2").style.display="none";
                                   
                               }
                               
                               
                               if(!productCertified.includes("MC44")){
                                   canSwipe=1;
                                   buttonClickResonse=false;
                                   benfitMedicalPlanName="pru_value_med_benefit";
                                   document.getElementById("pru_million_med_active").checked=false;
                                  document.getElementById("millionMedactive").style.display="none";
                                   
                               }
                              
                               if(productCertified.includes("MC43_Yes") &&  (!productCertified.includes("MC44") ||productCertified.includes("MC44_No"))){
                                   
                                   
                                  
                                   
                                   canSwipe=1;
                                   buttonClickResonse=false;
                                   benfitMedicalPlanName="pru_million_med_2_0";
                                   document.getElementById("pru_million_med_2_0").checked=true;
                                 // document.getElementById("millionMedactive").style.display="none";
                                   document.getElementById("millionMed2").style.display="block";
                                   $("#pmp_popup,.mask").fadeIn();
                                   
                               }
                               if(productCertified.includes("MC44_Yes") &&  (!productCertified.includes("MC43") || productCertified.includes("MC43_No"))){
                                   
                                   
                                   document.getElementById("pru_million_med_active").checked=true;
                                   
                                   $(".blvan").css("display", "block");
                                   
                                   canSwipe=1;
                                   buttonClickResonse=false;
                                   benfitMedicalPlanName="pru_million_med_active";
                                   $("#pmp_popup,.mask").fadeIn();
                                   
                               }
                               
                               
                               
                           }
                    
                    
                    // Pradnya: added for may 24 solution button changes
//                   else if(buttonPlansIDs[i].id=="al_sqs_buttons.prumy_medical_plus")
//
//                    {
//                        console.log("MC47_No"+MC47_No)
//                        if(mainLifeDataObject["pvm_qualification_check"]=="Yes" && mainLifeDataObject["product_certified_check"]=="MC47_No" && mainLifeDataObject["product_certified_check"]=="MC46_No")
//                           {
//                            console.log("MC47_No"+MC47_No)
//                             //  mainLifeDataObject["pvm_qualification_check"]
//
//                             //  document.getElementById("pru_million_med_benefit").disabled=true;
//                               document.getElementById("millionMed2").style.display='none';
//                                $(".blvan").css("display", "block");
//                               document.getElementById("pru_million_med_active").checked=true;
//                               canSwipe=1;
//                               buttonClickResonse=false;
//                               benfitMedicalPlanName="pru_million_med_active";
//
//
//                           }else if(mainLifeDataObject["pvm_qualification_check"]=="Yes" && productCertified.includes("MC47_Yes") && productCertified.includes("MC46_Yes"))
//                           {
//                               $(".blvan").css("display", "none");
//                               document.getElementById("millionMedDiv").style.display='block';
//
//                               document.getElementById("pru_million_med_benefit").checked=true;
//                               canSwipe=1;
//                               buttonClickResonse=false;
//                               benfitMedicalPlanName="pru_million_med_benefit";
//
//                           }
//                        else if(mainLifeDataObject["rider_certified_check"]=="PruMillionMed_No" && mainLifeDataObject["pvm_qualification_check"]=="No")
//                        {
//                               document.getElementById("millionMedDiv").style.display='none';
//                              $(".blvan").css("display", "none");
//                            document.getElementById("pruhealth_medical_benefit").checked=true;
//
//                        }
//                        else if(mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && mainLifeDataObject["pvm_qualification_check"]=="Yes")
//                           {
//
//                               canSwipe=0;
//                              buttonClickResonse=true;
//                               document.getElementById("pru_value_med_benefit").checked=true;
//                               $("#pmp_popup,.mask").fadeIn();
//
//                           }
//                        // Pradnya: added for may 24 solution button changes
//                        else if(mainLifeDataObject["rider_certified_check"]=="PruMillionMed_Yes" && mainLifeDataObject["pvm_qualification_check"]=="Yes")
//                        {
//                            $(".blvan").css("display", "none");
//                            document.getElementById("millionMedDiv").style.display='block';
//
//                            document.getElementById("pru_million_med_benefit").checked=true;
//                            canSwipe=1;
//                            buttonClickResonse=false;
//                            benfitMedicalPlanName="pru_million_med_benefit";
//
//                        }
//                       // document.getElementById(buttonPlansIDs[i].id).disabled=true; commeted for defect 7248 temp on date 1-07-2019
//
//    //                     canSwipe=0;
//    //                    buttonClickResonse=true;
//    //
//
//                       // $("#pmp_popup,.mask").fadeIn();
//
//                        //return false;
//
//                    }
                
                else if(mainLifeDataObject["pamb_channel"]=="Banca" && buttonPlansIDs[i].id=="al_sqs_buttons.prumy_medical_plus"){
                    document.getElementById("pru_million_med_active").checked=true;//Pradnya: added for 1407 for may24 release
                    canSwipe=0;
                    buttonClickResonse=true;
                    $("#pmp_popup,.mask").fadeIn();
                    benfitMedicalPlanName="pru_million_med_active";
                }
                else if(buttonPlansIDs[i].id=="al_sqs_buttons.prumy_diabetes_care")
                {
                     canSwipe=0;
                    document.getElementById("pru_my_diabetes_care_duration").value=diabetsDuration;
                    document.getElementById("pru_my_diabetes_care_hba1c_level").value=hba1c_level;
                    document.getElementById("al_sqs_buttons.prumy_diabetes_care").disabled=true;
                    
                    buttonClickResonse=true;
                     $("#pru_my_diabetes_care_popup,.mask").fadeIn();
                    
                    //return false;
                }
                    
                    
                    else if(buttonPlansIDs[i].id=="al_sqs_buttons.pruterm_premier")
                    {
                         canSwipe=0;
                        
                        
                        
                        var mainlife_anb_obj = 5 + eval(mainLifeDataObject["al_person_details.mlife.anb"]);
                        // Slider 1
                        document.getElementById("demo").innerHTML = mainlife_anb_obj;
                        // slider 2
                        document.getElementById("demo_ptp").innerHTML = mainlife_anb_obj;
                        // Slider 1  // Added condition on 27th May
                        //document.getElementById("myRange_1").min = slider_anb;
                        var show_ANB_Slider = 80 - eval(mainLifeDataObject["al_person_details.mlife.anb"]);
                        document.getElementById("myRange_1").max = show_ANB_Slider;
                        document.getElementById("myRange_2").max = show_ANB_Slider;
                       
                        
                        
                        console.log("SSD",mainlife_anb_obj);
                        // Slider 2  // Added condition on 27th May
                       // document.getElementById("myRange_2").min = slider_anb;
                       
                        document.getElementById("al_sqs_buttons.pruterm_premier").disabled=true;
                        buttonClickResonse=true;
                         $("#pruterm_premier_popup,.mask").fadeIn();
                        
                       ShowAgeForPTP(slider_one);
                       ShowAgeForPTPTwo(slider_two);
                        
                    }
                 else if(buttonPlansIDs[i].id=="al_sqs_buttons.savings_solution")//Added for savings solution for may release on date 2-4-2019
                 {
                     canSwipe=0;
                     buttonClickResonse=true;
                     
                     
                   if(mainLifeDataObject["al_person_details.mlife.anb"] >50)
                   {
                        $(".svn").css("display", "none");
                       
                   }
                     //comment by ankita for defect 10566 on 28 april 2021
                    /*if(mainLifeDataObject["al_person_details.mlife.anb"]<51)
                                      {
                                           $(".denrich").css("display", "none");
                                          
                                      }*/
                     
                     if(mainLifeDataObject["al_person_details.mlife.anb"] >=61)
                     {
                          $("#pcdrDiv").css("display", "none");
                          $(".dgrowth").css("display", "none");
                         
                     }
                     
                   
                     if(($("#pcdrDiv").css('display')=="block" && $("#pcDiv").css('display')=="block" && $(".dgrowth").css('display')=="block" && $(".denrich").css('display')=="block") || ($("#pcdrDiv").css('display')=="block" && $("#pcDiv").css('display')=="block" && $(".denrich").css('display')=="block") || ($("#pcdrDiv").css('display')=="block" && $(".dgrowth").css('display')=="block") || ($("#pcDiv").css('display')=="block" && $(".dgrowth").css('display')=="block")){
                         
                         if( $(".dgrowth").css('display')=="none" && $(".denrich").css('display')=="none") {

                             document.getElementById("savings_pcdr_benefit").checked =true;
                         }

                         if($(".denrich").css('display')=="none") {

                             document.getElementById("savings_growth_benefit").checked =true;
                        }

                        $("#savings_popup,.mask").fadeIn();
                         
                     }else{
                         if($("#pcdrDiv").css('display')=="block"){
                             
                             buttonClickResonse=false;
                             canSwipe=1;
                             benfitMedicalPlanName="savings_pcdr_benefit";
                             
                         }else if($("#pcDiv").css('display')=="block" ){
                             buttonClickResonse=false;
                             canSwipe=1;
                             benfitMedicalPlanName="solutions_pc_benefit";
                             
                         }else if($(".dgrowth").css('display')=="block"){
                             
                             buttonClickResonse=false;
                             canSwipe=1;
                             benfitMedicalPlanName="savings_growth_benefit";
                             
                         }
                         else if($(".denrich").css('display')=="block"){
                             
                             buttonClickResonse=false;
                             canSwipe=1;
                             benfitMedicalPlanName="solutions_enrichDiv_benefit";
                             
                         }
                         
                         
                         // $("#savings_popup,.mask").fadeIn();
                         
                         
                         
                         if(($("#pcdrDiv").css('display')=="block" && ($("#pcDiv").css('display')=="block" || $(".dgrowth").css('display')=="block" || $(".denrich").css('display')=="block")) || (($("#pcDiv").css('display')=="block") && ($("#pcdrDiv").css('display')=="block" || $(".dgrowth").css('display')=="block" || $(".denrich").css('display')=="block")) || (($(".dgrowth").css('display')=="block") && ($("#pcdrDiv").css('display')=="block" || $("#pcDiv").css('display')=="block" || $(".denrich").css('display')=="block")) || (($(".denrich").css('display')=="block")&& ($("#pcdrDiv").css('display')=="block" || $("#pcDiv").css('display')=="block"  || $(".dgrowth").css('display')=="block"))){
                             
                              $("#savings_popup,.mask").fadeIn();
                         }
                         
                         
                         
                     }
                     
                      // $("#savings_popup,.mask").fadeIn();
                     
                     
                     
                     
                     
                     
                     if($(".denrich").css('display')=="none") {

                        document.getElementById("savings_growth_benefit").checked =true;
                                           }

                  

                                         if($(".denrich").css('display')=="none") {

                                             document.getElementById("savings_growth_benefit").checked =true;
                                        }
                                      if( $(".dgrowth").css('display')=="none" && $(".denrich").css('display')=="none") {

                                                                document.getElementById("savings_pcdr_benefit").checked =true;
                                                            }
                   
                     if( $(".dgrowth").css('display')=="none" && $(".denrich").css('display')=="none" && $("#pcdrDiv").css('display')=="none") {

                                                                                    document.getElementById("solutions_pc_benefit").checked =true;
                                                                                }
                    
                     if(($("#pcdrDiv").css('display')=="none" && $("#pcDiv").css('display')=="none" && $(".dgrowth").css('display')=="none" && $(".denrich").css('display')=="block")){
                        
                         document.getElementById("solutions_enrichDiv_benefit").checked =true;
                         buttonClickResonse=false;
                         canSwipe=1;
                         benfitMedicalPlanName="solutions_enrichDiv_benefit";
                        
                         
                       //   $("#savings_popup,.mask").fadeIn();
                        
                        }
                     
                     
                     
//                     if(benfitMedicalPlanName=="savings_growth_benefit"){
//
//                            document.getElementById("savings_growth_benefit").checked =true;
//                                        }else if(benfitMedicalPlanName=="solutions_pc_benefit"){
//                                             document.getElementById("solutions_pc_benefit").checked =true;
//                                        }else if(benfitMedicalPlanName=="savings_pcdr_benefit"){
//                                             document.getElementById("savings_pcdr_benefit").checked =true;
//                                        }
//                                        else if(benfitMedicalPlanName=="solutions_enrich_benefit"){
//                                             document.getElementById("solutions_enrichDiv_benefit").checked =true;
//                                        }
//
                 }
                    
                 else if(buttonPlansIDs[i].id=="al_sqs_buttons.pruprotect_xtra" || buttonPlansIDs[i].id=="al_sqs_buttons.prubest_gift")//Added for savings solution for may release on date 2-4-2019
                 {
                     if(buttonPlansIDs[i].id=="al_sqs_buttons.pruprotect_xtra")
                     {
                         maxSolutionSelected="al_sqs_buttons.pruprotect_xtra";
                         
                     }else{
                         
                        maxSolutionSelected="al_sqs_buttons.prubest_gift";
                         
                     }
                     
                     
                     canSwipe=0;
                     buttonClickResonse=true;
                     
                   
                    
                     if($(".wmax").css('display')=="block" &&  $("#wealthPlusDiv").css('display')=="block") {
                          $("#extra_best_popup,.mask").fadeIn();
                         
                     }else
                     {
                        if($(".wmax").css('display')=="block")
                        {
                            buttonClickResonse=false;
                            document.getElementById("wealth_plus_benefit").checked=true;
                             canSwipe=1;
                            
                            benfitMedicalPlanName="wealth_plus_benefit";
                           
                            
                        }else{
                            
                             canSwipe=1;
                            document.getElementById("wealth_max_benefit").checked=true;
                            benfitMedicalPlanName="wealth_max_benefit";
                             buttonClickResonse=false;
                        }
                         
                     }
                     
                    
                     
                 }
                    
                }
                
                
            }
            else /*if(buttonPlansIDs[i].id !="al_sqs_buttons.tailor_your_solution")*/
            {
                console.log("buttonPlansIDs Final"+buttonPlansIDs[i].id);
                
                var plansName=(buttonPlansIDs[i].id).split(".")
                var plansImageId="plans_image"+"."+plansName[1];
                
                if(ribbenProductFinal.indexOf(plansName[1])>=0)
                {
                    plansName[1]=plansName[1]+"_rec";
                }
                //   document.getElementById(plansImageId).src=documentDirectoryPath+"Images/"+plansName[1]+"_dim.png";
                
                // document.getElementById(plansImageId).src=documentDirectoryPath+"Images/"+plansName[1]+"_dim.png"; //original code commetted for may solution release on date 3-4-2019
                //  document.getElementById(buttonPlansIDs[i].id).disabled=true;
                
                
//                document.getElementById(plansImageId).src=documentDirectoryPath+"Images/"+plansName[1]+".png"; //Added for new May Release 2019 on date by Sachin Tupe. // Shrikant
                
                setImgPathArray.push(documentDirectoryPath1+"Images/"+plansName[1]+".png");
                setImgDivArray.push(plansImageId);
                
                
                // document.getElementById(buttonPlansIDs[i].id).disabled=true; TODO for defect 7248 on date 1-07-2019
                
                
                
            }
            
            
      
    }

    //Shrikant
    if(setImgPathArray.length > 0)
    {
        fnMPGetImageFileData(0,setImgPathArray,setImgDivArray,"GetClearImage");
    }
}



function fnMsButtonsValidateAndSwipeLeft()
{
    
    
    if(buttonClickResonse)
    {
        canSwipe=0;
    }
    
    if(selectedPlanName!="")
    {
        
        if(selectedPlanName !="al_sqs_buttons.prumy_medical_plus" && selectedPlanName !="al_sqs_buttons.savings_solution" && selectedPlanName !="al_sqs_buttons.pruprotect_xtra" && selectedPlanName !="al_sqs_buttons.prubest_gift" /*&& selectedPlanName !="al_sqs_buttons.prumy_first_policy"*/ && selectedPlanName !="al_sqs_buttons.prumy_critical_care" )//Added savings solution added for may release on date 2-4-2019
        {
            benfitMedicalPlanName="";
        }
        
        if(selectedPlanName !="al_sqs_buttons.prumy_diabetes_care" && selectedPlanName !="al_sqs_buttons.savings_solution")
        {
            diabetsDuration="";
            hba1c_level="";
        }
        
        if(selectedPlanName =="al_sqs_buttons.prumy_child_plus" && (mainLifeDataObject["pamb_channel"]=="Banca" || mainLifeDataObject["pamb_channel"]=="Agency" || mainLifeDataObject["pamb_channel"]=="FA"))
        {
            benfitMedicalPlanName="pru_million_med_active";
        }
        if(selectedPlanName =="al_sqs_buttons.prumy_critical_care" && mainLifeDataObject["pamb_channel"]=="Banca")
        {
            benfitMedicalPlanName="pru_million_med_2_0";
            if(!productCertified.includes("MC43_Yes"))
            {
                benfitMedicalPlanName="";
            }
        }
        
     /*   if(selectedPlanName !="al_sqs_buttons.pruterm_premier" && selectedPlanName !="al_sqs_buttons.savings_solution")
        {
            diabetsDuration="";
            hba1c_level="";
            slider_one="";
            slider_two="";
        }*/
        
        var solutionsPlan={"al_sqs_buttons_plan":selectedPlanName,
            "pru_my_medical_plus_solutions.medicals_benefit":benfitMedicalPlanName,
            "duration_with_diabets":diabetsDuration,
            "hba1c_level":hba1c_level,
            "slider_one":slider_one,
            "slider_two":slider_two
        }
        
        
        
        
        js_set_var("buttons_plans_response", JSON.stringify(solutionsPlan), function()
                   {
                   
                  

                   
                        if(benefitRespnseData)
                        {
                   js_set_var("beneft_selection_response",JSON.stringify(ben_select_data_clear),function()
                              {
                              js_set_var("loading_details_response",JSON.stringify(loading_res_clear),function()
                                         {
                                         
                                         js_set_var("prod_choice_response",JSON.stringify(prod_choice_rs_clear), function()
                                                    {});
                                         
                                         
                                         });
                              
                              
                              
                              });
                        }
                   
                   /*if(document.getElementById("pru_my_diabetes_care_duration").value>6 || document.getElementById("pru_my_diabetes_care_hba1c_level").value>8)
                   {
                   alert("760");
                   
                   }else
                   {
                   menuController.loadPage("top_mysolutions_productchoice",0);}*/
                   
                   console.log("CANSWAP VALUE"+canSwipe);
                   
                   if((document.getElementById("pru_my_diabetes_care_duration").value=="" && document.getElementById("pru_my_diabetes_care_hba1c_level").value=="") && buttonClickResonse) //If condition added for internal defect for top navigation.
                   {
                   console.log("DO Nothing");
                   
                   }else
                   {
                   menuController.loadPage("top_mysolutions_productchoice",0);
                   }
                   
                   });
        

    }
    else
    {
    alert("759")
    }
    
    
    
    
}

function fnMsButtonsValidateAndSwipeRight()
{
console.log("SSSSSSSS");
    
    if(selectedPlanName!="")
    {console.log("SSSSSSSS");
        if(selectedPlanName !="al_sqs_buttons.prumy_medical_plus"  && selectedPlanName !="al_sqs_buttons.savings_solution" && selectedPlanName !="al_sqs_buttons.pruprotect_xtra" && selectedPlanName !="al_sqs_buttons.prubest_gift" /*&& selectedPlanName !="al_sqs_buttons.prumy_first_policy"*/ && selectedPlanName !="al_sqs_buttons.prumy_critical_care")
        {
            benfitMedicalPlanName="";
        }
        
        if(selectedPlanName !="al_sqs_buttons.prumy_diabetes_care")
        {
            diabetsDuration="";
            hba1c_level="";
        }
//        if(selectedPlanName !="al_sqs_buttons.pruterm_premier")
//        {console.log("SSSSSSSS");
//            slider_one="";
//            slider_two="";
//        }

        
    }
    console.log("SSSSSSSS");
        var solutionsPlan={"al_sqs_buttons_plan":selectedPlanName,
            "pru_my_medical_plus_solutions.medicals_benefit":benfitMedicalPlanName,
            "duration_with_diabets":diabetsDuration,
            "hba1c_level":hba1c_level,
            "slider_one":slider_one,
            "slider_two":slider_two
        }

        
        js_set_var("buttons_plans_response", JSON.stringify(solutionsPlan), function()
                   {
                   
                   if(mainLifeDataObject["pamb_channel"]=="UOB"|| Channel=="UOB"){
                   
                   menuController.loadPage("top_mysolutions_refferal_details",0)
                   
                   }else{
                    menuController.loadPage("top_mysolutions_maindetails",0)
                   }
                   
                   
                   });
        
        
   // }
   
    
    
    
   // menuController.loadPage("top_mysolutions_maindetails",0)

}



function fnMsButtonsOnExit()
{

    
    if(selectedPlanName!="")
    {
        
        if(selectedPlanName !="al_sqs_buttons.prumy_medical_plus" && selectedPlanName !="al_sqs_buttons.savings_solution" && selectedPlanName !="al_sqs_buttons.pruprotect_xtra" && selectedPlanName !="al_sqs_buttons.prubest_gift" /*&& selectedPlanName !="al_sqs_buttons.prumy_first_policy"*/ && selectedPlanName !="al_sqs_buttons.prumy_critical_care")
        {
        benfitMedicalPlanName="";
        }
        
        if(selectedPlanName !="al_sqs_buttons.prumy_diabetes_care")
        {
            diabetsDuration="";
           hba1c_level="";
        }

        
        console.log("@@hba1c_level",hba1c_level);
        
        var solutionsPlan={"al_sqs_buttons_plan":selectedPlanName,
                                    "pru_my_medical_plus_solutions.medicals_benefit":benfitMedicalPlanName,
                                    "duration_with_diabets":diabetsDuration,
                                    "hba1c_level":hba1c_level
                                    }
        
        js_set_var("buttons_plans_response", JSON.stringify(solutionsPlan), function()
                   {
                   
                   
                   
                   if(benefitRespnseData)
                   {
                   js_set_var("beneft_selection_response",JSON.stringify(ben_select_data_clear),function()
                              {
                              js_set_var("loading_details_response",JSON.stringify(loading_res_clear),function()
                                         {
                                         
                                         js_set_var("prod_choice_response",JSON.stringify(prod_choice_rs_clear), function()
                                                    {
                                                    });

                                         
                                         });

                              
                              });
                   
                   }
                   if(document.getElementById("pru_my_diabetes_care_duration").value>6 || document.getElementById("pru_my_diabetes_care_hba1c_level").value>8)
                   {
                   alert("760");

                   
                   }else
                   {
                   console.log("menuController.swipeDirection"+menuController.swipeDirection);
                   
                   /*if(menuController.swipeDirection=="LTR")
                   {
                   menuController.loadPage("top_mysolutions_productchoice",0);
                   
                   }else
                   {
                   menuController.loadPage("top_mysolutions_maindetails",0)
                   
                   }*/
                   
                 
                   
                   
                   if((document.getElementById("pru_my_diabetes_care_duration").value=="" && document.getElementById("pru_my_diabetes_care_hba1c_level").value=="") && buttonClickResonse) //If condition added for internal defect for top navigation.
                   {
                   canSwipe=0;
                   console.log("DO Nothing");
                   return false;
                  
                   }else
                   {
                   canSwipe=1;
                   menuController.done(); //Changed by Paromita for on 28 Dec 2018 Def 6666
                   
                   }
                   }
                   
                   });
        
       
    }
    else
    {
        alert("759")
    }
    



}

function fnMsMedicalBenefitSelection(keyValue)
{
    setImgPathArray=[];
    setImgDivArray=[];

var medicalBenefitOption=document.getElementById("pmp_popup").getElementsByTagName('input');
var medicalButtonChoice=document.getElementById("pmp_popup").getElementsByTagName('button');
    
    for (var i = 0; i < medicalBenefitOption.length; ++i)
    {
        if (medicalBenefitOption[i].type == "radio")
        {
          var   idOfBenfit = medicalBenefitOption[i].id;
        
            if(document.getElementById(idOfBenfit).checked)
            {
                
               // benfitMedicalPlanName=document.getElementById(idOfBenfit+"."+"label").textContent;
                benfitMedicalPlanName=idOfBenfit;
                
            }
            
            
            
        }
    
    }
    
    if(medicalButtonChoice[1].id==keyValue)
    {
        // canSwipe=1;
        document.getElementById("pru_million_med_active").checked=true;
        fnMsOnClickPlansButton('al_sqs_buttons.prumy_medical_plus');
    }

   document.getElementById("al_sqs_buttons.prumy_medical_plus").disabled=false;
    canSwipe=1;
    buttonClickResonse=false;
   if(keyValue=="prumy_medical_plus_cancel_btn")//Added for enhancement of defect 7248
   {
    document.getElementById("plans_image.prumy_medical_plus").src=documentDirectoryPath+"Images/"+"prumy_medical_plus.png";  //original code shrikant and sourabh
       //setImgPathArray.push(documentDirectoryPath1+"Images/"+"prumy_medical_plus.png");
       // setImgDivArray.push(plansImageId);
      // selectedPlanName="";
     
       selectedPlanName="";
       
   }
    
    
    $(".mask").hide();
    $("#pmp_popup,.mask").fadeOut();
    
    //Shrikant
//    if(setImgPathArray.length > 0)
//    {
//        fnMPGetImageFileData(0,setImgPathArray,"plans_image.prumy_medical_plus");
//    }
}

/*******Added function for saving solutions validation***********/

function savingsBenefitSelection(keyValue)
{
    setImgPathArray=[];
    setImgDivArray=[];
    var medicalBenefitOption=document.getElementById("savings_popup").getElementsByTagName('input');
    var medicalButtonChoice=document.getElementById("savings_popup").getElementsByTagName('button');
    
    for (var i = 0; i < medicalBenefitOption.length; ++i)
    {
        if (medicalBenefitOption[i].type == "radio")
        {
            var   idOfBenfit = medicalBenefitOption[i].id;
            
            if(document.getElementById(idOfBenfit).checked)
            {
                
                // benfitMedicalPlanName=document.getElementById(idOfBenfit+"."+"label").textContent;
                benfitMedicalPlanName=idOfBenfit;
                
            }
            
            
            
        }
        
    }
    
    if(medicalButtonChoice[1].id==keyValue)
    {
        // canSwipe=1;
      //  document.getElementById("savings_growth_benefit").checked=true;
        document.getElementById("solutions_enrichDiv_benefit").checked=true
       
        fnMsOnClickPlansButton('al_sqs_buttons.savings_solution');
    }
    
    document.getElementById("al_sqs_buttons.savings_solution").disabled=false;
    canSwipe=1;
    buttonClickResonse=false;
    
    if(keyValue=="savings_solution_cancel_btn")//Added for enhancement of defect 7248
    {
        document.getElementById("plans_image.savings_solution").src=documentDirectoryPath+"Images/"+"savings_solution.png"; // original code shikant and sourabh and sachin
        //setImgPathArray.push(documentDirectoryPath1+"Images/"+"savings_solution.png");
       // setImgDivArray.push(plansImageId);
        selectedPlanName="";
      
    }
    
    
    $(".mask").hide();
    $("#savings_popup,.mask").fadeOut();
    //Shrikant
//    if(setImgPathArray.length > 0)
//    {
//        fnMPGetImageFileData(0,setImgPathArray,"plans_image.savings_solution");
//    }
    
}

function pruterm_premier(keyValue)
{
    setImgPathArray=[];
    setImgDivArray=[];
    var medicalBenefitOption=document.getElementById("pruterm_premier_popup").getElementsByTagName('input');
    var medicalButtonChoice=document.getElementById("pruterm_premier_popup").getElementsByTagName('button');
    //var slider_one_save = "";
    //var slider_two_save = "";
    slider_one = document.getElementById("myRange_1").value;
    slider_two = document.getElementById("myRange_2").value;
    
    
    console.log("slider_one-->",slider_one);
    console.log("slider_two-->",slider_two);
    
    if (eval(slider_two) > eval(slider_one))
    {
        console.log("### Solution checking 11111");
        if(keyValue=="pruterm_premier_ok_btn")
        {
        console.log("slider_one-->",slider_one);
        console.log("slider_two-->",slider_two);
        alert ("848");
        //$(".mask").hide();
        $("#pruterm_premier_popup,.mask").fadeIn();
            canSwipe=0;
        }
        
        else {
            
            console.log("Shivani Check Popup 1111");
            $(".mask").hide();
            $("#pruterm_premier_popup,.mask").fadeOut();
            canSwipe=1;
        }
    }
    
    
    
       if (eval(slider_two) == eval(slider_one))
        {
            console.log("### Solution checking 22222");
            console.log("slider_one-->",slider_one);
            console.log("slider_two-->",slider_two);
            fnMsOnClickPlansButton('al_sqs_buttons.pruterm_premier');
            $(".mask").hide();
            $("#pruterm_premier_popup,.mask").fadeOut();
            canSwipe=1;
            
            
        }

    
      if (eval(slider_two) < eval(slider_one))
      {
          console.log("### Solution checking 444444");
          console.log("slider_one-->",slider_one);
          console.log("slider_two-->",slider_two);
          //fnMsOnClickPlansButton('al_sqs_buttons.pruterm_premier');
          $(".mask").hide();
          $("#pruterm_premier_popup,.mask").fadeOut();
          canSwipe=1;
          
          
      }
    
   // else{
        
    console.log("### Solution checking 33333");
    document.getElementById("al_sqs_buttons.pruterm_premier").disabled=false;
    
    buttonClickResonse=false;
    
    if(keyValue=="pruterm_premier_cancel_btn")
    {
        
        console.log("### Solution checking ###");
        document.getElementById("plans_image.pruterm_premier").src=documentDirectoryPath+"Images/"+"pruterm_premier.png"; // original code shikant and sourabh and sachin
        selectedPlanName="";
        $(".mask").hide();
        $("#pruterm_premier_popup,.mask").fadeOut();
        canSwipe=1;
    }
    
    console.log("Shivani Check Popup 44444");
    
    //}
    
}


function ShowAgeForPTP(slider_one)
 {
    var show_age = eval(mainLifeDataObject["al_person_details.mlife.anb"]);
    //var slider_step_one = "";
     //document.getElementById('show_age_PTP').innerHTML=show_age;
     //document.getElementById("myRange_1").step = slider_step_one;
     slider_one = document.getElementById("myRange_1").value;
     var add_age_step_one = eval(slider_one) + show_age;
     console.log("add_age_step_one",add_age_step_one);
     document.getElementById('show_age_PTP').innerHTML = add_age_step_one + " (" + slider_one + " Years" + ")";
     console.log("slider_step_1",slider_one);
 }
function ShowAgeForPTPTwo(slider_two)
{
   var show_age_one = eval(mainLifeDataObject["al_person_details.mlife.anb"]);
   //var slider_step_two = "";
   
   //document.getElementById("myRange_2").step = slider_step_two;
   slider_two = document.getElementById("myRange_2").value;
    var add_age_step_two = eval(slider_two) + show_age_one;
   document.getElementById('show_age_PTP_Two').innerHTML= add_age_step_two + " (" + slider_two + " Years" + ")";
   console.log("slider_step_2",slider_two);
    
}



/***************End*********************************************/




function extra_bestBenefitSelection(keyValue)
{
    setImgPathArray=[];
    setImgDivArray=[];
    var medicalBenefitOption=document.getElementById("extra_best_popup").getElementsByTagName('input');
    var medicalButtonChoice=document.getElementById("extra_best_popup").getElementsByTagName('button');
    
    for (var i = 0; i < medicalBenefitOption.length; ++i)
    {
        if (medicalBenefitOption[i].type == "radio")
        {
            var   idOfBenfit = medicalBenefitOption[i].id;
            
            if(document.getElementById(idOfBenfit).checked)
            {
                
                // benfitMedicalPlanName=document.getElementById(idOfBenfit+"."+"label").textContent;
                benfitMedicalPlanName=idOfBenfit;
                
            }
            
            
            
        }
        
    }
    
    
    if(medicalButtonChoice[1].id==keyValue)
    {
        // canSwipe=1;
        document.getElementById("wealth_max_benefit").checked=true;
        fnMsOnClickPlansButton('al_sqs_buttons.pruprotect_xtra');
    }
    
    if(maxSolutionSelected=="al_sqs_buttons.pruprotect_xtra"){
       document.getElementById("al_sqs_buttons.pruprotect_xtra").disabled=false;
        
    }else {
        
          document.getElementById("al_sqs_buttons.prubest_gift").disabled=false;
    }
    
    
    canSwipe=1;
    buttonClickResonse=false;
    
    if(keyValue=="max_solution_cancel_btn")//Added for enhancement of defect 7248
    {
          selectedPlanName="";
        if(maxSolutionSelected=="al_sqs_buttons.pruprotect_xtra"){
           document.getElementById("plans_image.pruprotect_xtra").src=documentDirectoryPath+"Images/"+"pruprotect_xtra.png";
            
        }else {
            
            document.getElementById("plans_image.prubest_gift").src=documentDirectoryPath+"Images/"+"prubest_gift.png";
        }
        
        
       // document.getElementById("plans_image.pruprotect_xtra").src=documentDirectoryPath+"Images/"+"pruprotect_xtra.png"; // original code shikant and sourabh and sachin
        //setImgPathArray.push(documentDirectoryPath1+"Images/"+"savings_solution.png");
        // setImgDivArray.push(plansImageId);
      
        
    }
    
    
    $(".mask").hide();
    $("#extra_best_popup,.mask").fadeOut();
    //Shrikant
    //    if(setImgPathArray.length > 0)
    //    {
    //        fnMPGetImageFileData(0,setImgPathArray,"plans_image.savings_solution");
    //    }
    
}



/***************End*********************************************/












function fnMSDiabetesCareValidation(id)
{

    hlevelCheckFlag=false;
    diabetesDurationCheck=false;
    bothDiabetesAndHlev=false;
    document.getElementById("prumy_diabetes_care_ok_btn").disabled=false;
    
   if(document.getElementById(id).value.substring(0,1)=="0")
   {
    while(document.getElementById(id).value.charAt(0) === '0')
    {
        document.getElementById(id).value=document.getElementById(id).value.substring(1);
    
    }
       
       document.getElementById(id).value=document.getElementById(id).value;
   }
    
    
    
    
if(id=="pru_my_diabetes_care_duration")
{
    var durationValue=document.getElementById("pru_my_diabetes_care_duration").value;
    var containDotCheckD=durationValue.slice(-1);
    
    
if(containDotCheckD!="." && document.getElementById("pru_my_diabetes_care_duration").value > 6)
{
    
    diabetesDurationCheck=true;
    alert("760")
    return false;
}

}else if(id=="pru_my_diabetes_care_hba1c_level")
{
    var hba1cValue=document.getElementById("pru_my_diabetes_care_duration").value;
    var containDotCheckH=hba1cValue.slice(-1);

    
if(containDotCheckH!="." &&  document.getElementById("pru_my_diabetes_care_hba1c_level").value > 8)
{
   
    hlevelCheckFlag=true;
    alert("760")
    return false;
}

}




}
//Added by ankita on 27 Dec 2018 for defect 6651
function fnMSDiabetesCareValidationAfterOk(idDiabeticDuration,idHba1cLevel)
{
    var diabetesDurationCheckFlag = false;
    var hlevelCheck=false;
    
    if(idDiabeticDuration=="pru_my_diabetes_care_duration")
    {
        var durationValue=document.getElementById("pru_my_diabetes_care_duration").value;
        var containDotCheckD=durationValue.slice(-1);
        
        
        if(containDotCheckD!="." && document.getElementById("pru_my_diabetes_care_duration").value > 6)
        {
            
            diabetesDurationCheckFlag=true;
            
        }
        
    }
    if(idHba1cLevel=="pru_my_diabetes_care_hba1c_level")
    {
        var hba1cValue=document.getElementById("pru_my_diabetes_care_hba1c_level").value;
        var containDotCheckH=hba1cValue.slice(-1);
        
        
        if(containDotCheckH!="." &&  document.getElementById("pru_my_diabetes_care_hba1c_level").value > 8)
        {
            
            hlevelCheck=true;
            
        }
        
    }
    console.log("diabetesDurationCheckFlag:"+diabetesDurationCheckFlag);
    console.log("hlevelCheck:"+hlevelCheck);
    if(diabetesDurationCheckFlag == true || hlevelCheck == true)
    {
        canSwipe =0;
        $("#pru_my_diabetes_care_popup,.mask").fadeIn();
        alert("760");
        
        
        return false;
    }
    else{
         buttonClickResonse=false;
       canSwipe=1;
        $(".mask").hide();
        $("#pru_my_diabetes_care_popup,.mask").fadeOut();
    }
    
}


function fnMSDiabetesCareButtonOperation(keyValue)
{
    ArrayOfImagesPath=[];
    ArrayOfvaridDiv=[];
    var medicalButtonOption=document.getElementById("pru_my_diabetes_care_popup").getElementsByTagName('button');
   
   
    console.log("keyValue::"+keyValue+" medicalButtonOption[0].id"+medicalButtonOption[0].id +" medicalButtonOption[1].id"+medicalButtonOption[1].id);
    if(medicalButtonOption[0].id==keyValue)
    {
        if(document.getElementById("pru_my_diabetes_care_duration").value=="" &&  document.getElementById("pru_my_diabetes_care_hba1c_level").value=="")
        {
            diabetes_care_duration="";
            diabetes_care_hba1c_level="";
            
            alert("763");
            return false;
            
        }
       
        if(document.getElementById("pru_my_diabetes_care_hba1c_level").value<=0){
            
            document.getElementById("pru_my_diabetes_care_hba1c_level").value="";
            
        }
        
        if(document.getElementById("pru_my_diabetes_care_duration").value !="")
        {
            diabetsDuration=document.getElementById("pru_my_diabetes_care_duration").value;
        
        }else
        {
        
        alert("762")
            return false;
        
        
        }
        
        if(document.getElementById("pru_my_diabetes_care_hba1c_level").value !="")
        {
         hba1c_level=document.getElementById("pru_my_diabetes_care_hba1c_level").value;
           
        
        }else
        {
        
          alert("761")
             return false;
        
        }

    
    
    }else if(medicalButtonOption[1].id==keyValue)
    {
    
        diabetsDuration="";
        hba1c_level="";
        fnMsOnClickPlansButton('al_sqs_buttons.prumy_diabetes_care');//Added for new image issue in Nov.2020
        document.getElementById("pru_my_diabetes_care_duration").value="";
        document.getElementById("pru_my_diabetes_care_hba1c_level").value="";
        document.getElementById("plans_image.prumy_diabetes_care").src=documentDirectoryPath+"Images/"+"prumy_diabetes_care.png"; //original condition shikant and sourabh
       // ArrayOfImagesPath.push(documentDirectoryPath1 +"Images/"+"prumy_diabetes_care.png");
       // ArrayOfvaridDiv.push(plansImageId);
        selectedPlanName="";
        
       // fnMsOnClickPlansButton('al_sqs_buttons.prumy_diabetes_care');
    
      
    
    }
    
    
    
    
     document.getElementById("al_sqs_buttons.prumy_diabetes_care").disabled=false;
    fnMSDiabetesCareValidationAfterOk('pru_my_diabetes_care_duration','pru_my_diabetes_care_hba1c_level');
    //Shrikant
//    if(ArrayOfImagesPath.length > 0)
//    {
//        fnMPGetImageFileData(0,ArrayOfImagesPath,"plans_image.prumy_diabetes_care");
//    }
   
    
   
}


function toSolutionObject(solutionObject)
{
    var valiadSolution=[];
    var curr_dt = fnGetDateTimeStamp();
    var curr_dts = curr_dt.split(" ");
    var currnt_dt = curr_dts[0].split("-");
    var plansObj = {};
    var plansObj1={};
    var oneDay = 24 * 60 * 60 * 1000;
    var date4 = new Date(currnt_dt[0], eval(currnt_dt[1]) - 1, currnt_dt[2]); //Current Date
    
    for (var i = 0; i < solutionObject.length; ++i)
        if (solutionObject[i] !== undefined) plansObj[i] = solutionObject[i];
    
    
  var plans=  _.where(plansObj,{Channel_Name:Channel});
    
    for (var i = 0; i < plans.length; ++i)
        if (plans[i] !== undefined) plansObj1[i] = plans[i];
    
    
    for(var keys in plansObj1)
    {
        console.log(plansObj1[keys]["Solution_Name"]);
        console.log(plansObj1[keys]["Solution_Expiry_Date"]);
        console.log(plansObj1[keys]["Solution_Effective_Date"]);
        
        var new_expdts = plansObj1[keys]["Solution_Expiry_Date"].split(" ");
        var new_expdt = new_expdts[0].split("-");
        
        var new_effectdts = plansObj1[keys]["Solution_Effective_Date"].split(" ");
        var new_effect = new_effectdts[0].split("-");
        
        
        
        var date3 = new Date(new_expdt[0], new_expdt[1] - 1, new_expdt[2]); //Expiry Date
        var date5 = new Date(new_effect[0], new_effect[1] - 1, new_effect[2]);//Effective Date
        var diffDaysexp = Math.round((date3.getTime() - date4.getTime()) / (oneDay));
                
        var diffDate1 = Math.round((date4.getTime() - date5.getTime()) / (oneDay));
        var diffDate = Math.round((date3.getTime() - date5.getTime()) / (oneDay));
                                  
        
        if (diffDaysexp < 0)
        {
            //return false;
        }

       else if (diffDate1 < 0)
            {
                                      //return false;
            }
        else if(diffDate <0){
           // valiadSolution.push(plansObj1[keys]["Solution_Name"])
        }
        else
        {
            valiadSolution.push(plansObj1[keys]["Solution_Name"])
            
            
        }

        
    }
    
    console.log("valiadSolution"+valiadSolution);
    return valiadSolution;

}


function toSolutionObjectSequance(solution_sq)
{


    var sequancePlanArray=[];
     
    
     var sequencePlan= {};
     for (var i = 0; i <= solution_sq.length-1; ++i)
     if (solution_sq[i] !== undefined) sequencePlan[i] = solution_sq[i];
   //var dataX=toObject(solutions_sequence);
    
    
    
     var count=1;
     var arraycount="";
     for (var i in sequencePlan)
     {
     console.log(sequencePlan[i])
     console.log("Count is"+count);
         arraycount=count;
         var countStr=""+count;
         var plans=_.where(sequencePlan,{Image_Sequence:countStr}) ;
         console.log("@Search File"+plans[0])
         if(plans[0]!=undefined && plans[0]!="" && plans[0]!='undefined')
         {
         var plansName =plans[0].Solution_Name;
         sequancePlanArray.push(plansName);
         }
    
     count++;
     }
    
    return sequancePlanArray;
    
    



}

function fnNotAllowedZero()
{
    console.log("TEXT BOX Value"+document.getElementById("pru_my_diabetes_care_hba1c_level").Value)
    
}

 



