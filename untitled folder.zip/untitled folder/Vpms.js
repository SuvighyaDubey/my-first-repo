var arrPDS = [];
var VPMSArrayForEachChoiceFunctionCancerX = [];
var arrComparsion = [];
var FundCode = {};

var jsonProduct={}

var iRiderCountPruAllocator = 0;
var iRiderCountPruBooster = 0;

var benefit_flag_update = "0";

var isSIOCampaignFlag="Yes";
var isSIOCampaignFlagReserve="No";
var obj_loading_solutions={};
/*********************************Following Varible for SB accumulator by Sachin T.****************************************************/
var bundleCurrentPlan="";
var callFromOther="";
var bundlePage="";
var bundleJsonOutput="";
var bundleFundRes="";
var bunddleFundArray="";
var bundleGlobalFund=""
var iSelectedBundleRiderCount="";
var callfromfromBundleOutput=false;
 var dataHighLow="";
var objLoadingToSetForOutput;//added by ankita on 9 April 2019 for defect 7090
var obj_solution="";
var campaignProductName="";
var campaignExpDate=""; // added by abhilash
var campaignEffeDate="";// added by abhilash
var canEnterCampaign="";// added by abhilash
var isAlertFromVPMS="No"; //vpms and TFS
var investmentPremiumVal_next = 0; // Added by Shivani for Def - 134 enhancement for PRULink Supreme

//Flag and variable for target sustainability

var bTagetSusEffective = "Yes"; // Was used for Effective date handling for PRUsignature income now not in use has been defaulted to Yes.
var targetSustainabilityFlag="No";  // Used for Proceed with reduce term changes to directly preview the output
var targetMaximumPremium="No"; //Used if existing budgeted Premium is greater than the new maximum Premium change budgeted premium to the new premium
var szPRUsaverExists = "No"; //Used to set the excess value of budget premium in saver or PRUallocater
var szPRUsaverValue = 0;
var szFullPayIndicator  = "No";
var szPRUallocatorPremiumAvailable  = "No"; //Used if initial or Exiting PRUallocator value exists
var szNegativeCashValueFlag = "No"; // Used for Def 7717 to display the Negative Cash value error only once
var szOkToAmendCVFlag = "No";//added by ankita on 23 jan 2020 for million cover product
var newPRUAllocatorPremiumPMC="";

var szBasicPremium = 0;
var szOldAllocatorValueIfNA = 0;




var PlanCode = {"PRUmy treasure":"SP01","PRUmillion cover":"ILS3","PRUsignature income":"IL07","PRUwith you":"ILS2","PRUSignature Booster":"SP02","PRUsignature infinite":"ILS6","PRUValue Gain":"TR14","PRUwealth gain plus":"TR02","PRUcancer X":"TT03","PRUgrowth":"TR03","PRUsignature prime":"SP03","PRUsignature USD":"IL05","RetireGuard (SP)":"4PIACB","PRUsignature":"7PYB","PRUretirement growth":"4PIAC","PRUcash double reward":"6PDB","PRUcash":"6PCB","PRUEasy Protect":"TR16","PRUMillion Cover 2.0":"IL14","PRUMy Gift":"IL11","PRUElite Invest":"IL21","PRUSignature GrowthPlus":"IL22","PRUEnhanced Cover":"IL24","PRULady_PRL":"TR37","PRUSignature Plus":"IL27"};//added retireguard by ankita on 4 sept 2019//"PRUcash double reward":"6PDB" // Added condition for PRUMy GIft



var oldPlanCode = {"PRUsignature infinite":"IL06"};
var targetOpt={"70":"A70","100":"A100","80":"A80","60":"A60","20":"Y20","90":"A90","65":"A65","75":"A75","85":"A85","95":"A95"};//Added A90 by ankita for PRULink Cover product on 4 April 2019//Added 65,75,85,95 for target sus CR may by Sachin T.
var return_resonse_data=""; //TODO

var insuranceTypeCode={"individual":"OTH","employee":"EER","keyman":"KEYM","partnership":"PART","Business Loan Insurance (for Company/LLP)":"EER","Business Loan Insurance (for Sole Proprietorship/Partnership)":"SELF","Spouse":"SPOU"};//EER and SELF added by ankita on 4 may 2020 for new insurance type
var arrModernFamilyList={"Brother":"BRO","Nephew":"NENC","Uncle":"UNCL","Grandfather":"GRPA","Grandchildren":"GCLI","Cousin Brother":"COUB","Step Father":"STFA","Step Child":"SCHL","Sister":"SIS","Niece":"NENC","Aunty":"AUNT","Grandmother":"GRPA","Cousin Sister":"COUS","Step Mother":"STMO","Spouse":"SPOU","Legal Guardian":"GUAR","Parent":"PRNT","Child":"CHILD"};//change grandchild to grandchilder by ankita on 22 april 2022 for modern family CR

/*start
Common header to add comment if added new product condition and also specify that product is similar to which product

condition for product name PRUSignature Vanguard added by ankita and is similar to PRUWealth plus and PRUSignature Assure product for july release.
condition for product name PRUSignature Harvest Plus added by ankita and is similar to PRUSignature Harvest product for september release.
 condition for product name PRUSignature Ace added by ankita and is similar to PRUSignature Invest product with 2 new fields added on UI named Loading Premium and target sustainability age on 12 sept 2022 for october release
 condition for product name PRUElite Invest added by ankita and is similar to PRULink Supreme product for april release 2023.
 //Added PRUEnhanced Cover similar to PRUMillion Cover 2.0 by Pradnya for July 2023 release
 conditions for PRUWealth Enrich added by Sachin T. for August 2023 Release.
 *Pradnya: added condition for PRULady_PRL for jan24 release*
 Pradnya: added PRULink Supreme Plus product for march24 release.
 Pradnya: added conditions for PRUSignature Plus for june24 release 

end*/


/***************************************************************************************/
function fnGetRiderChoice(CheckShift,currentPlan,payoutperiodId,callFromFlag)
{
    console.log("inside fnGetRiderChoice");

    var jsonRideIds ={"Payor Basic":"enhanced_prupayor_basic","PRUpayor basic":"enhanced_prupayor_basic","Payor Saver":"enhanced_prupayor_saver","PRUpayor saver":"enhanced_prupayor_saver","Parent Payor Basic":"pruparent_payor_basic","2Parent Payor Basic":"pruparent_double_payor_basic","Parent Payor Saver":"pruparent_payor_saver","2Parent Payor Saver":"pruparent_double_payor_saver","Spouse Payor Basic":"pruspouse_payor_basic","Spouse Payor Saver":"pruspouse_payor_saver","Acci Guard Plus":"pruacci_guard","Acci Med Plus":"pruacci_med","Acci Income Plus":"pruacci_income","Essential Child Plus":"enhanced_prue_child","PRUsaver kid/ PRUsaver":"prusaver_kid","Infant Care Plus":"enhanced_infant_care","PRUPayor Basic":"enhanced_prupayor_basic","PRUPayor Saver":"enhanced_prupayor_saver","Essential Child Plus\/ Crisis Care":"enhanced_prue_child","PRUSaver Kid\/ PRUSaver":"prusaver_kid","Crisis Guard 2.0":"crisis_guard","Level SA Rider 2.0":"level_sa_rider","Payor Basic 2.0":"enhanced_prupayor_basic","Payor Saver 2.0":"enhanced_prupayor_saver","Spouse Payor Basic 2.0":"pruspouse_payor_basic","Spouse Payor Saver 2.0":"pruspouse_payor_saver","Parent Payor Basic 2.0":"pruparent_payor_basic","Parent Payor Saver 2.0":"pruparent_payor_saver","Crisis Care 2.0":"crisis_care","Refund Of Premium - 100%":"rop_100","Refund Of Premium - 106%":"rop_106","PRULady Cancer Income":"prulady_cancer_income","Double Enhancer":"double_enhancer_cash","PRULegacy":"prulegacy_cash","PRUSaver (Before age 70)":"prusaver","PRUPayor Basic Plus":"enhanced_prupayor_basic","PRUPayor Saver Plus":"enhanced_prupayor_saver","PRUSpouse Payor Basic Plus":"pruspouse_payor_basic","PRUSpouse Payor Saver Plus":"pruspouse_payor_saver","Life Assured Waiver Plus":"pruwaiver","Disability Care":"disability_care","SA Booster":"incremental_sa_benefit","PRUWaiver Plus":"pruwaiver","Spouse Waiver Plus":"spouse_waiver","Parent Waiver Plus":"parent_waiver","PRUsaver (Max entry age 70 n.b.)":"prusaver","2 Parent Payor Basic (P1)":"pruparent_double_payor_basic","2 Parent Payor Saver (P1)":"pruparent_double_payor_saver","PRUMillion Med 2.0":"prumillion_med_2_0","PRUMillion Med Booster 2.0":"prumillion_med_booster_2_0"};//last three keys are added by ankita on 7 May 2019 as we are getting this name from VPMS response//added PRUSaver (Before age 70) by ankita on 4 dec 2020//mom_and_baby_care condition added by ankita on 5 dec 2022 for pruwith you product and to modify if vpms come replace mom_and_baby_care with enhanced_infant_care//enhanced_infant_care changed by ankita for infant care plus id
    if(currentPlan == "PRUcash double reward" || currentPlan == "PRUcash")
    {
        jsonRideIds["Spouse Waiver"]="spouse_waiver_cash";
	jsonRideIds["Parent Waiver"]="parent_waiver_cash";
    jsonRideIds["PRUWaiver"]="pruwaiver_cash";
	jsonRideIds["Cash Booster"]="cashbooster";
    }


    var todayDate  = new Date();
    var todayYear  = todayDate.getFullYear();
    var todayMonth = todayDate.getMonth() + 1;
    var todayDay   = todayDate.getDate();
    var szChannelName = "AGY";
    var szSubChannelName = "AGY";//chnaged by ankita as changes sent by VPMS on 03 May 2018
    
    localStorage.setItem("current_plan",currentPlan);
    
    console.log("currentPlan:"+currentPlan);
    
    if(todayDay < 10)
    {
        todayDay = "0" + todayDay
    }
    if(todayMonth < 10)
    {
        todayMonth = "0" + todayMonth
    }
    console.log("subChannelTypeForAgencyBancaRepls:--" + subChannelTypeForAgencyBancaRepls + " channelTypeForAgencyBancaRepls:--" +channelTypeForAgencyBancaRepls);
    if(channelTypeForAgencyBancaRepls == "banca")
    {
        szChannelName = "SCB";
        if(subChannelTypeForAgencyBancaRepls =="SCB_STF")
        {
            //szSubChannelName ="SCBSTF"
            szSubChannelName ="STF"//chnaged by ankita as changes sent by VPMS on 03 May 2018
        }
        else
        {
            //szSubChannelName ="SCBFSC"
            szSubChannelName ="FSC"//chnaged by ankita as changes sent by VPMS on 03 May 2018
        }
    }
    else if(channelTypeForAgencyBancaRepls == "uob")
    {
        szChannelName = "UOB";
        //szSubChannelName = subChannelTypeForAgencyBancaRepls;
        szSubChannelName = "";//chnaged by ankita as changes sent by VPMS on 03 May 2018
        //szSubChannelName = subChannelTypeForAgencyBancaRepls;//added by ankita on 11 may 2020 as changes sent thorugh email dated on 8 may 2020 by chui san
        //console.log("subChannelTypeForAgencyBancaRepls:"+subChannelTypeForAgencyBancaRepls);
        /*if(subChannelTypeForAgencyBancaRepls == "BB")
        {
            szSubChannelName = "PFS";//personal banking
        }*/
        /*if(subChannelTypeForAgencyBancaRepls == "CB" || subChannelTypeForAgencyBancaRepls == "BB")
        {
            szSubChannelName = "BCB";//Business/ Commercial Banking
        }
        else
        {
            szSubChannelName = "PFS";
        }*/
    }
   
    //to remove temporary added on 22 oct 2020
    /*if(currentPlan == "PRUSignature Treasure")
    {
       currentPlan = "PRUSignature Reserve";
       //szChannelName = "UOB";
       //szSubChannelName = "";
    }*/
    
//    if(currentPlan == "PRUSignature Assure")
//    {
//       currentPlan = "PRULink Cover";
//       szChannelName = "UOB";
//       szSubChannelName = "";
//    }
    
//    if(currentPlan == "PRUAll Care")
//    {
//       currentPlan = "PRUCash Enrich";
//       szChannelName = "AGY";
//       szSubChannelName = "";
//    }
    
//        if(currentPlan == "PRUSignature GrowthPlus")
//        {
//           currentPlan = "PRUElite Invest";
//           szChannelName = "AGY";
//           szSubChannelName = "";
//        }
    
    
    
    console.log("currentPlan::"+currentPlan);
    var Current_date_dat = "";
    Current_date_dat = todayYear.toString()+todayMonth.toString()+todayDay.toString();
    
    var inceptionDate=obj_prochoice["al_sqs_details.Inception_dt"].split("/");
    
    if(parseInt(inceptionDate[0]) < 10)
    {
        inceptionDate[0] = "0" + parseInt(inceptionDate[0]);
    }
    if(parseInt(inceptionDate[1]) < 10)
    {
        inceptionDate[1] = "0" + parseInt(inceptionDate[1]);
    }

    var querySelect=fnGetProductMaster(currentPlan)
    querySelect.execute(function (jsonProductresponse)

                        {
    js_get_var("prod_choice_response",function(prod_choice_res)
               {
               js_get_var("main_life_response",function(main_life_response)
                          {
                          js_get_var("sec_life_response",function(sec_life_response)
                                     {
                                     js_get_var("third_life_response",function(third_life_response)
                                                {
                                                js_get_var("beneft_selection_response", function(ben_selection_res)
                                                    {
                                                       js_get_var("VPMSRiderJson",function(VPMSRiderJson)
                                                                  {
                                                                  js_get_var("fnSetPayoutPeriodDropdownCallFrom",function(fnSetPayoutPeriodDropdownCallFrom)
                                                                  {
                                                           var obj_ben_sel="";
                                                           if(ben_selection_res != "" && ben_selection_res != null && ben_selection_res != "null"  && ben_selection_res != "(null)")
                                                           {
                                                            obj_ben_sel = JSON.parse(ben_selection_res);
                                                           }
                                                                   console.log("obj_ben_sel-->"+JSON.stringify(obj_ben_sel));
                                                    var objmain_life_response=JSON.parse(main_life_response);
                                                    var dob="";
                                                    var objsec_life_response="";
                                                    var objthird_life_response="";
                                                    if(objmain_life_response["al_person_details.pre_natal_child_flg"] == "Yes")
                                                    {
                                                        dob = objmain_life_response["al_person_details.mlife.expected_delivery_dt"].split("/");
                                                    }
                                                    else
                                                    {
                                                        dob =objmain_life_response["al_person_details.mlife.dob"].split("/");
                                                    }
                                                    var sec_dob="";
                                                    var third_dob="";
                                                    var occ_sec="";
                                                    var occ_third="";
                                                    if (sec_life_response != "" && sec_life_response != null && sec_life_response != "null" && sec_life_response != "(null)")
                                                    {
                                                        objsec_life_response=JSON.parse(sec_life_response);
                                                        var dob_sec =objsec_life_response["al_person_details.slife.dob"].split("/");
                                                        sec_dob=dob_sec[2]+dob_sec[1]+dob_sec[0];
                                                        occ_sec=getOccupationCodeAndNOB(objsec_life_response["al_employee_details.slife.occupation"],"","occupation");
                                                    }
                                                    if (third_life_response != "" && third_life_response != null && third_life_response != "null" && third_life_response != "(null)")
                                                    {
                                                        objthird_life_response=JSON.parse(third_life_response);
                                                        var dob_third =objthird_life_response["al_person_details.tlife.dob"].split("/");
                                                        third_dob=dob_third[2]+dob_third[1]+dob_third[0];
                                                        occ_third=getOccupationCodeAndNOB(objthird_life_response["al_employee_details.tlife.occupation"],"","occupation");
                                                    }


                                                    var obj_prochoice="";
                                                    obj_prochoice=JSON.parse(prod_choice_res);
                                                console.log("obj_prochoice --->"+JSON.stringify(obj_prochoice));
                                                                   console.log("obj_prochoice Ins type--->"+objmain_life_response["al_person_details.mlife.insu_type"]);
                                                    
                                                    var pagedata={
                                                                  "setvar":
                                                                  {
                                                                        "A_Search_str":"",
                                                                        "A_Insured_DOB_01_dat":dob[2]+dob[1]+dob[0],
                                                                        "A_Insured_DOB_02_dat":sec_dob,
                                                                        "A_Insured_DOB_03_dat":third_dob,
                                                                        "A_Code_Occupation_01_key":getOccupationCodeAndNOB(objmain_life_response["al_employee_details.mlife.occupation"],"","occupation"),


                                                                        "A_Code_Occupation_02_key":occ_sec,
                                                                        "A_Code_Occupation_03_key":occ_third,

                                                                        "A_Policy_Inception_dat":inceptionDate[2]+inceptionDate[1]+inceptionDate[0],
                                                           
                                                                        "A_Master_Premium_Term_key":"",
                                                                        "A_Insured_Name_01_str":objmain_life_response["al_person_details.mlife.first_name"],
                                                                        "A_Insured_Name_02_str":objsec_life_response["al_person_details.slife.first_name"],
                                                                        "A_Insured_Name_03_str":objthird_life_response["al_person_details.tlife.first_name"],

                                                                        "A_Code_Gender_01_key":objmain_life_response["al_person_details.mlife.gender"]=="Male"?"M":"F",
                                                                        "A_Code_Gender_02_key":objsec_life_response["al_person_details.slife.gender"]=="Male"?"M":"F",
                                                                        "A_Code_Gender_03_key":objthird_life_response["al_person_details.tlife.gender"]=="Male"?"M":"F",
                                                                        "A_Code_Smoker_Status_01_key":objmain_life_response["al_person_details.mlife.smoke_status"]=="Smoker"?"S":"N",
                                                                        "A_Code_Smoker_Status_02_key":objsec_life_response["al_person_details.slife.smoke_status"]=="Smoker"?"S":"N",
                                                                        "A_Code_Smoker_Status_03_key":objthird_life_response["al_person_details.tlife.smoke_status"]=="Smoker"?"S":"N",
                                                                        "A_Code_Natural_Business_01_key":objmain_life_response["al_employee_details.mlife.nature_of_business"],
                                                                        "A_Code_Natural_Business_02_key":objsec_life_response["al_employee_details.slife.nature_of_business"],
                                                                        "A_Code_Natural_Business_03_key":objthird_life_response["al_employee_details.tlife.nature_of_business"],

                                                                        "A_Code_ILP_Fund_Source_key":"LF",



                                                                        "A_Rating_Date_dat":Current_date_dat,//changed by ankita on 3 July 2018(change in inputs email sent by VPMS) for defect 5781
                                                                        "A_Policy_Proposal_dat":Current_date_dat,//changed by ankita on 3 July 2018(change in inputs email sent by VPMS) for defect 5781
                                                                        "A_Code_Channel_key":szChannelName,
                                                                        "A_Code_Sub_Channel_key":szSubChannelName,
                                                                        "A_Master_Payout_Age_key":"",
                                                                        "A_Master_Payout_Frequency_key":"",
                                                                        "A_Master_Payout_Period_key":"",
                                                                        "A_Sustain_Age_High_int":"",
                                                                        "A_Sustain_Age_Low_int":"",
                                                                        "A_Master_Campaign_key":"",
                                                                        "A_Master_ILP_TargetSust_key":"",//added by ankita on 27 April 2019
                                                                        "A_Code_Insurance_Type_key":insuranceTypeCode[objmain_life_response["al_person_details.mlife.insu_type"]],
                                                                        "A_Code_Religion_key":"",//added by ankita on 9 July 2019
                                                                        "A_Master_Full_Coverage_Age_key":"",
                                                                             "A_Tran_Code_key":"NB"//added by ankita for change in potd-29239 on 4 june 2021
                                                                  
                                                                   },
                                                                  "VPMSFunctionNameInSequence":["P_Fetch_Benefit_out"],
                                                                  "VPMSCallType":"compute"

                                                                }
                                                                //added by ankita for PAMBNEWP-8825
                                                                             
                                                                             //
                                                                  //added by ankita to change logic of passing code to VPMS PRUSIgnature Vanguard onwards
                                                                if(currentPlan !== "PRUSignature Protect" && currentPlan !== "EssentialLife (SP)")//Added by sachin tupe for insu type
                                                                             {
                                                                             if(objmain_life_response["al_person_details.mlife.insu_type"]==="Business Loan Insurance (for Company/LLP)")
                                                               {
                                                                             pagedata["setvar"]["A_Code_Insurance_Type_key"]="BLCO"
                                                                             
                                                               }
                                                                             if(objmain_life_response["al_person_details.mlife.insu_type"]==="Business Loan Insurance (for Sole Proprietorship/Partnership)")
                                                                             {
                                                                                           pagedata["setvar"]["A_Code_Insurance_Type_key"]="BLSP"
                                                                                           
                                                                             }
                                                                             
                                                                             }
                                                                             
                                                                   //added by ankita for modern family CR
                                                                      if(objmain_life_response["al_person_details.mlife.insu_type_header"]=="non_business_purpose")
                                                                    {
                                                                             
                                                                             if(objmain_life_response["al_sqs_details.sec_parti_flag"] == "No")
                                                                             {
                                                                             pagedata["setvar"]["A_Code_Insurance_Type_key"]="SELF"
                                                                             
                                                                             }
                                                                             else if(objmain_life_response["al_sqs_details.sec_parti_flag"] == "Yes")
                                                                             {
                                                                             pagedata["setvar"]["A_Code_Insurance_Type_key"]=arrModernFamilyList[objsec_life_response["al_person_details.slife.relationship"]];
                                                                             }
                                                                    }
                                                                             
                                                                             //added by ankita on 7 dec 2020 as per changes requested for POTD-23607
                                                                             if(obj_prochoice["al_sqs_details.payment_backdate"]=="Yes")
                                                                             {
                                                                                 pagedata["setvar"]["A_Rating_MAR_dat"]=inceptionDate[2]+inceptionDate[1]+inceptionDate[0];
                                                                                 pagedata["setvar"]["A_Policy_Proposal_dat"]=inceptionDate[2]+inceptionDate[1]+inceptionDate[0];
                                                                             }
                                                                             else
                                                                             {
                                                                                pagedata["setvar"]["A_Rating_MAR_dat"]=Current_date_dat;
                                                                                pagedata["setvar"]["A_Policy_Proposal_dat"]=Current_date_dat;
                                                                             }
                                                           
                                                var pagedataChoiceFunction={
                                                "setvar":
                                                {
                                                
                                                "A_Search_str":"",
                                                "A_Policy_Inception_dat": inceptionDate[2]+inceptionDate[1]+inceptionDate[0],
                                                "A_Insured_DOB_01_dat":dob[2]+dob[1]+dob[0],
                                                "A_Insured_DOB_02_dat":sec_dob,
                                                "A_Insured_DOB_03_dat":third_dob,
                                                "A_Master_Premium_Term_key":"",
                                                "A_Rating_Date_dat":Current_date_dat,
                                                "A_Master_Payout_age_key":"",
                                                "A_Code_Channel_key":szChannelName,
                                                "A_Code_Sub_Channel_key":szSubChannelName,
                                                "A_Master_Payout_age_key":"",
                                                "A_Master_Policy_Term_key":"",
                                                "A_Master_Premium_Term_key":"",
                                                "A_Rating_MAR_dat":Current_date_dat,
                                                "A_Code_Insurance_Type_key":insuranceTypeCode[objmain_life_response["al_person_details.mlife.insu_type"]],
                                                "A_Code_Religion_key":"",//added by ankita on 9 July 2019
                                                "A_Master_Full_Coverage_Age_key":""
                                                },
                                                "VPMSCallType":"choice"
                                                
                                                }
                                                                             //added by ankita for modern family CR
                                                                               if(objmain_life_response["al_person_details.mlife.insu_type_header"]=="non_business_purpose")
                                                                             {
                                                                                      
                                                                                      if(objmain_life_response["al_sqs_details.sec_parti_flag"] == "No")
                                                                                      {
                                                                                      pagedataChoiceFunction["setvar"]["A_Code_Insurance_Type_key"]="SELF"
                                                                                      
                                                                                      }
                                                                                      else if(objmain_life_response["al_sqs_details.sec_parti_flag"] == "Yes")
                                                                                      {
                                                                                      pagedataChoiceFunction["setvar"]["A_Code_Insurance_Type_key"]=arrModernFamilyList[objsec_life_response["al_person_details.slife.relationship"]];
                                                                                      }
                                                                             }
                                                               //added by ankita for PAMBNEWP-8825
                                                                             //added by ankita to change logic of passing code to VPMS PRUSIgnature Vanguard onwards
                                                                             if(currentPlan !== "PRUSignature Protect" && currentPlan !== "EssentialLife (SP)")//Added by sachin tupe for insu type
                                                                             {
                                                                             
                                                                             if(objmain_life_response["al_person_details.mlife.insu_type"]==="Business Loan Insurance (for Company/LLP)")
                                                               {
                                                                             pagedataChoiceFunction["setvar"]["A_Code_Insurance_Type_key"]="BLCO"
                                                                             
                                                               }
                                                                             if(objmain_life_response["al_person_details.mlife.insu_type"]==="Business Loan Insurance (for Sole Proprietorship/Partnership)")
                                                                             {
                                                                                           pagedataChoiceFunction["setvar"]["A_Code_Insurance_Type_key"]="BLSP"
                                                                                           
                                                                             }
                                                                             }
                                                 //added by ankita on 7 dec 2020 as per changes requested for POTD-23607
                                                  if(obj_prochoice["al_sqs_details.payment_backdate"]=="Yes")
                                                  {
                                                      pagedataChoiceFunction["setvar"]["A_Rating_MAR_dat"]=inceptionDate[2]+inceptionDate[1]+inceptionDate[0];
                                                      pagedataChoiceFunction["setvar"]["A_Policy_Proposal_dat"]=inceptionDate[2]+inceptionDate[1]+inceptionDate[0];
                                                  }
                                                 else
                                                 {
                                                    pagedataChoiceFunction["setvar"]["A_Rating_MAR_dat"]=Current_date_dat;
                                                    pagedataChoiceFunction["setvar"]["A_Policy_Proposal_dat"]=Current_date_dat;
                                                 }
                                                           
                                                if(currentPlan == "PRUwith you")
                                               {
                                                  pagedata["setvar"]["A_Master_Campaign_key"]=vpmsEaseCampaignCode;
                                               }
                                                           if(currentPlan == "PRUGlobal Series")
                                                           {
                                                           pagedata["setvar"]["A_Currency_key"]=obj_prochoice["al_sqs_details.foreign_currency"];//added by ankita on 11 April to get currency from dropdown value selected
                                                           }
                                                if(objmain_life_response["al_sqs_details.sec_parti_flag"] == "No")
                                                {
                                                
                                                pagedata["setvar"]["A_Code_Smoker_Status_02_key"]="";
                                                pagedata["setvar"]["A_Code_Gender_02_key"]="";
                                                pagedata["setvar"]["A_Insured_DOB_02_dat"]="";
                                                pagedata["setvar"]["A_Insured_Name_02_str"]="";
                                                pagedata["setvar"]["A_Code_Nature_Business_02_key"]="";
                                                pagedata["setvar"]["A_Code_Occupation_02_key"]="";
                                                }
                                                if(objsec_life_response["al_sqs_details.third_parti_flg"] == "No")
                                                {
                                                
                                                pagedata["setvar"]["A_Code_Smoker_Status_03_key"]="";
                                                pagedata["setvar"]["A_Code_Gender_03_key"]="";
                                                pagedata["setvar"]["A_Insured_DOB_03_dat"]="";
                                                pagedata["setvar"]["A_Insured_Name_03_str"]="";
                                                pagedata["setvar"]["A_Code_Nature_Business_03_key"]="";
                                                pagedata["setvar"]["A_Code_Occupation_03_key"]="";
                                                }
                                                                  console.log("szSubChannelName:"+szSubChannelName+"szChannelName:"+szChannelName);
                                                var pagedata1={
                                                                    "setvar":
                                                                    {
                                                                        "A_Search_str":"",
                                                                        "A_Code_Sub_Channel_key":szSubChannelName,
                                                                        "A_Code_Channel_key":szChannelName,
                                                                        "A_Code_Insurance_Type_key":insuranceTypeCode[objmain_life_response["al_person_details.mlife.insu_type"]],
                                                                        "A_Code_Religion_key":"",//added by ankita on 9 July 2019
                                                                        "A_Master_Full_Coverage_Age_key":""
                                                                  

                                                                    },
                                                                    "VPMSFunctionNameInSequence":["A_Master_Product_Master_key"],
                                                                    "VPMSCallType":"choice"

                                                                  }
                                                                             //added by ankita for modern family CR
                                                                                                                                                          if(objmain_life_response["al_person_details.mlife.insu_type_header"]=="non_business_purpose")
                                                                                                                                                        {
                                                                                                                                                                 
                                                                                                                                                                 if(objmain_life_response["al_sqs_details.sec_parti_flag"] == "No")
                                                                                                                                                                 {
                                                                                                                                                                 pagedata1["setvar"]["A_Code_Insurance_Type_key"]="SELF"
                                                                                                                                                                 
                                                                                                                                                                 }
                                                                                                                                                                 else if(objmain_life_response["al_sqs_details.sec_parti_flag"] == "Yes")
                                                                                                                                                                 {
                                                                                                                                                                 pagedata1["setvar"]["A_Code_Insurance_Type_key"]=arrModernFamilyList[objsec_life_response["al_person_details.slife.relationship"]];
                                                                                                                                                                 }
                                                                                                                                                        }
                                                                //added by ankita for PAMBNEWP-8825
                                                                             //added by ankita to change logic of passing code to VPMS PRUSIgnature Vanguard onwards
                                                                              if(currentPlan !== "PRUSignature Protect" && currentPlan !== "EssentialLife (SP)")//Added by sachin tupe for insu type
                                                                             {
                                                                             if(objmain_life_response["al_person_details.mlife.insu_type"]==="Business Loan Insurance (for Company/LLP)")
                                                               {
                                                                             pagedata1["setvar"]["A_Code_Insurance_Type_key"]="BLCO"
                                                                             
                                                               }
                                                                             if(objmain_life_response["al_person_details.mlife.insu_type"]==="Business Loan Insurance (for Sole Proprietorship/Partnership)")
                                                                             {
                                                                                           pagedata1["setvar"]["A_Code_Insurance_Type_key"]="BLSP"
                                                                                           
                                                                             }
                                                                             }
                                                                             
                                               //added by ankita on 7 dec 2020 as per changes requested for POTD-23607
                                               if(obj_prochoice["al_sqs_details.payment_backdate"]=="Yes")
                                               {
                                                   pagedata1["setvar"]["A_Rating_MAR_dat"]=inceptionDate[2]+inceptionDate[1]+inceptionDate[0];
                                                   pagedata1["setvar"]["A_Policy_Proposal_dat"]=inceptionDate[2]+inceptionDate[1]+inceptionDate[0];
                                               }
                                             else
                                             {
                                                pagedata1["setvar"]["A_Rating_MAR_dat"]=Current_date_dat;
                                                pagedata1["setvar"]["A_Policy_Proposal_dat"]=Current_date_dat;
                                             }
                                                                             
                                                           
                                                                 
                                                  console.log("pagedata pagedata1 --->"+JSON.stringify(pagedata1));
                                                var pagedataFunds={
                                                                "setvar":
                                                                {
                                                                "A_Search_str":"",
                                                                "A_Code_ILP_Fund_Source_key":"LF",
                                                                "A_Policy_Inception_dat": inceptionDate[2]+inceptionDate[1]+inceptionDate[0],
                                                                "A_Insured_DOB_01_dat":dob[2]+dob[1]+dob[0],
                                                                "A_Code_Insurance_Type_key":insuranceTypeCode[objmain_life_response["al_person_details.mlife.insu_type"]],
                                                                "A_Code_Religion_key":"",//added by ankita on 9 July 2019
                                                                "A_Master_Full_Coverage_Age_key":"",
                                                                "A_Rating_MAR_dat":Current_date_dat
                                                                },
                                                                "VPMSFunctionNameInSequence":["A_Master_ILP_Fund_key"],
                                                                "VPMSCallType":"choice"
                                                
                                                                }
                                                                             //added by ankita for modern family CR
                                                                                                                                                          if(objmain_life_response["al_person_details.mlife.insu_type_header"]=="non_business_purpose")
                                                                                                                                                        {
                                                                                                                                                                 
                                                                                                                                                                 if(objmain_life_response["al_sqs_details.sec_parti_flag"] == "No")
                                                                                                                                                                 {
                                                                                                                                                                 pagedataFunds["setvar"]["A_Code_Insurance_Type_key"]="SELF"
                                                                                                                                                                 
                                                                                                                                                                 }
                                                                                                                                                                 else if(objmain_life_response["al_sqs_details.sec_parti_flag"] == "Yes")
                                                                                                                                                                 {
                                                                                                                                                                 pagedataFunds["setvar"]["A_Code_Insurance_Type_key"]=arrModernFamilyList[objsec_life_response["al_person_details.slife.relationship"]];
                                                                                                                                                                 }
                                                                                                                                                        }
                                                              //added by ankita for PAMBNEWP-8825
                                                                             //added by ankita to change logic of passing code to VPMS PRUSIgnature Vanguard onwards
                                                                              if(currentPlan !== "PRUSignature Protect" && currentPlan !== "EssentialLife (SP)")//Added by sachin tupe for insu type
                                                                             {
                                                                             if(objmain_life_response["al_person_details.mlife.insu_type"]==="Business Loan Insurance (for Company/LLP)")
                                                               {
                                                                             pagedataFunds["setvar"]["A_Code_Insurance_Type_key"]="BLCO"
                                                                             
                                                               }
                                                                             if(objmain_life_response["al_person_details.mlife.insu_type"]==="Business Loan Insurance (for Sole Proprietorship/Partnership)")
                                                                             {
                                                                                           pagedataFunds["setvar"]["A_Code_Insurance_Type_key"]="BLSP"
                                                                                           
                                                                             }
                                                                             }
                                                    //added by ankita on 7 dec 2020 as per changes requested for POTD-23607
                                                    if(obj_prochoice["al_sqs_details.payment_backdate"]=="Yes")
                                                    {
                                                        pagedataFunds["setvar"]["A_Rating_MAR_dat"]=inceptionDate[2]+inceptionDate[1]+inceptionDate[0];
                                                        pagedataFunds["setvar"]["A_Policy_Proposal_dat"]=inceptionDate[2]+inceptionDate[1]+inceptionDate[0];
                                                    }
                                                     else
                                                     {
                                                        pagedataFunds["setvar"]["A_Rating_MAR_dat"]=Current_date_dat;
                                                        pagedataFunds["setvar"]["A_Policy_Proposal_dat"]=Current_date_dat;
                                                     }
                                                                             
                                                 if(obj_prochoice["al_sqs_details.product_name"] == "EssentialLife (SP)" && channelTypeForAgencyBancaRepls == "uob")//added by ankita on 16 june 2020 as changes sent through email dated on 4 june 2020 by chui san
                                                 {
                                                     if(subChannelTypeForAgencyBancaRepls == "BB")
                                                     {
                                                          szSubChannelName = "SME";
                                                     }
                                                     else if(subChannelTypeForAgencyBancaRepls == "CB")
                                                     {
                                                          szSubChannelName = "CBD";
                                                     }
                                                     else
                                                     {
                                                          szSubChannelName = subChannelTypeForAgencyBancaRepls;
                                                     }
                                                                                                                     
                                                   //szSubChannelName = subChannelTypeForAgencyBancaRepls;//added by ankita on 11 may 2020 as changes sent thorugh email dated on 8 may 2020 by chui san
                                                   pagedata["setvar"]["A_Code_Sub_Channel_key"]=szSubChannelName;
                                                   pagedataChoiceFunction["setvar"]["A_Code_Sub_Channel_key"]=szSubChannelName;
                                                   pagedata1["setvar"]["A_Code_Sub_Channel_key"]=szSubChannelName;
                                                   
                                                 }
                                                // Added by shivani on 25/02/2021
                                                if(obj_prochoice["al_sqs_details.product_name"] === "PRUMulti Crisis Guard")
                                                {
                                                    
                                                  szSubChannelName = subChannelTypeForAgencyBancaRepls;
                                                  pagedata["setvar"]["A_Code_Sub_Channel_key"]=szSubChannelName;
                                                  pagedataChoiceFunction["setvar"]["A_Code_Sub_Channel_key"]=szSubChannelName;
                                                  pagedata1["setvar"]["A_Code_Sub_Channel_key"]=szSubChannelName;
                                                  
                                                }
                                                                             
                                                                             
                                                console.log("subChannelTypeForAgencyBancaRepls" + subChannelTypeForAgencyBancaRepls + "channelTypeForAgencyBancaRepls" +channelTypeForAgencyBancaRepls);

                                                    if(objmain_life_response["al_sqs_details.sec_parti_flag"] == "Yes")
                                                    {
                                                    pagedata["setvar"]["A_Second_Life_boo"]="Y";
                                                    pagedataChoiceFunction["setvar"]["A_Second_Life_boo"]="Y";
                                                    }
                                                    else
                                                    {
                                                    pagedata["setvar"]["A_Second_Life_boo"]="N";
                                                    pagedataChoiceFunction["setvar"]["A_Second_Life_boo"]="N";
                                                    }
                                                    if(objsec_life_response["al_sqs_details.third_parti_flg"] == "Yes")
                                                    {
                                                    pagedata["setvar"]["A_Third_Life_boo"]="Y";
                                                    }
                                                    else
                                                    {
                                                    pagedata["setvar"]["A_Third_Life_boo"]="N";
                                                    }
                                                    if(objmain_life_response["al_person_details.pre_natal_child_flg"] == "Yes")
                                                    {
                                                     pagedata["setvar"]["A_Insured_Prenatal_01_boo"]="Y";
                                                    }
                                                    else
                                                    {
                                                     pagedata["setvar"]["A_Insured_Prenatal_01_boo"]="N";
                                                    }

                                                console.log("pagedata == "+JSON.stringify(pagedata));
                                                                  
                                                                  var currencyKey = "";
                                                                  
                                                                  
                                                                  var querySelect=fnGetCurrencyKey(obj_prochoice["al_sqs_details.product_name"]);
                                                            
                                                                  
                                                                  
                                                                  querySelect.execute(function (response)
                                                                                      {
                                                                                      
                                                                                      if(response != "{}" && response != "")
                                                                                      {
                                                                                      var obj = JSON.parse(response);
                                                                                      console.log("Response:"+JSON.stringify(obj));
                                                                                      currencyKey=obj[0]['product_currency'];
                                                                                      console.log("currencyKey:"+currencyKey);
                                                                                      if(currencyKey == "RM")
                                                                                      {
                                                                                      currencyKey = "MYR";
                                                                                      }
                                                                                      pagedata1["setvar"]["A_Currency_key"] = currencyKey;
                                                                                      
                                                                                      if(currentPlan == "PRUGlobal Series")
                                                                                      {
                                                                                      pagedata1["setvar"]["A_Currency_key"]=obj_prochoice["al_sqs_details.foreign_currency"];//added by ankita on 11 April to get currency from dropdown value selected
                                                                                      }
                                                console.log("pagedata1 == "+JSON.stringify(pagedata1));
                                                    js_call_native_func("VPMSCall",pagedata1,function(A_Master_Product_Master_key_response)
                                                                      {
                                                                        //On swipe call from product selection screen Sourabh
                                                                        console.log("A_Master_Product_Master_key_response---"+A_Master_Product_Master_key_response)
                                                                        var responseParsing = JSON.parse(A_Master_Product_Master_key_response);
                                                                        console.log("responseParsing-1--:"+JSON.stringify(responseParsing));
                                                                        console.log("responseParsing-2--"+JSON.stringify(responseParsing[pagedata1["VPMSFunctionNameInSequence"]]))
                                                                        
                                                                        var PlanCodeValue ="";
                                                                       if(PlanCode.hasOwnProperty(currentPlan))// sourabh 0404 added this if condition for checking VPMS need to remove PRUglobal series // need to change by Paromita
                                                                        {
                                                                            PlanCodeValue= PlanCode[currentPlan];
                                                                        
                                                                        }
                                                                        else
                                                                        {
                                                                            PlanCodeValue = _.invert((responseParsing[pagedata1["VPMSFunctionNameInSequence"]]))[currentPlan];
                                                                        }
                                                                        console.log("PlanCodeValue:"+PlanCodeValue);
                                                                       
                                                                    
                                                                        pagedata["setvar"]["A_Master_Product_Master_key"]= PlanCodeValue;
                                                                        pagedata["setvar"]["A_Master_Rider_key"]= PlanCodeValue;
                                                                        
                                                                        pagedataFunds["setvar"]["A_Master_Rider_key"]= PlanCodeValue;
                                                                        pagedataFunds["setvar"]["A_Master_Product_Master_key"]= PlanCodeValue;
                                                                        
                                                                        pagedataChoiceFunction["setvar"]["A_Master_Rider_key"]= PlanCodeValue;
                                                                        pagedataChoiceFunction["setvar"]["A_Master_Product_Master_key"]= PlanCodeValue;
                                                                        if(currentPlan == "PRUGlobal Series")
                                                                        {
                                                                        pagedataChoiceFunction["setvar"]["A_Currency_key"]=obj_prochoice["al_sqs_details.foreign_currency"];
                                                                        }
                                                                        
                                                                        if(callFromFlag=="A_Master_Premium_Term_key" || callFromFlag=="A_Master_Payout_Age_key" || callFromFlag=="A_Master_Accumulation_Period_key")
                                                                        {
                                                                          fnSetChoiceDropdownPayoutPeriod(payoutperiodId,pagedataChoiceFunction,callFromFlag,fnSetPayoutPeriodDropdownCallFrom);
                                                                        }
                                                                        else if(callFromFlag=="setRiderTerm")
                                                                        {
                                                                            fnSetRiderTerm(payoutperiodId,pagedata,callFromFlag,0,currentPlan,VPMSRiderJson);
                                                                        }
                                                                        else
                                                                        {
                                                                        console.log("pagedata pagedataFunds --->"+JSON.stringify(pagedataFunds));
                                                                        js_call_native_func("VPMSCall",pagedataFunds,function(response1)
                                                                                            {
                                                                                             console.log(" pagedataFunds response1---"+response1)
                                                                                            responseParsing = JSON.parse(response1);
                                                                                            var objresponse1 = (responseParsing[pagedataFunds["VPMSFunctionNameInSequence"]]);
                                                                                            for(sub in objresponse1)
                                                                                            {
                                                                                            FundCode[sub] = "LF"
                                                                                            }
                                                                                            
                                                                                            console.log("VPMS FundCode1:"+JSON.stringify(FundCode));
                                                                                            console.log("VPMS response1 :"+objresponse1);
                                                                                            pagedataFunds["setvar"]["A_Code_ILP_Fund_Source_key"]= "GF";
                                                                                            js_call_native_func("VPMSCall",pagedataFunds,function(response3)
                                                                                                                {
                                                                                                                console.log("VPMS response3:"+response3);
                                                                                                                responseParsing = JSON.parse(response3);
                                                                                                                var objresponse3 = (responseParsing[pagedataFunds["VPMSFunctionNameInSequence"]]);
                                                                                                                for(sub1 in objresponse3)
                                                                                                                {
                                                                                                                FundCode[sub1] = "GF"
                                                                                                                }
                                                                                                                console.log("VPMS FundCode2:"+JSON.stringify(FundCode));
                                                                        

                                                                                                    
                                                                            js_set_var("bTagetSusEffective", bTagetSusEffective, function()

                                                                                       {
                                                                                       console.log("pagedata bTagetSusEffective --->"+bTagetSusEffective);
                                                                                       console.log("pagedata112 pagedata --->"+JSON.stringify(pagedata));
                                                                            js_call_native_func("VPMSCall",pagedata,function(response)
                                                                                                {
                                                                                                      console.log("VPMS1 response:"+response);
                                                                                                
                                                                                        
                                                                                                      responseParsing = JSON.parse(response);
                                                                                                      var objChoiceValues = (responseParsing[pagedata["VPMSFunctionNameInSequence"]]);
                                                                                                
                                                                                                      var per_valid_res="{";
                                                                                                
                                                                                                      var valid_riders="RiderName=";
                                                                                                      console.log("valid_riders"+valid_riders);
                                                                                                
                                                                                                      var VPMSRiderJson = {};
                                                                                                      var VPMSRiderTerm = {};

                                                                                                      
                                                                                                      var objChoiceValuesSplit = objChoiceValues["result"].split(";")
                                                                                                      console.log("Ridername-->"+objChoiceValuesSplit.length)
                                                                                                      Valid_Rider="";
                                                                                                      for(iCount = 0 ;iCount < objChoiceValuesSplit.length-1;iCount++)
                                                                                                      {
                                                                                                      
                                                                                                          console.log("objChoiceValuesSplit[iCount]-->"+objChoiceValuesSplit[iCount])
                                                                                                          var Ridername = objChoiceValuesSplit[iCount+1];
                                                                                              
                                                                                                
                                                                                                
                                                                                                          console.log("Ridername-->"+Ridername)
                                                                                                          var storeRiderName = Ridername;
                                                                                                          console.log("storeRiderName-->"+storeRiderName)
                                                                                                
                                                                                                
                                                                                                          
                                                                    console.log("jsonRideIds basic:"+jsonRideIds[Ridername]);                                      if(jsonRideIds[Ridername]!= "undefined" && jsonRideIds[Ridername]!= undefined && jsonRideIds[Ridername]!= "null" && jsonRideIds[Ridername]!= null)
                                                                                                          {
                                                                                                           Element="rider_row_al_rider_sqs."+jsonRideIds[Ridername];
                                                                                                
                                                                                                            if(storeRiderName != currentPlan)
                                                                                                            {
                                                                                                                Valid_Rider+="RiderName="+jsonRideIds[Ridername]+"::Visible=Yes||";
                                                                                                            }
                                                                                                          }
                                                                                                         else
                                                                                                         {
                                                                                                          Ridername= Ridername.replace(/ /g,"_");
                                                                                                          Ridername= Ridername.replace("*","");
                                                                                                          Ridername= Ridername.toLowerCase();
                                                                        
                                                                                                //if added by Shivani for PRUSignature Reserve to handle the PRUWaiver(hide and show)
                                                                                                if(currentPlan == "PRUSignature Reserve"){
                                                                                                if(objChoiceValuesSplit[iCount]=="VT19" )
                                                                                                {
                                                                                                
                                                                                                Ridername="pruwaiver";
                                                                                                
                                                                                                }
                                                                                                
                                                                                                else if(objChoiceValuesSplit[iCount]=="VT20"){
                                                                                                
                                                                                                Ridername="spouse_waiver";
                                                                                                
                                                                                                }
                                                                                                
                                                                                                else if(objChoiceValuesSplit[iCount]=="VT21"){
                                                                                                
                                                                                                Ridername="family_income_benefit_pruwaiver";
                                                                                                
                                                                                                }
                                                                                                else if(objChoiceValuesSplit[iCount]=="VT22"){
                                                                                                
                                                                                                Ridername="family_income_benefit_spouse_waiver";
                                                                                                
                                                                                                }
                                                                                                
                                                                                                
                                                                                                }
                                                                                                Element="rider_row_al_rider_sqs."+Ridername;
                                                                                             
                                                                                                            console.log("Current plan1:"+currentPlan);
                                                                                                            console.log("Ridername:"+Ridername);
                                                                                                         if(storeRiderName != currentPlan)
                                                                                                            {
                                                                    console.log("inside basic");                                               Valid_Rider+="RiderName="+Ridername+"::Visible=Yes||";
                                                                                                            }
                                                                                                
                                                                                                          }
                                                                                                console.log("Valid_Rider=="+Valid_Rider);
                                                                                                
                                                                                                            if(storeRiderName != currentPlan)
                                                                                                            {
                                                                                                                per_valid_res+='"'+Element+'":"'+Element+'",';
                                                                                                            }
                                                                                                          VPMSRiderJson[Element]= objChoiceValuesSplit[iCount];
                                                                                                          if(objChoiceValuesSplit[iCount + 7] != "" && objChoiceValuesSplit[iCount + 7] != "undefined" && objChoiceValuesSplit[iCount + 7] != null)
                                                                                                          VPMSRiderTerm[Element] = objChoiceValuesSplit[iCount + 7]
                                                                                                          iCount = iCount + 17;
                                                                                                      
                                                                                                      }
                                                                                                      
                                                                                                console.log("per_valid_res middle-->"+per_valid_res);
                                                                                                
                                                                                                      if(per_valid_res.length>1) // condition added by supriya
                                                                                                      per_valid_res=per_valid_res.slice(0,-1);
                                                                                                      per_valid_res+="}";
                                                                                                
                                                                                                      if (per_valid_res == "{}")
                                                                                                    {
                                                                                                        per_valid_res = {"Error":"3000"};
                                                                                                    }
                                                                                                
                                                                                                
                                                                                                console.log("Plan==>"+pagedataChoiceFunction["setvar"]["A_Master_Product_Master_Key"]);
                                                                                                console.log("currentPlan==>"+currentPlan);
                                                                                                 console.log("pagedata FINAL == "+JSON.stringify(pagedata));
                                                                                                console.log("Before per_valid_res-->"+per_valid_res);
                                                                                                
                                                                                                
                                                                                                //added by ankita on 16 August 2019 for pruwith with you new riders
                                                                                                if(productCertified.indexOf("CSS_Yes") == -1 && currentPlan == "PRUwith you")
                                                                                                {
                                                                                                    var arrCINewRiders=["early_crisis_care","multi_crisis_care","total_multi_crisis_care"];
                                                                                                    console.log("productCertified-->"+productCertified);
                                                                                                    console.log("productCertified1-->"+productCertified.indexOf("CSS_Yes"));
                                                                                                    per_valid_res= JSON.parse(per_valid_res);
                                                                                                    for(var i=0;i<arrCINewRiders.length;i++)
                                                                                                    {
                                                                                                        console.log("New riders rider_row_al_rider_sqs."+arrCINewRiders[i]);
                                                                                                        var delRiderName="rider_row_al_rider_sqs."+arrCINewRiders[i];
                                                                                                
                                                                                                        delete per_valid_res[delRiderName];
                                                                                                    }
                                                                                                    console.log("after per_valid_res111"+JSON.stringify(per_valid_res));
                                                                                                    per_valid_res = JSON.stringify(per_valid_res);
                                                                                                    
                                                                                                }
                                                            //added by ankita to hide enhanced infant care rider even if vpms returning the rider
                                                                                                if(currentPlan == "PRUwith you")
                                                                                                {
                                                                                                    var arrhideRider=["enhanced_infant_care"];
                                                                                                    
                                                                                                    per_valid_res= JSON.parse(per_valid_res);
                                                                                                    for(var i=0;i<arrhideRider.length;i++)
                                                                                                    {
                                                                                                        console.log("New riders rider_row_al_rider_sqs."+arrhideRider[i]);
                                                                                                        var delRiderName="rider_row_al_rider_sqs."+arrhideRider[i];
                                                                                                
                                                                                                        delete per_valid_res[delRiderName];
                                                                                                    }
                                                                                                    console.log("after per_valid_res111"+JSON.stringify(per_valid_res));
                                                                                                    per_valid_res = JSON.stringify(per_valid_res);
                                                                                                    
                                                                                                }
                                                                     //added by ankita for defect 145 on 4 march 2022
                                                                     // Commented by Shivani for Modern Family SRF3 for May2022
                                                              /*   if(currentPlan == "PRULink Cover")
                                                                                                                                                               {
                                                                                                                                                                   var arrNewRidersToHide=["early_crisis_care","multi_crisis_care","total_multi_crisis_care","protect_booster"];
                                                                                                                             per_valid_res= JSON.parse(per_valid_res);
                                                                                                                                                                   for(var i=0;i<arrNewRidersToHide.length;i++)
                                                                                                                                                                   {
                                                                                                                                                                       console.log("New riders rider_row_al_rider_sqs."+arrNewRidersToHide[i]);
                                                                                                                                                                       var delRiderName="rider_row_al_rider_sqs."+arrNewRidersToHide[i];
                                                                                                                                                               
                                                                                                                                                                       delete per_valid_res[delRiderName];
                                                                                                                                                                   }
                                                                                                                                                                   console.log("after per_valid_res111"+JSON.stringify(per_valid_res));
                                                                                                                                                                   per_valid_res = JSON.stringify(per_valid_res);
                                                                                                                                                                   
                                                                                                                                                               }*/
                                                                                                console.log("after per_valid_res222"+JSON.stringify(per_valid_res));
                                                                   //added by ankita on 14 april and to remove if vpms come.temporary added to check
                                                                                                /*if(obj_prochoice["al_sqs_details.product_name"]==="PRULink Cover")
                                                                                                {
                                                                                                var per_valid_res="{";
                                                                                                        per_valid_res+='"rider_row_al_rider_sqs.crisis_care":"rider_row_al_rider_sqs.crisis_care","rider_row_al_rider_sqs.protect_booster":"rider_row_al_rider_sqs.protect_booster","rider_row_al_rider_sqs.total_multi_crisis_care":"rider_row_al_rider_sqs.total_multi_crisis_care","rider_row_al_rider_sqs.early_crisis_care":"rider_row_al_rider_sqs.early_crisis_care","rider_row_al_rider_sqs.crisis_guard":"rider_row_al_rider_sqs.crisis_guard","rider_row_al_rider_sqs.pruvalue_med":"rider_row_al_rider_sqs.pruvalue_med","rider_row_al_rider_sqs.prumedic_overseas":"rider_row_al_rider_sqs.prumedic_overseas","rider_row_al_rider_sqs.prumillion_med":"rider_row_al_rider_sqs.prumillion_med","rider_row_al_rider_sqs.pruhealth":"rider_row_al_rider_sqs.pruhealth","rider_row_al_rider_sqs.pruacci_guard":"rider_row_al_rider_sqs.pruacci_guard","rider_row_al_rider_sqs.pruacci_med":"rider_row_al_rider_sqs.pruacci_med","rider_row_al_rider_sqs.pruacci_income":"rider_row_al_rider_sqs.pruacci_income","rider_row_al_rider_sqs.enhanced_prupayor_basic":"rider_row_al_rider_sqs.enhanced_prupayor_basic","rider_row_al_rider_sqs.enhanced_prupayor_saver":"rider_row_al_rider_sqs.enhanced_prupayor_saver","rider_row_al_rider_sqs.prusaver":"rider_row_al_rider_sqs.prusaver","rider_row_al_rider_sqs.prusaverchecking":"rider_row_al_rider_sqs.prusaverchecking"';

                                                                                                per_valid_res+="}";
                                                                                                //per_valid_res={"rider_row_al_rider_sqs.pruwaiver":"rider_row_al_rider_sqs.pruwaiver","rider_row_al_rider_sqs.assured_waiver_plus":"rider_row_al_rider_sqs.assured_waiver_plus"};
                                                                                                //VPMSRiderJson={"rider_row_al_rider_sqs.pruvalue_gain":"TR14","rider_row_al_rider_sqs.pruwaiver":"VT23","rider_row_al_rider_sqs.assured_waiver_plus":"VT25"};
                                                                                                }*/
                                                    /*if(obj_prochoice["al_sqs_details.product_name"]==="PRUSignature Treasure")
                                                                                                {
                                                                                                var per_valid_res="{";
                                                                                                
                                                                                                per_valid_res+='"rider_row_al_rider_sqs.parent_waiver":"rider_row_al_rider_sqs.parent_waiver","rider_row_al_rider_sqs.pruwaiver":"rider_row_al_rider_sqs.pruwaiver"';                         console.log("FINAL per_valid_res-->"+per_valid_res);
                                                                                                per_valid_res+="}";
                                                                                                VPMSRiderJson={"rider_row_al_rider_sqs.prusignature_reward":"TR09","rider_row_al_rider_sqs.pruwaiver":"VT16","rider_row_al_rider_sqs.parent_waiver":"VT17"};
                                                                                                console.log("VPMSRiderJson::"+JSON.stringify(VPMSRiderJson));
                                                                                                }*/
                                                                                                if(currentPlan == "PRUcancer X")
                                                                                                {
                                                                                                console.log("In PRUcancer x");
                                                                                                  fnCallChoiceFunctionVPMSForCancerX(per_valid_res,VPMSRiderJson,VPMSRiderTerm,A_Master_Product_Master_key_response,pagedata1,CheckShift,pagedataChoiceFunction);
                                                                                                }
                                                                                                else
                                                                                                {
                                                                                                
                                                                                                fnCallSetFuncAfterAllChoice(per_valid_res,VPMSRiderJson,VPMSRiderTerm,A_Master_Product_Master_key_response,pagedata1,CheckShift);
                                                                                                }
                                                                                                
                                                                                            });
                                                                                       });
                                                                        });
                                                                                            });
                                                                        
                                                                        }
                                                                      });
                                                                                      }//added
                                                                                      });//added
                                                           });
                                                });
                                          });
               });
               });
               });
               });
                        });
}


function fnGenerateInputforCalculation(flag_cals,loadingflag_generate,callfrom)//Pradnya: to check for june24 release
{
//    if(document.getElementById("al_rider_sqs.basic_plan_prutri_care.id").checked===false)
//    {
//        document.getElementById("al_rider_sqs.prusignature_ppr1.rider_term").value="0";
//        document.getElementById("al_rider_sqs.prusignature_ppr1.rider_premium").value="0.00";
//        $("#totalPremiumValuecomp_bundle").text("0.00");
//        $("#taxValuecomp_bundle").text("0.00");
//        //document.getElementById("taxValuecomp_bundle").value="0.00";
//        document.getElementById("al_person_details.total_tax_plus_prem_bundle").value="0.00";
//    }
    isAlertFromVPMS="No";
    bundleCurrentPlan="";
    callFromOther="";
    console.log("vpmsEaseCampaignCode:"+vpmsEaseCampaignCode);
    targetSustainabilityFlag = "No";
    targetMaximumPremium = "No";
    szFullPayIndicator  = "No";
    console.log("marcamCode:"+marcamCode)
    console.log("fnGenerateInputforCalculation");
    isSIOCampaignFlag="No";
    console.log("flag---"+benefit_flag_update);
    var bFirstCallFlag = false;
    var szChannelName = "AGY";
    var szSubChannelName = "AGY";//chnaged by ankita as changes sent by VPMS on 03 May 2018
    //var currentPlan = localStorage.getItem("current_plan");
    console.log("currentPlan:"+currentPlan);
    isSIOCampaignFlag="No";
    
    var bundleProductName="";
    szNegativeCashValueFlag = "No";
    
    isPreviewDone="No";
    document.getElementById("email_doc_Input").checked=true;
    document.getElementById("email_doc_Output").checked=false;
    
    //szOkToAmendCVFlag = "No";
    //newPRUAllocatorPremiumPMC="";
    //szBasicPremium = 0;
    
    //szOldAllocatorValueIfNA=0;
   
    //Hardcoded condition for checking
   /* if(currentPlan=="PRUsignature income")
    {
        currentPlan="PRUsmart gain";
    }*/
    //to remove temporary added
    /*if(currentPlan == "PRUEasy Protect")
    {
        currentPlan = "PRUgrowth";
        //szChannelName = "UOB";
        //szSubChannelName = "";
    }*/
    
    // temporary
    /*if(currentPlan === "PRUMulti Crisis Guard")
    {
        currentPlan = "PRUMy Gift";
        //szChannelName = "UOB";
        //szSubChannelName = "";
    }*/
  /* if(currentPlan == "PRUTerm Premier")
    {
       currentPlan = "PRUCash Enrich";
       szChannelName = "AGY";
       szSubChannelName = "";
    }*/
    
//    if(currentPlan == "PRUAll Care")
//    {
//       currentPlan = "PRUCash Enrich";
//       szChannelName = "AGY";
//       szSubChannelName = "";
//    }
    
//  if(currentPlan == "PRUSignature GrowthPlus")
//         {
//            currentPlan = "PRUElite Invest";
//            szChannelName = "AGY";
//            szSubChannelName = "";
//         }
    
    console.log("currentPlan2:"+currentPlan);
    
    //Abhilash/Sourabh/Ankita/Sachin for def - 8901 26 dec 2019
   /* if(callfrom=="bundle_product") //Added for SB Accumalator product by Sachinn Tupe.
    {
        callFromOther=callfrom;
        bundleProductName=flag_cals;
        currentPlan=flag_cals;
        flag_cals="";
        callfrom="";
    }*/
    
    
    
    console.log("fnGenerateInputforCalculation channelTypeForAgencyBancaRepls:"+channelTypeForAgencyBancaRepls+"subChannelTypeForAgencyBancaRepls:"+subChannelTypeForAgencyBancaRepls);
    if(channelTypeForAgencyBancaRepls == "banca")
    {
        szChannelName = "SCB";
        if(subChannelTypeForAgencyBancaRepls =="SCB_STF")
        {
            //szSubChannelName ="SCBSTF"
            szSubChannelName ="STF"//chnaged by ankita as changes sent by VPMS on 03 May 2018
        }
        else
        {
            //szSubChannelName ="SCBFSC"
            szSubChannelName ="FSC"//chnaged by ankita as changes sent by VPMS on 03 May 2018
        }
    }
    else if(channelTypeForAgencyBancaRepls == "uob")
    {
        szChannelName = "UOB";
        
        szSubChannelName = "";//chnaged by ankita as changes sent by VPMS on 03 May 2018
        //szSubChannelName = subChannelTypeForAgencyBancaRepls;//added by ankita on 11 may 2020 as changes sent thorugh email dated on 8 may 2020 by chui san
        /*if(subChannelTypeForAgencyBancaRepls == "CB" || subChannelTypeForAgencyBancaRepls == "BB")
        {
            szSubChannelName = "BCB";//Business/ Commercial Banking
        }
        else
        {
            szSubChannelName = "PFS";
        }*/
    }
    
    // need to remove sourabh
   /* if(currentPlan == "PRUTerm Premier")
    {
        currentPlan = "PRUCash Enrich";
        szChannelName = "AGY";
        szSubChannelName = "AGY";
    }*/
   
//    if(currentPlan == "PRUAll Care")
//    {
//        currentPlan = "PRUCash Enrich";
//        szChannelName = "AGY";
//        szSubChannelName = "AGY";
//    }
//
    /*if(currentPlan == "PRUSignature Harvest")
    {
    currentPlan = "PRUSignature Reward";
       szChannelName = "SCB";
      szSubChannelName = "";
     }*/
    
   /* if(currentPlan == "PRUGain Plus")
       {
       currentPlan = "PRUFlexi Gain";
          szChannelName = "UOB";
         szSubChannelName = "";
        }*/
    //to remove temporary added on 22 oct 2020
   /* if(currentPlan == "PRUSignature Treasure")
    {
       currentPlan = "PRUSignature Reserve";
       //szChannelName = "UOB";
       //szSubChannelName = "";
    }*/
/*if(currentPlan == "PRULink Supreme")
       {
       currentPlan = "PRUMax Cover";
          szChannelName = "UOB";
         szSubChannelName = "";
        }*/

    console.log("CCurent plan",currentPlan)
//
//    if(true)
//       {
//           currentPlan = "PRULink Cover";
//           szChannelName = "UOB";
//           szSubChannelName = "";
//          // alert("dfsadf")
//       }
    
    
//   if(currentPlan == "PRUSignature GrowthPlus")
//          {
//             currentPlan = "PRUElite Invest";
//             szChannelName = "AGY";
//             szSubChannelName = "";
//          }
   
    var jsonFrequecy= {"A":"01","H":"02","Q":"04","M":"12","SP":"00"}; //Added payment frequency for single premium by paromita on 06 June 2018
    var jsonPaymentMethod= {"Credit Card1":"R","Debit Card":"R","Auto Debit":"D","Cash/Cheque":"C","Discounted Ad":"P","Bank Transfer":"N"};
    if(currentPlan == "PRUsignature prime" || currentPlan == "PRUGlobal Series")
    {
        jsonPaymentMethod["Bank Transfer"]="N";
    }
    //added by ankita on 20 may 2021 for POPRT-1801 changes
    if(currentPlan == "PRUsignature" || currentPlan == "PRUsignature infinite" || currentPlan == "PRUSignature Reward" || currentPlan == "PRUSignature Reserve" || currentPlan == "PRUSignature Assure" || currentPlan == "PRUSignature Harvest" || currentPlan == "PRUSignature Treasure" || currentPlan == "PRUSignature Vanguard" || currentPlan == "PRUSignature Harvest Plus" || currentPlan == "PRUSignature Boost" || currentPlan == "PRUSignature GrowthPlus" || currentPlan == "PRUSignature Plus")
    {
        jsonPaymentMethod["Bank Transfer"]="F";
    }
    var personArray={"1":"mlife","2":"slife","3":"tlife"};
   
    
    var fundsArray={"al_sqs_details.equity_focus_fund":"FF","al_sqs_details.managed_fund2":"PM2","al_sqs_details.dana_urus2":"HM2","al_sqs_details.dana_unggul":"HE","al_sqs_details.bond_fund":"PF","al_sqs_details.equity_income_fund":"PI","al_sqs_details.dana_aman":"HF","al_sqs_details.asia_equity_fund":"ASF","al_sqs_details.asian_high_yield_bond_fund":"AHB","al_sqs_details.asia_property":"APS","al_sqs_details.global_market_naviga":"GMN","al_sqs_details.asia_managed_fund":"AMF","al_sqs_details.asia_local_bond_fund":"ALB","al_sqs_details.multi_asset_fund":"AMU","al_sqs_details.dragon_peacock":"DPF","al_sqs_details.equity_fund":"AEF","al_sqs_details.asia_select_focus_fund":"SFF","al_sqs_details.flexi_vantage_fund":"FVP","al_sqs_details.asia_opportunities_fund":"AOF","al_sqs_details.global_managed_fund":"GMF","al_sqs_details.global_opportunities_fund":"GOF","al_sqs_details.strategic_managed_fund":"PSM","al_sqs_details.global_leaders_fund":"GLE","al_sqs_details.japan_dynamic_fund":"JDM","al_sqs_details.euro_equity_fund":"EUF","al_sqs_details.global_growth_fund":"GGF","al_sqs_details.global_strategic_fund":"PGS","al_sqs_details.equity_plus_fund":"PEP","al_sqs_details.managed_plus_fund":"PMP","al_sqs_details.asia_great_fund":"PAGF","al_sqs_details.innovation_fund":"PIF","al_sqs_details.us_equity_fund":"USE","al_sqs_details.pacific_dynamic_income_fund":"ADI","al_sqs_details.sustainable_equity_fund":"SEF","al_sqs_details.global_esg_choice_fund":"GEC"};
    
    // Pradnya: added global_esg_choice_fund for march24 release
    //"al_sqs_details.global_strategic_fund":"PGS","al_sqs_details.equity_plus_fund":"PEP","al_sqs_details.managed_plus_fund":"PMP"
    //var fundsArray={"al_sqs_details.equity_focus_fund":"PGS","al_sqs_details.dana_urus2":"PEP","al_sqs_details.equity_income_fund":"PMP"};
    
    
    
    
    
    bunddleFundArray=fundsArray;//Added for SB accumulator product by Sachin T.
    var jsonInputParameter = {};
    
    var loadingAdditionalArray={"al_loading_details_sqs.mlife.millennium_ah_add.value":"ADD","al_loading_details_sqs.mlife.ah_amr.value":"AMR","al_loading_details_sqs.mlife.ah_adi.value":"ADI","al_loading_details_sqs.mlife.ah_phl.value_millennium":"PH","al_loading_details_sqs.mlife.ah_load.value":"ADD","al_loading_details_sqs.mlife.ah_pec.value":"JCE","al_loading_details_sqs.mlife.medical.value":"PH","al_loading_details_sqs.mlife.multi_crisis_care.value":"CIM","al_loading_details_sqs.mlife.early_crisis_care.value":"CIE","al_loading_details_sqs.mlife.total_multi_crisis_care.value":"CIT","al_loading_details_sqs.mlife.critical_illness_benefit_multicrisisguard.value":"ZC","al_loading_details_sqs.mlife.post_surgery_recovery_benefits.value":"SU","al_loading_details_sqs.mlife.intensive_care_support_benefits.value":"IC"};//last 3 ids added by ankita on 25 July 2019
    
    
    
    var noOfLife=1;
    var noOfRiders="0";
    
    
    
    var todayDate  = new Date();
    var todayYear  = todayDate.getFullYear();
    var todayMonth = todayDate.getMonth() + 1;
    var todayDay   = todayDate.getDate();
    if(todayDay < 10)
    {
        todayDay = "0" + todayDay
    }
    if(todayMonth < 10)
    {
        todayMonth = "0" + todayMonth
    }
    
    
    var Current_Date_dat = "";
    Current_Date_dat = todayYear.toString()+todayMonth.toString()+todayDay.toString();
    js_get_var("prod_choice_response",function(prod_choice_res)// //Abhilash/Sourabh/Ankita  def solving 8901 26 Dec 2019  get was done few lines below we shifted it here as current plan was not able to get
              {
               var obj_prochoice="";
               var currentPlan="";
               if(prod_choice_res != "" && prod_choice_res != null && prod_choice_res != "null"  && prod_choice_res != "(null)")
               {
                     obj_prochoice=JSON.parse(prod_choice_res);
                     currentPlan=obj_prochoice["al_sqs_details.product_name"];
               }
               console.log("currentPlan-11->"+currentPlan);
               if(callfrom=="bundle_product") //Added for SB Accumalator product by Sachinn Tupe.
               {
                   callFromOther=callfrom;
                   bundleProductName=flag_cals;
                   currentPlan=flag_cals;
                   flag_cals="";
                   callfrom="";
               }
    
    js_set_var("reduceAge", "", function()
               
               {
              // js_set_var("bundle_sqs_id","",function()
                               //{
               js_set_var("firstAge", "", function()
                          {
                          js_set_var("reducedPremiumTerm", "", function()
                                     {
    var querySelect=fnGetProductMaster(currentPlan)
    querySelect.execute(function (jsonProductresponse)

                        {
    
    js_get_var("szPlaneCode",function(szPlaneCode)
               {
    
    js_get_var("bundle_product_response",function(bundle_prod_choice_res)
            {
               
               
               
               if(bundle_prod_choice_res != "" && bundle_prod_choice_res != null && bundle_prod_choice_res != "null"  && bundle_prod_choice_res != "(null)")//Added for SB accumulator product by sachin T on date 7-2-2019.
               {
               
               bundleFundRes=JSON.parse(bundle_prod_choice_res);
               
               }
               
   // js_get_var("prod_choice_response",function(prod_choice_res)
     //          {
               js_get_var("VPMSRiderJson",function(VPMSRiderJson)
                          {
                          js_get_var("main_life_response",function(main_life_response)
                                     {
                                     js_get_var("sec_life_response", function(sec_life_response)
                                                {
                                                        js_get_var("third_life_response",function(third_life_res)
                                                        {
                                                        js_get_var("loading_details_response", function(loading_details_res)
                                                        {
                                                        js_get_var("buttons_plans_response", function(solutionsplanObj)
                                                          {
                                                          obj_solution ="";
                                                          if(solutionsplanObj != "" && solutionsplanObj != null && solutionsplanObj != "null"  && solutionsplanObj != "(null)")
                                                          {
                                                           console.log("solution result"+solutionsplanObj)
                                                              
                                                          obj_solution=JSON.parse(solutionsplanObj);
                                                              console.log("parse error"+solutionsplanObj)
                                                          }
                                                        var obj_mlife_res = JSON.parse(main_life_response);
                                                            console.log("parse error4"+solutionsplanObj)
                                                        var obj_slife_res="";
                                                        var obj_tlife_res ="";
                                                       if (sec_life_response != "" && sec_life_response != null && sec_life_response != "null" && sec_life_response != "(null)")
                                                       {
                                                        obj_slife_res = JSON.parse(sec_life_response);
                                                        }
                                                       if (third_life_res != "" && third_life_res != null && third_life_res != "null" && third_life_res != "(null)")
                                                       {
                                                        obj_tlife_res = JSON.parse(third_life_res);
                                                        }
                                                            console.log("vpms res:"+VPMSRiderJson);
                                                        var objVPMSRiderJson = JSON.parse(VPMSRiderJson);
                                                                   console.log("objVPMSRiderJson:"+JSON.stringify(objVPMSRiderJson));
                                                                   
                                                       
                                                                   
                                                           if(callFromOther=="bundle_product") //Added for bundle product by Sachin T on date 1-2-2019.
                                                                   {
                                                                   
                                                                  if(bundle_prod_choice_res != "" && bundle_prod_choice_res != null && bundle_prod_choice_res != "null"  && bundle_prod_choice_res != "(null)")
                                                                   {
                                                                   obj_prochoice="";
                                                                   obj_prochoice=JSON.parse(bundle_prod_choice_res);
                                                                 
                                                                   bundleCurrentPlan=obj_prochoice["al_sqs_details.product_name"];
                                                                   bundleCurrentPlanDetails=bundleCurrentPlan;
                                                                   
                                                                   
                                                                   }
                                                                   
                                                                   
                                                           
                                                                   
                                                                   }
                                                                   
                                                        var obj_loading="";
                                                        if (loading_details_res != "" && loading_details_res != null && loading_details_res != "null" && loading_details_res != "(null)")
                                                        {
                                                        obj_loading=JSON.parse(loading_details_res);
                                                        }
                                                                   //added by ankita on 20 sept 2022 as per mail by henry on 13 sept 2022
                                                                   if(obj_prochoice["al_sqs_details.product_name"] === "PRUSignature Ace")
                                                                   {
                                                          if(obj_loading === "")
                                                          {
                                                             document.getElementById("row_al_sqs_details.loading_premium").style.display="none";
                                                                document.getElementById("rider_row_al_rider_sqs.loading_premium").style.display="none";
                                                          }
                                                                   else
                                                                   {
                                                                   document.getElementById("row_al_sqs_details.loading_premium").style.display="block";
                                                                   document.getElementById("rider_row_al_rider_sqs.loading_premium").style.display="block";
                                                                   
                                                                   }
                                                                   }
                                                        console.log("obj_loading 123:"+obj_loading);
                                                                   if(obj_prochoice["al_sqs_details.product_name"] === "PRUsignature" || obj_prochoice["al_sqs_details.product_name"] === "PRUSignature Plus")
                                                                   {
                                                                   obj_loading="";
                                                                   }
                                                                   console.log("after obj_loading 123:"+obj_loading);
                                                        var inceptionDate=obj_prochoice["al_sqs_details.Inception_dt"].split("/");
                                                        
                                                        if(parseInt(inceptionDate[0]) < 10)
                                                        {
                                                        inceptionDate[0] = "0" + parseInt(inceptionDate[0]);
                                                        }
                                                        if(parseInt(inceptionDate[1]) < 10)
                                                        {
                                                        inceptionDate[1] = "0" + parseInt(inceptionDate[1]);
                                                        }
                                                                   
                                                       var inputs= document.getElementById("rider_block").getElementsByTagName('input');
                                                       if(obj_prochoice["al_sqs_details.product_name"]=="PRUsignature USD" || obj_prochoice["al_sqs_details.product_name"]=="PRUsignature")
                                                       {
                                                          inputs= document.getElementById("prusignature_rider_block").getElementsByTagName('input');
                                                       }// added by supriya for rider input prusignature USD
                                                       else if(obj_prochoice["al_sqs_details.product_name"]=="PRUwealth gain plus" || obj_prochoice["al_sqs_details.product_name"]=="PRUgrowth" || obj_prochoice["al_sqs_details.product_name"]=="PRUSignature Optimiser" || obj_prochoice["al_sqs_details.product_name"]=="PRUValue Gain" || obj_prochoice["al_sqs_details.product_name"]=="PRUSenior Med" || obj_prochoice["al_sqs_details.product_name"]=="PRUSignature Reward" || obj_prochoice["al_sqs_details.product_name"]=="PRUSignature Reserve" || obj_prochoice["al_sqs_details.product_name"]=="EssentialLife (SP)" || obj_prochoice["al_sqs_details.product_name"]=="PRUSignature Protect" || obj_prochoice["al_sqs_details.product_name"]=="PRUEasy Protect" || obj_prochoice["al_sqs_details.product_name"] === "PRUCash Enrich" || obj_prochoice["al_sqs_details.product_name"] === "PRUTerm Premier" || obj_prochoice["al_sqs_details.product_name"] === "PRUAll Care" || obj_prochoice["al_sqs_details.product_name"] === "PRUFlexi Gain" || obj_prochoice["al_sqs_details.product_name"]==="PRUSignature Harvest" || obj_prochoice["al_sqs_details.product_name"]==="PRUGain Plus" || obj_prochoice["al_sqs_details.product_name"]=="PRUSignature Treasure" || obj_prochoice["al_sqs_details.product_name"]==="PRUSignature Harvest Plus" || obj_prochoice["al_sqs_details.product_name"] === "PRUEnrich Gain" || obj_prochoice["al_sqs_details.product_name"]==="PRUSignature Boost" || obj_prochoice["al_sqs_details.product_name"]==="PRUMan" || obj_prochoice["al_sqs_details.product_name"]==="PRULady_PRL")//added condition for PRUgrowth by Ankita // Added condition for PRUSignature Reserve by Shivani on 5th Mar 2020//Abhilash: EssentialLife (SP)_SCB name changed to PRUSignature Protect on 6th July
                                                       {
                                                       inputs= document.getElementById("rider_block_pruaspire").getElementsByTagName('input');
                                                                   
                                                       
         
                                                       }
                                                       else if(obj_prochoice["al_sqs_details.product_name"]=="PRUcancer X")//added condition for PRUcancer X by Ankita on 5 June 2018
                                                       {
                                                        inputs= document.getElementById("rider_blocks").getElementsByTagName('input');
                                                       }else if(currentPlan=="SB accumalutor" || obj_prochoice["al_sqs_details.product_name"]=="PRUSignature Booster")
                                                       {
                                                       
                                                       inputs= document.getElementById("bundle_rider_block").getElementsByTagName('input');
                                                       
                                                       
                                                       } else if(obj_prochoice["al_sqs_details.product_name"]=="PRUcash" || obj_prochoice["al_sqs_details.product_name"]=="PRUcash double reward")//added for pcvpms
                                                       {
                                                       inputs= document.getElementById("prucash_block").getElementsByTagName('input');
                                                       }
                                                                   
                                                        var frequency = jsonFrequecy[obj_prochoice["al_sqs_details.payment_frequency"]];
                                                       var dob ="";
                                                       if(obj_mlife_res["al_person_details.pre_natal_child_flg"] == "Yes")
                                                       {
                                                            dob = obj_mlife_res["al_person_details.mlife.expected_delivery_dt"].split("/");
                                                       }
                                                       else
                                                       {
                                                            dob =obj_mlife_res["al_person_details.mlife.dob"].split("/");
                                                       }
                                                       var ProductCode =""
                                                       if(PlanCode.hasOwnProperty(obj_prochoice["al_sqs_details.product_name"]))// sourabh 0404 added this if condition for checking VPMS need to remove PRUglobal series // need to change by Paromita
                                                       {
                                                            ProductCode= PlanCode[currentPlan];
                                                       
                                                       }
                                                       else
                                                       {
                                                            ProductCode = JSON.parse(szPlaneCode)[obj_prochoice["al_sqs_details.product_name"]];
                                                       }
                                                                   
//                                                       /*****************Added for dummy calculation/////////****************/
//
//                                                                   if(obj_prochoice["al_sqs_details.product_name"]=="PRUSignature Assure"){
//
//                                                                            currentPlan = "PRULink Cover";
//                                                                            szChannelName = "UOB";
//                                                                            szSubChannelName = "";
//                                                                            ProductCode="IL08";
//
//                                                                   }
//
//                                                          /*******************************************************************/
                                                                   
                                                                   /*****************Added for dummy calculation///////****************/
                                                                   
//                                                                                                                                      if(obj_prochoice["al_sqs_details.product_name"]=="PRUAll Care"){
//
////                                                                                                                                               currentPlan = "PRULink Cover";
////                                                                                                                                               szChannelName = "UOB";
////                                                                                                                                               szSubChannelName = "";
//
//
//                                                                                                                                         currentPlan = "PRUCash Enrich";
//                                                                                                                                         szChannelName = "AGY";
//                                                                                                                                           szSubChannelName = "";
//                                                                                                                                            ProductCode="TR20";
//
//
//
//
//                                                                                                                                      }
                                                                   
                                                                                                                             /*******************************************************************/
                                                                   
                                                                   
                                                                   
                                                                   
                                                                   
                                                        var pagedata={
                                                            "setvar":{
                                                                "A_Block_Start_int":"1",
                                                                "A_Block_Num_int":"99",
                                                                "A_Search_str":"",
                                                                "A_Country_key":"MYS",
                                                                "VPMS_VPM_Path":"",
                                                                "A_Code_Payment_Frequency_key":jsonFrequecy[obj_prochoice["al_sqs_details.payment_frequency"]],
                                                                "A_Master_Product_Master_Key":ProductCode,
                                                                "A_Code_Channel_key":szChannelName,
                                                                "A_Rating_Date_dat":Current_Date_dat,//changed by ankita on 3 July 2018(change in inputs by VPMS) for defect 5781
                                                                "A_Policy_Inception_dat":inceptionDate[2]+inceptionDate[1]+inceptionDate[0],
                                                                "A_Policy_Effective_dat":inceptionDate[2]+inceptionDate[1]+inceptionDate[0],
                                                                "A_Code_Payment_Method_key":jsonPaymentMethod[obj_prochoice["al_sqs_details.payment_mode"]],
                                                                "A_Tran_Code_key":"NB",
                                                                "A_Master_Premium_Term_key":(obj_prochoice["al_sqs_details.product_name"]== "PRUwith you" || obj_prochoice["al_sqs_details.product_name"]== "PRUmy treasure" || obj_prochoice["al_sqs_details.product_name"]== "PRUsignature prime" || obj_prochoice["al_sqs_details.product_name"]== "PRUSignature Invest" || obj_prochoice["al_sqs_details.product_name"]== "PRULink Investor Account" || obj_prochoice["al_sqs_details.product_name"]== "PRUGlobal Series" || obj_prochoice["al_sqs_details.product_name"]== "PRULink Cover" || obj_prochoice["al_sqs_details.product_name"]== "PRUSenior Med" || obj_prochoice["al_sqs_details.product_name"]=="EssentialLife (SP)" || obj_prochoice["al_sqs_details.product_name"]=="PRUSignature Protect" || obj_prochoice["al_sqs_details.product_name"]=="PRUSignature Assure" || obj_prochoice["al_sqs_details.product_name"]=="PRULink Growth" || obj_prochoice["al_sqs_details.product_name"]== "PRUSignature Ace"
                                                                    || obj_prochoice["al_sqs_details.product_name"]== "PRUMan" || obj_prochoice["al_sqs_details.product_name"]== "PRULady_PRL")?"":document.getElementById("al_sqs_details.premium_payment_period_plm_plus").value,
                                                                "A_Code_Plan_Type_key":"Par",
                                                                "A_Payout_Survival_Benf_boo":"N",
                                                                "A_SelectPaidUp_boo":"N",
                                                                   "A_Code_TargetSust_key": (obj_prochoice["al_sqs_details.product_name"]== "PRUwith you" || obj_prochoice["al_sqs_details.product_name"]== "PRULink Cover" || obj_prochoice["al_sqs_details.product_name"]== "PRUWealth Plus" || obj_prochoice["al_sqs_details.product_name"]== "PRUmillion cover" || obj_prochoice["al_sqs_details.product_name"]== "PRUWealth Max" || obj_prochoice["al_sqs_details.product_name"]== "PRUMillion Cover 2.0" || obj_prochoice["al_sqs_details.product_name"]== "PRUSignature Assure" || obj_prochoice["al_sqs_details.product_name"]=== "PRUSignature Vanguard" || obj_prochoice["al_sqs_details.product_name"]==="PRUEnhanced Cover" || obj_prochoice["al_sqs_details.product_name"]== "PRUWealth Enrich")?document.getElementById("al_sqs_details.target_sustainability_option").value:"100",
                                                                   
                                                                "A_Code_Rider_Payage_key":"",
                                                                "A_Budget_Exc_Premium_rea":"0",
                                                                "A_Code_Sub_Channel_key":szSubChannelName,
                                                                   "A_Master_ILP_TargetSust_key":(obj_prochoice["al_sqs_details.product_name"]== "PRUwith you" || obj_prochoice["al_sqs_details.product_name"]== "PRULink Cover" || obj_prochoice["al_sqs_details.product_name"]== "PRUWealth Plus" || obj_prochoice["al_sqs_details.product_name"]== "PRUmillion cover" || obj_prochoice["al_sqs_details.product_name"]== "PRUWealth Max" || obj_prochoice["al_sqs_details.product_name"]== "PRUMillion Cover 2.0" || obj_prochoice["al_sqs_details.product_name"]== "PRUSignature Assure" ||  obj_prochoice["al_sqs_details.product_name"]=== "PRUSignature Vanguard" || obj_prochoice["al_sqs_details.product_name"]=== "PRUEnhanced Cover" || obj_prochoice["al_sqs_details.product_name"]== "PRUWealth Enrich")?targetOpt[document.getElementById("al_sqs_details.target_sustainability_option").value]:"A100",
                                                                "A_Insured_Prenatal_02_boo":"",
                                                                "A_Insured_Prenatal_03_boo":"",
                                                                "A_Code_Survival_Benefit_key":"Y",
                                                                "A_Policy_Proposal_dat":Current_Date_dat,//changed by ankita on 3 July 2018(change in inputs by VPMS) for defect 5781
                                                                //"A_Master_Policy_Term_key":"", //added by supriya for error result":"","message":"","rc":"-1","field":"A_Master_Policy_Term_key"
                                                                   "A_SelectDAP_boo":"",
                                                                   "A_Master_Payout_Age_key":"",
                                                                   "A_Master_Payout_Frequency_key":"",
                                                                   "A_Master_Payout_Period_key":"",
                                                                   "A_Sustain_Age_High_int":"",
                                                                   "A_Sustain_Age_Low_int":"",

                                                                   "A_Master_Campaign_key":"",
                                                                   "A_Rating_MAR_dat":Current_Date_dat,
                                                                   "A_Master_Campaign_Bonus_key":marcamCode,
                                                                    "A_Master_Payout_Option_key":"",
                                                                   "A_Code_GIO_SIO_key": "N",//Changed by ankita on 18 Dec 2018 as mail sent by Chui San

                                                                   "A_CA_Load_Rate_01_rea":"",//Added by ankita - While integrating vpm version 324 we get this field as missing when calling output function
                                                                   "A_SB_Allocator_Prem_rea":"0",
                                                                   "A_SB_Allocator_Term_int":"0",
                                                                   "A_FullPay_boo":"",//new input added by ankita on 22 April 2019 as mail send by Chui San
                                                                   "A_Code_Insurance_Type_key":insuranceTypeCode[obj_mlife_res["al_person_details.mlife.insu_type"]],
                                                                   "A_Code_Religion_key":"",//added by ankita on 9 July 2019
                                                                   "A_Master_Full_Coverage_Age_key":"",//added by ankita by email of chui san on 25 July 2019
                                                                   "A_Payout_Survival_Benf_key":"",
                                                                   "A_Master_Accumulation_Period_key":"",
                                                                   "A_Retirement_Income_rea":"0",
                                                                   "A_GtdSurvivalBen_rea":"0",
                                                                   "A_Master_Sum_Assured_key":"" //added by Shivani for change in PAMBNEWP-5679 on 3May 2022 for PRUCancerX product
                                                                   
                                                                   },

                                                                
                                                                "VPMSCallType":"compute"
                                                     
                                                     }
                                                                   //added by ankita for modern family CR
                                                                     if(obj_mlife_res["al_person_details.mlife.insu_type_header"]=="non_business_purpose")
                                                                   {
                                                                            
                                                                            if(obj_mlife_res["al_sqs_details.sec_parti_flag"] == "No")
                                                                            {
                                                                            pagedata["setvar"]["A_Code_Insurance_Type_key"]="SELF"
                                                                            
                                                                            }
                                                                            else if(obj_mlife_res["al_sqs_details.sec_parti_flag"] == "Yes")
                                                                            {
                                                                            pagedata["setvar"]["A_Code_Insurance_Type_key"]=arrModernFamilyList[obj_slife_res["al_person_details.slife.relationship"]];
                                                                            }
                                                                   }
                                                            
                                                            if(currentPlan == "PRULink Cover" || currentPlan == "PRUwith you" || currentPlan == "PRUSignature Assure")
                                                          {
                                                                   
                                                                   if(document.getElementById("al_rider_sqs.prumillion_med_active.id").checked == true)
                                                                   {
                                                                   pagedata["setvar"]["A_Discount_Tier_key"]="2"
                                                                   
                                                                   }
                                                                   else
                                                                   {
                                                                       pagedata["setvar"]["A_Discount_Tier_key"]="";
                                                                   }
                                                          }
                                                               //added by ankita for PAMBNEWP-8825
                                                                   //added by ankita to change logic of passing code to VPMS PRUSIgnature Vanguard onwards
                                                                    if(currentPlan !== "PRUSignature Protect" && currentPlan !== "EssentialLife (SP)")//Added by sachin tupe for insu type
                                                                   {
                                                                   if(obj_mlife_res["al_person_details.mlife.insu_type"]==="Business Loan Insurance (for Company/LLP)")
                                                               {
                                                                             pagedata["setvar"]["A_Code_Insurance_Type_key"]="BLCO"
                                                                             
                                                               }
                                                                             if(obj_mlife_res["al_person_details.mlife.insu_type"]==="Business Loan Insurance (for Sole Proprietorship/Partnership)")
                                                                             {
                                                                                           pagedata["setvar"]["A_Code_Insurance_Type_key"]="BLSP"
                                                                                           
                                                                             }
                                                                   }
                                                                   if(obj_prochoice["al_sqs_details.product_name"] === "PRUSignature Treasure")
                                                                   {
                                                                   pagedata["setvar"]["A_GtdSurvivalBen_rea"]=(document.getElementById("al_rider_sqs.retirement_income.rider_value") != undefined && document.getElementById("al_rider_sqs.retirement_income.rider_value") != "null" && document.getElementById("al_rider_sqs.retirement_income.rider_value").value!="")? document.getElementById("al_rider_sqs.retirement_income.rider_value").value :"0"
                                                                   
                                                                   }
                                                                   
                                                                   //added by ankita on 7 dec 2020 as per changes requested for POTD-23607
                                                                  if(obj_prochoice["al_sqs_details.payment_backdate"]=="Yes")
                                                                  {
                                                                      pagedata["setvar"]["A_Rating_MAR_dat"]=inceptionDate[2]+inceptionDate[1]+inceptionDate[0];
                                                                      pagedata["setvar"]["A_Policy_Proposal_dat"]=inceptionDate[2]+inceptionDate[1]+inceptionDate[0];
                                                                   
                                                                  }
                                                                   else
                                                                   {
                                                                      pagedata["setvar"]["A_Rating_MAR_dat"]=Current_Date_dat;
                                                                      pagedata["setvar"]["A_Policy_Proposal_dat"]=Current_Date_dat;
                                                                   }
                                                                   if(obj_prochoice["al_sqs_details.product_name"] == "EssentialLife (SP)" && channelTypeForAgencyBancaRepls == "uob")
                                                                   {
                                                                       if(subChannelTypeForAgencyBancaRepls == "BB")
                                                                       {
                                                                            szSubChannelName = "SME";
                                                                       }
                                                                       else if(subChannelTypeForAgencyBancaRepls == "CB")
                                                                       {
                                                                            szSubChannelName = "CBD";
                                                                       }
                                                                       else
                                                                       {
                                                                            szSubChannelName = subChannelTypeForAgencyBancaRepls;
                                                                       }
                                                                   
                                                                     //szSubChannelName = subChannelTypeForAgencyBancaRepls;//added by ankita on 11 may 2020 as changes sent thorugh email dated on 8 may 2020 by chui san
                                                                     pagedata["setvar"]["A_Code_Sub_Channel_key"]=szSubChannelName;
                                                                   }
                                                                   // Added by Shivani on 25/02/2021
                                                                   if(obj_prochoice["al_sqs_details.product_name"] === "PRUMulti Crisis Guard")
                                                                                                                                     {
                                                                                                                                        
                                                                                                                                              szSubChannelName = subChannelTypeForAgencyBancaRepls;
                                                                                                                                       
                                                                                                                                       pagedata["setvar"]["A_Code_Sub_Channel_key"]=szSubChannelName;
                                                                                                                                     }
                                                                   
                                                                   
                                                                   
                                                                   console.log("szOldAllocatorValueIfNA:"+szOldAllocatorValueIfNA);
                                                                   //added by ankita for defect 8857 to restore previous value
                                                                   if(szOkToAmendCVFlag == "Yes" && (obj_prochoice["al_sqs_details.product_name"]=="PRUmillion cover" || obj_prochoice["al_sqs_details.product_name"]== "PRUMillion Cover 2.0" || obj_prochoice["al_sqs_details.product_name"]== "PRUEnhanced Cover"))
                                                                   {
                                                                        pagedata["setvar"]["A_Budget_Exc_Premium_rea"] = szOldAllocatorValueIfNA.toString();
                                                                   }
                                                                   if(currentPlan == "PRUSignature Optimiser" || currentPlan=="PRUcash double reward" || currentPlan=="PRUcash")
                                                                   {
                                                                        pagedata["setvar"]["A_Payout_Survival_Benf_key"]= "01";
                                                                   }
                                                                   //added by ankita on 19 Sept for RGSP VPMS inputs
                                                                   if(currentPlan == "RetireGuard (SP)" || currentPlan == "PRUretirement growth")
                                                                   {
                                                                        pagedata=fnSetRequiredInputsForRGSP(pagedata);
                                                                   
                                                                   }
                                                                   if(currentPlan == "PRUwealth gain plus")
                                                                   {
                                                                        pagedata["setvar"]["A_FullPay_boo"]="N";
                                                                   }
                                                                   if(currentPlan == "PRUWealth Plus" || currentPlan == "PRUWealth Max" ||  currentPlan=== "PRUSignature Vanguard" ||  currentPlan=== "PRUWealth Enrich")
                                                                   {
                                                                   
                                                                   //Code Added for Full pay condition handling by Sachin Tupe on date 12-7-2019.
                                                                   var vpmsFullPayValue=document.getElementById("al_sqs_details.premium_payment_period_pw_plus");
                                                                   var vpmsFpValue=vpmsFullPayValue.options[vpmsFullPayValue.selectedIndex]
                                                                   var vpmsFullIndicatorVal=vpmsFpValue.value.split("_")[0]
                                                                   console.log("vpmsFullIndicatorVal"+vpmsFullIndicatorVal);
                                                                
                                                                   pagedata["setvar"]["A_Master_Premium_Term_key"]=vpmsFullIndicatorVal //Added for full pay issue on date 12-5-2019 by sachin
                                                                   
                                                                        var selectedPaymentPeriod=document.getElementById("al_sqs_details.premium_payment_period_pw_plus").options[document.getElementById("al_sqs_details.premium_payment_period_pw_plus").selectedIndex ].text;
                                                                        console.log("selectedPaymentPeriod:"+selectedPaymentPeriod);
                                                                        if(selectedPaymentPeriod == "Full pay")
                                                                        {
                                                                            pagedata["setvar"]["A_FullPay_boo"]="Y";
                                                                        }
                                                                        else
                                                                        {
                                                                            pagedata["setvar"]["A_FullPay_boo"]="N";
                                                                        }
                                                                   }
                                                                   if(currentPlan == "PRUcash double reward")
                                                                   {
                                                                        //pagedata["setvar"]["A_Master_Premium_Term_key"]=document.getElementById("al_sqs_details.premium_payment_term_cash").value;
                                                                   if(document.getElementById("al_sqs_details.premium_payment_term_cash").value=="0")
                                                                   {
                                                                      pagedata["setvar"]["A_Master_Premium_Term_key"]=""
                                                                   }
                                                                   else
                                                                   {
                                                                     pagedata["setvar"]["A_Master_Premium_Term_key"]=document.getElementById("al_sqs_details.premium_payment_term_cash").value
                                                                   }
                                                                   }
                                                                   
                                                                   
                                                                   /********Added for PRUMy Gift***********/
                                                                   if(currentPlan == "PRUMy Gift")
                                                                   {
                                                                   
                                                                   //Code Added for Full pay condition handling by Sachin Tupe on date 12-7-2019.
                                                                   var vpmsFullPayValue=document.getElementById("al_sqs_details.premium_payment_period_plm_plus");
                                                                   var vpmsFpValue=vpmsFullPayValue.options[vpmsFullPayValue.selectedIndex];
                                                                   var vpmsFullIndicatorVal=vpmsFpValue.value.split("_")[0];
                                                                   console.log("vpmsFullIndicatorVal"+vpmsFullIndicatorVal);
                                                                   
                                                                   pagedata["setvar"]["A_Master_Premium_Term_key"]=vpmsFullIndicatorVal //Added for full pay issue on date 12-5-2019 by sachin
                                                                   
                                                                   var selectedPaymentPeriod=document.getElementById("al_sqs_details.premium_payment_period_plm_plus").options[document.getElementById("al_sqs_details.premium_payment_period_plm_plus").selectedIndex ].text;
                                                                   console.log("selectedPaymentPeriod:"+selectedPaymentPeriod);
                                                                   if(selectedPaymentPeriod == "Full pay")
                                                                   {
                                                                   pagedata["setvar"]["A_FullPay_boo"]="Y";
                                                                   }
                                                                   else
                                                                   {
                                                                   pagedata["setvar"]["A_FullPay_boo"]="N";
                                                                   }
                                                                   }
                                                                   
                                                                   
                                                                  
                                                                   
                                                                   
                                                                   
                                                                   if(currentPlan === "PRUMulti Crisis Guard")
                                                                                                                                     {
                                                                                                                                     
                                                                                                                                    
                                                                                                                                     var vpmsFullPayValue=document.getElementById("al_sqs_details.premium_payment_period_plm_plus");
                                                                                                                                     var vpmsFpValue=vpmsFullPayValue.options[vpmsFullPayValue.selectedIndex];
                                                                   
                                                                   
                                                                   
                                                                                                                                     var vpmsFullIndicatorVal=vpmsFpValue.value.split("_")[0];
                                                                                                                                     console.log("vpmsFullIndicatorVal"+vpmsFullIndicatorVal);
                                                                                                                 // Modified condition by Shivani for DEF - 10497
                                                                                                                if(document.getElementById("al_sqs_details.premium_payment_period_plm_plus").value=="0")
                                                                                                                                     {
                                                                                                                                        pagedata["setvar"]["A_Master_Premium_Term_key"]="";
                                                                                                                                     }
                                                                                                                                     else
                                                                                                                                     {
                                                                                                                                       pagedata["setvar"]["A_Master_Premium_Term_key"]=vpmsFullIndicatorVal;
                                                                                                                                     }
                                                                   
                                                                                                                                    
                                                                                                                                     var selectedPaymentPeriod=document.getElementById("al_sqs_details.premium_payment_period_plm_plus").options[document.getElementById("al_sqs_details.premium_payment_period_plm_plus").selectedIndex ].text;
                                                                                                                                     console.log("selectedPaymentPeriod:"+selectedPaymentPeriod);
                                                                                                                                     if(selectedPaymentPeriod == "Full pay")
                                                                                                                                     {
                                                                                                                                     pagedata["setvar"]["A_FullPay_boo"]="Y";
                                                                                                                                     }
                                                                                                                                     else
                                                                                                                                     {
                                                                                                                                     pagedata["setvar"]["A_FullPay_boo"]="N";
                                                                                                                                     }
                                                                   
                                                                  
                                                                                                                                     }
                                                                   
                                                                   
                                                                    console.log("marcamStart:"+marcamStart);
                                                                    console.log("Current_Date_dat:"+Current_Date_dat);
                                                                    console.log("marcamend:"+marcamend);
                                                                   var today = new Date();
                                                                   
                                                                   
                                                         if(currentPlan == "PRUSignature Booster") //to remove // need to change by Paromita
                                                            {
                                                                   
                                                                    //pagedata["setvar"]["A_Master_Product_Master_Key"]= "SP02";
                                                                    pagedata["setvar"]["A_Master_Premium_Term_key"]= "";
                                                                   pagedata["setvar"]["A_Code_Plan_Type_key"]= "ILP";
                                                                   
                                                                   
                                                                   
                                                            }
                                                            if(currentPlan == "PRUMan" || currentPlan == "PRULady_PRL") //to remove // need to change by Paromita
                                                               {
                                                                      
                                                                       
                                                                       pagedata["setvar"]["A_Master_Premium_Term_key"]= document.getElementById("al_rider_sqs.common_products.premium_payment_term").value;
                                                                     
                                                                      
                                                                      
                                                                      
                                                               }
                                                                 
                                                              
                                                                
                                                                   
                                                                   
                                                                   if(currentPlan == "PRUcash") //pcvpms
                                                                   {
                                                                   ////set blank by ankita as per changes in potd-20756 on 8 oct 2020
                                                                   pagedata["setvar"]["A_Master_Premium_Term_key"]=""
                                                                   
                                                                   // Modified by Shivani
                                                                   /*if(document.getElementById("al_rider_sqs.prucash.rider_term").value=="0")
                                                                   {
                                                                      pagedata["setvar"]["A_Master_Premium_Term_key"]=""
                                                                   }
                                                                   else
                                                                   {
                                                                     pagedata["setvar"]["A_Master_Premium_Term_key"]=document.getElementById("al_rider_sqs.prucash.rider_term").value
                                                                   }*/
                                                                   
                                                                   
                                                                   pagedata["setvar"]["A_Master_Payout_Frequency_key"]="01";
                                                                   }
                                                                   
                                                                   // Shivani / Ankita added temporary on 26th Nov 2020
                                                                   /*if(currentPlan == "PRUSignature Reserve" || currentPlan == "PRUSignature Reward")
                                                                   {
                                                                   console.log("1234567898");
                                                                   pagedata["setvar"]["A_Proposal_Received_dat"]= Current_Date_dat;
                                                                   }*/
                                                                   
                                                                   
                                                                   
                                                            if(currentPlan == "PRUSignature Invest" || currentPlan == "PRUGlobal Series" || currentPlan == "PRUMy Gift" || currentPlan =="PRULink Cover" || currentPlan =="PRUMax Cover" || currentPlan ==="PRUMulti Crisis Guard" || currentPlan ==="PRUSignature Assure" || currentPlan ==="PRULink Growth" || currentPlan ==="PRULink Supreme" || currentPlan ==="PRUSignature Vanguard" || currentPlan === "PRUSignature Ace" || currentPlan === "PRUElite Invest" || currentPlan === "PRUSignature GrowthPlus" || currentPlan === "PRULink Supreme Plus" || currentPlan === "PRUSignature Plus")
                                                            {
                                                                pagedata["setvar"]["A_Code_Plan_Type_key"]= "ILP";
                                                                
                                                            }
                                                                   
                                                   if(currentPlan == "PRUsignature income")
                                                   {
                                                        pagedata["setvar"]["A_Master_Payout_Age_key"]= document.getElementById("al_sqs_details.prusignature_income_payout_age").value;
                                                        pagedata["setvar"]["A_Master_Payout_Frequency_key"]= document.getElementById("al_sqs_details.prusignature_income_payout_frequency").value;
                                                        pagedata["setvar"]["A_Master_Payout_Period_key"]= document.getElementById("al_sqs_details.prusignature_income_payout_period").value;
                                                     
                                                   }
                                                                   if(currentPlan == "PRUcash double reward")
                                                                   {
                                                                        pagedata["setvar"]["A_Master_Payout_Frequency_key"]="01";
                                                                   }
                                                    
                                                    console.log("DAP Flag:"+document.getElementById("al_sqs_details.premium_lump_sum"));
                                                    if(document.getElementById("al_sqs_details.premium_lump_sum") != undefined && document.getElementById("al_sqs_details.premium_lump_sum") != "null" && document.getElementById("al_sqs_details.premium_lump_sum") != null)
                                                    {
                                                                   console.log("DAP Flag value:"+document.getElementById("al_sqs_details.premium_lump_sum"));
                                                                   if(document.getElementById("al_sqs_details.premium_lump_sum").checked)
                                                                   {
                                                                      pagedata["setvar"]["A_SelectDAP_boo"]= "Y";
                                                                   
                                                                   }
                                                                   else
                                                                   {
                                                                      pagedata["setvar"]["A_SelectDAP_boo"]= "N";
                                                                   }
                                                    }
                                               if(currentPlan == "PRUcash double reward" || currentPlan == "PRUcash")
                                               {
                                                if(document.getElementById("al_sqs_details.premium_lump_sum_cash") != undefined && document.getElementById("al_sqs_details.premium_lump_sum_cash") != "null" && document.getElementById("al_sqs_details.premium_lump_sum_cash") != null)
                                                   {
                                                   console.log("DAP Flag value:"+document.getElementById("al_sqs_details.premium_lump_sum_cash"));
                                                   if(document.getElementById("al_sqs_details.premium_lump_sum_cash").checked)
                                                   {
                                                   pagedata["setvar"]["A_SelectDAP_boo"]= "Y";
                                                   
                                                   }
                                                   else
                                                   {
                                                   pagedata["setvar"]["A_SelectDAP_boo"]= "N";
                                                   }
                                                   }
                                            }
                                                                   
                                                    if(currentPlan == "PRUsmart gain")
                                                   {
                                                       if(document.getElementById("al_sqs_details.payout_lump_sum_prusmart_gain.id") != undefined && document.getElementById("al_sqs_details.payout_lump_sum_prusmart_gain.id") != "null" && document.getElementById("al_sqs_details.payout_lump_sum_prusmart_gain.id") != null)
                                                       {
                                                           console.log("DAP Flag value:"+document.getElementById("al_sqs_details.payout_lump_sum_prusmart_gain.id"));
                                                           if(document.getElementById("al_sqs_details.payout_lump_sum_prusmart_gain.id").checked)
                                                           {
                                                                   pagedata["setvar"]["A_SelectDAP_boo"]= "Y";
                                                           
                                                           }
                                                           else
                                                           {
                                                                   pagedata["setvar"]["A_SelectDAP_boo"]= "N";
                                                           }
                                                       }
                                                    }
                                                    
                                                    
                                                    if(currentPlan == "PRUwith you" || currentPlan == "PRUmillion cover" || currentPlan == "PRUmy treasure" || currentPlan == "PRUsignature prime" || currentPlan == "PRUSignature Invest" || currentPlan == "PRULink Investor Account" || currentPlan == "PRUGlobal Series" || currentPlan == "PRULink Cover" || currentPlan == "PRUMy Gift" || currentPlan == "PRUMillion Cover 2.0" || currentPlan === "PRUMulti Crisis Guard" || currentPlan == "PRUSignature Assure" || currentPlan === "PRULink Growth" || currentPlan === "PRUSignature Ace" || currentPlan === "PRUEnhanced Cover")//Sourabh added PRUSignature Invest on 16 jan 2019 @@@ // by sourabh on  1 april 2019 for PRUGlobal Series
                                                    {
                                                                   if(document.getElementById("al_sqs_details.insurance_premium").value == "")
                                                                   {
                                                                     pagedata["setvar"]["A_Budget_Premium_rea"]= "0";//
                                                                   }
                                                                   else
                                                                   {
                                                                   pagedata["setvar"]["A_Budget_Premium_rea"]= document.getElementById("al_sqs_details.insurance_premium").value;
                                                                   }
                                                                   if(currentPlan == "PRUsignature prime" || currentPlan == "PRUGlobal Series")
                                                                   {
                                                                        pagedata["setvar"]["A_Currency_key"] = "USD";
                                                                   }
                                                    }else if(currentPlan == "PRUWealth Plus" || currentPlan == "PRUWealth Max" || currentPlan=== "PRUSignature Vanguard" || currentPlan=== "PRUWealth Enrich")
                                                            {
                                                                   
                                                                   if(document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").value == "")
                                                                   {
                                                                   pagedata["setvar"]["A_Budget_Premium_rea"]= "0";
                                                                   }
                                                                   else
                                                                   {
                                                                   pagedata["setvar"]["A_Budget_Premium_rea"]= document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").value;
                                                                   }
                                                                   if(currentPlan=== "PRUWealth Enrich") //Def -1122 by Paromita on 29th Aug
                                                                   {
                                                                       if(document.getElementById("al_sqs_details.insurance_premium").value == "")
                                                                       {
                                                                           pagedata["setvar"]["A_Budget_Premium_rea"]= "0";
                                                                       }
                                                                       else
                                                                       {
                                                                           pagedata["setvar"]["A_Budget_Premium_rea"]= Math.min(parseFloat(pagedata["setvar"]["A_Budget_Premium_rea"]),parseFloat(document.getElementById("al_sqs_details.pwp_max_bua_premium").value)).toString(); // Def 1089 on 31Aug by Paromita
                                                                       }
                                                                       if(document.getElementById("al_sqs_details.pruallocator_premium").value == "" || document.getElementById("al_sqs_details.pruallocator_premium").value == "0.00")
                                                                       {
                                                                           pagedata["setvar"]["A_Budget_Exc_Premium_rea"] = "0"
                                                                       }
                                                                       else
                                                                       {
                                                                           pagedata["setvar"]["A_Budget_Exc_Premium_rea"]= document.getElementById("al_sqs_details.pruallocator_premium").value;
                                                                           szPRUallocatorPremiumAvailable  = "Yes";
                                                                       }
                                                                   }
                                                                   
                                                            }
                                                    else if(currentPlan == "PRUsignature infinite" )
                                                    {
                                                                   if(document.getElementById("al_rider_sqs.prusignature_infinite.rider_premium").value != "")
                                                                   {
                                                                        pagedata["setvar"]["A_Budget_Premium_rea"]= (parseFloat(document.getElementById("al_rider_sqs.prusignature_infinite.rider_premium").value) * 0.2).toString();
                                                                        pagedata["setvar"]["A_Budget_Exc_Premium_rea"]= (parseFloat(document.getElementById("al_rider_sqs.prusignature_infinite.rider_premium").value) * 0.8).toString();
                                                                   }
                                                                   else
                                                                   {
                                                                        pagedata["setvar"]["A_Budget_Premium_rea"]= "0";
                                                                   }
                                                    }
                                                    // else if condition added by Shivani on 23rd Jan 2020 for PRUMax Cover
                                                   else if(currentPlan == "PRUMax Cover" )
                                                   {
                                                                   if(document.getElementById("al_rider_sqs.prusignature_infinite.rider_premium").value != "")
                                                                   {
                                                                            pagedata["setvar"]["A_Budget_Premium_rea"]= (parseFloat(document.getElementById("al_rider_sqs.prusignature_infinite.rider_premium").value) * 0.5).toString();
                                                                            pagedata["setvar"]["A_Budget_Exc_Premium_rea"]= (parseFloat(document.getElementById("al_rider_sqs.prusignature_infinite.rider_premium").value) * 0.5).toString();
                                                                   }
                                                                   else
                                                                   {
                                                                            pagedata["setvar"]["A_Budget_Premium_rea"]= "0";
                                                                   }
                                                                   
                                                   }
                                                    else if(currentPlan == "PRUsignature USD" || currentPlan == "PRUsignature") //added by supriya for usd
                                                    {
                                                    
                                                    pagedata["setvar"]["A_Master_Premium_Term_key"] = "3";
                                                    if(document.getElementById("al_rider_sqs.prusignature.rider_premium").value != "")
                                                    {
                                                    pagedata["setvar"]["A_Budget_Premium_rea"]= document.getElementById("al_rider_sqs.prusignature.rider_premium").value;
                                                                   
                                                    }
                                                    else
                                                   {
                                                    pagedata["setvar"]["A_Budget_Premium_rea"]= "0";
                                                   }
                                                    
                                                    pagedata["setvar"]["A_Master_ILP_TargetSust_key"]= "A100";
                                                    pagedata["setvar"]["A_Currency_key"] = "USD";
                                                    pagedata["setvar"]["A_Master_Policy_Term_key"] = "";
                                                                   
                                                                   if(currentPlan == "PRUsignature"){
                                                                   
                                                                     pagedata["setvar"]["A_Master_FlexiWithdrawal_boo"]="";
                                                                     pagedata["setvar"]["A_Master_MaxIncomeOption_boo"]="";
                                                                   
                                                                   }
                                                    
                                                    }
                                                                   // Added by Shivani for Mar2022
                                                                   else if(currentPlan ==="PRULink Supreme")
                                                                    {
                                                                    
                                                                    pagedata["setvar"]["A_Master_Premium_Term_key"] = "3";
                                                                    if(document.getElementById("al_rider_sqs.basic_plan.rider_premium").value != "")
                                                                    {
                                                                    pagedata["setvar"]["A_Budget_Premium_rea"]= document.getElementById("al_rider_sqs.basic_plan.rider_premium").value;
                                                                                   
                                                                    }
                                                                    else
                                                                   {
                                                                    pagedata["setvar"]["A_Budget_Premium_rea"]= "0";
                                                                   }
                                                                    
                                                            
                                                                    
                                                                    }
                                                            
                                                                   else if(currentPlan ==="PRULink Supreme Plus" || currentPlan ==="PRUSignature Plus")
                                                                    {
                                                                    
                                                                    pagedata["setvar"]["A_Master_Premium_Term_key"] = document.getElementById("al_sqs_details.premium_payment_period_plm_plus").value;
                                                                    if(document.getElementById("al_rider_sqs.basic_plan.rider_premium").value != "")
                                                                    {
                                                                    pagedata["setvar"]["A_Budget_Premium_rea"]= document.getElementById("al_rider_sqs.basic_plan.rider_premium").value;
                                                                                   
                                                                    }
                                                                    else
                                                                   {
                                                                    pagedata["setvar"]["A_Budget_Premium_rea"]= "0";
                                                                   }
                                                                    
                                                            
                                                                    
                                                                    }
                                                                   else if(currentPlan ==="PRUElite Invest" || currentPlan ==="PRUSignature GrowthPlus")
                                                                           {
                                                                           
                                                                           pagedata["setvar"]["A_Master_Premium_Term_key"] = "5";
                                                                           if(document.getElementById("al_rider_sqs.basic_plan.rider_premium").value != "")
                                                                           {
                                                                           pagedata["setvar"]["A_Budget_Premium_rea"]= document.getElementById("al_rider_sqs.basic_plan.rider_premium").value;
                                                                                          
                                                                           }
                                                                           else
                                                                          {
                                                                           pagedata["setvar"]["A_Budget_Premium_rea"]= "0";
                                                                          }
                                                                           
                                                                   
                                                                           
                                                                           }
                                                                   
                                                                   
                                                    else if(currentPlan == "PRUwealth gain plus" || currentPlan == "PRUSignature Optimiser" || currentPlan =="PRUValue Gain" || currentPlan =="PRUSignature Reward" )//added condition for PRUgrowth by Ankita
                                                    {
                                                     pagedata["setvar"]["A_Master_Premium_Term_key"]=document.getElementById("al_sqs_details.premium_payment_term").value;
                                                     pagedata["setvar"]["A_Budget_Premium_rea"]= "0";
                                                    }
                                                   else if(currentPlan === "PRUCash Enrich" || currentPlan =="PRUFlexi Gain" || currentPlan =="PRUGain Plus" || currentPlan =="PRUSignature Harvest" || currentPlan==="PRUSignature Treasure" || currentPlan =="PRUSignature Harvest Plus" || currentPlan =="PRUEnrich Gain" || currentPlan =="PRUSignature Boost")
                                                   {
                                                   pagedata["setvar"]["A_Master_Premium_Term_key"] = (document.getElementById("al_sqs_details.premium_payment_term") != undefined && document.getElementById("al_sqs_details.premium_payment_term") != "null" && document.getElementById("al_sqs_details.premium_payment_term").value !="0")? document.getElementById("al_sqs_details.premium_payment_term").value :"";
                                                   }
                                                   else if(currentPlan == "PRUgrowth" || currentPlan == "PRUEasy Protect")
                                                   {
                                                        if(document.getElementById("al_sqs_details.premium_payment_term").value=="0")
                                                        {
                                                                   pagedata["setvar"]["A_Master_Premium_Term_key"]="";
                                                        }
                                                        else
                                                        {
                                                                  pagedata["setvar"]["A_Master_Premium_Term_key"]=document.getElementById("al_sqs_details.premium_payment_term").value;
                                                        }
                                                                   
                                                       pagedata["setvar"]["A_Budget_Premium_rea"]= "0";
                                                   }
                                                   else if(currentPlan == "PRUcancer X")//added condition for PRUgrowth by Ankita
                                                   {
                                                   pagedata["setvar"]["A_Master_Premium_Term_key"]=document.getElementById("al_sqs_details.premium_payment_term_text").value;
                                                        
                                                   }
                                                   else if(currentPlan == "PRUsmart gain")
                                                   {
                                                      pagedata["setvar"]["A_Budget_Premium_rea"]= "0";
                                                   }
                                                   else if(currentPlan == "PRUsignature income")
                                                   {
                                                       if(document.getElementById("al_rider_sqs.basic_plan.rider_premium").value != "")
                                                       {
                                                       pagedata["setvar"]["A_Budget_Premium_rea"]= document.getElementById("al_rider_sqs.basic_plan.rider_premium").value;
                                                       }
                                                       else
                                                       {
                                                       pagedata["setvar"]["A_Budget_Premium_rea"]= "0";
                                                       }
                                                   }
                                                    else if(currentPlan == "PRUSignature Booster")
                                                   {
                                                        pagedata["setvar"]["A_Budget_Premium_rea"]="4000";
                                                   }
                                                          
                                                                   
                                                if(currentPlan === "PRUAll Care"){
                                                                   
                                                                    pagedata["setvar"]["A_Master_Premium_Term_key"]=document.getElementById("al_rider_sqs.basic_plans.rider_term").value
                                                                   
                                                                   }
                                                                   
                                                                   
                                                                   
                                                                   
                                                   
                                                                   
                                                    if(obj_mlife_res["al_sqs_details.sec_parti_flag"] == "Yes")
                                                    {
                                                                noOfLife = 2;
                                                    }
                                                    else
                                                    {
                                                               pagedata["setvar"]["A_CODE_SMOKER_STATUS_02_KEY"]="";
                                                               pagedata["setvar"]["A_Code_Smoker_Status_02_key"]="";
                                                               pagedata["setvar"]["A_CODE_GENDER_02_KEY"]="";
                                                               pagedata["setvar"]["A_Code_Gender_02_key"]="";
                                                               pagedata["setvar"]["A_Insured_DOB_02_dat"]="";
                                                               pagedata["setvar"]["A_Insured_Name_02_str"]="";
                                                               pagedata["setvar"]["A_Occupation_02_key"]="";
                                                               pagedata["setvar"]["A_Code_Nature_Business_02_key"]="";
                                                               pagedata["setvar"]["A_Code_Occupation_02_key"]="";
                                                               pagedata["setvar"]["A_Death_Load_Rate_02_rea"]="0";
                                                               pagedata["setvar"]["A_Death_Load_Permille_02_rea"]="0";
                                                               pagedata["setvar"]["A_Death_Load_Pursuit_02_rea"]="0";
                                                               pagedata["setvar"]["A_Death_Load_Permille_Term_02_rea"]="0";
                                                               pagedata["setvar"]["A_Death_Load_Pursuit_Term_02_rea"]="0";
                                                               pagedata["setvar"]["A_TPD_Load_Rate_02_rea"]="0";
                                                               pagedata["setvar"]["A_TPD_Load_Permille_02_rea"]="0";
                                                               pagedata["setvar"]["A_TPD_Load_Pursuit_02_rea"]="0";
                                                               pagedata["setvar"]["A_CC_Load_Rate_02_rea"]="0";
                                                               pagedata["setvar"]["A_TPD_Load_Permille_Term_02_rea"]="0";
                                                               pagedata["setvar"]["A_TPD_Load_Pursuit_Term_02_rea"]="0";
                                                               
                                                    }
                                                    if(obj_slife_res["al_sqs_details.third_parti_flg"] == "Yes")
                                                    {
                                                               noOfLife = 3;
                                                    }
                                                    else
                                                    {
                                                               
                                                               
                                                                pagedata["setvar"]["A_CODE_SMOKER_STATUS_03_KEY"]="";
                                                                pagedata["setvar"]["A_Code_Smoker_Status_03_key"]="";
                                                                pagedata["setvar"]["A_CODE_GENDER_03_KEY"]="";
                                                                pagedata["setvar"]["A_Code_Gender_03_key"]="";
                                                                pagedata["setvar"]["A_Insured_DOB_03_dat"]="";
                                                                pagedata["setvar"]["A_Insured_Name_03_str"]="";
                                                                pagedata["setvar"]["A_Occupation_03_key"]="";
                                                                pagedata["setvar"]["A_Code_Nature_Business_03_key"]="";
                                                                pagedata["setvar"]["A_Code_Occupation_03_key"]="";
                                                               pagedata["setvar"]["A_Death_Load_Rate_03_rea"]="0";
                                                               pagedata["setvar"]["A_Death_Load_Permille_03_rea"]="0";
                                                               pagedata["setvar"]["A_Death_Load_Pursuit_03_rea"]="0";
                                                               pagedata["setvar"]["A_Death_Load_Permille_Term_03_rea"]="0";
                                                               pagedata["setvar"]["A_Death_Load_Pursuit_Term_03_rea"]="0";
                                                               pagedata["setvar"]["A_TPD_Load_Rate_03_rea"]="0";
                                                               pagedata["setvar"]["A_TPD_Load_Permille_03_rea"]="0";
                                                               pagedata["setvar"]["A_TPD_Load_Pursuit_03_rea"]="0";
                                                               pagedata["setvar"]["A_CC_Load_Rate_03_rea"]="0";
                                                               pagedata["setvar"]["A_TPD_Load_Permille_Term_03_rea"]="0";
                                                               pagedata["setvar"]["A_TPD_Load_Pursuit_Term_03_rea"]="0";

                                                                
                                                    }
                                                   if(obj_mlife_res["al_sqs_details.sec_parti_flag"] == "Yes")
                                                   {
                                                   pagedata["setvar"]["A_Second_Life_boo"]="Y";
                                                   
                                                   }
                                                   else
                                                   {
                                                   pagedata["setvar"]["A_Second_Life_boo"]="N";
                                                   
                                                   }
                                                   if(obj_slife_res["al_sqs_details.third_parti_flg"] == "Yes")
                                                   {
                                                   pagedata["setvar"]["A_Third_Life_boo"]="Y";
                                                   }
                                                   else
                                                   {
                                                   pagedata["setvar"]["A_Third_Life_boo"]="N";
                                                   }
                                                   if(obj_mlife_res["al_person_details.pre_natal_child_flg"] == "Yes")
                                                   {
                                                   pagedata["setvar"]["A_Insured_Prenatal_01_boo"]="Y";
                                                   }
                                                   else
                                                   {
                                                   pagedata["setvar"]["A_Insured_Prenatal_01_boo"]="N";
                                                   }
                                                                   //Added by ankita for aoto calculate for product PRUwith you and solution selected is diabetic care
                                                                   var
                                                                   obj_loading_solutions = solutions_loading;
                                                                   var loadingArrayId={"TPD":"al_loading_details_sqs.mlife.tpd.value","CI":"al_loading_details_sqs.mlife.critical_illness.value","Medical":"al_loading_details_sqs.mlife.ah_phl.value_millennium","Medical":"al_loading_details_sqs.mlife.medical.value"};
                                                                   var objLoadingArrayToSetInInput = {};
                                                                   //added by ankita on 9 April 2019 for defect 7090
                                                                   
                                                                   objLoadingToSetForOutput = "{";
                                                                   //end
                                                                   for(i=0;i<obj_loading_solutions.length;i++)
                                                                   {
                                                                   console.log("obj_solutions_loading[i]:"+JSON.stringify(obj_loading_solutions[i]));
                                                                   var getValuesToSet = obj_loading_solutions[i];
                                                                   console.log("getValuesToSet:"+getValuesToSet["SolutionName"]);
                                                                   if(getValuesToSet["SolutionName"] == "PRUmy diabetes care" && (getValuesToSet["ProductName"] == "PRUwith you" || getValuesToSet["ProductName"] == "PRULink Cover" || getValuesToSet["ProductName"] == "PRUSignature Assure"))
                                                                   {
                                                                   console.log("Diabetes level:"+obj_solution["duration_with_diabets"]);
                                                                    console.log("Hba1c level:"+obj_solution["hba1c_level"]);
                                                                   if(obj_solution["duration_with_diabets"]>getValuesToSet["DiabeticDurationMin"] && obj_solution["duration_with_diabets"]<=getValuesToSet["DiabeticDurationMax"])
                                                                   {
                                                                   
                                                                   if(obj_solution["hba1c_level"]>getValuesToSet["HbA1cMin"] && obj_solution["hba1c_level"]<=getValuesToSet["HbA1cMax"])
                                                                   {
                                                                   
                                                                   var loadingId=loadingArrayId[getValuesToSet["LoadingParameter"]];
                                                                   //added by ankita on 9 April 2019 for defect 7090
                                                                   var loadingValueToSet=getValuesToSet["LoadingValue"];
                                                                   objLoadingToSetForOutput += '"'+loadingId+'":"'+loadingValueToSet+'",';
                                                                   console.log("loadingId:"+loadingId);
                                                                   console.log("loadingId1:"+getValuesToSet["LoadingValue"]);
                                                                   objLoadingArrayToSetInInput[loadingId] = getValuesToSet["LoadingValue"];
                                                                   console.log("objLoadingArray:"+objLoadingArrayToSetInInput[loadingId]);
                                                                   console.log("Padedata loading solurtion:"+JSON.stringify(objLoadingArrayToSetInInput));
                                                                   console.log("add loading solurtion:"+loadingAdditionalArray["al_loading_details_sqs.mlife.ah_phl.value_millennium"]);
                                                                 
                                                                   }
                                                                   }
                                                                   }
                                                                   }
                                                                   //added by ankita on 9 April 2019 for defect 7090
                                                                   objLoadingToSetForOutput = objLoadingToSetForOutput.slice(0, -1);
                                                                   objLoadingToSetForOutput += "}";
                                                                   //end
                                                                    console.log("Padedata loading solurtion1:"+JSON.stringify(objLoadingToSetForOutput));
                                                                   if(obj_loading == "" && obj_solution["al_sqs_buttons_plan"]=="al_sqs_buttons.prumy_diabetes_care")
                                                                   {
                                                                        obj_loading=objLoadingArrayToSetInInput;
                                                                   }
                                                                    console.log("Diabetes loading solurtion1:"+JSON.stringify(obj_loading));
                                                   
                                                                   
                                                    
                                                    for(var iCount=1;iCount<=noOfLife;iCount++)
                                                    {
                                                        var dob="";
                                                       
                                                        if(obj_mlife_res["al_person_details.pre_natal_child_flg"] == "Yes" && iCount == 1)
                                                        {
                                                           
                                                          dob = obj_mlife_res["al_person_details.mlife.expected_delivery_dt"].split("/");
                                                          
                                                        }
                                                        else
                                                        {
                                                          dob = eval("obj_"+personArray[iCount]+"_res[\"al_person_details."+personArray[iCount]+".dob\"]").split("/");
                                                        }
                                                       
                                                        pagedata["setvar"]["A_Insured_DOB_0"+iCount+"_dat"]= dob[2]+dob[1]+dob[0];
                                                        pagedata["setvar"]["A_Code_Gender_0"+iCount+"_key"]=eval("obj_"+personArray[iCount]+"_res[\"al_person_details."+personArray[iCount]+".gender\"]")=="Male"?"M":"F";
                                                        pagedata["setvar"]["A_Code_Smoker_Status_0"+iCount+"_key"]=eval("obj_"+personArray[iCount]+"_res[\"al_person_details."+personArray[iCount]+".smoke_status\"]")=="Smoker"?"S":"N";
                                                        pagedata["setvar"]["A_Insured_Name_0"+iCount+"_str"]=eval("obj_"+personArray[iCount]+"_res[\"al_person_details."+personArray[iCount]+".first_name\"]");
                                                        pagedata["setvar"]["A_Occupation_0"+iCount+"_key"]=getOccupationCodeAndNOB(eval("obj_"+personArray[iCount]+"_res[\"al_employee_details."+personArray[iCount]+".occupation\"]"),"","occupation");
                                                        pagedata["setvar"]["A_Code_Occupation_0"+iCount+"_key"]=getOccupationCodeAndNOB(eval("obj_"+personArray[iCount]+"_res[\"al_employee_details."+personArray[iCount]+".occupation\"]"),"","occupation");
                                                        pagedata["setvar"]["A_Code_Nature_Business_0"+iCount+"_key"]=eval("obj_"+personArray[iCount]+"_res[\"al_employee_details."+personArray[iCount]+".nature_of_business\"]");
                                                                   
                                                       pagedata["setvar"]["A_Death_Load_Rate_0"+iCount+"_rea"]=(eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".em.value\"]")!=undefined && eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".em.value\"]")!="null" && eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".em.value\"]")!="")?eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".em.value\"]"):"0" ;
                                                                   
                                                       pagedata["setvar"]["A_Death_Load_Permille_0"+iCount+"_rea"]=(eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".death_per_mille.value\"]")!=undefined && eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".death_per_mille.value\"]")!="null" && eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".death_per_mille.value\"]")!="")?eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".death_per_mille.value\"]"):"0";
                                                                   
                                                       pagedata["setvar"]["A_Death_Load_Pursuit_0"+iCount+"_rea"]=(eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".death_pursuit.value\"]")!=undefined && eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".death_pursuit.value\"]")!="null" && eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".death_pursuit.value\"]")!="")?eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".death_pursuit.value\"]"):"0";
                                                                   
                                                     
                                                                   
                                                        pagedata["setvar"]["A_TPD_Load_Rate_0"+iCount+"_rea"]=(eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".tpd.value\"]")!=undefined && eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".tpd.value\"]")!="null" && eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".tpd.value\"]")!="")?eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".tpd.value\"]"):"0";
                                                                   
                                                                   
                                                                   
                                                        pagedata["setvar"]["A_TPD_Load_Permille_0"+iCount+"_rea"]=(eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".tpd_per_mille.value\"]")!=undefined && eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".tpd_per_mille.value\"]")!="null" && eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".tpd_per_mille.value\"]")!="")?(eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".tpd_per_mille.value\"]")/100.0).toString():"0";
                                                                   
                                                       
                                                                   
                                                       pagedata["setvar"]["A_TPD_Load_Pursuit_0"+iCount+"_rea"]=(eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".tpd_pursuit.value\"]")!=undefined && eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".tpd_pursuit.value\"]")!="null" && eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".tpd_pursuit.value\"]")!="")?(eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".tpd_pursuit.value\"]")/100.0).toString():"0";
                                                                   
                                                       pagedata["setvar"]["A_CC_Load_Rate_0"+iCount+"_rea"]=(eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".critical_illness.value\"]")!=undefined && eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".critical_illness.value\"]")!="null" && eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".critical_illness.value\"]")!="")?eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".critical_illness.value\"]"):"0";
                                                                   
                                                       pagedata["setvar"]["A_Death_Load_Permille_Term_0"+iCount+"_rea"]=(eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".death_per_mille_term.value\"]")!=undefined && eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".death_per_mille_term.value\"]")!="null" && eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".death_per_mille_term.value\"]")!="")?eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".death_per_mille_term.value\"]"):"0";
                                                                   
                                                       pagedata["setvar"]["A_Death_Load_Pursuit_Term_0"+iCount+"_rea"]=(eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".death_pursuit_term.value\"]")!=undefined && eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".death_pursuit_term.value\"]")!="null" && eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".death_pursuit_term.value\"]")!="")?eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".death_pursuit_term.value\"]"):"0";
                                                                   
                                                       pagedata["setvar"]["A_TPD_Load_Permille_Term_0"+iCount+"_rea"]=(eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".tpd_per_mille_term.value\"]")!=undefined && eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".tpd_per_mille_term.value\"]")!="null" && eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".tpd_per_mille_term.value\"]")!="")?eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".tpd_per_mille_term.value\"]"):"0";
                                                                   
                                                       pagedata["setvar"]["A_TPD_Load_Pursuit_Term_0"+iCount+"_rea"]=(eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".tpd_pursuit_term.value\"]")!=undefined && eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".tpd_pursuit_term.value\"]")!="null" && eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".tpd_pursuit_term.value\"]")!="")?eval("obj_loading[\"al_loading_details_sqs."+personArray[iCount]+".tpd_pursuit_term.value\"]"):"0";
                                                                        if(currentPlan=="PRUsignature USD") // added by supriya for USD
                                                                        {
                                                                                 
                                                                   
                                    console.log("Sup inside loading value"+obj_loading["al_loading_details_sqs.mlife.loading_value_indicator"]);
                                                                                 if(obj_loading["al_loading_details_sqs.mlife.loading_value_indicator"]=="Y")
                                                                                     {
                                                                   
                                                                                       pagedata["setvar"]["A_Death_Load_Rate_0"+iCount+"_rea"]="105";
                                                                                       pagedata["setvar"]["A_TPD_Load_Rate_0"+iCount+"_rea"]="105";
                                                                                     }
                                                                                   else{
                                                                   
                                                                                       pagedata["setvar"]["A_Death_Load_Rate_0"+iCount+"_rea"]="0";
                                                                                       pagedata["setvar"]["A_TPD_Load_Rate_0"+iCount+"_rea"]="0";
                                                                                     }
                                                                        }
                                                                   
                                                                   
                                                                   if(currentPlan=="RetireGuard (SP)" || currentPlan=="PRUretirement growth")
                                                                   {
                                                                   if(document.getElementById("al_sqs_details.life_heavily_sub_standard").checked==true)
                                                                       {
                                                                            pagedata["setvar"]["A_Death_Load_Rate_0"+iCount+"_rea"]="105";
                                                                            pagedata["setvar"]["A_TPD_Load_Rate_0"+iCount+"_rea"]="105";
                                                                       }
                                                                       else
                                                                       {
                                                                            pagedata["setvar"]["A_Death_Load_Rate_0"+iCount+"_rea"]="0";
                                                                            pagedata["setvar"]["A_TPD_Load_Rate_0"+iCount+"_rea"]="0";
                                                                       }
                                                                   }
                                                                  if(currentPlan == "PRUValue Gain" || currentPlan == "PRUFlexi Gain" || currentPlan == "PRUGain Plus" || currentPlan == "PRUEnrich Gain")
                                                                                                                                                                                                                                                                                                                                                                                                                              {
                                                                                                                                                                                                                                                                                                                                                                                                                              if(obj_loading["al_loading_details_sqs.mlife.prulady_cancer_income_loading.value"]!=undefined && obj_loading["al_loading_details_sqs.mlife.prulady_cancer_income_loading.value"]!="null" && obj_loading["al_loading_details_sqs.mlife.prulady_cancer_income_loading.value"]!="")
                                                                                                                                                                                                                                                                                                                                                                                                                               {
                                                                                                                                                                                                                                                                                                                                                                                                                                 pagedata["setvar"]["A_CA_Load_Rate_0"+iCount+"_rea"]=obj_loading["al_loading_details_sqs.mlife.prulady_cancer_income_loading.value"];
                                                                                                                                                                                                                                                                                                                                                                                                                               }
                                                                                                                                                                                                                                                                                                                                                                                                                               else
                                                                                                                                                                                                                                                                                                                                                                                                                               {
                                                                                                                                                                                                                                                                                                                                                                                                                                pagedata["setvar"]["A_CA_Load_Rate_0"+iCount+"_rea"]="0";
                                                                                                                                                                                                                                                                                                                                                                                                                               }
                                                                                                                                                                                                                                                                                                                                                                                                                              }
                                                                   
                                                                   
                                                                   if(currentPlan == "PRUcancer X")
                                                                   {
                                                                     if(obj_loading["al_loading_details_sqs.mlife.ca.value"]!=undefined && obj_loading["al_loading_details_sqs.mlife.ca.value"]!="null" && obj_loading["al_loading_details_sqs.mlife.ca.value"]!="")
                                                                    {
                                                                      pagedata["setvar"]["A_CA_Load_Rate_0"+iCount+"_rea"]=obj_loading["al_loading_details_sqs.mlife.ca.value"];
                                                                    }
                                                                    else
                                                                    {
                                                                     pagedata["setvar"]["A_CA_Load_Rate_0"+iCount+"_rea"]="0";
                                                                   
                                                                    }
                                                                   }
                                                                  
                                                    
                                                      
                                                    }                                                            // Added by Shivani for MAr2022 release
                                                                                                                                                                                                                                                                                                                                                                                                                              if(currentPlan==="PRULink Supreme" || currentPlan==="PRULink Supreme Plus")                                                                          {
                                                                    console.log("SSD inside loading value"+obj_loading["al_loading_details_sqs.mlife.loading_value_indicator"]);
                                                                                                                                                                                                                                                                                                                                                                                                                                                            if(obj_loading["al_loading_details_sqs.mlife.loading_value_indicator"]=="Y")
                                                                                                                                                                                                                                                                                                                                                                                                                                                                               {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      pagedata["setvar"]["A_Death_Load_Rate_01_rea"]="105";
                                                                                                                                                                                                                                                                                                                                                                                                                              pagedata["setvar"]["A_TPD_Load_Rate_01_rea"]="105";
                                                                                                                                                                                                                                                                                                                                                                                                                                                                               }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                             else{
                                                                                                                
                                                                                                                                                                                                                                                                                                                                                                                                                              pagedata["setvar"]["A_Death_Load_Rate_01_rea"]="0";
                                                                                                                                                                                                                                                                                                                                                                                                                              pagedata["setvar"]["A_TPD_Load_Rate_01_rea"]="0";
                                                                                                                                                                                                                                                                                                                                                                                                                                                                               }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               if(currentPlan==="PRUElite Invest" || currentPlan==="PRUSignature GrowthPlus")                                                                                                                                                                                            {
                                                                                                                                                                                                                                                                                                                                                                                                                              console.log("SSD inside loading value"+obj_loading["al_loading_details_sqs.mlife.loading_value_indicator"]);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      if(obj_loading["al_loading_details_sqs.mlife.loading_value_indicator"]=="Y")
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                pagedata["setvar"]["A_Death_Load_Rate_01_rea"]="105";
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        pagedata["setvar"]["A_TPD_Load_Rate_01_rea"]="105";
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       else{
                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        pagedata["setvar"]["A_Death_Load_Rate_01_rea"]="0";
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        pagedata["setvar"]["A_TPD_Load_Rate_01_rea"]="0";
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            }
                                                                   
                                                   if(currentPlan=="PRUsignature income") // added by Paromita for Def5848
                                                   {
                                                   
                                                   
                                                   console.log("Sup inside loading value"+obj_loading["al_loading_details_sqs.mlife.em.value"]);
                                                   if(obj_loading["al_loading_details_sqs.mlife.em.value"]=="105")
                                                   {
                                                   
                                                   pagedata["setvar"]["A_Death_Load_Rate_01_rea"]="105";
                                                   pagedata["setvar"]["A_TPD_Load_Rate_01_rea"]="105";
                                                   }
                                                   else{
                                                   
                                                   pagedata["setvar"]["A_Death_Load_Rate_01_rea"]="0";
                                                   pagedata["setvar"]["A_Death_Load_Rate_01_rea"]="0";
                                                   }
                                                   }
                                                    var iRiderCount = 0;
                                                                                                        
                                                                   var arrMedicalArray=["al_rider_sqs.pruvalue_med.","al_rider_sqs.prumillion_med.","al_rider_sqs.prumedic_overseas.","al_rider_sqs.pruhealth.","al_rider_sqs.prumillion_med_booster.","al_rider_sqs.pruvalue_med_booster.","al_rider_sqs.prumillion_med_active.","al_rider_sqs.prumillion_med_2_0.","al_rider_sqs.active_booster.","al_rider_sqs.prumillion_med_booster_2_0."];// Pradnya: added pruactive_med & prumillion_med_plus for may24 release
                                                    for (var i = 0; i < inputs.length; ++i)
                                                    {
                                                        console.log("inputs-->"+inputs[i].id);
                                                        
                                                        if (inputs[i].type == "checkbox")
                                                        {
                                                            if (inputs[i].checked && inputs[i].id != "al_sqs_details.premium_lump_sum" && inputs[i].id != "al_rider_sqs.pruvalue_med.rider_option" && inputs[i].id != "al_rider_sqs.compassionate_benefit.id" && inputs[i].id != "al_rider_sqs.cancer_benefit.id" && inputs[i].id != "al_rider_sqs.maturity_benefit.id" && inputs[i].id != "al_sqs_details.premium_lump_sum_cash" && inputs[i].id!=="al_rider_sqs.basic_plan_prutri_care.id" )//added al_sqs_details.premium_lump_sum_cash by ankita on 17 sept for pc and pcdr product
                                                            {
                                                                
                                                                var idtemp = splitdots(inputs[i].id);
                                                                
                                                                console.log("idtemp===>"+idtemp);
                                                                if(inputs[i].id == "al_rider_sqs.basic_plan.id" || inputs[i].id == "al_rider_sqs.basic_plan_prusignature.id" || inputs[i].id == "al_rider_sqs.basic_plans.id" || inputs[i].id =="al_rider_sqs.common_products.id" || inputs[i].id == "al_rider_sqs.bundle_basic.id" || inputs[i].id == "al_rider_sqs.elsp.id" || inputs[i].id == "al_rider_sqs.prucash.id")//second condition is added by supriya )//al_rider_sqs.bundle_basic.id added by Sachin Tupe on date 1-2-2019.
                                                                {
//                                                                   if(currentPlan == "PRUcash"){//pcvpms
//                                                                   idtemp=idtemp.replace("basic_plan","prucash");
//
//                                                                   }
 if(currentPlan == "PRUcash double reward")
                                   {
    idtemp="al_rider_sqs.prucash.";
                                         }
                                                                    console.log("idtemp11===>"+idtemp);
                                                                                                                                                                                                                                                                                                                                                                                   if(currentPlan == "PRUsignature" ||currentPlan == "PRUSignature Plus")
                                                                                                                                                                                                                                                                                                                                                                                                  {
                                                                                                                                                                                                               pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iRiderCount+"]"] = "0";
                                                                                                                                                                                                                                                                                                                                                                                                                              pagedata["setvar"]["A_Basic_Sum_Assured_rea"] ="0";
                                                                   
                                                                
                                                                   }
                                                                                                                                                                                                                                                                                                                                                                                                                              
                                                                   // Else if added by Shivani for PRUSignature Reserve on 9th Mar 2020
                                                                   else if(currentPlan=="PRUSignature Reserve")
                                                            {
                                                                                                                                                                                                                                                                                                                                                                                                                              pagedata=fnSetDropdownValuesForReserve(pagedata);
                                                                                                                                                                                                                    
                                                                   
                                                                                                                                                                                                                                                                                                                                                                                                                               pagedata["setvar"]["A_Payout_Survival_Benf_key"]= document.getElementById("al_sqs_details.retirement_payout_option").value;
                                                                   pagedata["setvar"]["A_Retirement_Income_rea"] = (parseFloat(document.getElementById("al_rider_sqs.retirement_income.rider_value").value) * 12).toString();
                                                                   
                                                                   pagedata["setvar"]["A_Basic_Sum_Assured_rea"] = (parseFloat(document.getElementById("al_rider_sqs.retirement_income.rider_value").value) * 12).toString();
                                                                   pagedata["setvar"]["A_Rider_Sum_Assured_rea"] = (parseFloat(document.getElementById("al_rider_sqs.retirement_income.rider_value").value) * 12).toString();
                                                                   
                                                                   pagedata["setvar"]["A_Master_Rider_key["+iRiderCount+"]"] = objVPMSRiderJson["rider_row_"+idtemp.replace(/\.$/, '')];
                                                                   
                                                                   
                                                                   
                                                            }
                                                                                                                                                                                                                                                                                                                                                                                                                               else if(currentPlan ==="PRUSignature Treasure")
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     //pagedata=fnSetDropdownValuesForReserve(pagedata);
                                                                                                                                                                                                                                                                                                                                                                                                                              
                                                                     //added by ankita on 15 feb 2022 as this change was mentioned in potd 3044
                                                                       if((document.getElementById("al_sqs_details.premium_payment_term") != undefined && document.getElementById("al_sqs_details.premium_payment_term") != "null" && document.getElementById("al_sqs_details.premium_payment_term").value !="0"))
                                                                                                                                                                                                                                                                                                                                                                                                                              {
                                                                                                                                         pagedata["setvar"]["A_Master_Payout_Age_key"]=
                                                                                                                                                                                                                                                                                                                                                                                                                              (parseInt(document.getElementById("al_sqs_details.premium_payment_term").value) + parseInt(obj_prochoice["al_sqs_details.mlife.il_anb"])).toString();;
                                                                       
                                                                   pagedata["setvar"]["A_Master_Payout_Period_key"]=(100-parseInt(pagedata["setvar"]["A_Master_Payout_Age_key"])).toString();;                                     }
                                                                                                                                                                                                                                                                                                                                                                                                                              else
                                                                                                                                                                                                                                                                                                                                                                                                                              {
                                                                                                                                                                           pagedata["setvar"]["A_Master_Payout_Age_key"]="";
                                                                                                                                                                                                                                                                                                                                                                                                                              pagedata["setvar"]["A_Master_Payout_Period_key"]="";
                                                                                                                                                                                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                                                                                                                                                                                              
                                                                                                                                       
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            pagedata["setvar"]["A_Payout_Survival_Benf_key"]= document.getElementById("al_rider_sqs.retirement_income.rider_value").value;
                                                                        if((document.getElementById("al_sqs_details.payout_frequency_option") != undefined && document.getElementById("al_sqs_details.payout_frequency_option") != "null" && document.getElementById("al_sqs_details.payout_frequency_option").value !="0"))
                                                                                                                                                                                                                                                                                                                                                                                                                              {
                                                                                                                                                                                                                                                                                                                                                                                                                              pagedata["setvar"]["A_Master_Payout_Frequency_key"]= document.getElementById("al_sqs_details.payout_frequency_option").value;
                                                                                                                                                                                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                                                                                                                                                                                              else
                                                                                                                                                                                                                                                                                                                                                                                                                              {
                                                                                                                                                                       pagedata["setvar"]["A_Master_Payout_Frequency_key"]="";
                                                                                                                                                                                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                                                                                                                                                                                              pagedata["setvar"]["A_Retirement_Income_rea"] = (document.getElementById("al_rider_sqs.retirement_income.rider_value").value);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          pagedata["setvar"]["A_Basic_Sum_Assured_rea"] = (document.getElementById("al_rider_sqs.retirement_income.rider_value").value);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          pagedata["setvar"]["A_Rider_Sum_Assured_rea"] = (document.getElementById("al_rider_sqs.retirement_income.rider_value").value);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          pagedata["setvar"]["A_Master_Rider_key["+iRiderCount+"]"] = objVPMSRiderJson["rider_row_"+idtemp.replace(/\.$/, '')];
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   }
                                                                                                                                                                                                                                                                                                                                                                                                                              // ADDed by Shivani for PLCI
                                                                                                                                                                                                                                                                                                                                                                                                                              /*else if(currentPlan=="PRUValue Gain")
                                                                                                                                                                                                                                                                                                                                                                                                                              {
                                                                                       console.log("In else if : value gain");
                                                                                     pagedata["setvar"]["A_Basic_Sum_Assured_rea"] = (parseFloat(document.getElementById("al_rider_sqs.basic_plans.rider_value").value)).toString();
                                                                                
                                                                                                                                                                                                                                                                                                                                                                                                                              pagedata["setvar"]["A_Rider_Sum_Assured_rea"] = (parseFloat(document.getElementById("al_rider_sqs.basic_plans.rider_value").value)).toString();
                                                                    
                                                                                                                                                                                                                                                                                                                                                                                                                    pagedata["setvar"]["A_Master_Rider_key["+iRiderCount+"]"] = objVPMSRiderJson["rider_row_"+idtemp.replace(/\.$/, '')];
                                                                                                                                                                                                                                                                                                                                                                            }*/
                                                                                                                                                                                                                                                                                                                                                                                                  else
                                                                                                                                                                                                                                                                                                                                                                                                  {
                                                                                                                      
                                                                                                                                                                                                                                                                                                             console.log("Check def-211");
                                                                                                                                                                                                                                                                                                                                                                                                                              pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iRiderCount+"]"] = (document.getElementById(idtemp+"rider_value") != undefined && document.getElementById(idtemp+"rider_value") != "null" && document.getElementById(idtemp+"rider_value").value!="")? document.getElementById(idtemp+"rider_value").value :"0";
                                                                                                                                                                                                                                                                                                                                                                                                  console.log("Rider value==>:"+document.getElementById(idtemp+"rider_value").value);
                                                                                                                                                                                                                                                                                                                                                                                                   pagedata["setvar"]["A_Basic_Sum_Assured_rea"] = (document.getElementById(idtemp+"rider_value") != undefined && document.getElementById(idtemp+"rider_value") != "null" && document.getElementById(idtemp+"rider_value").value!="")? document.getElementById(idtemp+"rider_value").value :"0";
                                                                                                                                                                                                                                                                                                                                                                                                  }
                                                                    
                                                                   console.log("Term value==>"+document.getElementById("al_rider_sqs.common_products.rider_term").value);
                                                                   console.log("currentPlan =="+ currentPlan);
                                                                   console.log ("PMCG 444444 : ",idtemp);
                                                                   if(currentPlan == "PRUsmart gain" || currentPlan == "PRUcancer X" || currentPlan == "PRUwealth gain plus" || currentPlan == "PRUsignature income" || currentPlan == "PRUSignature Optimiser" || currentPlan == "PRUSignature Booster" || currentPlan =="PRUValue Gain" || currentPlan =="PRUMy Gift" || currentPlan =="PRUSenior Med" || currentPlan =="PRUSignature Reward" || currentPlan =="EssentialLife (SP)" || currentPlan =="PRUSignature Protect" || currentPlan =="PRUMulti Crisis Guard" || currentPlan === "PRUCash Enrich" || currentPlan === "PRUAll Care" || currentPlan === "PRUFlexi Gain" || currentPlan === "PRUSignature Harvest" || currentPlan === "PRUGain Plus" || currentPlan =="PRUSignature Harvest Plus" || currentPlan === "PRUEnrich Gain" || currentPlan =="PRUSignature Boost" || currentPlan =="PRUMan" || currentPlan =="PRULady_PRL") //Changed by Paromita for Policy term not valid error//Abhilash: EssentialLife (SP)_SCB name changed to PRUSignature Protect on 6th July

                                                                   {
                                                                       console.log ("PMCG 333333");
                                                                        pagedata["setvar"]["A_Master_Policy_Term_key["+iRiderCount+"]"] = (document.getElementById(idtemp+"rider_term") != undefined && document.getElementById(idtemp+"rider_term") != "null" && document.getElementById(idtemp+"rider_term").value !="0")? document.getElementById(idtemp+"rider_term").value :"";
                                                                   
                                                                   }
                                                                                                                                                                                                                                                                                                                                                                                                                              else if(currentPlan == "PRULink Growth")
                                                                                                                                                                                                                                                                                                                                                                                                                              {
                                                                                                                                                                                                                                                                                                                                                                                                                              pagedata["setvar"]["A_Master_Policy_Term_key["+iRiderCount+"]"]="8";
                                                                                                                                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                                                                                                                                              }
                                                                   else if(currentPlan == "PRUgrowth")
                                                                   {
                                                                        if(document.getElementById(idtemp+"rider_term").value=="0")
                                                                        {
                                                                   pagedata["setvar"]["A_Master_Policy_Term_key["+iRiderCount+"]"] ="";
                                                                        }
                                                                        else
                                                                        {
                                                                   pagedata["setvar"]["A_Master_Policy_Term_key["+iRiderCount+"]"] =document.getElementById(idtemp+"rider_term").value;

                                                                        }
                                                                   }
                                                                                        
                                                                                                                                                                                    
                                                                   else if(currentPlan=="PRUEasy Protect")
                                                                   {
                                                                   pagedata["setvar"]["A_Master_Policy_Term_key["+iRiderCount+"]"] ="";
                                                                   
                                                                   pagedata["setvar"]["A_Master_Policy_Term_key"] ="";
                                                                   
                                                                   }
                                                                   else if(currentPlan =="PRUcash double reward" || currentPlan =="PRUcash")
                                                                   {
                                                                   if(document.getElementById(idtemp+"rider_term").value=="0")
                                                                   {
                                                                   pagedata["setvar"]["A_Master_Policy_Term_key["+iRiderCount+"]"] ="";
                                                                   }
                                                                   else
                                                                   {
                                                                     pagedata["setvar"]["A_Master_Policy_Term_key["+iRiderCount+"]"] = document.getElementById(idtemp+"rider_term").value
                                                                   }
                                                                   }
                                                                   else if(currentPlan == "RetireGuard (SP)" || currentPlan == "PRUretirement growth")
                                                                   {
                                                                   
                                                                       var totalPolicyTermRGSP=parseInt(document.getElementById("al_sqs_details.accumulation_period").value)+parseInt(document.getElementById("al_sqs_details.payout_period").value);
                                                                       console.log("totalPolicyTermRGSP:",totalPolicyTermRGSP)
                                                                       pagedata["setvar"]["A_Master_Policy_Term_key["+iRiderCount+"]"]=""+totalPolicyTermRGSP;
                                                                   }
                                                                                                                                                                                                                    else if(currentPlan == "PRUTerm Premier" )
                                                                                                                                                                                                                    {
                                                                                                                                                                                                    pagedata["setvar"]["A_Master_Policy_Term_key["+iRiderCount+"]"] = (document.getElementById("al_rider_sqs.ptp.rider_term") != undefined && document.getElementById("al_rider_sqs.ptp.rider_term") != "null" && document.getElementById("al_rider_sqs.ptp.rider_term").value !="0")? document.getElementById("al_rider_sqs.ptp.rider_term").value :"";
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                                                                                                                                              else
                                                                                                                                                                                                                                                                                                                                                                                                                              {
                                                                                                                                                                                                                                                                                                                                                                                                                              // need to remove Added by Shivani
                                                                                                                                                                                                                                                                                                                                                                                                                              /*if(currentPlan === "PRUMulti Crisis Guard")
                                                                                                                                                                                                                                                                                                                                                                                                        {
                                                                                                                                                                                                                                                                                                                                                                                                                              console.log("Shivani policy term 123456");
                                                                                                                                                                                                                                                                                                                                                                                                                              pagedata["setvar"]["A_Master_Policy_Term_key["+iRiderCount+"]"] ="42";
                                                                                                                                                                                                                                                                                                                                                                                                                              pagedata["setvar"]["A_Expiry_Age_rea["+iRiderCount+"]"] ="42";
                                                                                                                                                                                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                                                                                                                                                                                              else
                                                                                                                                                                                                                                                                                                                                                                                                                              {
                                                                                                                                               console.log("Shivani policy term ");  */                                                                                                                                              pagedata["setvar"]["A_Master_Policy_Term_key["+iRiderCount+"]"] ="";
                                                                                                                                                                                                                                                                                                                                                                                                                              //}
                                                                   }
                                                                   var idName = "rider_row_al_rider_sqs."+(obj_prochoice["al_sqs_details.product_name"].replace(" ","_").toLowerCase());
                                                                   console.log("idName==    value gain 4"+idName);
                                                                    // 0404 need to remove sourabh 4 April 2019 only keep else
                                                                   if(PlanCode.hasOwnProperty(currentPlan)) // need to change by Paromita
                                                                   {
                                                                       console.log("value gain 5"); pagedata["setvar"]["A_Master_Rider_key["+iRiderCount+"]"] = PlanCode[currentPlan];
                                                                   }else{
                                                                     console.log("value gain 6"); pagedata["setvar"]["A_Master_Rider_key["+iRiderCount+"]"] = objVPMSRiderJson["rider_row_al_rider_sqs."+(obj_prochoice["al_sqs_details.product_name"].replace(/ /g,"_").toLowerCase())];
                                                                   }
                                                                   
                                                                   
                                                                   //need to remove on 22 July 2019
                                                                   if(currentPlan == "PRUSenior Med")
                                                                   {
                                                                   
                                                                  
                                                                   pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] =document.getElementById("al_rider_sqs.common_products.rider_value").value;
                                                                   pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iRiderCount+"]"] = "5000";
                                                                    pagedata["setvar"]["A_Basic_Sum_Assured_rea"] = "5000";
                                                                   pagedata["setvar"]["A_Master_Premium_Term_key"] = (document.getElementById(idtemp+"rider_term") != undefined && document.getElementById(idtemp+"rider_term") != "null")? document.getElementById(idtemp+"rider_term").value :"";
                                                                  
                                                                   
                                                                   
                                                                   }
                                                                    if(currentPlan == "PRUMan" || currentPlan == "PRULady_PRL")
                                                                    {
                                                                    
                                                                   
                                                                    pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] =document.getElementById("al_rider_sqs.common_products.rider_value").value;
                                                                    pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iRiderCount+"]"] = document.getElementById("al_rider_sqs.common_products.rider_value").value;
                                                                     pagedata["setvar"]["A_Basic_Sum_Assured_rea"] = document.getElementById("al_rider_sqs.common_products.rider_value").value;
                                                                    pagedata["setvar"]["A_Master_Premium_Term_key"] = (document.getElementById("al_rider_sqs.common_products.premium_payment_term") != undefined && document.getElementById("al_rider_sqs.common_products.premium_payment_term") != "null")? document.getElementById("al_rider_sqs.common_products.premium_payment_term").value :"";
                                                                   
                                                                    
                                                                    
                                                                    }
                                                                    
                                                                                    if(currentPlan == "PRUTerm Premier")
                                                                                     {
                                                                                     
                                                                                    
                                                                            
                                                                                     pagedata["setvar"]["A_Master_Premium_Term_key"] = (document.getElementById("al_sqs_details.premium_payment_term_ptp") != undefined && document.getElementById("al_sqs_details.premium_payment_term_ptp") != "null")? document.getElementById("al_sqs_details.premium_payment_term_ptp").value :"";
                                                                                    
                                                                                     
                                                                                     
                                                                                     }
                                                                   
                                                                  if(currentPlan != "PRUMy Gift")
                                                                   {
                                                                   
                                                                   pagedata["setvar"]["A_Expiry_Age_rea["+iRiderCount+"]"] = (document.getElementById(idtemp+"rider_expiry_age") != undefined && document.getElementById(idtemp+"rider_expiry_age") != "null" && document.getElementById(idtemp+"rider_expiry_age").value!="")? document.getElementById(idtemp+"rider_expiry_age").value :"0";
                                                                   }else
                                                                   {
                                                                    pagedata["setvar"]["A_Expiry_Age_rea["+iRiderCount+"]"] = (document.getElementById(idtemp+"rider_expiry_age_dropdown") != undefined && document.getElementById(idtemp+"rider_expiry_age_dropdown") != "null" && document.getElementById(idtemp+"rider_expiry_age_dropdown").value!="")? document.getElementById(idtemp+"rider_expiry_age_dropdown").value :"0";
                                                                   
                                                                   }
                                                                   
                                                                if(currentPlan == "PRUSignature Booster")
                                                                 {
                                                                  pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iRiderCount+"]"] = "0";
                                                                  pagedata["setvar"]["A_Basic_Sum_Assured_rea"] = "0";
                                                                
                                                                }
                                                                 
                                                                  
                                                                }
                                                                else
                                                                {
                                                                   if(idtemp != "al_rider_sqs.compassionate_benefit." && idtemp != "al_rider_sqs.cancer_benefit." && idtemp != "al_rider_sqs.maturity_benefit." && idtemp!=="al_rider_sqs.basic_plan_prusignature_ppr1.")
                                                                   {
                                                                                                                                                                                                                                                                                                                                                                                                                              console.log("value gain 9");
                                                                   var temp="al_rider_sqs.pruvalue_med.rider_option";
                                                                   console.log("idtemp for prusaver kid--"+idtemp);
                                                                   if(idtemp != temp)
                                                                   {
                                                                                                                                                                                                                                                                                                                                                                                                                              console.log("value gain 10");
                                                                     if(idtemp == "al_rider_sqs.prusaver." || idtemp == "al_rider_sqs.pruvalue_med." || idtemp == "al_rider_sqs.prusaver_kid." || idtemp == "al_rider_sqs.pruacci_guard."|| idtemp == "al_rider_sqs.pruacci_income." || idtemp == "al_rider_sqs.pruacci_med." || idtemp == "al_rider_sqs.prumedic_overseas." || idtemp == "al_rider_sqs.enhanced_infant_care." || idtemp == "al_rider_sqs.enhanced_prue_child." || idtemp == "al_rider_sqs.prumillion_med." || idtemp == "al_rider_sqs.pruhealth." || idtemp == "al_rider_sqs.mom_and_baby_care."|| idtemp == "al_rider_sqs.prumillion_med_active." || idtemp == "al_rider_sqs.prumillion_med_2_0." || idtemp =="al_rider_sqs.active_booster." || idtemp =="al_rider_sqs.prumillion_med_booster_2_0.")
                                                                         // Pradnya: added pruactive_med & prumillion_med_plus for may24
                                                                     {
                                                                      console.log("Deductible check PLS 11111")
                                                                        if(idtemp == "al_rider_sqs.prusaver." || idtemp == "al_rider_sqs.prusaver_kid.")
                                                                        {
                                                                            pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iRiderCount+"]"] = (document.getElementById(idtemp+"rider_premium") != undefined && document.getElementById(idtemp+"rider_premium") != "null" && document.getElementById(idtemp+"rider_premium").value != "")? document.getElementById(idtemp+"rider_premium").value :"0";
                                                                            pagedata["setvar"]["A_Code_Rider_Payage_key["+iRiderCount+"]"] = (document.getElementById(idtemp+"payout_age") != undefined && document.getElementById(idtemp+"payout_age") != "null")? document.getElementById(idtemp+"payout_age").value :"";
                                                                   
                                                                        }
                                                                        else if(idtemp == "al_rider_sqs.enhanced_infant_care.")
                                                                       {
                                                                           var planvalue="";
                                                                           console.log("Infant care plan value1:"+document.getElementById(idtemp+"rider_value"));
                                                                           console.log("Infant care plan value2:"+document.getElementById(idtemp+"rider_value").value);
                                                                           if(document.getElementById(idtemp+"rider_value") != undefined && document.getElementById(idtemp+"rider_value") != "null")
                                                                           {
                                                                               if(document.getElementById(idtemp+"rider_value").value == "Plan 1")
                                                                               {
                                                                                    planvalue = "1";
                                                                               }
                                                                               else if(document.getElementById(idtemp+"rider_value").value == "0")
                                                                               {
                                                                                    planvalue = "2";

                                                                               }
                                                                               else
                                                                               {
                                                                                    planvalue = "";
                                                                               }
                                                                           }
                                                                   
                                                                  
                                                                            pagedata["setvar"]["A_Master_Rider_Plan_key["+iRiderCount+"]"] = planvalue;
                                                                            pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iRiderCount+"]"] = (document.getElementById(idtemp+"rider_value1") != undefined && document.getElementById(idtemp+"rider_value1") != "null" && document.getElementById(idtemp+"rider_value1").value!="")? document.getElementById(idtemp+"rider_value1").value :"0";
                                                                   
                                                                       }
                                                                                                                                                                                                                                                                                                                                                                                                                              else if(idtemp === "al_rider_sqs.mom_and_baby_care.")//mom_and_baby_care condition added by ankita on 5 dec 2022 for pruwith you product
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        //var planvalue="";
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        console.log("Infant care plan value1:"+document.getElementById(idtemp+"rider_value"));
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        console.log("Infant care plan value2:"+document.getElementById(idtemp+"rider_value").value);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        if(document.getElementById(idtemp+"rider_value") != undefined && document.getElementById(idtemp+"rider_value") != "null")
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            /*if(document.getElementById(idtemp+"rider_value").value == "Plan 1")
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 planvalue = "1";
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            else if(document.getElementById(idtemp+"rider_value").value == "0")
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 planvalue = "2";

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            else
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 planvalue = "";
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            }*/
                                                                                                    pagedata["setvar"]["A_Master_Rider_Plan_key["+iRiderCount+"]"] = document.getElementById(idtemp+"rider_value").value;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                                                                              else
                                                                                                                                                                                                                                                                                                                                                                                                                              {
                                                                                                       pagedata["setvar"]["A_Master_Rider_Plan_key["+iRiderCount+"]"] ="";
                                                                                                                                                                                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         //pagedata["setvar"]["A_Master_Rider_Plan_key["+iRiderCount+"]"] = planvalue;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iRiderCount+"]"] = (document.getElementById(idtemp+"rider_value1") != undefined && document.getElementById(idtemp+"rider_value1") != "null" && document.getElementById(idtemp+"rider_value1").value!="")? document.getElementById(idtemp+"rider_value1").value :"0";
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    }
                                                                       else if(idtemp == "al_rider_sqs.prumillion_med." || idtemp =="al_rider_sqs.pruhealth.")
                                                                       {
                                                                           var planvalue="";
                                                                           console.log("al_rider_sqs.prumillion_med plan value1:"+document.getElementById(idtemp+"rider_value"));
                                                                   
                                                                           if(document.getElementById(idtemp+"rider_value") != undefined && document.getElementById(idtemp+"rider_value") != "null")
                                                                           {
                                                                                planvalue = document.getElementById(idtemp+"rider_value").value;
                                                                                planvalue = planvalue.replace("Plan ","");
                                                                           }
                                                                           else
                                                                           {
                                                                                planvalue = "";
                                                                           }
                                                                   
                                                                           pagedata["setvar"]["A_Master_Rider_Plan_key["+iRiderCount+"]"] = planvalue;
                                                                           pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iRiderCount+"]"] = (planvalue != undefined &&planvalue != "null" && planvalue)? planvalue:"0";
                                                                           if(idtemp =="al_rider_sqs.pruhealth.")
                                                                           {
                                                                                if(document.getElementById("al_rider_sqs.pruhealth.rider_option_coinsurence").checked)
                                                                               {
                                                                                    pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] = "Coinsurance";
                                                                               }
                                                                               else if(document.getElementById("al_rider_sqs.pruhealth.rider_option_deductible").checked)
                                                                               {
                                                                                     pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] = "3000";
                                                                               }
                                                                   
                                                                           }
                                                                           else
                                                                           {
                                                                                   //pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] = "300"; //Since by default it requires med saver 300
                                                                                                                                                                                                                                                                                                                                                                                                                              pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] = (document.getElementById("al_rider_sqs.prumillion_med.rider_option_value") != undefined && document.getElementById("al_rider_sqs.prumillion_med.rider_option_value") != "null")? document.getElementById("al_rider_sqs.prumillion_med.rider_option_value").value :"";
                                                                           }
                                                                        }
                                                                       else if(idtemp == "al_rider_sqs.prumillion_med_active.") //Pradnya: added for may24 release
                                                                       {
                                                                           var planvalue="";
                                                                           console.log("al_rider_sqs.prumillion_med_active plan value1:"+document.getElementById(idtemp+"rider_value"));
                                                                   
                                                                           if(document.getElementById(idtemp+"rider_value") != undefined && document.getElementById(idtemp+"rider_value") != "null"  && document.getElementById(idtemp+"rider_value").value != "0")//Pradnya: added condition for checking "0" for def 1401 june24 release for setting planvalue blank if plan is not selected
                                                                           {
                                                                               console.log("if prumillion_med_active plan value1 :",planvalue);
                                                                                planvalue = document.getElementById(idtemp+"rider_value").value;
                                                                                planvalue = planvalue.replace("Plan ","");
                                                                           }
                                                                           else
                                                                           {
                                                                               console.log(" else prumillion_med_active plan value1:",planvalue);
                                                                                planvalue = "";
                                                                           }
                                                                           console.log("prumillion_med_active plan value1:",planvalue);
                                                                           pagedata["setvar"]["A_Master_Rider_Plan_key["+iRiderCount+"]"] = planvalue;
                                                                           pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iRiderCount+"]"] = (planvalue != undefined &&planvalue != "null" && planvalue)? planvalue:"0";
                                                                           
                                                                           
                                                                                if(document.getElementById("al_rider_sqs.prumillion_med_active.rider_option_coinsurence").checked)
                                                                               {
                                                                                    pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] = "Coinsurance";
                                                                               }
                                                                               else if(document.getElementById("al_rider_sqs.prumillion_med_active.rider_option_deductible").checked)
                                                                               {
                                                                                     pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] = document.getElementById("al_rider_sqs.prumillion_med_active.rider_option_deductible_300").value;
                                                                                   
                                                                                   if(document.getElementById("al_rider_sqs.prumillion_med_active.rider_option_deductible_300").value =="0"|| document.getElementById("al_rider_sqs.prumillion_med_active.rider_option_deductible_300").value == 0)
                                                                                   {
                                                                                           pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] = "";
                                                                                   }
                                                                                   
                                                                               }

                                                                   
                                                                           
                                                                          
                                                                        }
                                                                       else if(idtemp == "al_rider_sqs.active_booster.") //Pradnya: added for may24 release
                                                                       {
                                                                           var planvalue="";
                                                                           console.log("Checking rider values"+document.getElementById(idtemp+"rider_value"));
                                                                   
                                                                           if(document.getElementById("al_rider_sqs.prumillion_med_active.rider_value") != undefined && document.getElementById("al_rider_sqs.prumillion_med_active.rider_value") != "null")
                                                                           {
                                                                                planvalue = document.getElementById("al_rider_sqs.prumillion_med_active.rider_value").value;
                                                                                //planvalue = planvalue.replace("Plan ","");
                                                                           }
                                                                           else
                                                                           {
                                                                                planvalue = "";
                                                                           }
                                                                   
                                                                           console.log("actual plan value"+planvalue+"rider count"+iRiderCount)
                                                                           
                                                                           pagedata["setvar"]["A_Master_Rider_Plan_key["+iRiderCount+"]"] = planvalue;
                                                                           pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iRiderCount+"]"] = (planvalue != undefined &&planvalue != "null" && planvalue)? planvalue:"0";
                                                                           
                                                                           
                                                                                if(document.getElementById("al_rider_sqs.prumillion_med_active.rider_option_coinsurence").checked)
                                                                               {
                                                                                    pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] = "Coinsurance";
                                                                               }
                                                                               else if(document.getElementById("al_rider_sqs.prumillion_med_active.rider_option_deductible").checked)
                                                                               {
                                                                                     pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] = document.getElementById("al_rider_sqs.prumillion_med_active.rider_option_deductible_300").value;
                                                                               }
                                                                   
                                                                           
                                                                          
                                                                           console.log("Final page data for active booster",pagedata);
                                                                           
                                                                           
                                                                        }
                                                                       else if(idtemp == "al_rider_sqs.prumillion_med_booster_2_0.") //Pradnya: added for may24 release
                                                                       {
                                                                           var planvalue="";
                                                                           console.log("Checking rider values"+document.getElementById(idtemp+"rider_value"));
                                                                   
                                                                           if(document.getElementById("al_rider_sqs.prumillion_med_2_0.rider_value") != undefined && document.getElementById(idtemp+"rider_value") != "null")
                                                                           {
                                                                                planvalue = document.getElementById("al_rider_sqs.prumillion_med_2_0.rider_value").value;
                                                                                //planvalue = planvalue.replace("Plan ","");
                                                                           }
                                                                           else
                                                                           {
                                                                                planvalue = "";
                                                                           }
                                                                           
                                                                           
                                                                           console.log("actual plan value"+planvalue+"rider count"+iRiderCount)
                                                                           
                                                                           pagedata["setvar"]["A_Master_Rider_Plan_key["+iRiderCount+"]"] = planvalue;
                                                                           pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iRiderCount+"]"] = (planvalue != undefined &&planvalue != "null" && planvalue)? planvalue:"0";
                                                                           
                                                                           
                                                                                if(document.getElementById("al_rider_sqs.prumillion_med_2_0.rider_option_coinsurence").checked)
                                                                               {
                                                                                    pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] = "Coinsurance";
                                                                               }
                                                                               else if(document.getElementById("al_rider_sqs.prumillion_med_2_0.rider_option_deductible").checked)
                                                                               {
                                                                                     pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] = document.getElementById("al_rider_sqs.prumillion_med_2_0.rider_option_deductible_300").value;
                                                                               }
                                                                   
                                                                           
                                                                          
                                                                           console.log("Final page data for active booster",pagedata);
                                                                           
                                                                           
                                                                        }
                                                                         
                                                                       else if(idtemp == "al_rider_sqs.prumillion_med_2_0.") //Pradnya: added for may24 release
                                                                       {
                                                                           var planvalue="";
                                                                           console.log("al_rider_sqs.prumillion_med_2_0 plan value1:"+document.getElementById(idtemp+"rider_value"));
                                                                   
                                                                           if(document.getElementById(idtemp+"rider_value") != undefined && document.getElementById(idtemp+"rider_value") != "null" && document.getElementById(idtemp+"rider_value").value != "0")//Pradnya: added condition for checking "0" for def 1401 june24 release for setting planvalue blank if plan is not selected
                                                                           {
                                                                                planvalue = document.getElementById(idtemp+"rider_value").value;
                                                                                //planvalue = planvalue.replace("Plan ","");
                                                                           }
                                                                           else
                                                                           {
                                                                                planvalue = "";
                                                                           }
                                                                           //planvalue="300";
                                                                           pagedata["setvar"]["A_Master_Rider_Plan_key["+iRiderCount+"]"] = planvalue;
                                                                           pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iRiderCount+"]"] = (planvalue != undefined &&planvalue != "null" && planvalue)? planvalue:"0";
                                                                           
                                                                           
                                                                                if(document.getElementById("al_rider_sqs.prumillion_med_2_0.rider_option_coinsurence").checked)
                                                                               {
                                                                                    pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] = "Coinsurance";
                                                                               }
                                                                               else if(document.getElementById("al_rider_sqs.prumillion_med_2_0.rider_option_deductible").checked)
                                                                               {
                                                                                     pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] = document.getElementById("al_rider_sqs.prumillion_med_2_0.rider_option_deductible_300").value;
                                                                                   if(document.getElementById("al_rider_sqs.prumillion_med_2_0.rider_option_deductible_300").value =="0"|| document.getElementById("al_rider_sqs.prumillion_med_2_0.rider_option_deductible_300").value == 0)
                                                                                   {
                                                                                           pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] = "";
                                                                                   }
                                                                               }
                                                                   
                                                                           
                                                                          
                                                                        }
                                                                         
                                                                        else
                                                                        {
                                                                             console.log("Check deductible PLS 11111"+document.getElementById("al_rider_sqs.pruvalue_med.rider_option_value").value);
                                                                             pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iRiderCount+"]"] = (document.getElementById(idtemp+"rider_value") != undefined && document.getElementById(idtemp+"rider_value") != "null" && document.getElementById(idtemp+"rider_value").value!="")? document.getElementById(idtemp+"rider_value").value :"0";
                                                                            pagedata["setvar"]["A_Master_Rider_Plan_key["+iRiderCount+"]"] = (document.getElementById(idtemp+"rider_value") != undefined && document.getElementById(idtemp+"rider_value") != "null")? document.getElementById(idtemp+"rider_value").value :"";
                                                                            pagedata["setvar"]["A_Code_MedValue_key["+iRiderCount+"]"] = (document.getElementById(idtemp+"rider_annual_limit") != undefined && document.getElementById(idtemp+"rider_annual_limit") != "null")? document.getElementById(idtemp+"rider_annual_limit").value :"";
                                                                                                                                                                         // if else added by shivani for VPMS input"A_Code_Rider_Deduct_key" taking values hence set it as blank on 24th AUG 2021
                                                                             if(idtemp == "al_rider_sqs.pruacci_guard."|| idtemp == "al_rider_sqs.pruacci_income." || idtemp == "al_rider_sqs.pruacci_med." || idtemp =="al_rider_sqs.enhanced_prue_child.")
                                                                                                                                                                                                                                                                                                                                                                                            {
                                                                                                                                                                                                                                        console.log("Check deductible PLS in ifff 22222 ");
                                                                           pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] = "";
                                                                                                                                                                                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                                                                                                                                                                                              else
                                                                                                                                                                                                                                                                                                                                                                                                                              {
                                                                         console.log("Check deductible PLS in else 3333 ");
                                                                         pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] = (document.getElementById("al_rider_sqs.pruvalue_med.rider_option_value") != undefined && document.getElementById("al_rider_sqs.pruvalue_med.rider_option_value") != "null")? document.getElementById("al_rider_sqs.pruvalue_med.rider_option_value").value :"";                                                                                                                 }

                                                                        }
                                                                   }
                                                                   else
                                                                   {
                                                                            console.log("In else");
                                                                   
                                                                           if((obj_prochoice["al_sqs_details.product_name"]=="PRUSignature Optimiser") && (idtemp == "al_rider_sqs.pruwaiver." || idtemp == "al_rider_sqs.parent_waiver." || idtemp == "al_rider_sqs.spouse_waiver."))//Added by ankita on 25 Feb 2019
                                                                           {
                                                                                pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iRiderCount+"]"]="0";
                                                                           }
                                                                           else
                                                                           {
                                                                               console.log("value gain 16");
                                                                                                                                                                                                                                                                                                                                                                                                                              if(obj_prochoice["al_sqs_details.product_name"]=="PRUFlexi Gain" || obj_prochoice["al_sqs_details.product_name"]=="PRUGain Plus" || obj_prochoice["al_sqs_details.product_name"]=="PRUEnrich Gain"){
                                                                                                                                                                                                                                                                                                                                                                                                                             pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iRiderCount+"]"] =document.getElementById("al_rider_sqs.basic_plans.rider_value").value;
                                                                                                                                                                                                                                                                                                                                                                                                                              }else{
                                                                                                                                                                                                                                                                                      pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iRiderCount+"]"] = (document.getElementById(idtemp+"rider_value") != undefined && document.getElementById(idtemp+"rider_value") != "null" && document.getElementById(idtemp+"rider_value").value!="")? document.getElementById(idtemp+"rider_value").value :"0";
                                                                                                                                                                                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                                                                                                                                                                                              
                                                                   
                                                                           }
                                                                        pagedata["setvar"]["A_Master_Rider_Plan_key["+iRiderCount+"]"] = "";
                                                                        pagedata["setvar"]["A_Code_MedValue_key["+iRiderCount+"]"] = "";
                                                                        pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] = "";
                                                                   }
                                                                   }
                                                                   
                                                                   if(idtemp == "al_rider_sqs.level_sa_rider.")//added by ankita for pruwealth plus product for level sa rider   al_rider_sqs.level_sa_rider.rider_term
                                                                   {
                                                                        pagedata["setvar"]["A_Master_Policy_Term_key["+iRiderCount+"]"] = (document.getElementById(idtemp+"rider_term") != undefined && document.getElementById(idtemp+"rider_term") != "null")? document.getElementById(idtemp+"rider_term").value :"";
                                                                   }//15 pb
                                                                else if(idtemp == "al_rider_sqs.protect_booster.")          {
                                                                                     console.log("in99-->");
                                                                                                                                                                                                                                                                                                                                                                                                                            pagedata["setvar"]["A_Master_Policy_Term_key["+iRiderCount+"]"] = (document.getElementById(idtemp+"rider_term") != undefined && document.getElementById(idtemp+"rider_term") != "null")? document.getElementById(idtemp+"rider_term").value :"";
                                                                                                                                                                                                                                                                                                                                                                                                                              }
                                                                                    // Added by Shivani for lady Cancer 
                                                                                                                                                                                                                                                                                                                                                                                                                              else if(idtemp =="al_rider_sqs.prulady_cancer_income.")
                                                                                                                                                                                                                                                                                                                                                                                                                              {
                                                                                                                                                                                                                                                                                                                                                                                                                              pagedata["setvar"]["A_Ori_Rider_Sum_Assured_rea["+iRiderCount+"]"] = (parseFloat(document.getElementById("al_rider_sqs.basic_plans.rider_value").value)).toString();
                                                                                                                                                                                                                                                                                                                                                                                                                              pagedata["setvar"]["A_Master_Policy_Term_key["+iRiderCount+"]"] =document.getElementById("al_rider_sqs.basic_plans.rider_term").value;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       pagedata["setvar"]["A_Master_Rider_Plan_key["+iRiderCount+"]"] = document.getElementById("al_rider_sqs.prulady_cancer_income.rider_value").value;

                                                                                                                                                                                                                                                                                                                                                                                                                              }
                                                                                                                                  
                                                                                                                                                                                                                                                                                                                                                                                                        // Added by Shivani for PRUTerm Premier
                                                                                                                                                                                                                                                                                                                                                                                                                              else if(idtemp =="al_rider_sqs.incremental_sa_benefit.")
                                                                                                                                                                                                                                                                                                                                                                                                                              {
                                                                                                                                                                                                                                                                                                                                                                                                                              //pagedata["setvar"]["A_Master_Premium_Term_key["+iRiderCount+"]"] = (parseFloat(document.getElementById("al_rider_sqs.incremental_sa_benefit.rider_term").value)).toString();
                                                                                                                                                                                                                                                                                                                                                                                                                              pagedata["setvar"]["A_Master_Policy_Term_key["+iRiderCount+"]"] =document.getElementById("al_rider_sqs.basic_plans.rider_term").value;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       //pagedata["setvar"]["A_Master_Rider_Plan_key["+iRiderCount+"]"] = document.getElementById("al_rider_sqs.incremental_sa_benefit.rider_value").value;

                                                                                                                                                                                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                                                                                                                                              
                                                                   else
                                                                   {
                                                                        pagedata["setvar"]["A_Master_Policy_Term_key["+iRiderCount+"]"] = "";
                                                                   }
                                                                   
                                                                   console.log("Rider:"+objVPMSRiderJson["rider_row_"+idtemp.replace(/\.$/, '')]);
                                                                    pagedata["setvar"]["A_Master_Rider_key["+iRiderCount+"]"] = objVPMSRiderJson["rider_row_"+idtemp.replace(/\.$/, '')];
                                                                   
                                                                   
                                                                   
                                                                   if(currentPlan != "PRUMy Gift")
                                                                   {
                                                                   
                                                                   
                                                                        pagedata["setvar"]["A_Expiry_Age_rea["+iRiderCount+"]"] = (document.getElementById(idtemp+"rider_expiry_age") != undefined && document.getElementById(idtemp+"rider_expiry_age") != "null" && document.getElementById(idtemp+"rider_expiry_age").value!="")? document.getElementById(idtemp+"rider_expiry_age").value :"0";
                                                                   }else
                                                                   {
                                                                    pagedata["setvar"]["A_Expiry_Age_rea["+iRiderCount+"]"] = (document.getElementById(idtemp+"rider_expiry_age_dropdown") != undefined && document.getElementById(idtemp+"rider_expiry_age_dropdown") != "null" && document.getElementById(idtemp+"rider_expiry_age_dropdown").value!="")? document.getElementById(idtemp+"rider_expiry_age_dropdown").value :"0";
                                                                   
                                                                   
                                                                   }
                                                                   
                                                                   
                                                                   }
                                                                                                            
                                                                   }
                                                                                                                                                                                                                                                                                                                                                                                                                              //added by ankita on 20 april for medical reprising CR
                                                                                                            if(obj_prochoice["al_sqs_details.product_name"] == "PRUwith you" || obj_prochoice["al_sqs_details.product_name"] == "PRULink Cover" || obj_prochoice["al_sqs_details.product_name"] == "PRUSignature Assure")
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    {
                                                                                                                                                                                              
                                                                                                                                                                                               console.log("In medical rider:"+arrMedicalArray.indexOf(idtemp));                   if(arrMedicalArray.indexOf(idtemp) != -1)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                {
                                                                                                                                                                                               console.log("In medical rider if");                      pagedata["setvar"]["A_COI_Reprice_dat["+iRiderCount+"]"] = Current_Date_dat;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                else
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                {
                                                                                                                                                                                                                                                                                                               pagedata["setvar"]["A_COI_Reprice_dat["+iRiderCount+"]"] ="";
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                                                               /*if(currentPlan=="PRUValue Gain" &&(document.getElementById("al_rider_sqs.prulady_cancer_income.id").checked))
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     {
                                                                                                                                                                                                                                                                                                                                                                                                                              console.log("In else if : value gain");                                         pagedata["setvar"]["A_Ori_Rider_Sum_Assured_rea["+iRiderCount+"]"] = (parseFloat(document.getElementById("al_rider_sqs.basic_plans.rider_value").value)).toString();
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            pagedata["setvar"]["A_Master_Policy_Term_key["+iRiderCount+"]"] =document.getElementById("al_rider_sqs.basic_plans.rider_term").value;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     pagedata["setvar"]["A_Master_Rider_Plan_key["+iRiderCount+"]"] = document.getElementById("al_rider_sqs.prulady_cancer_income.rider_value").value;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 }*/
                                                                   
                                                                iRiderCount++;
                                                                
                                                            }
                                                        }
                                                    }
                                                    
                                                                   
                                                                   if(currentPlan == "PRUSignature Reserve" && (document.getElementById("al_rider_sqs.family_income_benefit.id").checked))
                                                                   {
                                                                   console.log("Reserve-->>");
                                                                   if(document.getElementById("al_rider_sqs.pruwaiver.id").checked)
                                                                   {
                                                                   console.log("Reserve-->>PRUWaiver");
                                                                   pagedata["setvar"]["A_Master_Rider_key["+iRiderCount+"]"] = objVPMSRiderJson["rider_row_al_rider_sqs.family_income_benefit_pruwaiver"];
                                                                   pagedata["setvar"]["A_Master_Rider_Plan_key["+iRiderCount+"]"] = "";
                                                                   pagedata["setvar"]["A_Code_MedValue_key["+iRiderCount+"]"] = "";
                                                                   pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] = "";
                                                                   
                                                                   pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iRiderCount+"]"] ="0";
                                                                   pagedata["setvar"]["A_Expiry_Age_rea["+iRiderCount+"]"] ="0";
                                                                   iRiderCount++;
                                                                   
                                                                   }
                                                               if(document.getElementById("al_rider_sqs.spouse_waiver.id").checked)
                                                                   {
                                                                   console.log("Reserve-->>PRUSpouse Waiver");
                                                                   pagedata["setvar"]["A_Master_Rider_key["+iRiderCount+"]"] = objVPMSRiderJson["rider_row_al_rider_sqs.family_income_benefit_spouse_waiver"];
                                                                   pagedata["setvar"]["A_Master_Rider_Plan_key["+iRiderCount+"]"] = "";
                                                                   pagedata["setvar"]["A_Code_MedValue_key["+iRiderCount+"]"] = "";
                                                                   pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] = "";
                                                                   
                                                                   pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iRiderCount+"]"] ="0";
                                                                   pagedata["setvar"]["A_Expiry_Age_rea["+iRiderCount+"]"] ="0";
                                                                   iRiderCount++;
                                                                   
                                                                   }
                                                                   
                                                                   
                                                                   }
                                                                   
                                                                   
                                                                   
                                                                   if(currentPlan == "PRUcash double reward" && (document.getElementById("al_rider_sqs.prulegacy_cash.id").checked))
                                                                   {
                                                                   console.log("Reserve-->>");
                                                                   if(document.getElementById("al_rider_sqs.pruwaiver_cash.id").checked)
                                                                   {
                                                                   console.log("Reserve-->>PRUWaiver");
                                                                   pagedata["setvar"]["A_Master_Rider_key["+iRiderCount+"]"] = "6WRP";
                                                                   pagedata["setvar"]["A_Master_Rider_Plan_key["+iRiderCount+"]"] = "";
                                                                   pagedata["setvar"]["A_Code_MedValue_key["+iRiderCount+"]"] = "";
                                                                   pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] = "";
                                                                   
                                                                   pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iRiderCount+"]"] ="0";
                                                                   pagedata["setvar"]["A_Expiry_Age_rea["+iRiderCount+"]"] ="0";
                                                                   iRiderCount++;
                                                                   
                                                                   }
                                                                   if(document.getElementById("al_rider_sqs.spouse_waiver_cash.id").checked)
                                                                   {
                                                                   console.log("Reserve-->>PRUSpouse Waiver");
                                                                   pagedata["setvar"]["A_Master_Rider_key["+iRiderCount+"]"] ="6SWR";
                                                                   pagedata["setvar"]["A_Master_Rider_Plan_key["+iRiderCount+"]"] = "";
                                                                   pagedata["setvar"]["A_Code_MedValue_key["+iRiderCount+"]"] = "";
                                                                   pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] = "";
                                                                   
                                                                   pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iRiderCount+"]"] ="0";
                                                                   pagedata["setvar"]["A_Expiry_Age_rea["+iRiderCount+"]"] ="0";
                                                                   iRiderCount++;
                                                                   
                                                                   }
                                                                   
                                                                   if(document.getElementById("al_rider_sqs.parent_waiver_cash.id").checked)
                                                                   {
                                                                   console.log("Reserve-->>PRUSpouse Waiver");
                                                                   pagedata["setvar"]["A_Master_Rider_key["+iRiderCount+"]"] ="6PPW";
                                                                   pagedata["setvar"]["A_Master_Rider_Plan_key["+iRiderCount+"]"] = "";
                                                                   pagedata["setvar"]["A_Code_MedValue_key["+iRiderCount+"]"] = "";
                                                                   pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] = "";
                                                                   
                                                                   pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iRiderCount+"]"] ="0";
                                                                   pagedata["setvar"]["A_Expiry_Age_rea["+iRiderCount+"]"] ="0";
                                                                   iRiderCount++;
                                                                   
                                                                   }
                                                                   
                                                                   
                                                                   }
                                                                                                                                                                                                                    

                                                                                                                                                                                                                                                                                                                                                                                                                              
                                                                 
                                                                                                                                                                                                       
                                                    
                                                    pagedata["setvar"]["A_Nof_Riders_int"] = iRiderCount.toString();
                                                    pagedata["setvar"]["A_Nof_Other_Load_int"]="0";
                                                    
                                                    //for pruwealth gain plus
                                                    if(currentPlan == "PRUwealth gain plus" || currentPlan == "PRUgrowth" || currentPlan == "PRUSignature Optimiser" || currentPlan =="PRUValue Gain" || currentPlan =="PRUSignature Reward" || currentPlan == "PRUEasy Protect" || currentPlan === "PRUCash Enrich" || currentPlan === "PRUAll Care" || currentPlan === "PRUFlexi Gain" || currentPlan === "PRUGain Plus" || currentPlan === "PRUEnrich Gain")//added condition for PRUgrowth by Ankita
                                                    {
                                                        pagedata["setvar"]["A_Master_Policy_Term_key"] =document.getElementById("al_rider_sqs.basic_plans.rider_term").value;
                                                    }

                                                    else if(currentPlan == "PRUmy treasure" || currentPlan == "PRUsignature prime" || currentPlan == "PRUSignature Invest" || currentPlan == "PRULink Investor Account" || currentPlan == "PRUGlobal Series" || currentPlan == "PRULink Growth" || currentPlan === "PRUSignature Ace") //Sourabh added PRUSignature Invest on 16 jan 2019 @@@ // by sourabh on  1 april 2019 for PRUGlobal Series
                                                   {
                                                        pagedata["setvar"]["A_Master_Policy_Term_key"]  ="";
                                                   }
                                                                   
                                                    
                                                                   
                                                    var iLoadCount=0;
                                                   if(obj_solution["al_sqs_buttons_plan"]=="al_sqs_buttons.prumy_diabetes_care")
                                                   {
                                                        
                                                   }
                                                   for (var sub in loadingAdditionalArray)
                                                   {
                                                       
                                                       var loadValue=obj_loading[sub];
                                                       console.log("loadValue:"+loadValue);
                                                       if(loadValue != "0" && loadValue != "" && loadValue != undefined && loadValue != 0)
                                                       {
                                                            pagedata["setvar"]["A_Master_Load_Type_rea["+iLoadCount+"]"]=loadValue;
                                                            pagedata["setvar"]["A_Master_Load_Type_key["+iLoadCount+"]"]=loadingAdditionalArray[sub];
                                                        
                                                            iLoadCount++;
                                                       }
                                                   }
                                                                   
                                                                   
                                                    if(iLoadCount == 0)
                                                    {
                                                        pagedata["setvar"]["A_Master_Load_Type_key"]="";
                                                        pagedata["setvar"]["A_Master_Load_Type_rea"]="0";
                                                    }
                                                    pagedata["setvar"]["A_Nof_Other_Load_int"]=iLoadCount.toString();
                                                    var iFundsCount = 0;
                                                   if((currentPlan == "PRUsmart gain" && document.getElementById("al_rider_sqs.prusaver.id").checked == false) || currentPlan == "PRUmy treasure")
                                                   {
                                                       pagedata["setvar"]["A_ILP_Fund_value_rea["+iFundsCount+"]"]="0";
                                                       pagedata["setvar"]["A_Master_ILP_Fund_key["+iFundsCount+"]"]="PSM";
                                       
                                                       iFundsCount++;
                                                   }
                                                    if(currentPlan == "PRUsignature income")
                                                   {
                                                   pagedata["setvar"]["A_ILP_Fund_value_rea["+iFundsCount+"]"]="0";
                                                   pagedata["setvar"]["A_Master_ILP_Fund_key["+iFundsCount+"]"]="PL";//changed code by ankita from IPL to PL for mail sent on 28 August by VPMS
                                                   
                                                   iFundsCount++;
                                                   }
                                                                                                                                                                                                                                                                                                                                                           /*if(currentPlan == "PRUMulti Crisis Guard")
                                                                                                                                                                                                                                                                                                                                                           {
                                                                                                                                                                                                                                                                                                                                                           pagedata["setvar"]["A_ILP_Fund_value_rea["+iFundsCount+"]"]="0";
                                                                                                                                                                                                                                                                                                                                                           pagedata["setvar"]["A_Master_ILP_Fund_key["+iFundsCount+"]"]="PSM";
                                                                                                                                                                                                                                                                                                                                                                                                                              iFundsCount++;
                                                                                                                                                                                                                                                                                                                                                           }*/
                                                    if((currentPlan == "PRUsmart gain" && document.getElementById("al_rider_sqs.prusaver.id").checked == true) || currentPlan != "PRUsmart gain")
                                                    {
                                                    for (var sub in fundsArray)
                                                    {
                                                       var fundValue=obj_prochoice[sub];
                                                       
                                                       if(fundValue != "0")
                                                       {
                                                            pagedata["setvar"]["A_ILP_Fund_value_rea["+iFundsCount+"]"]=fundValue;
                                                            pagedata["setvar"]["A_Master_ILP_Fund_key["+iFundsCount+"]"]=fundsArray[sub];
                                                            iFundsCount++;
                                                       }
                                                      
                                                    }
                                                    }
                                                                 
                                                                   
                                                    pagedata["setvar"]["A_Code_ILP_Fund_Source_key"]="";
                                                    pagedata["setvar"]["A_Nof_fund_int"] = iFundsCount.toString();
                                                                 
                                                    console.log("currentPlan-->"+currentPlan);
                                                                                                                                                                                                                                                                                                                                                                                                                              console.log("currentPlan-->"+JSON.stringify(obj_slife_res));
                                                    if(currentPlan == "PRUwith you") //Added new field for VPMS by Paromita as per email by CUI San on 14 June 2018
                                                    {
                                                          pagedata["setvar"]["A_Code_GIO_SIO_key"] = "N"
                                                          pagedata["setvar"]["A_Master_Campaign_key"] = vpmsEaseCampaignCode;//Added by ankita on 30 August 2018 to pass campaign code to VPMS
                                                          
                                                    }
                                                            if (currentPlan == "PRUSignature Plus")//Pradnya: added for june 24 release
                                                            {
                                                                pagedata["setvar"]["A_Rider_Sum_Assured_rea[0]"] = document.getElementById("al_rider_sqs.prusignature_ppr1.rider_premium").value;
                                                                pagedata["setvar"]["A_Master_Premium_Term_key[1]"] = document.getElementById("al_sqs_details.premium_payment_period_plm_plus").value;
                                                                
                                                            }
                                            // Added by Shivani for Modern Family CR for MAy2022 Release
                                              if((obj_slife_res["al_person_details.slife.relationship"]!="Father" && obj_slife_res["al_person_details.slife.relationship"]!="Mother" && obj_slife_res["al_person_details.slife.relationship"]!="Friend" && obj_slife_res["al_person_details.slife.relationship"]!="Spouse" && obj_slife_res["al_person_details.slife.relationship"]!="Parent" && obj_slife_res["al_person_details.slife.relationship"]!="Legal Guardian") && (obj_slife_res!="" && obj_slife_res!="null" && obj_slife_res!="undefined"))
                                                         {
                                                                                                               
                                              fnMSChangeVPMSInput(pagedata,currentPlan);
                                                         }
                                                    fnCallOutputFunction(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,bFirstCallFlag,obj_prochoice["al_sqs_details.product_name"]);
                                                     });
                                                                   });//end
                                                   });
                                                                   
                             });
                      });
        
                });
          });
               });//Close of bundle product resonse.
               });
                        });
                          });
               });
    });
                          //});//ankita bundle
}

function fnParseRiderPremium(strRiderResult)
{
    
    if(strRiderResult != "" || strRiderResult != "null")
    {
        var arrRiderPremium = [];
        
        var arrSplitRider = strRiderResult.split(";");
        var iCount = 0;

        for(iCount= 0; iCount < arrSplitRider.length;iCount++)
        {
            if(arrSplitRider[iCount] == "LoadedwithGST")
            {
                
                var arrofEachRider = [];
                if(arrSplitRider[iCount+1] != "Unit Deducting")
                {
                    arrofEachRider.push(arrSplitRider[iCount+1]);
                }
                else
                {
                    arrofEachRider.push(0);
                }
                arrRiderPremium.push(arrofEachRider);
                
            }
            
        }
        
    }
    return arrRiderPremium;
    
}

//Function to validate PRUsaver (Cash Value)
function fnValidateOfPrusaver(pagedata,messageToValidate,obj_mainlife_response,obj_prodchoice_res,pagedata,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,checkFirstCal,jsonLeftPanel,strValidationString)
{
    console.log("messageToValidate:"+messageToValidate);
    var strSingleValidationError ="";
    bootbox.confirm({
                    
                    message: "<p class=\"text-left\">"+messageToValidate+"</p>",
                    buttons: {
                    cancel: {
                    label: '<i class="fa fa-check"></i>Cancel to proceed',
                    className: 'btn-default'
                    
                    },
                    confirm: {
                    label: '<i class="fa fa-times"></i>Ok to amend',
                    className: 'btn-default'
                    }
                    },
                    callback: function (result)
                    {
                    
                    canSwipe=0;
                    
                    if(result==true)
                    {
                    
                        canSwipe=1;
                        szNegativeCashValueFlag = "No";
                        var res = messageToValidate.match(/(\d[.]*)+/g).toString();
                        var res1 = res.replace(',','');
                        var res2 = res1.substring(0,res1.indexOf("."))
                        
                        
                        var investmentPremValue = res2;
                    
                        //var investmentPremValue = messageToValidate.replace(/(\d[.]*)+/g,'');
                        console.log("investmentPremValue::"+investmentPremValue);
                        document.getElementById("al_sqs_details.investment_premium").value =investmentPremValue;
                        //added by ankita on 8 may 2019 for pruwealth plus product
                        var insuValue="";
                        if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25")
                        {
                            insuValue=document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").value;
                        }
                        else
                        {
                            insuValue=document.getElementById("al_sqs_details.insurance_premium").value;
                        }
                    console.log("For max Cover--");
                        //var insuValue=document.getElementById("al_sqs_details.insurance_premium").value;
                        var investValue=document.getElementById("al_sqs_details.investment_premium").value;
                        document.getElementById("al_sqs_details.total_premium_plm_plus").value=(parseFloat(insuValue)+parseFloat(investValue)).toFixed(2);
                        //var iPolicyTermToSet = parseInt(document.getElementById("al_sqs_details.target_sustainability_option").value) - parseInt(obj_prodchoice_res["al_sqs_details.mlife.il_anb"]); //SR and ankita added comment for def-8966
                    var iPolicyTermToSet = "";
                    
                    if(document.getElementById("al_sqs_details.target_sustainability_option").value==20)
                    {
                    iPolicyTermToSet="20";
                    }
                    else
                    {
                    iPolicyTermToSet =  parseInt(document.getElementById("al_sqs_details.target_sustainability_option").value) - parseInt(obj_prochoice["al_sqs_details.mlife.il_anb"]);
                    }
                        if(obj_mainlife_response["al_person_details.pre_natal_child_flg"] == "Yes" || obj_prodchoice_res["al_sqs_details.mlife.il_anb"]<=18)
                        {
                            if(document.getElementById("al_rider_sqs.prusaver.id").checked)
                            {
                                console.log("PRUsaver attached -1->");
                                 document.getElementById("al_rider_sqs.prusaver.rider_premium").value =investmentPremValue;
                                document.getElementById("al_rider_sqs.prusaver.rider_premium").value =investmentPremValue;
                                 console.log("For max Cover");
                                if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL03" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS3" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL11" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL14" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL24")
                                {
                                    document.getElementById("al_rider_sqs.prusaver.rider_term").value = document.getElementById("al_sqs_details.premium_payment_period_plm_plus").value;
                                }
                                else
                                {
                                    //document.getElementById("al_rider_sqs.prusaver.rider_term").value = 100-obj_prodchoice_res["al_sqs_details.mlife.il_anb"];
                                    //added by ankita for defect 8640 on 25 dec 2019
                                    if(obj_prodchoice_res["al_sqs_details.product_name"]=="PRULink Cover" || obj_prodchoice_res["al_sqs_details.product_name"]=="PRUwith you" || obj_prodchoice_res["al_sqs_details.product_name"]=="PRUSignature Assure")
                                    {
                                        document.getElementById("al_rider_sqs.prusaver.rider_term").value = iPolicyTermToSet;
                                    }
                                    else
                                    {
                                        document.getElementById("al_rider_sqs.prusaver.rider_term").value = 100-obj_prodchoice_res["al_sqs_details.mlife.il_anb"];
                                    }
                    
                                }
                                document.getElementById("al_rider_sqs.prusaver.rider_expiry_age").value = 100;
                                document.getElementById("al_rider_sqs.prusaver.rider_premium").disabled=false;
                                document.getElementById("al_rider_sqs.prusaver.rider_premium").readOnly = false;
                            }
                            else if(document.getElementById("al_rider_sqs.prusaver_kid.id").checked)
                            {
                                document.getElementById("al_rider_sqs.prusaver_kid.rider_premium").value =investmentPremValue;
                                if(obj_prodchoice_res["al_sqs_details.product_name"]=="PRULink Cover" || obj_prodchoice_res["al_sqs_details.product_name"]=="PRUwith you" || obj_prodchoice_res["al_sqs_details.product_name"]=="PRUSignature Assure")
                                {
                                    document.getElementById("al_rider_sqs.prusaver_kid.rider_term").value = iPolicyTermToSet;
                                }
                                else
                                {
                                    document.getElementById("al_rider_sqs.prusaver_kid.rider_term").value =100-obj_prodchoice_res["al_sqs_details.mlife.il_anb"];
                                }
                                document.getElementById("al_rider_sqs.prusaver_kid.rider_expiry_age").value = 100;
                                document.getElementById("al_rider_sqs.prusaver_kid.payout_age").disabled=false;
                                document.getElementById("al_rider_sqs.prusaver_kid.rider_premium").disabled=false;
                                document.getElementById("al_rider_sqs.prusaver_kid.rider_premium").readOnly = false;
                                
                            }
                            else
                            {
                                console.log("In else--");
                             if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL13" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL19" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL26") //if condition added for 9102 Ankita / SR
                            {
                                 console.log("In if-1-");
                                document.getElementById("al_rider_sqs.prusaver.id").checked = true;
                                document.getElementById("al_rider_sqs.prusaver.rider_premium").value =investmentPremValue;
                                document.getElementById("al_rider_sqs.prusaver.rider_term").value = document.getElementById("al_sqs_details.premium_payment_period_plm_plus").value;
                                document.getElementById("al_rider_sqs.prusaver.rider_premium").disabled=false;
                                document.getElementById("al_rider_sqs.prusaver.rider_premium").readOnly = false;
                    
                            }else{
                                 console.log("In else--1-");
                                document.getElementById("al_rider_sqs.prusaver_kid.id").checked = true;
                                document.getElementById("al_rider_sqs.prusaver_kid.rider_premium").value =investmentPremValue;
                                document.getElementById("al_rider_sqs.prusaver_kid.rider_term").value =100-obj_prodchoice_res["al_sqs_details.mlife.il_anb"];
                                document.getElementById("al_rider_sqs.prusaver_kid.rider_expiry_age").value = 100;
                                document.getElementById("al_rider_sqs.prusaver_kid.payout_age").disabled=false;
                                document.getElementById("al_rider_sqs.prusaver_kid.rider_premium").disabled=false;
                                document.getElementById("al_rider_sqs.prusaver_kid.rider_premium").readOnly = false;
                            }
                          }
                        }
                        else
                        {
                            console.log("in else 1111");
                            document.getElementById("al_rider_sqs.prusaver.id").checked = true;
                            document.getElementById("al_rider_sqs.prusaver.rider_premium").value =investmentPremValue;

                            if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL03" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS3" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL11" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL14" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL24")
                            {
                                document.getElementById("al_rider_sqs.prusaver.rider_term").value = document.getElementById("al_sqs_details.premium_payment_period_plm_plus").value;
                            }
                            else
                            {
                                    //added by ankita for defect 8640 on 25 dec 2019
                                    if(obj_prodchoice_res["al_sqs_details.product_name"]=="PRULink Cover" || obj_prodchoice_res["al_sqs_details.product_name"]=="PRUwith you" || obj_prodchoice_res["al_sqs_details.product_name"]=="PRUSignature Assure")
                                    {
                                    document.getElementById("al_rider_sqs.prusaver.rider_term").value = iPolicyTermToSet;
                                    }
                                    else
                                    {
                                    document.getElementById("al_rider_sqs.prusaver.rider_term").value = 100-obj_prodchoice_res["al_sqs_details.mlife.il_anb"];
                                    }
                                    
                            }
                            document.getElementById("al_rider_sqs.prusaver.rider_expiry_age").value = 100;
                            document.getElementById("al_rider_sqs.prusaver.rider_premium").disabled=false;
                            document.getElementById("al_rider_sqs.prusaver.rider_premium").readOnly = false;


                        }
                        if(jsonLeftPanel != "" && (pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS2" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL08" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL16" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25"))
                        {
                            //added by ankita on 8 may 2019 for pruwealth plus product
                            if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25")
                            {
                    
                                document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").readOnly = false;
                                document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").disabled=false;
                            }
                            else
                            {
                                document.getElementById("al_sqs_details.insurance_premium").readOnly = false;
                                document.getElementById("al_sqs_details.insurance_premium").disabled=false;
                            }
                            
                            if(checkFirstCal == null || checkFirstCal == "" || checkFirstCal == "NA" || checkFirstCal == "undefined" || checkFirstCal== "0")
                            {
                                //added by ankita on 8 may 2019 for pruwealth plus product
                                if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25")
                                {
                                    document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").value = jsonLeftPanel["MinimumInsurance"];
                                }
                                else
                                {
                                    document.getElementById("al_sqs_details.insurance_premium").value = jsonLeftPanel["MinimumInsurance"];
                                }
                               //document.getElementById("al_sqs_details.insurance_premium").value = jsonLeftPanel["MinimumInsurance"];
                            }
                    
                    //added by ankita on 10 jan 2020 for defect 8934
                      pagedata["VPMSFunctionNameInSequence"] = ["P_Calculate_Prem_Sustain_out"];
                      console.log("pageData:"+JSON.stringify(pagedata));
                      
                      
                      js_call_native_func("VPMSCall",pagedata,function(resP_Calculate_Prem_Sustain_out)
                      {
                            console.log("resP_Calculate_Prem_Sustain_out def 8934 fnvalidateofprusaver-->" +resP_Calculate_Prem_Sustain_out);

                            var jsonresP_Calculate_Prem_Sustain_out = JSON.parse(resP_Calculate_Prem_Sustain_out);
                            var objresP_Calculate_Prem_Sustain_out = jsonresP_Calculate_Prem_Sustain_out[pagedata["VPMSFunctionNameInSequence"]];
                            console.log("objresP_Calculate_Prem_Sustain_out"+JSON.stringify(objresP_Calculate_Prem_Sustain_out));
                            var objSplitP_Calculate_Prem_Sustain_out = objresP_Calculate_Prem_Sustain_out["result"].split(";")
                            console.log("objSplitP_Calculate_Prem_Sustain_out"+objSplitP_Calculate_Prem_Sustain_out);
                            
                               
                                if(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeHigh") != -1)
                                {
                                    jsonLeftPanel["PolSustAgeHigh"] =  objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeHigh"))+1];
                                }
                                else
                                {
                                    jsonLeftPanel["PolSustAgeHigh"] = "0";
                                }
                                if(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeLow") != -1)
                                {
                                    jsonLeftPanel["PolSustAgeLow"] =  objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeLow"))+1];
                                }
                                else
                                {
                                    jsonLeftPanel["PolSustAgeLow"] = "0";
                                }
                            
                            document.getElementById("al_sqs_details.total_premium_plm_plus").value = jsonLeftPanel["TotPrem"];
                            document.getElementById("al_sqs_details.min_insurance_premium").value = jsonLeftPanel["MinimumInsurance"];
                            document.getElementById("al_sqs_details.max_insurance_premium").value = jsonLeftPanel["MaximumInsurance"];
                            document.getElementById("al_sqs_details.project_sustainability_age_high").value = jsonLeftPanel["PolSustAgeHigh"];
                            document.getElementById("al_sqs_details.project_sustainability_age_low").value = jsonLeftPanel["PolSustAgeLow"];
                                          
                                          
                                          });
                    }
                    else
                    {
                        if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS3" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL14" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL24")
                        {
                            //added by ankita on 21 jan 2020 for defect 8857
                        fnMsCallPremSuatainMillionCoverOkToAmend(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mainlife_response,obj_prodchoice_res,iSelectedRiderCount,bFirstCallFlag,jsonLeftPanel,investmentPremValue);
                            
                        }
                        else
                        {
                            PrusaverReset("");
                        }
                    
                    }
                    
                    }
                    else
                    {
                        szNegativeCashValueFlag = "Yes";
                    
                        //szOkToAmendCVFlag = "No";
                        pagedata["VPMSFunctionNameInSequence"] = ["P_Validate_Post_Benefit_out"];
                        js_call_native_func("VPMSCall",pagedata,function(szValidationError)
                                            {
                                                console.log("P_Validate_Post_Benefit_out szValidationError:"+szValidationError);
                                                szValidationError=szValidationError.replace(/\\r\\n/g, "<br />");//added for defect 7381 on 11 may 2019
                                                console.log("P_Validate_Post_Benefit_out szValidationError123:"+szValidationError);
                                                szValidationError=szValidationError.replace(/\\n/g, "<br />");//Commented for Standardize eeror message for defect 5158 by ankita on 14 May 2018
                                                console.log("P_Validate_Post_Benefit_out szValidationError124:"+szValidationError);
                                                var jsonszValidationError = JSON.parse(szValidationError)
                                            
                                            if(fnShowValidationError(jsonszValidationError[pagedata["VPMSFunctionNameInSequence"]],obj_mainlife_response,obj_prodchoice_res,pagedata,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel))
                                                {
                                                    szNegativeCashValueFlag = "No";
                                                    benefit_flag_update ="0";
                                                    console.log("benefit_flag_update--"+benefit_flag_update);
                                                    canSwipe=1;
                                                    fnCallOutputAfterValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mainlife_response,obj_prodchoice_res,iSelectedRiderCount,bFirstCallFlag)
                                                }
                                            });
                                            
                    
                    }
                    }});
    
    
}

//Function to add Dependend Rider by parsing the rider.

function fnAddDependentRider(pagedata,szResponseRider)
{
    var objRiderdetails = (szResponseRider);
    var strRiderdetails=objRiderdetails["result"];
    console.log("strRiderdetails="+strRiderdetails);
    iRiderCountPruAllocator = 0;
    iRiderCountPruBooster = 0;
    
    
    var dependentRider = strRiderdetails.split(";")
    
    var iDependentRiderCount = parseInt(pagedata["setvar"]["A_Nof_Riders_int"]);
    for(var iSplitCounter = 0; iSplitCounter < dependentRider.length; iSplitCounter++)
    {
        console.log("dependentRider[iSplitCounter]="+dependentRider[iSplitCounter]);
        console.log("dependentRider[iSplitCounter+1]="+dependentRider[iSplitCounter+1]);
        if(dependentRider[iSplitCounter] == "Dependents" && dependentRider[iSplitCounter+1] != "NA")
        {
            var listdependentRider = dependentRider[iSplitCounter+1].split(":")
            
            
            for(var iSplitRiderCounter = 0; iSplitRiderCounter < listdependentRider.length; iSplitRiderCounter++)
            {
                console.log("listdependentRider[iSplitRiderCounter]="+listdependentRider[iSplitRiderCounter]);
                console.log("listdependentRider[iSplitRiderCounter]="+listdependentRider[iSplitRiderCounter]);
                
                
                if(listdependentRider[iSplitRiderCounter] == "AL01" || listdependentRider[iSplitRiderCounter] == "AL05" || listdependentRider[iSplitRiderCounter] == "ALS1" || listdependentRider[iSplitRiderCounter] == "AL06" || listdependentRider[iSplitRiderCounter] == "AL07" || listdependentRider[iSplitRiderCounter] == "AL10" || listdependentRider[iSplitRiderCounter] == "AL11" || listdependentRider[iSplitRiderCounter] == "AL13" ||
                    listdependentRider[iSplitRiderCounter] == "AL14" || listdependentRider[iSplitRiderCounter] == "AL15" || listdependentRider[iSplitRiderCounter] == "AL16")//added condition for AL06 by ankita//added AL14 by ankita on 20 sept 2022 for PRUSignature Ace product
                {
                    iRiderCountPruAllocator = iDependentRiderCount;
                    console.log("iRiderCountPruAllocator="+iRiderCountPruAllocator);
                }
               
               if(listdependentRider[iSplitRiderCounter] == "BP01")//added condition for BP01 by Shivani
               {
                   iRiderCountPruBooster = iDependentRiderCount;
                   console.log("iRiderCountPruBooster= "+iRiderCountPruBooster);
               }
               
               
               if(listdependentRider[iSplitRiderCounter] == "CI26" || listdependentRider[iSplitRiderCounter] == "CI27" || listdependentRider[iSplitRiderCounter] == "PT05" || listdependentRider[iSplitRiderCounter] == "CS22")//added condition for AL06 by ankita
                              {
                                pagedata["setvar"]["A_Master_Rider_key["+iDependentRiderCount+"]"] = listdependentRider[iSplitRiderCounter] ;
                                pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iDependentRiderCount+"]"] = document.getElementById("al_rider_sqs.basic_plans.rider_value").value
               }
                
               else if(listdependentRider[iSplitRiderCounter] == "CM06")//Pradnya: added to pass 5000 for compassionate benefit for PRUSignature plus for def 1456 june24 release
                               {
                                 pagedata["setvar"]["A_Master_Rider_key["+iDependentRiderCount+"]"] = listdependentRider[iSplitRiderCounter] ;
                                 pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iDependentRiderCount+"]"] = "5000";
                }
               else{
               
               pagedata["setvar"]["A_Master_Rider_key["+iDependentRiderCount+"]"] = listdependentRider[iSplitRiderCounter] ;
                              pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iDependentRiderCount+"]"] = "0" ;
               
               }
                

               
                
               
               
               
                //added by ankita on 25 july 2019 for prusenior med rider
                if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "5PPT2")
                {
                    pagedata["setvar"]["A_Code_Rider_Deduct_key["+iDependentRiderCount+"]"] =document.getElementById("al_rider_sqs.common_products.rider_value").value;//to fetch from UI
                }
               
                
                if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "PI13")
                {
                    pagedata["setvar"]["A_Code_Rider_Deduct_key["+iDependentRiderCount+"]"] =document.getElementById("al_rider_sqs.basic_plan.rider_value").value;//to fetch from UI
                }
                
               if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "5PPT2")
                              {
                                  pagedata["setvar"]["A_Code_Rider_Deduct_key["+iDependentRiderCount+"]"] =document.getElementById("al_rider_sqs.common_products.rider_value").value;//to fetch from UI
                              }
                iDependentRiderCount++;
            }
        }
    }
    
    if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL11")
    {
       // iDependentRiderCount=iDependentRiderCount+1
        pagedata["setvar"]["A_Master_Rider_key["+iDependentRiderCount+"]"] = "AL06" ;
        pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iDependentRiderCount+"]"] = "0" ;
        iDependentRiderCount=iDependentRiderCount+1;
    }
               // Added by Shivani for PMCG PRUallocator
               if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL15")
               {
                  // iDependentRiderCount=iDependentRiderCount+1
                   pagedata["setvar"]["A_Master_Rider_key["+iDependentRiderCount+"]"] = "AL11" ;
                   pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iDependentRiderCount+"]"] = "0" ;
                   iDependentRiderCount=iDependentRiderCount+1;
               }
               // Added by Shivani for PMCG PRUBooster
               if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL15")
               {
                  // iDependentRiderCount=iDependentRiderCount+1
                   pagedata["setvar"]["A_Master_Rider_key["+iDependentRiderCount+"]"] = "BP01" ;
                   pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iDependentRiderCount+"]"] = "0" ;
                   iDependentRiderCount=iDependentRiderCount+1;
               }
               
               if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "TR14")
               {
                  // iDependentRiderCount=iDependentRiderCount+1
                   pagedata["setvar"]["A_Master_Rider_key["+iDependentRiderCount+"]"] = "AC10" ;
                   pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iDependentRiderCount+"]"] = "0" ;
                   iDependentRiderCount=iDependentRiderCount+1;
               }
    pagedata["setvar"]["A_Nof_Riders_int"] = iDependentRiderCount.toString();
    
    return pagedata;
}


//Function for validation error display

function fnShowValidationError(szValidationError,obj_mlife_res,obj_prochoice,pagedata,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel)
{
    isSIOCampaignFlag="No";
    isSIOCampaignFlagReserve="No";
    console.log("szValidationError"+JSON.stringify(szValidationError));
    //szValidationError=szValidationError.replace(/\\n/g, "<br />");
    console.log("ankita pageData inside fnShowValidationError:"+JSON.stringify(pagedata));
    var firstCal = document.getElementById("al_sqs_details.min_insurance_premium").value;
    var objVPMSValidateJSON = (szValidationError);
    var strValidate=objVPMSValidateJSON["result"];
    var arrAlerts = new Array();
    var arrWarnings = new Array();
               
    //strValidate=";A_Master_Rider_key;VW11:Total Critical Illness Sum Assured chosen is higher than the standard sum assured limit of RM750,000.00 for juvenile. The approval of this proposal is not guaranteed and subject to underwriting assessment.;A_Master_Rider_key;VW12:Total Basic Sum Assured  and Level SA Rider Sum Assured chosen is higher than the standard sum assured limit of RM2,000,000.00 for juvenile. The approval of this proposal is not guaranteed and subject to underwriting assessment.;";
    console.log("Before if strValidate:"+strValidate);
    /*if((strValidate=="A_Code_Payment_Method_key;V122:Payment Method is not valid.;;") && obj_prochoice["al_sqs_details.product_name"]=="PRUValue Gain")
    {
        return true;
    }
    else if((strValidate=="A_Code_Payment_Frequency_key;V120:Payment Frequency is not valid.;;") && obj_prochoice["al_sqs_details.product_name"]=="PRUValue Gain")
    {
        return true;
    }
    else if((strValidate=="A_Code_Payment_Frequency_key;V120:Payment Frequency is not valid.;A_Code_Payment_Method_key;V122:Payment Method is not valid.;;") && obj_prochoice["al_sqs_details.product_name"]=="PRUValue Gain")
    {
        return true;
    }*/
    //else
    //{
    strValidationErrorSplit = strValidate.split(";");
    //console.log("strValidationErrorSplit:"+strValidationErrorSplit+"--strValidate:"+strValidate);
   
    if(strValidationErrorSplit.length > 1 && strValidate != ";")
    {
        benefit_flag_update = "1";
        var iCount = 0;
        var strSingleValidationError ="";
        
        var strValidateSplitSingle = new Array();
        for(iCount = 0;iCount < strValidationErrorSplit.length;iCount++)
        {
            var strErrorMessage = "";
            
            if(strValidationErrorSplit[iCount].indexOf(":")!= -1)
            {
                strErrorMessage = strValidationErrorSplit[iCount];
                console.log("strErrorMessage:"+strErrorMessage)
                var strCodeErrorMessage = strErrorMessage;
                var code = strCodeErrorMessage.split(/:(.+)/)[0];
                strErrorMessage = strErrorMessage.split(/:(.+)/)[1];
                console.log("strErrorMessage2:"+strErrorMessage);
                strErrorMessage=strErrorMessage.replace(/\<br \/\>/g, "\n")//Added by ankita for defect 5476 on 21 May 2018
                console.log("strErrorMessage3:"+strErrorMessage);
                console.log("code :"+code);
                
                if(code.indexOf('V196')!= -1 || code.indexOf('V196')!= "-1")
                {
                    targetSustainabilityFlag = "No";
                    fnValidateOfMinMaxNA(strErrorMessage);
                    break;
                }
//               else if(code.indexOf('V373')!= -1 || code.indexOf('V373')!= "-1") //ToDO 11-08-2021
//                              {
//                                 // targetSustainabilityFlag = "No";
//                                 // fnValidateOfMinMaxNA(strErrorMessage);
//                                  break;
//                              }
                else if((code.indexOf('V221')!= -1 || code.indexOf('V221')!= "-1") && (obj_prochoice["al_sqs_details.product_name"]=="PRUwith you"))//Added by ankita for PRUwith you ease campaign
                {
                    targetSustainabilityFlag = "No";
                    console.log("Inside ease");
                   //change by ankita from 14 to 13 for new rider mom and baby care on 22 nov 2022
                   if(obj_mlife_res["al_person_details.gestational_week"]<13)
                    {
                        fnValidateEaseCampaignMessageC(pagedata);
                    }
                    else if(obj_mlife_res["al_person_details.gestational_week"]>=14 && obj_mlife_res["al_person_details.gestational_week"]<=17)
                    {
                        fnValidateEaseCampaignMessageB(pagedata);
                    }
                    break;
                }
                else if(code.indexOf('VW06')!= -1 || code.indexOf('VW06')!= "-1")
                {
                    targetSustainabilityFlag = "No";
                   isSIOCampaignFlag="Yes";
                    fnShowSIOWarningMsg(pagedata,strErrorMessage,obj_mlife_res,obj_prochoice,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel);
                    break;
                }
               else if((code.indexOf('V372')!= -1 || code.indexOf('V372')!= "-1") && obj_prochoice["al_sqs_details.product_name"]!=="PRUSignature Treasure")
                              {
                                 
                                  fnShowSIOWarningMsg(pagedata,strErrorMessage,obj_mlife_res,obj_prochoice,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel);
                                  break;
                              }
                                   // Added by Shivani for PRULink Supreme Sustainability pop up message
                                  else if((code.indexOf('V375')!= -1 || code.indexOf('V375')!= "-1"))
                                  {
                                          console.log("PLS V375 msg:"+strErrorMessage);
                               fnPopulateInvestmentPremium(pagedata,strErrorMessage,obj_mlife_res,obj_prochoice,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel);
                                          break;
                                       
                                      
                                  }
                           
              
               
               
                // Else if added by Shivani for PRUSignature REserve(VM13) for SIOcampaign
                /*else if((code.indexOf('VW13')!= -1 || code.indexOf('VW13')!= "-1") && obj_prochoice["al_sqs_details.product_name"]=="PRUSignature Reserve")//vm13
                {
                    isSIOCampaignFlagReserve="Yes";
                    fnShowSIOWarningMsg(pagedata,strErrorMessage,obj_mlife_res,obj_prochoice,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel);
                    break;
                }*/
                else if(code.indexOf('V294')!= -1 || code.indexOf('V294')!= "-1" || code.indexOf('V295')!= -1 || code.indexOf('V295')!= "-1")
                {
                    //isSIOCampaignFlag="Yes";
                    fnShowTargetSustainAlert(pagedata,strValidationErrorSplit[iCount],obj_mlife_res,obj_prochoice,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel);
                    break;
                }
               else if(code.indexOf('V381')!= -1 || code.indexOf('V381')!= "-1" || code.indexOf('V381')!= -1 || code.indexOf('V381')!= "-1")//added by ankita for prusignature ace product on 12 sept 2022
               {
                   //isSIOCampaignFlag="Yes";
                   fnShowTargetSustainAgeAlert(pagedata,strValidationErrorSplit[iCount],obj_mlife_res,obj_prochoice,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel);
                   break;
               }
                else if(code.indexOf('VW')!= -1 || code.indexOf('VW')!= "-1")
                {
                    if(szNegativeCashValueFlag != "Yes")
                    {
                        targetSustainabilityFlag = "No";
                    }
                    console.log("Before strValidateSplitSingle1:"+strValidateSplitSingle+"--strValidationErrorSplit[iCount]:"+strValidationErrorSplit[iCount]);
                    //strValidateSplitSingle=strValidateSplitSingle+strValidationErrorSplit[iCount];
                    console.log("strValidateSplitSingle2:"+strValidateSplitSingle);
                    console.log("strSingleValidationError:"+strSingleValidationError+"--strErrorMessage:"+strErrorMessage);
               //added by ankita on 4 Feb 2020 for defect 8999
                   if(strValidateSplitSingle != "")//Added by ankita for defect 5476 on 21 May 2018
                   {
                   
                       strValidateSplitSingle = strValidateSplitSingle + "\n" + strValidationErrorSplit[iCount] + "\n";
                   }
                   else
                   {
                       strValidateSplitSingle = strValidateSplitSingle + strValidationErrorSplit[iCount] + "\n";
                   }
                    console.log("After strValidateSplitSingle1:"+strValidateSplitSingle+"--strValidationErrorSplit[iCount]:"+strValidationErrorSplit[iCount]);
                   // break;
                    
                }
                else
                {
                    targetSustainabilityFlag = "No";
                    //strSingleValidationError = strSingleValidationError+ strErrorMessage + "<br /><br />";//Commented for Standardize eeror message for defect 5158 by ankita on 14 May 2018
                    console.log("strErrorMessage3:"+strErrorMessage);
                    console.log("strSingleValidationError:"+strSingleValidationError+"strErrorMessage:"+strErrorMessage);
                    if(strSingleValidationError != "")//Added by ankita for defect 5476 on 21 May 2018
                    {
                    
                        strSingleValidationError = strSingleValidationError + "\n" + strErrorMessage + "\n";
                    }
                    else
                    {
                        strSingleValidationError = strSingleValidationError + strErrorMessage + "\n";
                    }
                    console.log("strSingleValidationError1:"+strSingleValidationError+"strErrorMessage1:"+strErrorMessage);
                    
                   
                }
                
                
            }
            
        }
        
        if(strSingleValidationError != "" && strSingleValidationError != "undefined" && strSingleValidationError != undefined && strSingleValidationError != "null" && strSingleValidationError != "(null)" && strSingleValidationError != null)
        {
            
            if(jsonLeftPanel != "" && (pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS2" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL08" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10"  || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL16" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25"))
            {
                //added by ankita on 8 may 2019 for pruwealth plus product
                if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25")
                {
                    
                    document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").readOnly = false;
                    document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").disabled=false;
                }
                else
                {
                    document.getElementById("al_sqs_details.insurance_premium").readOnly = false;
                    document.getElementById("al_sqs_details.insurance_premium").disabled=false;
                }
                console.log("jsonLeftPanel:"+JSON.stringify(jsonLeftPanel)+"firstCal:"+firstCal);
                if((firstCal == null || firstCal == "" || firstCal == "NA" || firstCal == "undefined" || firstCal== "0"))
                {
                    console.log("jsonLeftPanel2:"+JSON.stringify(jsonLeftPanel));
                    if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25")
                    {
                        document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").value = jsonLeftPanel["MinimumInsurance"];//added by ankita on 8 May 2019 for pruwealth plus product
                    }
                    else
                    {
                        document.getElementById("al_sqs_details.insurance_premium").value = jsonLeftPanel["MinimumInsurance"];
                        
                    }
                    //document.getElementById("al_sqs_details.insurance_premium").value = jsonLeftPanel["MinimumInsurance"];
                }
               
        //added by ankita on 10 jan 2020 for defect 8934
          pagedata["VPMSFunctionNameInSequence"] = ["P_Calculate_Prem_Sustain_out"];
          console.log("pageData:"+JSON.stringify(pagedata));
          
          
          js_call_native_func("VPMSCall",pagedata,function(resP_Calculate_Prem_Sustain_out)
          {
                console.log("resP_Calculate_Prem_Sustain_out-->" +resP_Calculate_Prem_Sustain_out);

                var jsonresP_Calculate_Prem_Sustain_out = JSON.parse(resP_Calculate_Prem_Sustain_out);
                var objresP_Calculate_Prem_Sustain_out = jsonresP_Calculate_Prem_Sustain_out[pagedata["VPMSFunctionNameInSequence"]];
                console.log("objresP_Calculate_Prem_Sustain_out"+JSON.stringify(objresP_Calculate_Prem_Sustain_out));
                var objSplitP_Calculate_Prem_Sustain_out = objresP_Calculate_Prem_Sustain_out["result"].split(";")
                console.log("objSplitP_Calculate_Prem_Sustain_out"+objSplitP_Calculate_Prem_Sustain_out);
                
                    if(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeHigh") != -1)
                    {
                        jsonLeftPanel["PolSustAgeHigh"] =  objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeHigh"))+1];
                    }
                    else
                    {
                        jsonLeftPanel["PolSustAgeHigh"] = "0";
                    }
                    if(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeLow") != -1)
                    {
                        jsonLeftPanel["PolSustAgeLow"] =  objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeLow"))+1];
                    }
                    else
                    {
                        jsonLeftPanel["PolSustAgeLow"] = "0";
                    }
              //Added by Paromita for Agency CR on 3rd Aug 2023
              if(objSplitP_Calculate_Prem_Sustain_out.indexOf("TotPrem") != -1)
              {
                  jsonLeftPanel["TotPrem"] =  objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("TotPrem"))+1];
              }
              else
              {
                  jsonLeftPanel["TotPrem"] = "0";
              }
              if(objSplitP_Calculate_Prem_Sustain_out.indexOf("MaxInsPrem") != -1 && objSplitP_Calculate_Prem_Sustain_out.indexOf("InsPrem") != -1)
              {
                  jsonLeftPanel["InsurancePremium"] =  Math.min(objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("InsPrem"))+1],objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("MaxInsPrem"))+1]);
              }
              else
              {
                  jsonLeftPanel["InsurancePremium"] = "0";
              }
              if(objSplitP_Calculate_Prem_Sustain_out.indexOf("MaxBUAPrem") != -1)
              {
                  jsonLeftPanel["MaxBUAPrem"] =  objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("MaxBUAPrem"))+1];
              }
              else
              {
                  jsonLeftPanel["MaxBUAPrem"] = "0";
              }
              console.log("PN......Before allocator call")
              if(objSplitP_Calculate_Prem_Sustain_out.indexOf("MaxInsPrem") != -1)
              {
                  var PRUallocatorPremium = 0;
                  if(objSplitP_Calculate_Prem_Sustain_out.indexOf("AL15") != -1)
                  {
                      PRUallocatorPremium = objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("AL15"))+1]
                  }
//Def -1122 by Paromita on 29th Aug
                  console.log("PN......PRUallocatorPremium "+PRUallocatorPremium)
                  console.log("PN......--pruwealth_plus_target_bua_prem "+document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").value)
                  console.log("PN......--MaxInsPrem "+objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("MaxInsPrem"))+1])
                  jsonLeftPanel["PRUAllocator"] = Math.max(parseFloat(PRUallocatorPremium),(parseFloat(document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").value) -parseFloat(objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("MaxInsPrem"))+1])));
                  console.log("PN......--PRUAllocator "+jsonLeftPanel["PRUAllocator"])

              }
              else
              {
                  jsonLeftPanel["PRUAllocator"] = "0";
              }
              
              
                    document.getElementById("al_sqs_details.total_premium_plm_plus").value = jsonLeftPanel["TotPrem"];
                    document.getElementById("al_sqs_details.min_insurance_premium").value = jsonLeftPanel["MinimumInsurance"];
                    document.getElementById("al_sqs_details.max_insurance_premium").value = jsonLeftPanel["MaximumInsurance"];
                    document.getElementById("al_sqs_details.project_sustainability_age_high").value = jsonLeftPanel["PolSustAgeHigh"];
                    document.getElementById("al_sqs_details.project_sustainability_age_low").value = jsonLeftPanel["PolSustAgeLow"];
              
              if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25")
              {
                  document.getElementById("al_sqs_details.insurance_premium").value = jsonLeftPanel["InsurancePremium"];
                  document.getElementById("al_sqs_details.pwp_max_bua_premium").value = jsonLeftPanel["MaxBUAPrem"];
                  document.getElementById("al_sqs_details.pruallocator_premium").value = jsonLeftPanel["PRUAllocator"];
//Def -1122 by Paromita on 29th Aug
                  document.getElementById("al_rider_sqs.pruallocator.rider_premium").value = parseFloat(jsonLeftPanel["PRUAllocator"]).toFixed(2);
                  document.getElementById("al_rider_sqs.pruallocator.rider_term").value = (document.getElementById("al_sqs_details.premium_payment_period_pw_plus").value).split("_")[0];
              }
              
              
                              isAlertFromVPMS="Yes";
                    alert("751",strSingleValidationError);
                });
            }//added else by ankita on 21 jan 2020 for defect 8934 to avoid async call
            else
            {
                isAlertFromVPMS="Yes";
                alert("751",strSingleValidationError);
            }
            

           
            

           
        }
        else if(strValidateSplitSingle != "" && strValidateSplitSingle != "undefined" && strValidateSplitSingle != undefined && strValidateSplitSingle != "null" && strValidateSplitSingle != "(null)" && strValidateSplitSingle != null)
        {
            if(jsonLeftPanel != "" && (pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS2" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL08"  || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL16" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25"))
            {
                if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25")//added by ankita on 8 May 2019 for pruwealth plus
                {
                    document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").readOnly = false;
                    document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").disabled=false;
                }
                else
                {
                    document.getElementById("al_sqs_details.insurance_premium").readOnly = false;
                    document.getElementById("al_sqs_details.insurance_premium").disabled=false;
                }
                //document.getElementById("al_sqs_details.insurance_premium").readOnly = false;
                //document.getElementById("al_sqs_details.insurance_premium").disabled=false;
                if((firstCal == null || firstCal == "" || firstCal == "NA" || firstCal == "undefined" || firstCal== "0"))
                {
                    //document.getElementById("al_sqs_details.insurance_premium").value = jsonLeftPanel["MinimumInsurance"];
                    if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25")
                    {
                        document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").value = jsonLeftPanel["MinimumInsurance"];//added by ankita on 8 May 2019 for pruwealth plus product
                    }
                    else
                    {
                        document.getElementById("al_sqs_details.insurance_premium").value = jsonLeftPanel["MinimumInsurance"];

                    }
                   
                }
                
            }
            
            var strErrorMsg="";
            console.log("strValidateSplitSingle3:"+strValidateSplitSingle);
            var strValidateSplitSingleError = strValidate.split(".;");
            console.log("strValidateSplitSingleError:"+strValidateSplitSingleError);
            var arrWarningsCV="";//added by ankita for defect 9897
            for(i = 0;i < strValidateSplitSingleError.length;i++)
            {
                console.log("strValidateSplitSingleError[i]:"+strValidateSplitSingleError[i]);
                if(strValidateSplitSingleError[i].trim().length > 0)
                {
                    console.log("strValidateSplitSingleError1[i]:"+strValidateSplitSingleError[i]);
                    
                    if((strValidateSplitSingleError[i].indexOf(";VW02") != -1 || strValidateSplitSingleError[i].indexOf("VW02") != "-1") && (obj_prochoice["al_sqs_details.product_name"]=="PRUwith you" || obj_prochoice["al_sqs_details.product_name"]=="PRUWealth Plus" || obj_prochoice["al_sqs_details.product_name"]=="PRUWealth Max" || obj_prochoice["al_sqs_details.product_name"]=="PRULink Cover" || obj_prochoice["al_sqs_details.product_name"]=="PRUmillion cover" || obj_prochoice["al_sqs_details.product_name"]== "PRUMillion Cover 2.0" || obj_prochoice["al_sqs_details.product_name"]== "PRUSignature Assure" || obj_prochoice["al_sqs_details.product_name"]=== "PRUSignature Vanguard" || obj_prochoice["al_sqs_details.product_name"]=== "PRUEnhanced Cover" || obj_prochoice["al_sqs_details.product_name"]=== "PRUWealth Enrich"))
                    {
                        console.log("strValidateSplitSingleError2[i]:"+strValidateSplitSingleError[i]+".");
                        arrWarningsCV=strValidateSplitSingleError[i]+".";
                        console.log("arrWarningsCV:"+arrWarningsCV);
                    }
                    else if(strValidateSplitSingleError[i].indexOf(";VW") != -1 || strValidateSplitSingleError[i].indexOf("VW") != "-1")
                    {
                        console.log("strValidateSplitSingleError2[i]:"+strValidateSplitSingleError[i]+".");
                        arrWarnings.push(strValidateSplitSingleError[i]+".");
                        console.log("arrWarnings:"+arrWarnings);
                    }
                    else
                    {
                        if(strValidateSplitSingleError[i] != ";")
                        {
                            arrAlerts.push(strValidateSplitSingleError[i]+".");
                            console.log("arrAlerts:"+arrAlerts);
                        }
                    }
                }
            }
            console.log("arrWarnings.length:"+arrWarnings.length);
            
            if(arrAlerts.length > 0)
            {
                for(var iCnt = 0 ; iCnt < arrAlerts.length; iCnt++)
                {
                    if(iCnt == 0 && arrAlerts[iCnt].length > 0)
                    {
                        strErrorMsg = arrAlerts[iCnt].substring(arrAlerts[iCnt].indexOf(':')+1);
                        
                    }
                    else if(arrAlerts[iCnt].length > 0)
                    {
                        strErrorMsg = strErrorMsg + "\n" + arrAlerts[iCnt].substring(arrAlerts[iCnt].indexOf(':')+1);  //changed strErrorMessage to strErrorMsg for defect 6042 by ankita on 17 August 2018
                        
                    }
                }
                
            isAlertFromVPMS="Yes";
                alert("751",strErrorMsg);
             }
            else if(arrWarnings.length > 0)
            {
               //console.log("Before strErrorMessage4:"+arrWarnings+"--Length:"+arrWarnings.length+"--includes:"+arrWarnings.contains(arrWarnings,'VW02'));
                strErrorMsg = arrWarnings[0].substring(arrWarnings[0].indexOf(':')+1)
                console.log("After strErrorMessage4:"+strErrorMsg);
                console.log("arrWarnings[0]:"+arrWarnings[0]);
               var strConsolidatedWarningMsg="";//added by ankita to display consolidated alert messages for warning messages for defect 8999
               //added by ankita on 4 Feb 2020 for defect 8999
               /*if(arrWarnings.length>1)
               {
                    var errorSplit=arrWarnings.split(";");
                    console.log("errorSplit:"+errorSplit);
                   for(var iCntSplit = 0 ; iCntSplit < errorSplit.length; iCntSplit++)
                   {
                       if(errorSplit[iCntSplit].indexOf('VW02')!= -1)
                       {
                       
                       }
                   }
               
               }*/
               for(var iCnt = 0 ; iCnt < arrWarnings.length; iCnt++)
               {
                  
                       //strErrorMsg = arrWarnings[iCnt].substring(arrWarnings[iCnt].indexOf(':')+1);
                        //below code namely VW02,VW01,VW07 are added for special case handling scenarios
                       if((arrWarnings[iCnt].indexOf('VW02')!= -1 || arrWarnings[iCnt].indexOf('VW02')!= "-1") && szNegativeCashValueFlag != "Yes")
                       {
                          strErrorMsg = arrWarnings[iCnt].substring(arrWarnings[iCnt].indexOf(':')+1);
                      fnValidateOfPrusaver(pagedata,strErrorMsg,obj_mlife_res,obj_prochoice,pagedata,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,firstCal,jsonLeftPanel,strValidate);
                           console.log("In showValidate "+benefit_flag_update+"---"+strSingleValidationError);
                                break;
                           
                       }
                       else if(arrWarnings[iCnt].indexOf('VW01')!= -1 || arrWarnings[iCnt].indexOf('VW01')!= "-1")
                       {
                            strErrorMsg = arrWarnings[iCnt].substring(arrWarnings[iCnt].indexOf(':')+1);
                           fnValidateInvestmentPremium(pagedata,strErrorMsg,obj_mlife_res,obj_prochoice,firstCal,jsonLeftPanel);
                            break;
                           
                       }
               
               
                     
               
                       else if(arrWarnings[iCnt].indexOf('VW07')!= -1 || arrWarnings[iCnt].indexOf('VW07')!= "-1")//added by ankita on 6 Dec 2018 for campaign bonus
                       {
                                strErrorMsg = arrWarnings[iCnt].substring(arrWarnings[iCnt].indexOf(':')+1);
                            fnCampaignBonusCheck(pagedata,strErrorMsg,obj_mlife_res,obj_prochoice,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel);
                                break;
                           
                       }
                       else if((arrWarnings[iCnt].indexOf('VW13')!= -1 || arrWarnings[iCnt].indexOf('VW13')!= "-1") && (obj_prochoice["al_sqs_details.product_name"]=="PRUSignature Reserve" || obj_prochoice["al_sqs_details.product_name"]==="PRUSignature Treasure"))//vm13
                       {
                           strErrorMsg = arrWarnings[iCnt].substring(arrWarnings[iCnt].indexOf(':')+1);
                           isSIOCampaignFlagReserve="Yes";
                           fnShowSIOWarningMsg(pagedata,strErrorMsg,obj_mlife_res,obj_prochoice,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel);
                           break;
                       }
                       else if((arrWarnings[iCnt].indexOf('VW')!= -1 || arrWarnings[iCnt].indexOf('VW')!= "-1") && szNegativeCashValueFlag != "Yes")
                        {
                                console.log("Before strConsolidatedWarningMsg:"+strConsolidatedWarningMsg+"--arrWarnings:"+arrWarnings[iCnt]);
               
                       
                               strConsolidatedWarningMsg = strConsolidatedWarningMsg + "<br />" + arrWarnings[iCnt].substring(arrWarnings[iCnt].indexOf(':')+1) + "<br />";  //changed strErrorMessage to strErrorMsg for defect 6042 by ankita on 17 August 2018
                                //strConsolidatedWarningMsg=strConsolidatedWarningMsg+strErrorMsg;
                                console.log("after strConsolidatedWarningMsg:"+strConsolidatedWarningMsg+"--arrWarnings:"+arrWarnings[iCnt]); //fnShowSIOWarningMsg(pagedata,strErrorMsg,obj_mlife_res,obj_prochoice,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel);
                            
                        }
                        else
                        {
                            return true;
                        }
               }
               //added by ankita on 4 Feb 2020 for defect 8999
               console.log("strConsolidatedWarningMsg2:"+strConsolidatedWarningMsg);
               if(strConsolidatedWarningMsg != "")
               {
                    fnShowSIOWarningMsg(pagedata,strConsolidatedWarningMsg,obj_mlife_res,obj_prochoice,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel,arrWarningsCV,firstCal);
               }
                
               /*if((arrWarnings[0].indexOf('VW02')!= -1 || arrWarnings[0].indexOf('VW02')!= "-1") && szNegativeCashValueFlag != "Yes")
                {
                    fnValidateOfPrusaver(pagedata,strErrorMsg,obj_mlife_res,obj_prochoice,pagedata,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,firstCal,jsonLeftPanel,strValidate);
                    console.log("In showValidate "+benefit_flag_update+"---"+strSingleValidationError);
                    
                }
                else if(arrWarnings[0].indexOf('VW01')!= -1 || arrWarnings[0].indexOf('VW01')!= "-1")
                {
                    fnValidateInvestmentPremium(pagedata,strErrorMsg,obj_mlife_res,obj_prochoice,firstCal,jsonLeftPanel);
                    
                }
                else if(arrWarnings[0].indexOf('VW07')!= -1 || arrWarnings[0].indexOf('VW07')!= "-1")//added by ankita on 6 Dec 2018 for campaign bonus
                {
                    fnCampaignBonusCheck(pagedata,strErrorMsg,obj_mlife_res,obj_prochoice,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel);
                    
                }
                else if((arrWarnings[0].indexOf('VW')!= -1 || arrWarnings[0].indexOf('VW')!= "-1") && szNegativeCashValueFlag != "Yes")
                {
                        console.log("strErrorMsg:"+strErrorMsg+"--arrWarnings:"+arrWarnings);
               
                       
                    fnShowSIOWarningMsg(pagedata,strErrorMsg,obj_mlife_res,obj_prochoice,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel);
                    
                }
                else
                {
                    return true;
                }*/
                
            }
            else if(arrWarnings.length == 0 && arrWarningsCV.length > 0)
            {
                fnShowSIOWarningMsg(pagedata,"",obj_mlife_res,obj_prochoice,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel,arrWarningsCV,firstCal);
            }
        
        
        console.log("flag1---"+benefit_flag_update);
            console.log("Reserve--->"+isSIOCampaignFlagReserve);
    }
    }
    else
    {
        return true;
    }
    //}
    
    

}
    

//Function to calladd Dependend Rider by parsing the rider.
function fnCallOutputFunction(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,bFirstCallFlag,currentplan)
{
    var currencyKey = "";
    var querySelect=fnGetCurrencyKey(obj_prochoice["al_sqs_details.product_name"])
    querySelect.execute(function (response)
    {
                        
    if(response != "{}" && response != "")
    {
                        var obj = JSON.parse(response);
                        console.log("Response:"+JSON.stringify(obj));
                        currencyKey=obj[0]['product_currency'];
                        console.log("currencyKey:"+currencyKey);
                        if(currencyKey == "RM")
                        {
                            currencyKey = "MYR";
                        }
                        pagedata["setvar"]["A_Currency_key"] = currencyKey;
    
   
    var iSelectedRiderCount = parseInt(pagedata["setvar"]["A_Nof_Riders_int"]);
    
    console.log("Paromita iSelectedRiderCount In fnCallOutputFunction -->"+iSelectedRiderCount);
    
    pagedata["VPMSFunctionNameInSequence"]=["P_Fetch_Rider_Details_out"];
    
    if(currentplan == "PRUGlobal Series")
    {
        //added by ankita on 3 July 2019 for funds code to pass to VPMS for selected currency
        pagedata["setvar"]["A_Currency_key"]=obj_prochoice["al_sqs_details.foreign_currency"];;
        var fundCode = "";
        var querySelectFund=fnGetCodeFromSelectedFunds(obj_prochoice);
        querySelectFund.execute(function (responseFund)
            {
            
            if(responseFund != "{}" && responseFund != "")
            {
                var objFund = JSON.parse(responseFund);
                console.log("ResponseFund:"+JSON.stringify(objFund));
                var iFundsCount = 0;
                for(sub in objFund)
                {
                    console.log("objFund:"+objFund[sub]+"for sub:"+sub+"id:"+objFund[sub]["db_column"]+"fund code:"+objFund[sub]["fund_code"]);
                    var fundIdArray=objFund[sub]["db_column"];
                    var fundCode=objFund[sub]["fund_code"];
                    var fundIds = "al_sqs_details."+fundIdArray;
                    var fundValue=obj_prochoice[fundIds];
                    
                    if(fundValue != "0")
                    {
                    
                    pagedata["setvar"]["A_ILP_Fund_value_rea["+iFundsCount+"]"]=fundValue;
                    pagedata["setvar"]["A_Master_ILP_Fund_key["+iFundsCount+"]"]=fundCode;
                    
                    iFundsCount++;
                    }
                }
                                pagedata["setvar"]["A_Nof_fund_int"] = iFundsCount.toString();
            }
            
            console.log("After fund code:"+JSON.stringify(pagedata));
            js_call_native_func("VPMSCall",pagedata,function(responseRider)
                                {
                                    var jsonResponseRider = JSON.parse(responseRider);
                                    pagedata = fnAddDependentRider(pagedata,jsonResponseRider[pagedata["VPMSFunctionNameInSequence"]]); //Function to add Dependend Rider
                                
                                
                                    fnCallValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,iSelectedRiderCount,bFirstCallFlag,"");//added parameter obj_solution on 9 April 2019
                                
                                
                                
                                });
            });

    }
    else
    {
                        console.log("After dependent:"+JSON.stringify(pagedata));
    js_call_native_func("VPMSCall",pagedata,function(responseRider)
    {
        var jsonResponseRider = JSON.parse(responseRider);
        pagedata = fnAddDependentRider(pagedata,jsonResponseRider[pagedata["VPMSFunctionNameInSequence"]]); //Function to add Dependend Rider
                        
        if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL07")
        {
                        console.log("@@@uiaFundSelectionFlag"+uiaFundSelectionFlag);
            if(((document.getElementById("al_sqs_details.payout_option1_prusmart_gain.id").checked && document.getElementById("al_rider_sqs.prusaver.id").checked==false) ||(document.getElementById("al_sqs_details.payout_option3_prusmart_gain.id").checked && document.getElementById("al_rider_sqs.prusaver.id").checked==false)) && vpmsuiaFundSelectionFlag)//ADDED 'uiaFundSelectionFlag' for New CR of income by Sachin T.on Date 3-10-2018.
            {
                var alertMessageToValidate = "Fund selection is invalid because:<br />1. No PRUSaver and/or <br /> 2. GCP option 2 is not selected";
                console.log("alertMessageToValidate:"+alertMessageToValidate);
                bootbox.alert(alertMessageToValidate, function()
                              {
                              benefit_flag_update ="0";
                              console.log("benefit_flag_update--"+benefit_flag_update);
                              canSwipe=1;
                              
                              fnCallValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,iSelectedRiderCount,bFirstCallFlag,"");
                              });
            }
            else
            {
                fnCallValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,iSelectedRiderCount,bFirstCallFlag,"");
            }
        }
        else if(currentplan === "PRUSignature Ace")
        {
            fnCallValidationForAce(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,iSelectedRiderCount,bFirstCallFlag,"");
        }
//        else if(currentplan === "PRUSignature Assure" || currentplan === "PRULink Cover" || currentplan === "PRUwith you") //Pradnya: added for may24 release for validation 9
//
//        {
//            if(document.getElementById("al_rider_sqs.prumillion_med_2_0.id").checked && document.getElementById("al_rider_sqs.prumillion_med_active.id").checked==false)
//                {
//        bootbox.confirm({
//
//                        message: "You can save up to 15% of PRUMillion Med Active Insurance Charges for staying healthy.Do you want to proceed with PRUMillion Med Active?",
//                        className: 'my-popup',
//                        buttons: {
//                        cancel: {
//                        label: '<i class="fa fa-check"></i>Proceed with PRUMillion Med Active',
//                        className: 'btn-default'
//
//                        },
//                        confirm: {
//                        label: '<i class="fa fa-times"></i>Maintain my selection',
//                        className: 'btn-default'
//                        }
//                        },
//                        callback: function (result)
//                        {
//
//                        canSwipe=0;
//                        benefit_flag_update ="1";
//                        if(result==true)
//                        {
//                        console.log("result=="+result);
//                        canSwipe=1;
//
//
//                            planvalue = document.getElementById("al_rider_sqs.prumillion_med_2_0.rider_value").value;
//                            if(document.getElementById("al_rider_sqs.prumillion_med_2_0.rider_option_coinsurence").checked)
//                           {
//                               document.getElementById("al_rider_sqs.prumillion_med_2_0.rider_option_coinsurence").checked= true
//                                pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] = "Coinsurance";
//                           }
//                           else if(document.getElementById("al_rider_sqs.prumillion_med_2_0.rider_option_deductible").checked)
//                           {
//                               document.getElementById("al_rider_sqs.prumillion_med_2_0.rider_option_deductible").checked= true
//                                 pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] = document.getElementById("al_rider_sqs.prumillion_med_2_0.rider_option_deductible_300").value;
//                           }
//
//                        }
//                        else
//                        {
//                        document.getElementById("al_rider_sqs.prumillion_med_2_0.id").checked= false
//                        document.getElementById("al_rider_sqs.prumillion_med_active.id").checked= true
//                            planvalue = document.getElementById("al_rider_sqs.prumillion_med_2_0.rider_value").value;
//                            //pagedata["setvar"]["A_Master_Rider_Plan_key["+iRiderCount+"]"] = planvalue;
//                            if(document.getElementById("al_rider_sqs.prumillion_med_2_0.rider_option_coinsurence").checked)
//                           {
//                               document.getElementById("al_rider_sqs.prumillion_med_active.rider_option_coinsurence").checked= true
//                                pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] = "Coinsurance";
//                           }
//                           else if(document.getElementById("al_rider_sqs.prumillion_med_2_0.rider_option_deductible").checked)
//                           {
//                               document.getElementById("al_rider_sqs.prumillion_med_active.rider_option_deductible").checked= true
//                                 pagedata["setvar"]["A_Code_Rider_Deduct_key["+iRiderCount+"]"] = document.getElementById("al_rider_sqs.prumillion_med_2_0.rider_option_deductible_300").value;
//                           }
//                        canSwipe=1;
//
//                        }
//                        }})
//        }
//     }
        else
        {
            fnCallValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,iSelectedRiderCount,bFirstCallFlag,"");//added parameter obj_solution on 9 April 2019
        }
        
        
    });
                        }
                        }
                        });
}

function fnCallValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,iSelectedRiderCount,bFirstCallFlag,jsonLeftPanel)
{
    
    console.log("Paromita iSelectedRiderCount In fnCallValidation -->"+iSelectedRiderCount);
    
    var checkFirstCal = document.getElementById("al_sqs_details.min_insurance_premium").value;
    console.log("checkFirstCal fnCallValidation--"+checkFirstCal);
    console.log("bFirstCallFlag--"+bFirstCallFlag);
   /* if((obj_slife["al_person_details.slife.relationship"]!="Father" && obj_slife["al_person_details.slife.relationship"]!="Mother" && obj_slife["al_person_details.slife.relationship"]!="Friend" && obj_slife["al_person_details.slife.relationship"]!="Spouse" && obj_slife["al_person_details.slife.relationship"]!="Parent" && obj_slife["al_person_details.slife.relationship"]!="Legal Guardian"))
               {
    fnMSChangeVPMSInput(pagedata); // Added by Shivani for Modern Family CR for MAy2022 Release
               }*/
    
    // Sourabh when UI fields are dissable on first calculate

    if((pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS2" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL03" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL08" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS3" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL14" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL16" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL24") && bFirstCallFlag == false && szOkToAmendCVFlag == "No")
    {
        console.log("In Prevalidate");
        bFirstCallFlag = true;
        pagedata["VPMSFunctionNameInSequence"] = ["P_Validate_Pre_Benefit_out"];
    }
    else
    {
        console.log("In validate");
        bFirstCallFlag = false;
        pagedata["VPMSFunctionNameInSequence"] = ["P_Validate_Benefit_out"];
    }
    
    
    console.log("pageData:"+JSON.stringify(pagedata));
               
    // 0404 april 2019 by pass calculate validastion error message
               //added by ankita on 11 may 2020 to bypass validation call
    
    


//    if(obj_prochoice["al_sqs_details.product_name"]=="PRUEnhanced Cover")
//      {
//        fnCallOutputAfterValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,iSelectedRiderCount,bFirstCallFlag);
//      }
    //else
     // {



 
    js_call_native_func("VPMSCall",pagedata,function(szValidationError)
                    {
                            console.log("szValidationError:"+szValidationError);
                            szValidationError=szValidationError.replace(/\\r\\n/g, "<br />");//added for defect 7381 on 11 may 2019
                            console.log("szValidationError123:"+szValidationError);
                            szValidationError=szValidationError.replace(/\\n/g, "<br />");//Commented for Standardize eeror message for defect 5158 by ankita on 14 May 2018
                            console.log("szValidationError124:"+szValidationError);
                            var jsonszValidationError = JSON.parse(szValidationError)

                        if(fnShowValidationError(jsonszValidationError[pagedata["VPMSFunctionNameInSequence"]],obj_mlife_res,obj_prochoice,pagedata,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel))
                            {
                        console.log("pagedata callfrom:"+callfrom);

                                if(bFirstCallFlag == true)
                                {
                        
                                   if(callfrom == "bundle_product")
                                   {
                                   fnCallOutputAfterBundleValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,iSelectedRiderCount,bFirstCallFlag);
                                   }
                                    else if(obj_prochoice["al_sqs_details.product_name"]!="PRUSignature Booster" && callFromOther!="bundle_product")
                                    {
                                        console.log("Called main function after validation");
                                        fnCallOutputAfterValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,iSelectedRiderCount,bFirstCallFlag);
                                    }
                                    else if(obj_prochoice["al_sqs_details.product_name"]=="PRUSignature Booster" && callFromOther=="bundle_product")
                                    {
                                        fnCallOutputAfterBundleValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,iSelectedRiderCount,bFirstCallFlag);
                                    }
                                    
                                }
                                else
                                {
                                    pagedata["VPMSFunctionNameInSequence"] = ["P_Validate_Post_Benefit_out"];
                                    js_call_native_func("VPMSCall",pagedata,function(szValidationError)
                                                        {
                                                            console.log("P_Validate_Post_Benefit_out szValidationError:"+szValidationError);
                                                            szValidationError=szValidationError.replace(/\\r\\n/g, "<br />");//added for defect 7381 on 11 may 2019
                                                            console.log("P_Validate_Post_Benefit_out szValidationError123:"+szValidationError);
                                                            szValidationError=szValidationError.replace(/\\n/g, "<br />");//Commented for Standardize eeror message for defect 5158 by ankita on 14 May 2018
                                                            console.log("P_Validate_Post_Benefit_out szValidationError124:"+szValidationError);
                                                            var jsonszValidationError = JSON.parse(szValidationError)

                                                        if(fnShowValidationError(jsonszValidationError[pagedata["VPMSFunctionNameInSequence"]],obj_mlife_res,obj_prochoice,pagedata,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel))
                                                            {

//callFromOther="bundle_product";
                                                                if(callfrom==="bundle_product")
                                                                        {
                                                                fnCallOutputAfterBundleValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,iSelectedRiderCount,bFirstCallFlag);
                                                                
                                                                        
                                                                        }else if(obj_prochoice["al_sqs_details.product_name"]!="PRUSignature Booster" && callFromOther!="bundle_product")
                                                                {
                                                                    console.log("Called main function after validation");
                                                                    fnCallOutputAfterValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,iSelectedRiderCount,bFirstCallFlag);
                                                                }
                                                                else if(obj_prochoice["al_sqs_details.product_name"]=="PRUSignature Booster" && callFromOther=="bundle_product")
                                                                {
                                                                    fnCallOutputAfterBundleValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,iSelectedRiderCount,bFirstCallFlag);
                                                                }
                                                                
                                                            }
                                                        });
                                }
                            }
                    });
            
      //}
     
    }
    





//Function to call all output function after validation


function fnCallOutputAfterValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,iSelectedRiderCount,bFirstCallFlag)
{
    var jsonAllOutput = {};
    var PRUallocatorPremiumValue = "0";
    var PreviousCallAllocatorValue = "0";
    var checkFirstCal = document.getElementById("al_sqs_details.min_insurance_premium").value;
     console.log("checkFirstCal fnCallOutputAfterValidation--"+checkFirstCal);
    console.log("Paromita iSelectedRiderCount In fnCallOutputAfterValidation -->"+iSelectedRiderCount);
    console.log("decided function")
    console.log("flag value"+benefit_flag_update);
    benefit_flag_noupdate ="0";
    benefit_flag_update="0";
    product_flag_update="0";
    mlife_flag_update="0";
    slife_flag_update="0";
    tlife_flag_update="0";
    
    loading_flag_update = 0;
    loading_flag_noupdate = 0;
    console.log("flag2---"+benefit_flag_update);
    callfromfromBundleOutput=false;
    console.log("NO ERROR");
    //console.log("strValidate"+strValidate);
               //added by ankita for defect 527 changes by fatin for PRUSignature Ace product
              if(pagedata["setvar"]["A_Master_Product_Master_Key"] === "SP11")
               {
               pagedata["changeInSetVar"]={"P_Calculate_Prem_Sustain_out":{"A_Budget_Exc_Premium_rea":"0"}};
               }
    
    pagedata["VPMSFunctionNameInSequence"] = ["P_Calculate_Prem_Sustain_out"];
    console.log("pageData:"+JSON.stringify(pagedata));
    
    
    js_call_native_func("VPMSCall",pagedata,function(resP_Calculate_Prem_Sustain_out)
                        {
                        
                        js_get_var("VPMSRiderJson",function(VPMSRiderJson)
                                   {
                                   var objVPMSRiderJson = JSON.parse(VPMSRiderJson);
                                   console.log("objVPMSRiderJson:"+JSON.stringify(objVPMSRiderJson));
                        console.log("resP_Calculate_Prem_Sustain_out-->" +resP_Calculate_Prem_Sustain_out);
                        
                        var jsonresP_Calculate_Prem_Sustain_out = JSON.parse(resP_Calculate_Prem_Sustain_out);
                        var objresP_Calculate_Prem_Sustain_out = jsonresP_Calculate_Prem_Sustain_out[pagedata["VPMSFunctionNameInSequence"]];
//added condition of SP11 by ankita on 29 sept 2022 for PRUSIgnature Ace product
                        if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL03" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS2" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL08" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS3" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL14" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL16" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "SP11" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL24")
                        {
                        
                            console.log("objresP_Calculate_Prem_Sustain_out"+JSON.stringify(objresP_Calculate_Prem_Sustain_out));
                            var objSplitP_Calculate_Prem_Sustain_out = objresP_Calculate_Prem_Sustain_out["result"].split(";")
                            console.log("objSplitP_Calculate_Prem_Sustain_out"+objSplitP_Calculate_Prem_Sustain_out);
                            var indexMinimumPremium = objSplitP_Calculate_Prem_Sustain_out.indexOf("MinInsPrem");
                            if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25")
                            {
                                indexMinimumPremium = objSplitP_Calculate_Prem_Sustain_out.indexOf("MinBUAPrem")
                            }
                            console.log("indexMinimumPremium"+indexMinimumPremium);
                            
                            
                            console.log("objSplitP_Calculate_Prem_Sustain_out[parseInt(indexMinimumPremium)+1]"+objSplitP_Calculate_Prem_Sustain_out[parseInt(indexMinimumPremium)+1]);
                            
                            console.log("[parseInt(indexMinimumPremium)+1]"+[parseInt(indexMinimumPremium)+1]);
                            
                            console.log("[parseInt(indexMinimumPremium)]"+[parseInt(indexMinimumPremium)]);
                            
                            console.log("objSplitP_Calculate_Prem_Sustain_out[parseInt(indexMinimumPremium)+1]"+objSplitP_Calculate_Prem_Sustain_out[parseInt(indexMinimumPremium)+1]);
                            if((pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS2" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL08" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL03" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS3" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL14" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL16" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL24") && ((checkFirstCal == null || checkFirstCal == "" || checkFirstCal == "NA" || checkFirstCal == "undefined" || checkFirstCal== "0")))
                            {
                                   //added by ankita for prumy first policy solution button on 9 august 2022
                                pagedata["setvar"]["A_Budget_Premium_rea"] = objSplitP_Calculate_Prem_Sustain_out[parseInt(indexMinimumPremium)+1];
                                   //pagedata["setvar"]["A_Budget_Premium_rea"] =document.getElementById("al_sqs_details.insurance_premium").value;
                            }
                               //Def -1122 by Paromita on 29th Aug
                            if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25")// && !((checkFirstCal == null || checkFirstCal == "" || checkFirstCal == "NA" || checkFirstCal == "undefined" || checkFirstCal== "0"))) //Def1190 by Paromita on Sept 5th 2023
                            {
                                console.log("PN...objSplitP_Calculate_Prem_Sustain_out",objSplitP_Calculate_Prem_Sustain_out)
                                var PRUallocatorPremium = 0;
                                if(objSplitP_Calculate_Prem_Sustain_out.indexOf("MaxInsPrem") != -1)
                                {
                                    
                                    if(objSplitP_Calculate_Prem_Sustain_out.indexOf("AL15") != -1)
                                    {
                                        PRUallocatorPremium = objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("AL15"))+1]
                                    }
                                    PRUallocatorPremium = Math.max(parseFloat(PRUallocatorPremium),(parseFloat(document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").value)- parseFloat(objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("MaxInsPrem"))+1])));
                                    pagedata["setvar"]["A_Budget_Exc_Premium_rea"] = PRUallocatorPremium.toString();
                                }
                                else
                                {
                                    pagedata["setvar"]["A_Budget_Exc_Premium_rea"] = "0";
                                }
                                console.log("PN... PRUallocatorPremium"+PRUallocatorPremium)
                                if(PRUallocatorPremium >0 )
                                {
                                    szPRUallocatorPremiumAvailable  = "Yes";
                                    document.getElementById("al_sqs_details.pruallocator_premium").value = parseFloat(PRUallocatorPremium).toFixed(2);
                                    document.getElementById("al_rider_sqs.pruallocator.rider_premium").value = parseFloat(PRUallocatorPremium).toFixed(2);
                                    document.getElementById("al_rider_sqs.pruallocator.rider_term").value = (document.getElementById("al_sqs_details.premium_payment_period_pw_plus").value).split("_")[0];
                                }
                                else //Def1189 by Paromita on Sept 6th 2023 clearing value of PRUallocator
                                {
                                    szPRUallocatorPremiumAvailable = "No";
                                    document.getElementById("al_sqs_details.pruallocator_premium").value = parseFloat(PRUallocatorPremium).toFixed(2);
                                }
                                
                                if(objSplitP_Calculate_Prem_Sustain_out.indexOf("MaxInsPrem") != -1 && objSplitP_Calculate_Prem_Sustain_out.indexOf("InsPrem") != -1)
                                {
                                    //Def1190 by Paromita on Sept 5th 2023 
                                    var szBudgetPremium = 0;
                                    if(((checkFirstCal == null || checkFirstCal == "" || checkFirstCal == "NA" || checkFirstCal == "undefined" || checkFirstCal== "0")))
                                    {
                                        szBudgetPremium = objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("MinBUAPrem"))+1];
                                    }
                                    else
                                    {
                                        szBudgetPremium = document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").value
                                    }
                                    console.log("PN... szBudgetPremium"+szBudgetPremium);
                                    pagedata["setvar"]["A_Budget_Premium_rea"] =  Math.min(szBudgetPremium,objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("MaxInsPrem"))+1]).toString();
                                }
                                else
                                {
                                    pagedata["setvar"]["A_Budget_Premium_rea"] = "0";
                                }
                                
                            }
                            
                            
                            
                            
                            
                            
                            //added by ankita for Benbill defect CR changes on 4 sept 2020 for 2 parent payor basic and saver changes
                            console.log("Before pagedata Ankita:"+JSON.stringify(pagedata));
                                   //for PRUWith You and PRULink Cover product
                                   //Note: for any riders if 2 parent payor basic and saver riders are present then need to add condition in below if loop and similarly code of both riders to pass SA to respective hidden riders
                            if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS2" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL08" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL16")
                            {
                                var pagedataKeyArray= Object.keys(pagedata["setvar"]);
                                for(var iCount =0;iCount < pagedataKeyArray.length; iCount++)
                                {
                                    console.log("pagedataKeyArray[iCount]---"+pagedataKeyArray[iCount]);
                                   //VS10:2 parent payor basic code,VS11:2 parent payor basic hidden rider code,VS15:2 parent payor saver code,VS16:2 parent payor saver hidden rider code for PRUWith You product
                                   //VI28:2 parent payor basic code,VI29:2 parent payor basic hidden rider code,VI33:2 parent payor saver code,VI33:2 parent payor saver hidden rider code for PRULink Cover product
                                   
                                    if(pagedata["setvar"][pagedataKeyArray[iCount]] == "VS10" || pagedata["setvar"][pagedataKeyArray[iCount]] == "VS11" || pagedata["setvar"][pagedataKeyArray[iCount]] == "VS15" || pagedata["setvar"][pagedataKeyArray[iCount]] == "VS16" || pagedata["setvar"][pagedataKeyArray[iCount]] == "VI28" || pagedata["setvar"][pagedataKeyArray[iCount]] == "VI29" || pagedata["setvar"][pagedataKeyArray[iCount]] == "VI33" || pagedata["setvar"][pagedataKeyArray[iCount]] == "VI34")
                                    {
                                        var RiderValueKey = pagedataKeyArray[iCount].replace("A_Master_Rider_key","A_Rider_Sum_Assured_rea");
                                        console.log("RiderValueKey:"+RiderValueKey);
                                        console.log("budgeted premium:"+pagedata["setvar"]["A_Budget_Premium_rea"]);
                                       if(pagedata["setvar"][pagedataKeyArray[iCount]] == "VS10" || pagedata["setvar"][pagedataKeyArray[iCount]] == "VS11" || pagedata["setvar"][pagedataKeyArray[iCount]] == "VI28" || pagedata["setvar"][pagedataKeyArray[iCount]] == "VI29")
                                       {
                                          pagedata["setvar"][RiderValueKey] = pagedata["setvar"]["A_Budget_Premium_rea"];
                                       }
                                       if((pagedata["setvar"][pagedataKeyArray[iCount]] == "VS15" || pagedata["setvar"][pagedataKeyArray[iCount]] == "VS16" || pagedata["setvar"][pagedataKeyArray[iCount]] == "VI33" || pagedata["setvar"][pagedataKeyArray[iCount]] == "VI34") && (document.getElementById("al_rider_sqs.prusaver.id").checked))
                                       {
                                         pagedata["setvar"][RiderValueKey] = document.getElementById("al_rider_sqs.prusaver.rider_premium").value;
                                       }
                                       if((pagedata["setvar"][pagedataKeyArray[iCount]] == "VS15" || pagedata["setvar"][pagedataKeyArray[iCount]] == "VS16" || pagedata["setvar"][pagedataKeyArray[iCount]] == "VI33" || pagedata["setvar"][pagedataKeyArray[iCount]] == "VI34") && (document.getElementById("al_rider_sqs.prusaver_kid.id").checked))
                                       {
                                         pagedata["setvar"][RiderValueKey] = document.getElementById("al_rider_sqs.prusaver_kid.rider_premium").value;
                                       }
                                    }
                                }
                            }
                            console.log("After pagedata Ankita:"+JSON.stringify(pagedata));
                            //end here
                                //added condition of SP11 by ankita on 29 sept 2022 for PRUSIgnature Ace product
                            if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS3" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL11" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL14" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "SP11" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL24")
                            {
                                //pagedata["setvar"]["A_Budget_Premium_rea"] = objSplitP_Calculate_Prem_Sustain_out[parseInt(indexMinimumPremium)+1];
                        
                                var indexPRUallocatorPremium = objSplitP_Calculate_Prem_Sustain_out.indexOf("AL05");
                                if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS3")
                                   {
                                        indexPRUallocatorPremium = objSplitP_Calculate_Prem_Sustain_out.indexOf("ALS1");
                                   }
                                   if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25")
                                   {
                                        indexPRUallocatorPremium = objSplitP_Calculate_Prem_Sustain_out.indexOf("AL15");
                                   }
                                   if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL14")//added by ankita on 4 dec 2020
                                   {
                                        indexPRUallocatorPremium = objSplitP_Calculate_Prem_Sustain_out.indexOf("AL10");
                                   }
                                 if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL24")//added by ankita on 4 dec 2020
                                   {
                                     indexPRUallocatorPremium = objSplitP_Calculate_Prem_Sustain_out.indexOf("AL16");
                                   }
                                   if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12") //Added by Paromita for PRUwealth Max
                                   {
                                        indexPRUallocatorPremium = objSplitP_Calculate_Prem_Sustain_out.indexOf("AL07");
                                   }
                                   if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20") //Added by Paromita for PRUwealth Max
                                     {
                                          indexPRUallocatorPremium = objSplitP_Calculate_Prem_Sustain_out.indexOf("AL13");
                                     }
                                   if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "SP11") //Added by ankita for PRUSignature Ace product
                                   {
                                        indexPRUallocatorPremium = objSplitP_Calculate_Prem_Sustain_out.indexOf("AL14");
                                   }
                                   console.log("Before PreviousCallAllocatorValue:"+PreviousCallAllocatorValue);
                                PreviousCallAllocatorValue = pagedata["setvar"]["A_Budget_Exc_Premium_rea"];
                                   console.log("After PreviousCallAllocatorValue:"+PreviousCallAllocatorValue+" indexPRUallocatorPremium:"+indexPRUallocatorPremium);
                                    console.log("1.. pagedata[setvar][A_Rider_Sum_Assured_rea[0]"+ pagedata["setvar"]["A_Rider_Sum_Assured_rea[0]"]);
                                   
                                   console.log("PRUallocatorPremiumValue1::"+PRUallocatorPremiumValue);
                                if(indexPRUallocatorPremium != -1)
                                {
                                console.log("PRUallocatorPremiumValue2::"+PRUallocatorPremiumValue);
                                   /*if(szPRUallocatorPremiumAvailable == "No") //Paromita Def 7571 Def 7574
                                   {
                                   
                                       PRUallocatorPremiumValue = objSplitP_Calculate_Prem_Sustain_out[parseInt(indexPRUallocatorPremium)+1];
                                   }
                                   else
                                   {
                                        PRUallocatorPremiumValue = document.getElementById("al_rider_sqs.pruallocator.rider_premium").value;
                                   }*/
                                
                                   //added by ankita for 8857 defect
                                   if(szOkToAmendCVFlag == "Yes" && (pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS3" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL14" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL24")) //Paromita Def 7571 Def 7574
                                   {
                                   console.log("PRUallocatorPremiumValue3::"+PRUallocatorPremiumValue+"--szOldAllocatorValueIfNA:"+szOldAllocatorValueIfNA);
                                   
                                       PRUallocatorPremiumValue = szOldAllocatorValueIfNA.toString();
                                   }
                                   else
                                   {
                                   console.log("PRUallocatorPremiumValue4::"+PRUallocatorPremiumValue);
                                        if(szPRUallocatorPremiumAvailable == "No") //Paromita Def 7571 Def 7574
                                        {console.log("PRUallocatorPremiumValue5::"+PRUallocatorPremiumValue);
                                        
                                            PRUallocatorPremiumValue = objSplitP_Calculate_Prem_Sustain_out[parseInt(indexPRUallocatorPremium)+1];
                                        }
                                        else
                                        {
                                            console.log("PRUallocatorPremiumValue6::"+PRUallocatorPremiumValue);
                                             PRUallocatorPremiumValue = document.getElementById("al_rider_sqs.pruallocator.rider_premium").value;
                                        }
                                   }
                                console.log("PRUallocatorPremiumValue7::"+PRUallocatorPremiumValue);
                                   if(targetMaximumPremium == "No")
                                   {
                                        pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iRiderCountPruAllocator+"]"] = PRUallocatorPremiumValue;
                                        pagedata["setvar"]["A_Budget_Exc_Premium_rea"] = PRUallocatorPremiumValue;
                                   }
                                   else
                                   {
                                        PRUallocatorPremiumValue = pagedata["setvar"]["A_Budget_Exc_Premium_rea"];
                                   }
                                   console.log("PRUallocatorPremiumValue8::"+PRUallocatorPremiumValue);
                                }
                                else
                                {
                                   
                                   /*if(szPRUallocatorPremiumAvailable == "No") //For Def 7482 //Paromita Def 7571 Def 7574
                                   {
                                        PRUallocatorPremiumValue = "0";
                                   
                                   }
                                   else
                                   {
                                        PRUallocatorPremiumValue = document.getElementById("al_rider_sqs.pruallocator.rider_premium").value;
                                   }*/
                                   console.log("padedata before::"+JSON.stringify(pagedata));
                                   //added by ankita for 8857 defect
                                   if(szOkToAmendCVFlag == "Yes" && (pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS3" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL14" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL24")) //Paromita Def 7571 Def 7574
                                   {
                                      console.log("PRUallocatorPremiumValue in Yes::"+PRUallocatorPremiumValue);
                                       PRUallocatorPremiumValue = document.getElementById("al_rider_sqs.pruallocator.rider_premium").value;
                                      console.log("PRUallocatorPremiumValue in Yes1::"+PRUallocatorPremiumValue)
                                   }
                                   else
                                   {
                                        if(szPRUallocatorPremiumAvailable == "No") //Paromita Def 7571 Def 7574
                                        {
                                        
                                            PRUallocatorPremiumValue = "0";
                                        }
                                        else
                                        {
                                             PRUallocatorPremiumValue = document.getElementById("al_rider_sqs.pruallocator.rider_premium").value;
                                        }
                                   }
                                   console.log("PRUallocatorPremiumValue before setting::"+PRUallocatorPremiumValue);
                                   //added by ankita for defect 9103
                                   if(PRUallocatorPremiumValue == "")
                                   {
                                     PRUallocatorPremiumValue = "0";
                                   }
                                   console.log("PRUallocatorPremiumValue after setting::"+PRUallocatorPremiumValue);
                                   pagedata["setvar"]["A_Rider_Sum_Assured_rea["+iRiderCountPruAllocator+"]"] = PRUallocatorPremiumValue;
                                   pagedata["setvar"]["A_Budget_Exc_Premium_rea"] = PRUallocatorPremiumValue;
                                   console.log("PRUallocatorPremiumValue9::"+PRUallocatorPremiumValue);
                                   console.log("padedata after1::"+JSON.stringify(pagedata));
                                }
                                   console.log("PRUallocatorPremiumValue10::"+PRUallocatorPremiumValue);
                                
                        
                            }
                        }
                        console.log("PRUallocatorPremiumValue11::"+PRUallocatorPremiumValue);
                                   console.log("padedata after2::"+JSON.stringify(pagedata));
                        if((pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS2" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS3" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL08" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL14" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL16" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL24") && targetSustainabilityFlag =="Yes")
                        {
                            var MaximumPremium = "";
                            if(objSplitP_Calculate_Prem_Sustain_out.indexOf("MaxInsPrem") != -1)
                            {
                                MaximumPremium = objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("MaxInsPrem"))+1];
                            }
                            else
                            {
                                MaximumPremium = "0";
                            }
                                   console.log("Def 7574: pagedata[\"setvar\"][\"A_Budget_Premium_rea\"]----"+pagedata["setvar"]["A_Budget_Premium_rea"]+" MaximumPremium---"+MaximumPremium)
                                   
                                   var total_BUA_Premium = parseFloat(pagedata["setvar"]["A_Budget_Premium_rea"])+ parseFloat(PreviousCallAllocatorValue); // Changed according to the CR.
                            if(parseFloat(total_BUA_Premium) > parseFloat(MaximumPremium))
                            {
                                targetMaximumPremium = "Yes";
                                
                                szPRUsaverValue = parseFloat(total_BUA_Premium) - parseFloat(MaximumPremium);
                        
                                pagedata["setvar"]["A_Budget_Premium_rea"] = MaximumPremium;
                                var pagedataKeyArray= Object.keys(pagedata["setvar"]);
                                for(var iCount =0;iCount < pagedataKeyArray.length; iCount++)
                                {
                                   console.log("pagedataKeyArray[iCount]---"+pagedataKeyArray[iCount])
                                   console.log("pagedata[\"setvar\"][pagedataKeyArray[iCount]]---"+pagedata["setvar"][pagedataKeyArray[iCount]]);
                                    if(((pagedata["setvar"][pagedataKeyArray[iCount]] == "STS3" || pagedata["setvar"][pagedataKeyArray[iCount]] == "STS5" || pagedata["setvar"][pagedataKeyArray[iCount]]== "ST15" || pagedata["setvar"][pagedataKeyArray[iCount]]== "ST17") && pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS2") || (pagedata["setvar"][pagedataKeyArray[iCount]] == "AL05"  && pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10") || (pagedata["setvar"][pagedataKeyArray[iCount]] == "ALS1"  && pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS3") || (pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL14" && pagedata["setvar"][pagedataKeyArray[iCount]] == "AL10")  || (pagedata["setvar"][pagedataKeyArray[iCount]] == "AL07"  && pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12") || (pagedata["setvar"][pagedataKeyArray[iCount]] == "ST12"  && pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL08") || (pagedata["setvar"][pagedataKeyArray[iCount]] == "ST28"  && pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL16") || (pagedata["setvar"][pagedataKeyArray[iCount]] == "AL13"  && pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20")||(pagedata["setvar"][pagedataKeyArray[iCount]] == "AL15" && pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25") || (pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL24" && pagedata["setvar"][pagedataKeyArray[iCount]] == "AL16")) //Changed by Paromita on 7th June 2020 for Def9486//IL08 condition added by ankita for internal issue reported by rakesh sir in target sustainability scenario on 13 june 2022
                                    {
                                        var RiderValueKey = pagedataKeyArray[iCount].replace("A_Master_Rider_key","A_Rider_Sum_Assured_rea")
                                        pagedata["setvar"][RiderValueKey] =  (parseFloat(pagedata["setvar"][RiderValueKey]) +  parseFloat(szPRUsaverValue)).toString();
                                   console.log("Def 7574: pagedata[\"setvar\"][RiderValueKey]---"+pagedata["setvar"][RiderValueKey]);
                                       
                                   
                                  
                                        if((pagedata["setvar"][pagedataKeyArray[iCount]] == "AL05"  && pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10") ||(pagedata["setvar"][pagedataKeyArray[iCount]] == "AL07"  && pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" ) || (pagedata["setvar"][pagedataKeyArray[iCount]] == "ALS1"  && pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS3") || (pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL14" && pagedata["setvar"][pagedataKeyArray[iCount]] == "AL10") || (pagedata["setvar"][pagedataKeyArray[iCount]] == "AL13"  && pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20")||(pagedata["setvar"][pagedataKeyArray[iCount]] == "AL15" && pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25") || (pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL24" && pagedata["setvar"][pagedataKeyArray[iCount]] == "AL16")) //Changed by Paromita on 7th June 2020 for Def9486//AL10 added by ankita on 4 dec 2020
                                        {
                                           pagedata["setvar"][RiderValueKey] =  (parseFloat(szPRUsaverValue)).toString();
                                           console.log("Def 7574: pagedata[\"setvar\"][RiderValueKey]---"+pagedata["setvar"][RiderValueKey]);
                                   
                                           szPRUsaverValue = pagedata["setvar"][RiderValueKey];
                                   
                                            console.log("Def 7574 1...: szPRUsaverValue---"+szPRUsaverValue);
                                          pagedata["setvar"]["A_Budget_Exc_Premium_rea"] = szPRUsaverValue;
                                   //added by ankita for defect 10395 on 21 dec 2020
                                   PRUallocatorPremiumValue=szPRUsaverValue;
                                   
                                        }
                                        szPRUsaverValue = pagedata["setvar"][RiderValueKey];
                                   console.log("Def 7574 2....: szPRUsaverValue---"+szPRUsaverValue);
                                        szPRUsaverExists = "Yes";
                                        break;
                                    }
                                  }
                                   
                                console.log("Def 7574: pagedata---"+JSON.stringify(pagedata))
                                  console.log("objresP_Calculate_Prem_Sustain_out---"+JSON.stringify(objresP_Calculate_Prem_Sustain_out))
                                   if(szPRUsaverExists == "No")
                                   {
                                       var nofRiderCount =  pagedata["setvar"]["A_Nof_Riders_int"];
                                       var idtemp = "";
                                       if(obj_prochoice["al_sqs_details.mlife.il_anb"] <= 18)
                                       {
                                       idtemp = "al_rider_sqs.prusaver_kid";
                                       }
                                       else
                                       {
                                       idtemp = "al_rider_sqs.prusaver"
                                       }
                                       pagedata["setvar"]["A_Master_Rider_key["+nofRiderCount+"]"] = objVPMSRiderJson["rider_row_"+idtemp.replace(/\.$/, '')];
                                       pagedata["setvar"]["A_Rider_Sum_Assured_rea["+nofRiderCount+"]"] = parseFloat(szPRUsaverValue).toString();
                                   //added by ankita on 20 april for medical reprising CR
                                   if(obj_prochoice["al_sqs_details.product_name"]== "PRUwith you" || obj_prochoice["al_sqs_details.product_name"]== "PRULink Cover" || obj_prochoice["al_sqs_details.product_name"]== "PRUSignature Assure")
                                   {
                                        pagedata["setvar"]["A_COI_Reprice_dat["+nofRiderCount+"]"] ="";
                                   }
                                       szPRUsaverValue =  pagedata["setvar"]["A_Rider_Sum_Assured_rea["+nofRiderCount+"]"]
                                       //objresP_Calculate_Prem_Sustain_out["InvsPrem"] = parseFloat(szPRUsaverValue).toString();
                                        nofRiderCount = parseInt(nofRiderCount)+1;
                                        pagedata["setvar"]["A_Nof_Riders_int"]= nofRiderCount.toString();
                                   }
                            }
                            else // Changed according to the CR and Def 7492.
                            {
                                   pagedata["setvar"]["A_Budget_Premium_rea"] = total_BUA_Premium.toString();
                                   if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS3" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL14" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL24")
                                   {
                                    szPRUsaverValue = PRUallocatorPremiumValue;
                                   }
                            }
                        }
                       else // Changed according to the CR and Def 7492.
                       {
                                   //pagedata["setvar"]["A_Budget_Premium_rea"] = total_BUA_Premium.toString();
                                   if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS3" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL14" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL24")
                                   {
                                    szPRUsaverValue = PRUallocatorPremiumValue;
                                   }
                       }
                        console.log("padedata after3::"+JSON.stringify(pagedata));
                        //Added by Paromita for PRUsignature issue(Column returning value 10) on 26th May 2018
                        if(pagedata["setvar"]["A_Master_Product_Master_Key"]=="IL06" || pagedata["setvar"]["A_Master_Product_Master_Key"]=="ILS6" )
                        {
                            if(document.getElementById("al_rider_sqs.prusignature_infinite.rider_premium").value != "")
                            {
                                PRUallocatorPremiumValue= (parseFloat(document.getElementById("al_rider_sqs.prusignature_infinite.rider_premium").value) * 0.8).toString();
                            }
                            else
                            {
                                PRUallocatorPremiumValue = "0";
                            }
                        }
                           if(pagedata["setvar"]["A_Master_Product_Master_Key"]=="IL13")
                           {
                               if(document.getElementById("al_rider_sqs.prusignature_infinite.rider_premium").value != "")
                               {
                               PRUallocatorPremiumValue= (parseFloat(document.getElementById("al_rider_sqs.prusignature_infinite.rider_premium").value) * 0.5).toString();
                               }
                               else
                               {
                               PRUallocatorPremiumValue = "0";
                               }
                           }
                        console.log("bFirstCallFlag -->"+bFirstCallFlag);
                                   
                                   
                        if(bFirstCallFlag)
                        {
                            var jsonLeftPanel ={};
                        
                        
                            if(objSplitP_Calculate_Prem_Sustain_out.indexOf("MinInsPrem") != -1)
                            {
                                jsonLeftPanel["MinimumInsurance"] =  objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("MinInsPrem"))+1];
                            }
                            else
                            {
                                jsonLeftPanel["MinimumInsurance"] = "0";
                            }
                            
                            if(objSplitP_Calculate_Prem_Sustain_out.indexOf("MaxInsPrem") != -1)
                            {
                                jsonLeftPanel["MaximumInsurance"] =  objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("MaxInsPrem"))+1];
                            }
                            else
                            {
                                jsonLeftPanel["MaximumInsurance"] = "0";
                            }
                            if(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeHigh") != -1)
                            {
                                jsonLeftPanel["PolSustAgeHigh"] =  objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeHigh"))+1];
                            }
                            else
                            {
                                jsonLeftPanel["PolSustAgeHigh"] = "0";
                            }
                            if(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeLow") != -1)
                            {
                                jsonLeftPanel["PolSustAgeLow"] =  objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeLow"))+1];
                            }
                            else
                            {
                                jsonLeftPanel["PolSustAgeLow"] = "0";
                            }
                        
                            if(objSplitP_Calculate_Prem_Sustain_out.indexOf("MinInsPrem") != -1)
                            {
                                jsonLeftPanel["TotPrem"] =  objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("MinInsPrem"))+1];
                            }
                            else
                            {
                                jsonLeftPanel["TotPrem"] = "0";
                            }
                        
                        //PRuallocator Premium
                            if(objSplitP_Calculate_Prem_Sustain_out.indexOf("AL01") != -1)
                            {
                        
                                jsonLeftPanel["PRUallocatorPremium"] =  objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("AL01"))+1];
                            }
                            else
                            {
                                jsonLeftPanel["PRUallocatorPremium"] = "0";
                            }
                        
                        
                        
                        
                            fnCallValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,iSelectedRiderCount,bFirstCallFlag,jsonLeftPanel);
                        }
                        else
                        {
                        
                        pagedata["VPMSFunctionNameInSequence"] = ["P_Calculate_Premium_out"];//added
                        console.log("pageData P_Calculate_Premium_out:"+JSON.stringify(pagedata));
                        js_call_native_func("VPMSCall",pagedata,function(resP_Calculate_Premium_out)
                        {
                            console.log("resresP_Calculate_Premium_outt-->" +resP_Calculate_Premium_out);

                       //new function name P_SI_Section20_Details_out added by Ankita on 15 june 2023 for july release 2023 CR for PRUElite Invest product VPMS changes
                                            pagedata["VPMSFunctionNameInSequence"]=["P_Calculate_Premium_out","P_SI_Product_Disclosure_out","P_SI_Section01_Details_out","P_SI_Section01_Details_out_Block2","P_SI_Section02_Details_out","P_SI_Section03_Details_out","P_SI_Section04_Details_out","P_SI_Section05_Details_out","P_SI_Section06_Details_out","P_SI_Section07_Details_out","P_SI_Section08_Details_out","P_SI_Section09_Details_out","P_SI_Section10_Details_out","P_SI_Section11_Details_out","P_SI_Section02_PRUterm_out","P_SI_Section12_Details_out","P_Calculate_FlexiWithdrawal_out","P_SI_Section14_Details_out","P_SI_Section13_Details_out","P_SI_Section15_Details_out","P_SI_Section16_Details_out","P_SI_Section17_Details_out","P_SI_Section18_Details_out","P_SI_Section19_Details_out","P_SI_Section20_Details_out","P_SI_Section21_Details_out"];

                            console.log("pageData:"+JSON.stringify(pagedata));
                                            console.log("PRUallocatorPremiumValue final:"+PRUallocatorPremiumValue);
                        pagedata["changeInSetVar"]={"P_Calculate_Premium_out":{"A_Budget_Exc_Premium_rea":PRUallocatorPremiumValue},"P_SI_Section01_Details_out":{"A_Block_Num_Int":"12"},"P_SI_Section01_Details_out_Block2":{"A_Block_Num_Int":"99","A_Block_Start_int":"13"},"P_SI_Section02_Details_out":{"A_Block_Start_int":"1"}};
                            //console.log("pade data value:"+pagedata["setvar"]["A_Budget_Exc_Premium_rea"]);
                           
                        console.log("pageData:"+JSON.stringify(pagedata));
                        
                            js_call_native_func("VPMSCall",pagedata,function(resP_Calculate_Premium_out)
                                                {
                                                //All output response to map in JSON
                                                console.log("resP_SI Final Engine output all Response-->" +resP_Calculate_Premium_out)
                                                
                                                jsonAllOutput = JSON.parse(resP_Calculate_Premium_out);
                                                
                                                console.log("resP_Calculate_Prem_Sustain_out-->-->" +resP_Calculate_Prem_Sustain_out)
                                                console.log("jsonresP_Calculate_Prem_Sustain_out1-->-->" +jsonresP_Calculate_Prem_Sustain_out)
                                                console.log("jsonresP_Calculate_Prem_Sustain_out2-->-->" +JSON.stringify(jsonresP_Calculate_Prem_Sustain_out));
                                                
                                               
                                                
                                                jsonAllOutput["P_Calculate_Prem_Sustain_out"]=objresP_Calculate_Prem_Sustain_out;
                                                console.log("jsonAllOutput-->" +JSON.stringify(jsonAllOutput))
                                                
                                                var jsonEngineOutput = fnParseTableOutput(jsonAllOutput,iSelectedRiderCount,obj_prochoice);
                                                console.log("From VPMS benefit_flag_update:"+benefit_flag_update);
                                                if(currentPlan == "PRUsignature infinite")
                                                    jsonEngineOutput = fnChangeProductCodeValue(jsonEngineOutput);
                                                var benefit_update_data_flags = {
                                                "benefit_flag_update": benefit_flag_update
                                                }
                                                
                                                var product_update_data_flags = {
                                                "product_flag_update": product_flag_update
                                                }
                                                var personal_update_data_flags = {
                                                "mlife_flag_update": mlife_flag_update,
                                                "slife_flag_update": slife_flag_update,
                                                "tlife_flag_update": tlife_flag_update
                                                }
                                                
                                                var loading_update_data_flagss = {
                                                "loading_flag_update": 0,
                                                "loading_flag_noupdate": 0
                                                }
                                                js_set_var("loading_update_flags", JSON.stringify(loading_update_data_flagss), function()
                                                           {
                                                           js_set_var("benefit_update_flags",JSON.stringify(benefit_update_data_flags),function()
                                                                      {
                                                                      js_set_var("product_update_flags",JSON.stringify(product_update_data_flags),function()
                                                                                 {
                                                                                 js_set_var("personal_update_flags", JSON.stringify(personal_update_data_flags), function()
                                                                                            {
                                                                                            js_get_var("benefit_update_flags_database", function(update_benefit_res)
                                                                                                       {
                                                                                                       var obj_update_personal_database_insert = JSON.parse(update_benefit_res);
                                                                                                     console.log("update_benefit_res:"+obj_update_personal_database_insert["benefit_flag_update"]);
                                                                                                       var benefit_update_data_flags_insert = {
                                                                                                       "benefit_flag_update": obj_update_personal_database_insert["benefit_flag_update"]
                                                                                                       }
                                                                                                     console.log("benefit_update_data_flags_insert:"+benefit_update_data_flags_insert["benefit_flag_update"]);
                                                                                                       js_set_var("benefit_update_flags_database_for_insert", JSON.stringify(benefit_update_data_flags_insert), function()
                                                                                                                  {
                                                                    //js_set_var("benefit_update_flags_database_for_insert_bundle", JSON.stringify(benefit_update_data_flags_insert), function()
                                                                                                                  //{
                                                                                                                  
                                                                                                                  console.log("isSIOCampaignFlag:"+isSIOCampaignFlag)
                                                                                                                 
                                                                                                                  
                                                                                                                  
                                                                                                                  document.getElementById("prev_button").disabled=false;
                                                                                                                  
                                                                                                                  obj_global_engine = jsonEngineOutput;
                                                                                                                  bundleGlobalFund=jsonEngineOutput;
                                                                                                                  console.log("bundleGlobalFund"+ JSON.stringify(bundleGlobalFund));
                                                                                                                  global_response  = JSON.stringify(jsonEngineOutput);
                                                                                                                  console.log("jsonEngineOutput"+ JSON.stringify(obj_global_engine));
                                                                                                                
                                                                                                                  
                                                                                                                  if(document.getElementById("al_sqs_details.survival_benefit_option3").checked)//Added for SB Accumulator product by Sachin on Date 7-2-2019
                                                                                                                  {
                                                                                                                  
                                                                                                                  
                                                                                                                  fnBundleOutPutResonse(jsonEngineOutput,flag_cals,loadingflag_generate,callfrom,obj_prochoice);
                                                                                                            
                                                                                                                  
                                                                                                                  }else
                                                                                                                  {
                                                                                                                  //Added by ankita on 9 April 2019 for loading details changes setting in output
                                                                                                                  js_get_var("engineloadingstring", function(loading_res)
                                                                                                                             {
                                                                                                                             var isFromLoadingPage="No";
                                                                                                                             console.log("loading--->"+loading_res);
                                                                                                                             if(loading_res != "" && loading_res != null && loading_res != "null"  && loading_res != "(null)")
                                                                                                                             {
                                                                                                                             console.log("loading111--->"+loading_res);
                                                                                                                             isFromLoadingPage="Yes";
                                                                                                                             objLoadingToSetForOutput="";
                                                                                                                             var obj_loading = JSON.parse(loading_res);
                                                                                                                             var result = $.parseJSON(obj_loading);
                                                                                                                             $.each(result, function(k, v)
                                                                                                                                    {
                                                                                                                                    objLoadingToSetForOutput += k+"="+v+"::";
                                                                                                                                    });
                                                                                                                             }else
                                                                                                                             {
                                                                                                                             console.log("loading11222--->");
                                                                                                                             isFromLoadingPage = "No";
                                                                                                                            
                                                                                                                             }
                                                                                                                             console.log("isFromLoadingPage:"+isFromLoadingPage);    if(obj_solution["al_sqs_buttons_plan"]=="al_sqs_buttons.prumy_diabetes_care" && isFromLoadingPage=="No")
                                                                                                                      {
                                                                                                    console.log("Shivani--> First");                     js_set_var("engineloadingstring", JSON.stringify(objLoadingToSetForOutput), function()
                                                                                                                             {
                                                                                                                                populateContriValues(jsonEngineOutput,flag_cals,loadingflag_generate,callfrom);
                                                                                                                                   
                                                                                                                             });
                                                                                                                      }
                                                                                                                             
                                                                                                                      else
                                                                                                                      {
                                                                                                    console.log("Shivani-->Second ");                     if(obj_prochoice["al_sqs_details.product_name"]=="RetireGuard (SP)" || obj_prochoice["al_sqs_details.product_name"]=="PRUretirement growth")//added by ankita on 24 Sept 2019 for RGSP product
                                                                                                                             {
                                                                                                                             console.log("Shivani--> ");                          fnMsBenSelPopulateRGSPValues(jsonEngineOutput,loadingflag_generate);
                                                                                                                             }else
                                                                                                                             {
                                                                                                  console.log("Shivani-->Else ");                            populateContriValues(jsonEngineOutput,flag_cals,loadingflag_generate,callfrom);
                                                                                                                             }
                                                                                                                      }
                                                                                                                             });
                                                                                                                  }//end else
                                                                                                                  
                                                                                                                  
                                                                                                                  
                                                                                                                  //});
                                                                                                                  });//ankita bundle
                                                                                                                  });
                                                                                                       //});
                                                                                            
                                                                                            
                                                                                            
                                                                                            
                                                                                            });
                                                                                 });
                                                                      });
                                                           });
                                               
                                                
                                                });//
                                            });
                        }
                        });
                        });
}






//Common function to parse all Output according to JSON

function fnParseTableOutput(jsonAllOutput,iSelectedRiderCount,obj_prochoice)
{
    console.log("In fnParseTableOutput")
    var inifiniteJSON ="";
    var jsonEngineOutputComplete ={};
    var product_output_json_1 = setJson();
    console.log("JSON name:"+product_output_json_1[obj_prochoice["al_sqs_details.product_name"]]);
    console.log("currentPlan==>"+currentPlan);
    console.log("callfromfromBundleOutput==>"+callfromfromBundleOutput);
    
    
    
    if(callfromfromBundleOutput) //Added for SB Accumulator product on date  6-2-2019 by Sachin.
    {
        console.log("Bundle product"+callfromfromBundleOutput);
    inifiniteJSON = product_output_json_1["PRUSignature Harvest Plus"];
    }else
    {
    inifiniteJSON = product_output_json_1[obj_prochoice["al_sqs_details.product_name"]];
    }
    
    console.log("inifiniteJSON:"+JSON.stringify(inifiniteJSON));
    for(sub in inifiniteJSON)
    {
        
        var iColumnlength = inifiniteJSON[sub]["Length"];
        var iRiderCountLength=inifiniteJSON[sub]["Length"];
        
        if(iColumnlength == "iRiderCount")
        {
            var saverRiderCount = 0;
            var extraRiderCount = 0;
            if(document.getElementById("al_rider_sqs.prusaver.id").checked || document.getElementById("al_rider_sqs.prusaver_kid.id").checked)
            {
                saverRiderCount++;
            }
            if(document.getElementById("al_rider_sqs.enhanced_prue_child.id").checked == true && document.getElementById("al_rider_sqs.crisis_care.id").checked != true)
            {
                extraRiderCount++;
            }
            
            iColumnlength = ((iSelectedRiderCount - saverRiderCount + extraRiderCount) * 2) + 6;
            if(document.getElementById("al_rider_sqs.crisis_guard.id").checked == true && (currentPlan == "PRUWealth Plus" || currentPlan == "PRUWealth Max" /*|| currentPlan == "PRUWealth Enrich"*/) )
            {
                iColumnlength=iColumnlength+2;
            }
            
        }
        
        if(inifiniteJSON[sub]["outputResult"] == "RiderPremium")
        {
			jsonEngineOutputComplete[inifiniteJSON[sub]["EngineOutIndex"]]=fnParseRiderPremium(jsonAllOutput[inifiniteJSON[sub]["FunctionName"]]["result"]);
		}
		else if(inifiniteJSON[sub]["outputResult"].indexOf("PDS") != -1  || inifiniteJSON[sub]["outputResult"].indexOf("PDSBundleProd") != -1)
        {
            var PDSOutputFunction = inifiniteJSON[sub]["FunctionName"];
            console.log("PDSOutputFunction"+PDSOutputFunction);
			var splitOutput = PDSOutputFunction.split(";")
            console.log("splitOutput"+splitOutput);
			var outputStringPDS = "";
			for(var iPDSCounter = 0; iPDSCounter < splitOutput.length; iPDSCounter++)
			{
                console.log("splitOutput[iPDSCounter]"+splitOutput[iPDSCounter]);
                var PDSOutputFunction = jsonAllOutput[splitOutput[iPDSCounter]]
                console.log("PDSOutputFunction"+PDSOutputFunction);
                //var objPDS = JSON.parse(PDSOutputFunction)
                var objPDS = (PDSOutputFunction)
                console.log("objPDS:"+objPDS);
                if(objPDS != undefined && objPDS != "undefined")
                {
                    if(splitOutput[iPDSCounter] == "P_SI_Section02_PRUterm_out")
                    {
                        outputStringPDS = outputStringPDS.concat("PRUterm;");
                        console.log("outputStringPDS1:"+outputStringPDS);
                    }
                    console.log("objPDS result:"+objPDS["result"]);
                    outputStringPDS = outputStringPDS.concat(objPDS["result"]);
                    console.log("outputStringPDS2:"+outputStringPDS);
                    outputStringPDS = outputStringPDS.concat(";");
                    console.log("outputStringPDS3:"+outputStringPDS);
                }
                
			}
            
            if(inifiniteJSON[sub]["outputResult"] == "PDSOldProduct")
            {
                 arrPDS = [];
                 var iCount=0;
                 for(iCount= 0; iCount <= 50;iCount++) //previous it was 46 added last two index for CR 8878
                 {
                 var arrofEachPDSElement = [];
                 arrofEachPDSElement.push("0");
                 arrPDS.push(arrofEachPDSElement);
                 
                 }
                jsonEngineOutputComplete[inifiniteJSON[sub]["EngineOutIndex"]]=fnParsePDSOldProduct(outputStringPDS);
            }
            else
            {
			    jsonEngineOutputComplete[inifiniteJSON[sub]["EngineOutIndex"]]=fnParseOutputPDS(inifiniteJSON[sub]["ColumnName"],outputStringPDS);
            }
            
            console.log("Engine Output"+jsonEngineOutputComplete[inifiniteJSON[sub]["EngineOutIndex"]]);
		}
        else if(inifiniteJSON[sub]["outputResult"] == "szDynamicRiderTable")
        {
            
            console.log("In szDynamicRiderTable"+jsonAllOutput[inifiniteJSON[sub]["FunctionName"]]);
            console.log("iColumnlength:"+iColumnlength);
            jsonEngineOutputComplete[inifiniteJSON[sub]["EngineOutIndex"]] = fnParseDynamicColumnOutput(jsonAllOutput[inifiniteJSON[sub]["FunctionName"]],inifiniteJSON[sub]["ColumnName"],iColumnlength);
        }
        else
        {
            
            var tableOutputFunction = inifiniteJSON[sub]["FunctionName"];
            var skipTagFromResponse = inifiniteJSON[sub]["skipTagFromResponse"];
            var parseTableFunction = inifiniteJSON[sub]["parseTableFunction"];
            console.log("skipTagFromResponse:"+skipTagFromResponse);
            var splitTableOutput = tableOutputFunction.split(";")
            var outputStringTable = "";
            for(var iTableCounter = 0; iTableCounter < splitTableOutput.length; iTableCounter++)
            {
                console.log("splitTableOutput[iTableCounter]--->"+splitTableOutput[iTableCounter])
                var tableOutput = jsonAllOutput[splitTableOutput[iTableCounter]];
                console.log("tableOutput--->"+tableOutput)
                //var objTable = JSON.parse(tableOutput);
                var objTable = (tableOutput);
                console.log("objTable[\"result\"]=----"+objTable["result"])
                outputStringTable = outputStringTable.concat(objTable["result"]);
                outputStringTable = outputStringTable.concat(";");
                console.log("outputStringTable"+outputStringTable)
            }
            console.log("outputStringTable : "+outputStringTable);
            console.log("inifiniteJSON[sub][\"ColumnName\"] : "+inifiniteJSON[sub]["ColumnName"]);
            console.log("iColumnlength : "+iColumnlength);
           
            jsonEngineOutputComplete[inifiniteJSON[sub]["EngineOutIndex"]] = fnParseOutputIntoTable(outputStringTable,inifiniteJSON[sub]["ColumnName"],iColumnlength,skipTagFromResponse,iRiderCountLength,parseTableFunction);
            
            
        }
        
        
    }
    
    
    console.log("Final Engine Output"+JSON.stringify(jsonEngineOutputComplete));
  
    return jsonEngineOutputComplete;
  
}


//function fnParseOutputIntoTable(strOutputString,stringOutputColumnName,iLengthRow,skipTagFromResponse)
function fnParseOutputIntoTable(strOutputString,stringOutputColumnName,iLengthRow,skipTagFromResponse,iRiderCountLength,parseTableFunction)
{
    
    //console.log("In fnParseOutputIntoTable Engine Output"+strOutputString+"iLengthRow:"+iLengthRow);
    var iColumnIndex;
    var iColumnValue;
    
    
    var jsonOutputColumnName = JSON.parse(stringOutputColumnName);
    
    console.log("jsonOutputColumnName:"+jsonOutputColumnName);
   
    
    var strOutputResult = strOutputString;
    
    var arrSI=[];
    
    var arrSIEachRow=[];
    
    var objSplitres = strOutputResult.split(";");
               
     
               
    console.log("iLengthRow:"+iLengthRow+"--objSplitres:"+objSplitres);
               
    console.log("parseTableFunction:"+parseTableFunction);
    if(skipTagFromResponse != "undefined" && skipTagFromResponse != undefined && skipTagFromResponse != "null" && skipTagFromResponse != "(null)" && skipTagFromResponse != null)
    {
            var arrReturnSplit=_.rest(objSplitres,4);
            console.log("arrReturnSplit:"+arrReturnSplit);
            objSplitres=arrReturnSplit;
    }
    else if(parseTableFunction != "undefined" && parseTableFunction != undefined && parseTableFunction != "null" && parseTableFunction != "(null)" && parseTableFunction != null)
    {
        var arrEachRowElement=[];
        var strOutputResult = strOutputString;
        strOutputResult=strOutputResult.replace(/ /g,"_");
        console.log("objSplitres111:"+objSplitres);
        objSplitres = strOutputResult.split(";");
        //var arrReturnSplit=objSplitres;
        for(var iCount =0 ; iCount < objSplitres.length ; iCount++)
        {
            var strColumnName = objSplitres[iCount];
            
            console.log("strColumnName:"+strColumnName);
            if(strColumnName == "Par_Policy" || strColumnName=="Non_Par_Policy")
            {
                console.log("Inside if");
                //var tg=strColumnName;
                for(i=1;i<parseTableFunction;i++)
                {
                    arrEachRowElement.push(strColumnName+"_"+objSplitres[iCount+i]);
                    iCount++;
                    arrEachRowElement.push(objSplitres[iCount+i]);
                }
                
                
                iCount=iCount + parseInt(parseTableFunction) - 1;
            }
            else
            {
                arrEachRowElement.push(strColumnName);
            }
        }
        console.log("arrEachRowElement:"+arrEachRowElement);
        
        objSplitres=arrEachRowElement;
        
        
        
        var iLengthEachRow=objSplitres.indexOf("Policy_Year", strOutputResult.indexOf("Policy_Year") + 1);
        
        if(iRiderCountLength!="iRiderCount" && iLengthEachRow!=-1)
        {
            iLengthRow = iLengthEachRow;
        }
        console.log("iLengthRow111:"+iLengthRow)
    }
   else
   {
               var iLengthEachRow=objSplitres.indexOf("End of Pol Year", strOutputResult.indexOf("End of Pol Year") + 1);
               
               if(iRiderCountLength!="iRiderCount" && iLengthEachRow!=-1)
                    {
                      iLengthRow = iLengthEachRow;
                    }
               
               
   }
    
    console.log("After iLengthRow:"+iLengthRow+"--objSplitres:"+objSplitres);
    for(var iCount =0 ; iCount < objSplitres.length ; iCount++)
    {
        var strColumnName = objSplitres[iCount];
    
        console.log("strColumnName:"+strColumnName+"--jsonOutputColumnName[strColumnName]:"+jsonOutputColumnName[strColumnName]);
        if(jsonOutputColumnName[strColumnName] != "undefined" && jsonOutputColumnName[strColumnName] != undefined && jsonOutputColumnName[strColumnName] != "null" && jsonOutputColumnName[strColumnName] != "(null)" && jsonOutputColumnName[strColumnName] != null)
        {
           
            iColumnIndex = parseInt(jsonOutputColumnName[strColumnName]);
            
            
            if(iColumnIndex != -1)
            {
				iColumnValue = objSplitres[iCount+1];
				
				arrSIEachRow.splice(iColumnIndex,0,iColumnValue);
                
				
				iCount++;
			}
        }
        
        //console.log("arrSIEachRow 2:"+arrSIEachRow);
        if(((iCount+1)%iLengthRow==0) && iCount != 0)
        {

            if(arrSIEachRow.length!=0) //changed by Paromita on  16 June 2018 for table row empty
            {
            
                arrSI.push(arrSIEachRow);
                //console.log("arrSI 1:"+arrSI);
            }
            arrSIEachRow=[];
        }
        
    }
    
    
    //start
    
    
    
    //end
    
    if(arrSIEachRow.length!=0) //changed by Paromita on  16 June 2018 for table row empty
    {
        //console.log("arrSI 2:"+arrSI);
        arrSI.push(arrSIEachRow);
        console.log("arrSI 3:"+arrSI);
    }
    return arrSI;
}


function fnParseOutputPDS(PDSJSON,strOutputResult)
{
    
    console.log("in fnParseOutputPDS"+strOutputResult);
    console.log("in PDSJSON"+PDSJSON);
   
    var iColumnIndex;
    var iColumnValue;
    var sameKeyCounterJSON = {};
    var sameKeyCounter = 1;
    
    
    var PDS={};
    
    
    var objSplitres = strOutputResult.split(";");
    console.log("in objSplitres"+objSplitres);
    
    PDSJSON = JSON.parse(PDSJSON);
    console.log("After in PDSJSON"+PDSJSON);
    
    
    for(submainPDS in PDSJSON)
    {
       if(objSplitres.indexOf(submainPDS) != -1)
       {
		   var baseIndex = objSplitres.indexOf(submainPDS);
		   
		   //console.log("typeof PDSJSON[submainPDS]:"+typeof PDSJSON[submainPDS])
           if(Array.isArray(PDSJSON[submainPDS]))
           {
               
               for (var i = 0; i < PDSJSON[submainPDS].length; i++)
               {
                   
                   var arrayKey = submainPDS.replace(/ /g,"_")+"_";
                   
                   var columnCountAdd = 0
                   for(subArrayinPDS in PDSJSON[submainPDS][i])
                   {
                       arrayKey=arrayKey+subArrayinPDS.replace(/ /g,"_");
                       columnCountAdd = PDSJSON[submainPDS][i][subArrayinPDS];
                   }
                   
                   arrayKey = fnCheckSameKey(arrayKey,PDS,sameKeyCounterJSON);
                   if(objSplitres[baseIndex+columnCountAdd]!="")
                   {
                       PDS[arrayKey] = objSplitres[baseIndex+columnCountAdd];
                   }
               }
           }
           else if(typeof PDSJSON[submainPDS] == "object")
		   {
			   PDS=fnRecursiveParsing(objSplitres,PDS,PDSJSON[submainPDS],baseIndex,submainPDS,sameKeyCounterJSON);
		   }
		   else
		   {
               var iPDScount = 1;
               if(PDSJSON[submainPDS] != 0)
               {
                   iPDScount = PDSJSON[submainPDS];
               }
               PDS[submainPDS.replace(/ /g,"_")] = objSplitres[baseIndex+iPDScount];
		   }
		   
	   }
        
    }
    //console.log("PDS:::"+ PDS)
    return PDS;
}



function fnRecursiveParsing(arrOutput,mainJsonPDS,jsonPDSObject,baseIndex,baseKey,sameKeyCounterJSON)
{
    for(subPDS in jsonPDSObject)
    {
        //console.log("subPDS:"+subPDS)
        if(arrOutput.indexOf(subPDS) != -1)
        {
            
            if(Array.isArray(jsonPDSObject[subPDS]))
            {
                
                for (var i = 0; i < jsonPDSObject[subPDS].length; i++)
                {
                    
                    var arrayKey = baseKey.replace(/ /g,"_")+"_"+subPDS.replace(/ /g,"_")+"_";
                    var columnCountAdd = 0
                    for(subArray in jsonPDSObject[subPDS][i])
                    {
                        arrayKey=arrayKey+subArray.replace(/ /g,"_");
                        columnCountAdd = jsonPDSObject[subPDS][i][subArray];
                    }
                    arrayKey = fnCheckSameKey(arrayKey,mainJsonPDS,sameKeyCounterJSON);
                    mainJsonPDS[arrayKey] = arrOutput[baseIndex+columnCountAdd];
                }
            }
            else if(typeof jsonPDSObject[subPDS] == "object")
            {
                var baseIndex = arrOutput.indexOf(subPDS);
                mainJsonPDS=fnRecursiveParsing(arrOutput,mainJsonPDS,jsonPDSObject[subPDS],baseIndex,baseKey+"_"+subPDS,sameKeyCounterJSON);
            }
            else
            {
                
                mainJsonPDS[baseKey.replace(/ /g,"_")+"_"+subPDS.replace(/ /g,"_")] = arrOutput[baseIndex+jsonPDSObject[subPDS]];
                
            }
            
        }
        
    }
    return mainJsonPDS;
}

function fnCheckSameKey(arrayKey,mainJsonPDS,sameKeyCounterJSON)
{
    var sameKeyCounter = 1;
    if(mainJsonPDS.hasOwnProperty(arrayKey))
    {
        if(sameKeyCounterJSON.hasOwnProperty(arrayKey))
        {
            sameKeyCounter = sameKeyCounterJSON[arrayKey];
        }
        else
        {
            sameKeyCounter = 1;
        }
        sameKeyCounterJSON[arrayKey] = sameKeyCounter+1;
        arrayKey=arrayKey+"_"+sameKeyCounter;
        sameKeyCounter++;
    }
    return arrayKey;
}

function fnParseDynamicColumnOutput(strOutputString,stringOutputColumnName,iLengthRow)
{
    
    console.log("In fnParseDynamicColumnOutput Engine Output"+JSON.stringify(strOutputString));
    var iColumnIndex;
    var iColumnValue;
    
    
    var jsonOutputColumnName = JSON.parse(stringOutputColumnName);
   
    var objVPMSJSON = (strOutputString);
    
    var strOutputResult = objVPMSJSON["result"];
    
    var arrSI=[];
    
    var arrSIEachRow=[];
    
    for(var i=0;i<22;i++)
    {
        arrSIEachRow.push("$");
    }
    
    var objSplitres = strOutputResult.split(";");
    
    for(var iCount =0 ; iCount < objSplitres.length ; iCount++)
    {
        var strColumnName = objSplitres[iCount];
        
        if(jsonOutputColumnName[strColumnName] != "undefined" && jsonOutputColumnName[strColumnName] != undefined && jsonOutputColumnName[strColumnName] != "null" && jsonOutputColumnName[strColumnName] != "(null)" && jsonOutputColumnName[strColumnName] != null)
        {
            
            iColumnIndex = parseInt(jsonOutputColumnName[strColumnName]);
            
            if(iColumnIndex != -1)
            {
                iColumnValue = objSplitres[iCount+1];
                //console.log("iColumnValue:"+iColumnValue);
                arrSIEachRow.splice(iColumnIndex,1,iColumnValue);
                iCount++;
            }
        }
        
        if(((iCount+1)%iLengthRow==0) && iCount != 0)
        {
            arrSIEachRow =_.without(arrSIEachRow, "$")
            
            arrSI.push(arrSIEachRow);
            
            
            arrSIEachRow=[];
            
            for(var i=0;i<22;i++)
            {
                arrSIEachRow.push("$");
            }
        }
        
    }
    return arrSI;
}

function fnParsePDSOldProduct(strPDS)
{
    
    var iDuplicateFlagYear=0;
    var iDuplicateFlagAge=0;
    var iDuplicateFlagLapseYear=0;
    
    if(strPDS != "" || strPDS != "null")
    {
        var arrSplitPDS = strPDS.split(";");
        var iCount = 0;
        
        for(iCount= 0; iCount < arrSplitPDS.length;iCount++)
        {
            var arrofEachPDSElement = [];
            
            switch(arrSplitPDS[iCount])
            {
                case "MinInsPrem":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(11,1,arrofEachPDSElement);
                    break;
                case "MaxInsPrem":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(10,1,arrofEachPDSElement);
                    break;
                case "Sustainability Year":
                    if(iDuplicateFlagYear==0)
                    {
                        iDuplicateFlagYear=1;
                        
                        arrofEachPDSElement.push(arrSplitPDS[iCount+2]);
                        arrPDS.splice(6,1,arrofEachPDSElement);
                        
                    }
                    
                    break;
                case "High":
                    
                    if(arrSplitPDS[iCount-3] == "Sustainability Year")
                    {
                        if(iDuplicateFlagYear==1)
                        {
                            
                            arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                            arrPDS.splice(4,1,arrofEachPDSElement);
                            
                        }
                    }
                    
                    if(arrSplitPDS[iCount-3] == "Lapse Year")
                    {
                        
                        if(iDuplicateFlagLapseYear==1)
                        {
                            
                            arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                            arrPDS.splice(40,1,arrofEachPDSElement);
                            
                            
                        }
                    }
                    break;
                case "PolSustAgeHigh":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(5,1,arrofEachPDSElement);
                    
                    break;
                case "PolSustAgeLow":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(7,1,arrofEachPDSElement);
                    
                    break;
                case "PolSustAgeHighYYMM":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(8,1,arrofEachPDSElement);
                    
                    break;
                case "PolSustAgeLowYYMM":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(9,1,arrofEachPDSElement);
                    
                    break;
                case "RecommendedInvsPrem":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(12,1,arrofEachPDSElement);
                    
                    break;
                case "TotPrem":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(0,1,arrofEachPDSElement);
                    
                    break;
                case "Age COI > Tot Prem":
                    
                    if(iDuplicateFlagAge==0)
                    {
                        iDuplicateFlagAge=1;
                        arrofEachPDSElement.push(arrSplitPDS[iCount+2]);
                        arrPDS.splice(2,1,arrofEachPDSElement);
                        
                        
                    }
                    
                    break;
                case "High":
                    
                    if(arrSplitPDS[iCount-3] == "Age COI > Tot Prem")
                    {
                        if(iDuplicateFlagAge==1)
                        {
                            arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                            arrPDS.splice(3,1,arrofEachPDSElement);
                            
                            
                        }
                    }
                    break;
                case "Death Benefit":
                    
                    arrofEachPDSElement.push(arrSplitPDS[iCount+2]);
                    arrPDS.splice(14,1,arrofEachPDSElement);
                    
                    break;
                case "Total and Permanent Disability Benefit":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+2]);
                    arrPDS.splice(15,1,arrofEachPDSElement);
                    break;
                    
                case "Maturity Benefit":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+2]);
                    arrPDS.splice(16,1,arrofEachPDSElement);
                    
                    break;
                case "Payor Basic":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(25,1,arrofEachPDSElement);
                    break;
                case "Payor Saver":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(26,1,arrofEachPDSElement);
                    break;
                case "Spouse Payor Basic":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(27,1,arrofEachPDSElement);
                    break;
                case "Spouse Payor Saver":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(28,1,arrofEachPDSElement);
                    break;
                case "Parent Payor Basic":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(29,1,arrofEachPDSElement);
                    break;
                case "Parent Payor Saver":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(30,1,arrofEachPDSElement);
                    break;
                case "2Parent Payor Basic":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(31,1,arrofEachPDSElement);
                    break;
                case "2Parent Payor Saver":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(32,1,arrofEachPDSElement);
                    break;
                case "PRUmedic overseas":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+2]);
                    arrPDS.splice(36,1,arrofEachPDSElement);
                    break;
                    
                case "Room and Board":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(33,1,arrofEachPDSElement);
                    break;
                    
                case "Med Value Point":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(34,1,arrofEachPDSElement);
                    break;
                    
                case "Med Saver/Deductible":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(35,1,arrofEachPDSElement);
                    break;
                    
                case "Additional Critical Illness 1":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(20,1,arrofEachPDSElement);
                    break;
                case "Accelerated Critical Illness":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(19,1,arrofEachPDSElement);
                    break;
                case "Additional Critical Illness 2":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(21,1,arrofEachPDSElement);
                    break;
                case "Child Specified Illness":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+2]);
                    arrPDS.splice(18,1,arrofEachPDSElement);
                    console.log("Child Specified Illness"+arrPDS);
                    break;
                case "Accidental Death":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(22,1,arrofEachPDSElement);
                    break;
                case "Accidental Medical Reimbusement":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(23,1,arrofEachPDSElement);
                    break;
                case "Accidental Income":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(24,1,arrofEachPDSElement);
                    break;
                case "Accidental Medical Reimbusement":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(23,1,arrofEachPDSElement);
                    break;
                case "Total Instalment Premium":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(37,1,arrofEachPDSElement);
                    break;
                case "Annualised Prem":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(1,1,arrofEachPDSElement);
                    
                    break;
                case "Service Charge":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(38,1,arrofEachPDSElement);
                    
                    break;
                case "Lapse Year":
                    if(iDuplicateFlagLapseYear==0)
                    {
                        iDuplicateFlagLapseYear=1;
                        arrofEachPDSElement.push(arrSplitPDS[iCount+2]);
                        arrPDS.splice(39,1,arrofEachPDSElement);
                        
                        
                    }
                    
                    break;
                case "PRUsaver kid Payout Amount Low":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(41,1,arrofEachPDSElement);
                    
                    break;
                case "PRUsaver kid Payout Amount High":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(42,1,arrofEachPDSElement);
                    
                    break;
                case "PRUsaver kid Payout Policy Year":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(43,1,arrofEachPDSElement);
                    
                    break;
                case "InvsPrem":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(44,1,arrofEachPDSElement);
                    
                    break;
                case "Essential Child Plus / Crisis Care": 
                    arrofEachPDSElement.push(arrSplitPDS[iCount+2]);
                    arrPDS.splice(45,1,arrofEachPDSElement);
                    
                    break;
                case "PRUSaver Kid/ PRUSaver":
                    arrofEachPDSElement.push(arrSplitPDS[iCount+2]);
                    arrPDS.splice(46,1,arrofEachPDSElement);
                    
                    break;
                    
                case "Saver Benefit":
                    
                    arrofEachPDSElement.push(arrSplitPDS[iCount+2]);
                    arrPDS.splice(47,1,arrofEachPDSElement);
                    
                    break;
                    
                    
                case "PRUsaver kid Payout Age":
                    
                   
                    arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                    arrPDS.splice(48,1,arrofEachPDSElement);
                      break;
               
               case "Sus":
               console.log("sus:"+arrSplitPDS[iCount-5]);
               if(arrSplitPDS[iCount-5] == "Sustainability Year")
               {
                   if(iDuplicateFlagYear==1)
                   {
                       console.log("sus:"+arrSplitPDS[iCount+1]);
                       arrofEachPDSElement.push(arrSplitPDS[iCount+1]);
                       arrPDS.splice(49,1,arrofEachPDSElement);
                       
                   }
               }
               break;
               
               case "Sustainability Age":
                              
                             
                arrofEachPDSElement.push(arrSplitPDS[iCount+6]);
                arrPDS.splice(50,1,arrofEachPDSElement);
                break;
            }
            
            
            
        }
               //Sustainability Year and Sustainability age added by ankita on 9 dec 2022 for mom and baby care rider
        
    }
    return arrPDS;
    
}

//Function to validate if min and max premium are -1
function fnValidateOfMinMaxNA(messageToValidate)
{
    console.log("messageToValidate:"+messageToValidate);
    bootbox.confirm({
                    
                    message: "<p class=\"text-left\">"+messageToValidate+"</p>",
                    buttons: {
                    confirm: {
                    label: '<i class="fa fa-times"></i>OK',
                    className: 'btn-default'
                    }
                    },
                    callback: function (result)
                    {
                    
                            if(result==true)
                            {
                            
                               document.getElementById("al_sqs_details.min_insurance_premium").value = "NA";
                            
                               document.getElementById("al_sqs_details.max_insurance_premium").value = "NA";
                            
                            }
                    }});
    
}





//Recommedded Investment Premium validation
function fnValidateInvestmentPremium(pagedata,messageToValidate,obj_mlife_res,obj_prochoice,firstCal,jsonLeftPanel)
{
    console.log("messageToValidate--"+messageToValidate);
    bootbox.confirm({
                    
                    message: "<p class=\"text-left\">"+messageToValidate+"</p>",
                    buttons: {
                    cancel: {
                    label: '<i class="fa fa-check"></i>Ok',
                    className: 'btn-default'
                    
                    },
                    confirm: {
                    label: '<i class="fa fa-times"></i>No,I would like to re-adjust my package',
                    className: 'btn-default'
                    }
                    },
                    callback: function (result)
                    {
                    
                    canSwipe=0;
                    console.log('This was logged in the callback: ' + result);
                    if(result==true)
                    {
                        benefit_flag_update = "1";// DEF-4792 Pramod Chavan: 22012018
                        canSwipe=1;
                        flag_popup=0;
                    }
                    else
                    {
                        flag_popup=0;// For DEF-4676
                        canSwipe=1;
                        var res = messageToValidate.match(/(\d[.]*)+/g).toString();
                        //var res1 = res.replace(',','');
                        //modify by ankita on 4 jan 2023 for internal issue of regex
                        var res1 = res.replace(/,/g, "");
                    
                        var res2 = res1.substring(0,res1.indexOf("."))
                    
                    
                        var investmentPremiumVal = res2;
                        var insuValue1="";
                        document.getElementById("al_sqs_details.investment_premium").value =investmentPremiumVal;
                    //console.log("investmentPremiumVal:"+investmentPremiumVal);
                    //console.log("id value:"+document.getElementById("al_sqs_details.investment_premium").value);
                        if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25")
                        {
                            insuValue1=document.getElementById("al_sqs_details.pruwealth_plus_ _bua_prem").value;
                        }
                        else
                        {
                            insuValue1=document.getElementById("al_sqs_details.insurance_premium").value;
                        }
                    
                        var investValue1=document.getElementById("al_sqs_details.investment_premium").value;
                        document.getElementById("al_sqs_details.total_premium_plm_plus").value=(parseFloat(insuValue1)+parseFloat(investValue1)).toFixed(2);
                    
                    //SR and ankita added comment for def-8966
                    var iPolicyTermToSet = "";
                    
                    if(document.getElementById("al_sqs_details.target_sustainability_option").value==20)
                    {
                        iPolicyTermToSet="20";
                    }
                    else
                    {
                        iPolicyTermToSet =  parseInt(document.getElementById("al_sqs_details.target_sustainability_option").value) - parseInt(obj_prochoice["al_sqs_details.mlife.il_anb"]);
                    }
                    
                        if(obj_mlife_res["al_person_details.pre_natal_child_flg"] == "Yes" || obj_prochoice["al_sqs_details.mlife.il_anb"]<=18)
                        {
                    
                            if(document.getElementById("al_rider_sqs.prusaver_kid.id").checked)
                            {
                                document.getElementById("al_rider_sqs.prusaver_kid.rider_premium").value =investmentPremiumVal;
                                document.getElementById("al_rider_sqs.prusaver_kid.rider_term").value =100-obj_prochoice["al_sqs_details.mlife.il_anb"];
                                document.getElementById("al_rider_sqs.prusaver_kid.rider_expiry_age").value = 100;
                                document.getElementById("al_rider_sqs.prusaver_kid.payout_age").disabled=false;
                                document.getElementById("al_rider_sqs.prusaver_kid.rider_premium").disabled=false;
                                document.getElementById("al_rider_sqs.prusaver_kid.rider_premium").readOnly = false;
                            }
                            else if(document.getElementById("al_rider_sqs.prusaver.id").checked)
                            {
                                document.getElementById("al_rider_sqs.prusaver.rider_premium").value =investmentPremiumVal;

                                if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL03" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS3" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL11" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL14" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL24")
                                {
                                    document.getElementById("al_rider_sqs.prusaver.rider_term").value = document.getElementById("al_sqs_details.premium_payment_period_plm_plus").value;
                                }
                                else
                                {
                                    //added by ankita for defect 8640 on 25 dec 2019
                                    if(obj_prochoice["al_sqs_details.product_name"]=="PRULink Cover" || obj_prochoice["al_sqs_details.product_name"]=="PRUwith you" || obj_prochoice["al_sqs_details.product_name"]=="PRUSignature Assure")
                                    {
                                        document.getElementById("al_rider_sqs.prusaver.rider_term").value = iPolicyTermToSet;
                                    }
                                    else
                                    {
                                        document.getElementById("al_rider_sqs.prusaver.rider_term").value = 100-obj_prochoice["al_sqs_details.mlife.il_anb"];
                                    }
                                    //document.getElementById("al_rider_sqs.prusaver.rider_term").value = 100-obj_prochoice["al_sqs_details.mlife.il_anb"];
                                }
                                
                                document.getElementById("al_rider_sqs.prusaver.rider_expiry_age").value = 100;
                                document.getElementById("al_rider_sqs.prusaver.rider_premium").disabled=false;
                                document.getElementById("al_rider_sqs.prusaver.rider_premium").readOnly = false;
                    
                            }
                            else
                            {
                                document.getElementById("al_rider_sqs.prusaver_kid.id").checked = true;
                                document.getElementById("al_rider_sqs.prusaver_kid.rider_premium").value =investmentPremiumVal;
                                //added by ankita for defect 8640 on 25 dec 2019
                                if(obj_prochoice["al_sqs_details.product_name"]=="PRULink Cover" || obj_prochoice["al_sqs_details.product_name"]=="PRUwith you" || obj_prochoice["al_sqs_details.product_name"]=="PRUSignature Assure")
                                {
                                    document.getElementById("al_rider_sqs.prusaver_kid.rider_term").value = iPolicyTermToSet;
                                }
                                else
                                {
                                    document.getElementById("al_rider_sqs.prusaver_kid.rider_term").value = 100-obj_prochoice["al_sqs_details.mlife.il_anb"];
                                }
                                //document.getElementById("al_rider_sqs.prusaver_kid.rider_term").value =100-obj_prochoice["al_sqs_details.mlife.il_anb"];
                                document.getElementById("al_rider_sqs.prusaver_kid.rider_expiry_age").value = 100;
                                document.getElementById("al_rider_sqs.prusaver_kid.payout_age").disabled=false;
                                document.getElementById("al_rider_sqs.prusaver_kid.rider_premium").disabled=false;
                                document.getElementById("al_rider_sqs.prusaver_kid.rider_premium").readOnly = false;
                            }
                        }
                        else
                        {
                            document.getElementById("al_rider_sqs.prusaver.id").checked = true;
                            document.getElementById("al_rider_sqs.prusaver.rider_premium").value =investmentPremiumVal;

                            if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL03" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS3" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL11" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL14" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL24")
                            {
                            document.getElementById("al_rider_sqs.prusaver.rider_term").value = document.getElementById("al_sqs_details.premium_payment_period_plm_plus").value;
                            }
                            else
                            {
                                //added by ankita for defect 8640 on 25 dec 2019
                                if(obj_prochoice["al_sqs_details.product_name"]=="PRULink Cover" || obj_prochoice["al_sqs_details.product_name"]=="PRUwith you" || obj_prochoice["al_sqs_details.product_name"]=="PRUSignature Assure")
                                {
                                    document.getElementById("al_rider_sqs.prusaver.rider_term").value = iPolicyTermToSet;
                                }
                                else
                                {
                                    document.getElementById("al_rider_sqs.prusaver.rider_term").value = 100-obj_prochoice["al_sqs_details.mlife.il_anb"];
                                }
                                //document.getElementById("al_rider_sqs.prusaver.rider_term").value = 100-obj_prochoice["al_sqs_details.mlife.il_anb"];
                            }
                        
                            document.getElementById("al_rider_sqs.prusaver.rider_expiry_age").value = 100;
                            document.getElementById("al_rider_sqs.prusaver.rider_premium").disabled=false;
                            document.getElementById("al_rider_sqs.prusaver.rider_premium").readOnly = false;
                        
                        
                        }
                    
                    if(jsonLeftPanel != "" && (pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS2" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL08" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL16" ||  pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" ||  pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25"))
                    {
                        
                        //added by ankita on 8 may 2019 for pruwealth plus product
                        if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25")
                        {
                    
                        document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").readOnly = false;
                        document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").disabled=false;
                        }
                        else
                        {
                        document.getElementById("al_sqs_details.insurance_premium").readOnly = false;
                        document.getElementById("al_sqs_details.insurance_premium").disabled=false;
                        }
                        if(firstCal == null || firstCal == "" || firstCal == "NA" || firstCal == "undefined" || firstCal== "0")
                        {
                            //added by ankita on 8 may 2019 for pruwealth plus product
                            if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25")
                            {
                            document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").value = jsonLeftPanel["MinimumInsurance"];
                            }
                            else
                            {
                            document.getElementById("al_sqs_details.insurance_premium").value = jsonLeftPanel["MinimumInsurance"];
                            }
                            
                        }
                    
                    //added by ankita on 10 jan 2020 for defect 8934
                      pagedata["VPMSFunctionNameInSequence"] = ["P_Calculate_Prem_Sustain_out"];
                      console.log("pageData:"+JSON.stringify(pagedata));
                      
                      
                      js_call_native_func("VPMSCall",pagedata,function(resP_Calculate_Prem_Sustain_out)
                      {
                            console.log("resP_Calculate_Prem_Sustain_out def 8934 fnvalidateinvestmentpremium-->" +resP_Calculate_Prem_Sustain_out);

                            var jsonresP_Calculate_Prem_Sustain_out = JSON.parse(resP_Calculate_Prem_Sustain_out);
                            var objresP_Calculate_Prem_Sustain_out = jsonresP_Calculate_Prem_Sustain_out[pagedata["VPMSFunctionNameInSequence"]];
                            console.log("objresP_Calculate_Prem_Sustain_out"+JSON.stringify(objresP_Calculate_Prem_Sustain_out));
                            var objSplitP_Calculate_Prem_Sustain_out = objresP_Calculate_Prem_Sustain_out["result"].split(";")
                            console.log("objSplitP_Calculate_Prem_Sustain_out"+objSplitP_Calculate_Prem_Sustain_out);
                            
                               
                                if(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeHigh") != -1)
                                {
                                    jsonLeftPanel["PolSustAgeHigh"] =  objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeHigh"))+1];
                                }
                                else
                                {
                                    jsonLeftPanel["PolSustAgeHigh"] = "0";
                                }
                                if(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeLow") != -1)
                                {
                                    jsonLeftPanel["PolSustAgeLow"] =  objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeLow"))+1];
                                }
                                else
                                {
                                    jsonLeftPanel["PolSustAgeLow"] = "0";
                                }
                        document.getElementById("al_sqs_details.total_premium_plm_plus").value = jsonLeftPanel["TotPrem"];
                        document.getElementById("al_sqs_details.min_insurance_premium").value = jsonLeftPanel["MinimumInsurance"];
                        document.getElementById("al_sqs_details.max_insurance_premium").value = jsonLeftPanel["MaximumInsurance"];
                        document.getElementById("al_sqs_details.project_sustainability_age_high").value = jsonLeftPanel["PolSustAgeHigh"];
                        document.getElementById("al_sqs_details.project_sustainability_age_low").value = jsonLeftPanel["PolSustAgeLow"];
                                          });
                    }
                    
                        PrusaverReset("");
                    
                    
                    
                    
                    }
                    }});
}



//Function to show Error message



function fnShowWarningMsg(pagedata,messageToValidate,obj_mainlife_response,obj_prodchoice_res,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel)
{
    console.log("fnShowWarningMsg messageToValidate:"+messageToValidate);
    
    bootbox.alert(messageToValidate, function()
                  {
                  benefit_flag_update ="0";
                  console.log("benefit_flag_update--"+benefit_flag_update);
                  canSwipe=1;
                  
                  fnCallOutputAfterValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mainlife_response,obj_prodchoice_res,iSelectedRiderCount,bFirstCallFlag)
                  });
    
}
function fnShowSIOWarningMsg(pagedata,messageToValidate,obj_mainlife_response,obj_prodchoice_res,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel,arrWarningsCV="",firstCal="")
{
    console.log("fnShowWarningMsg messageToValidate:"+messageToValidate+"--arrWarningsCV:"+arrWarningsCV+"--firstCal:"+firstCal);
    
    
   /* bootbox.alert(messageToValidate, function()
                  {
                  benefit_flag_update ="0";
                  console.log("benefit_flag_update--"+benefit_flag_update);
                  canSwipe=1;
                  if(arrWarningsCV!="")
                  {
                  arrWarningsCV =arrWarningsCV.substring(arrWarningsCV.indexOf(':')+1);
                  console.log("arrWarningsCV inside cv:"+arrWarningsCV);
                  fnValidateOfPrusaver(pagedata,arrWarningsCV,obj_mainlife_response,obj_prodchoice_res,pagedata,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,firstCal,jsonLeftPanel,"");
                  
                  //break;
                  }
                  else
                  {
                  
                  fnCallOutputAfterValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mainlife_response,obj_prodchoice_res,iSelectedRiderCount,bFirstCallFlag);
                  }
                  });*/
    if(messageToValidate!="")
    {
    bootbox.alert({
                   message: messageToValidate,
                   className:'anbalert',
                   buttons: {
                   ok: {
                   label: 'OK',
                   }
                   },
                   callback: function(){
                   canSwipe=1;
                   if(arrWarningsCV!="")
                   {
                   arrWarningsCV =arrWarningsCV.substring(arrWarningsCV.indexOf(':')+1);
                   console.log("arrWarningsCV inside cv:"+arrWarningsCV);
                   fnValidateOfPrusaver(pagedata,arrWarningsCV,obj_mainlife_response,obj_prodchoice_res,pagedata,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,firstCal,jsonLeftPanel,"");
                   
                   //break;
                   }
                   else
                   {
                   
                   fnCallOutputAfterValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mainlife_response,obj_prodchoice_res,iSelectedRiderCount,bFirstCallFlag);
                   }
                   }
                   });
    }
    else
    {
        if(arrWarningsCV!="")
        {
            arrWarningsCV =arrWarningsCV.substring(arrWarningsCV.indexOf(':')+1);
            console.log("arrWarningsCV inside cv:"+arrWarningsCV);
            fnValidateOfPrusaver(pagedata,arrWarningsCV,obj_mainlife_response,obj_prodchoice_res,pagedata,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,firstCal,jsonLeftPanel,"");
            
            //break;
        }
    }
    

    
    
    
}



function fnCallSetFuncAfterAllChoice(per_valid_res,VPMSRiderJson,VPMSRiderTerm,A_Master_Product_Master_key_response,pagedata1,CheckShift)
{
    
    localStorage.setItem("current_plan",currentPlan);
    console.log("currentPlan:"+currentPlan);
    console.log("canEnterCampaign:"+canEnterCampaign);
    var air_asia_campaign="";
    var querySelect=getCampaignDataForAirAsia(currentPlan); //Abhilash
    var isCampaignActive=false;
    querySelect.execute(function(air_asia_response){
    if(air_asia_response!="{}" && air_asia_response!="")
    {
                        
          var obj=JSON.parse(air_asia_response);
            for(sub in obj){
                campaignExpDate=obj[sub]['expiry_date'];
                campaignEffeDate=obj[sub]['effective_date'];
                if(checkDateIsBetTwoDates(campaignEffeDate,campaignExpDate,fnGetDateTimeStamp())==true){
                        isCampaignActive=true;
                        campaignname=obj[sub]['campaign_name'];
                        
                         air_asia_campaign =  _.where(obj, {"campaign_name":obj[sub]['campaign_name']});
                        console.log("air_asia_campaign"+ JSON.stringify(air_asia_campaign));
                }
            }
                        
    }
                        
    js_set_var("air_asia_campaign",JSON.stringify(air_asia_campaign),function()
    {
    
    localStorage.setItem("current_plan",currentPlan);
    console.log("currentPlan:"+currentPlan);
    
    js_set_var("hideshowrider",JSON.stringify(per_valid_res),function()
               {
               js_set_var("VPMSRiderJson",JSON.stringify(VPMSRiderJson),function()
                          {
                          js_set_var("VPMSRiderTerm",JSON.stringify(VPMSRiderTerm),function()
                                     {
                                     js_set_var("szPlaneCode",JSON.stringify(_.invert(JSON.parse(A_Master_Product_Master_key_response)[pagedata1["VPMSFunctionNameInSequence"]])),function()
                                                
                                                {
                                                console.log("arrayBundleProduct:"+arrayBundleProduct);
                                                if(arrayBundleProduct.indexOf("PRUCritical Protect")!=-1)
                                                {
                                                   fnFetchBundleProductList(CheckShift,"PRUCritical Protect");
                                                }
                                                else
                                                {
                                                
                                                
                                                
                                               if(CheckShift=="Swp_Module")
                                                {
                                                
                                                //abhilash
                               
                                                    console.log("getCampaignDataForAirAsia"+JSON.stringify(air_asia_campaign));
                                                 var campaignname="";
                                                    if(air_asia_campaign!="{}" && air_asia_campaign!="")
                                                    {
                                                   
                                                var obj2 = air_asia_campaign;
                                                console.log("obj2",obj2);
                                                    for(sub in obj2){
                                                    campaignExpDate=obj2[sub]['expiry_date'];
                                                    campaignEffeDate=obj2[sub]['effective_date'];
                                                
                                                
                                                    if(checkDateIsBetTwoDates(campaignEffeDate,campaignExpDate,fnGetDateTimeStamp())==true)
                                                        {
                                                        campaignProductName=obj2[sub]['product_name'];
                                                        campaignname=obj2[sub]['campaign_name'];
                                                        }
                                                    }
                                                
                                                                                             
                                                    if(checkDateIsBetTwoDates(campaignEffeDate,campaignExpDate,fnGetDateTimeStamp())==true)
                                                    {
                                                        if((currentPlan==campaignProductName) && (insu_type_for_nav == "individual"|| (campaignname=="upsize2" || campaignname=="platinum"))){
                                                        console.log("going to campaign vpmsjs");
                                                        menuController.loadPage("top_mysolutions_campaign",0);
                                                        }
                                                        else{
                                                        menuController.loadPage("top_mysolutions_benefit_selection",0);
                                                        }
                                                    }
                                                    else{
                                                    menuController.loadPage("top_mysolutions_benefit_selection",0);
                                                    }
                                                }
                                                else{
                                                //menuController.loadPage("top_mysolutions_benefit_selection",0); // commented by abhilash for air asia
                                                // added by Abhilash for air asia: swipe to campaign if true else swipe to benefit selection
                                                
                                                        menuController.loadPage("top_mysolutions_benefit_selection",0);
                                                   
                                                }
 
                                                
                                                }
                                                else if(CheckShift=="Ext_Module")
                                                {
                                                    menuController.done();
                                                }
                                                else
                                                {
                                                   console.log("stopSpinner ProcessEngineResult")
                                                   stopSpinner();//added by ankita on 3 oct 2019
                                                }
                                                }
                                                
                                                
                                                });
                                     });
                          });
               
               
               
               });//
                        });
                        });
}

function fnSetChoiceDropdownPayoutPeriod(payoutperiodId,pagedataChoiceFunction,callFromFlag,fnSetPayoutPeriodDropdownCallFrom)
{
               console.log("payoutperiodId-->"+payoutperiodId +"callFromFlag"+callFromFlag +"fnSetPayoutPeriodDropdownCallFrom-->"+fnSetPayoutPeriodDropdownCallFrom);
   js_get_var("beneft_selection_response", function(ben_selection_res)
        {
         var obj_ben_sel="";
               if(ben_selection_res != "" && ben_selection_res != null && ben_selection_res != "null"  && ben_selection_res != "(null)")
               {
                obj_ben_sel = JSON.parse(ben_selection_res);
               }
                      console.log("obj_ben_sel11-->"+JSON.stringify(obj_ben_sel));
               // js_get_var("SetDropDownPayoutPeriod_flag", function(SetDDvalueOnload_PayoutPeriod)
                                                          // {
                           //console.log("SetDDvalueOnload_PayoutPeriod-->"+typeof SetDDvalueOnload_PayoutPeriod);
                           //console.log("SetDDvalueOnload_PayoutPeriod-->"+ SetDDvalueOnload_PayoutPeriod);
    pagedataChoiceFunction["setvar"][callFromFlag]= document.getElementById(payoutperiodId).value;
    console.log("Age value income:"+document.getElementById(payoutperiodId).value);
    if(callFromFlag=="A_Master_Payout_Age_key" || callFromFlag=="A_Master_Accumulation_Period_key")
    {
               console.log("in both-->");
        pagedataChoiceFunction["VPMSFunctionNameInSequence"]=["A_Master_Payout_Period_key"];
    }
    else
    {
               console.log("in elsee-->");
        pagedataChoiceFunction["VPMSFunctionNameInSequence"]=["A_Master_Payout_Age_key"];
    }
    
    
    
    
   console.log("pagedataChoiceFunction == "+JSON.stringify(pagedataChoiceFunction));
    
    js_call_native_func("VPMSCall",pagedataChoiceFunction,function(responsechoice)
                        {
                        console.log("responsechoice:1"+responsechoice);
                        var responseParsing = JSON.parse(responsechoice);
                        var objresponsechoice = (responseParsing[pagedataChoiceFunction["VPMSFunctionNameInSequence"]]);
                        console.log("objresponsechoice:2"+objresponsechoice);
                        console.log("objresponsechoice:3"+JSON.stringify(objresponsechoice));
                        var sortedArr=[];
                        for(sub in objresponsechoice)
                        {
                            console.log("sub choice:1->"+sub);
                            sortedArr.push(sub);
                            console.log("sortedArr:"+sortedArr);
                        }
                        var dropdownppt;
                        if(callFromFlag=="A_Master_Payout_Age_key")
                        {
                           console.log("12345678 Income");
                        
                        if(currentPlan == "PRUSignature Reserve")
                                               {
                                               document.getElementById("al_sqs_details.reserve_payout_period").options.length=0;
                                                   dropdownppt=document.getElementById("al_sqs_details.reserve_payout_period");
                                               }
                        else
                        {
                            document.getElementById("al_sqs_details.prusignature_income_payout_period").options.length=0;
                            dropdownppt=document.getElementById("al_sqs_details.prusignature_income_payout_period");
                        }
                        }//def 9000 else if
                        else if(callFromFlag=="A_Master_Accumulation_Period_key")
                        {
                        console.log("sfdsf-->");
                            document.getElementById("al_sqs_details.payout_period").options.length=0;
                            dropdownppt=document.getElementById("al_sqs_details.payout_period");
                        }
                        
                        
                        else
                        {
                            document.getElementById("al_sqs_details.prusignature_income_payout_age").options.length=0;
                            dropdownppt=document.getElementById("al_sqs_details.prusignature_income_payout_age");
                        }
                       
                        console.log("dropdownppt--->"+dropdownppt);
                        var optn=document.createElement("option");
                        optn.value="0";
                         if(currentPlan == "PRUSignature Reserve")
                        {
                        optn.text="Payout Period";
                        }
                        else{
                        optn.text="Select";
                        }
                        dropdownppt.appendChild(optn);
                        for(var i=sortedArr.length-1;i>=0;i--)
                        {
                            console.log("sortedArr[i]"+sortedArr[i]);
                            var optn1=document.createElement("option");
                            optn1.value=sortedArr[i];
                            optn1.text=sortedArr[i];
                            dropdownppt.appendChild(optn1);
                        }
                        
                       // if((obj_ben_sel["al_sqs_details.accumulation_period"]!="" && obj_ben_sel["al_sqs_details.accumulation_period"]!="0" && obj_ben_sel["al_sqs_details.accumulation_period"]!="Select" && obj_ben_sel["al_sqs_details.accumulation_period"]!=undefined &&  obj_ben_sel["al_sqs_details.accumulation_period"]!="undefined") && SetDDvalueOnload_PayoutPeriod == true)
                                                                 //if(SetDDvalueOnload_PayoutPeriod == true || SetDDvalueOnload_PayoutPeriod == "true")     {
                        if(fnSetPayoutPeriodDropdownCallFrom == "OnLoad"){
                                                                      console.log("in fdskfj-->");
                                                                          document.getElementById("al_sqs_details.payout_period").value=obj_ben_sel["al_sqs_details.payout_period"];
                                                                      }
                        });
 });
             // });
}

function fnCallChoiceFunctionVPMSForCancerX(per_valid_res,VPMSRiderJson,VPMSRiderTerm,A_Master_Product_Master_key_response,pagedata1,CheckShift,pagedataChoiceFunction)
{
    pagedataChoiceFunction["VPMSFunctionNameInSequence"]=["A_Master_Sum_Assured_key"];
    console.log("pagedata PRUcancer X == "+JSON.stringify(pagedataChoiceFunction));
    js_call_native_func("VPMSCall",pagedataChoiceFunction,function(responsechoice)
                        {
                            
                            var responseParsing = JSON.parse(responsechoice);
                            var objresponsechoice = (responseParsing[pagedataChoiceFunction["VPMSFunctionNameInSequence"]]);
                           
                            
                            VPMSArrayForEachChoiceFunctionCancerX = [];
                            for(sub in objresponsechoice)
                            {
                            
                            VPMSArrayForEachChoiceFunctionCancerX.push(objresponsechoice[sub]);
                            
                            }
                        
                        
                            fnCallSetFuncAfterAllChoice(per_valid_res,VPMSRiderJson,VPMSRiderTerm,A_Master_Product_Master_key_response,pagedata1,CheckShift)
                        });
}

function fnValidateEaseCampaignMessageB(pagedata)
{
    
    var strSingleValidationError ="";
    bootbox.confirm({
                    
                    message: "The maximum Essential Child Plus Sum Assured for EASE is RM100,000.Click on EASE to proceed to reduce the Sum Assured to RM100,000 or below.Click on Health Questionnaires to continue with Sum Assured > RM100,000.",
                    className: 'my-popup',
                    buttons: {
                    cancel: {
                    label: '<i class="fa fa-check"></i>EASE',
                    className: 'btn-default'
                    
                    },
                    confirm: {
                    label: '<i class="fa fa-times"></i>Health Questionnaires',
                    className: 'btn-default'
                    }
                    },
                    callback: function (result)
                    {
                    
                    canSwipe=0;
                    benefit_flag_update ="1";
                    if(result==true)
                    {
                    console.log("result=="+result);
                    canSwipe=1;
                    console.log("vpmsEaseCampaignCode before:"+vpmsEaseCampaignCode);
                    vpmsEaseCampaignCode="";
                    console.log("vpmsEaseCampaignCode after:"+vpmsEaseCampaignCode);
                    pagedata["setvar"]["A_Master_Campaign_key"]=vpmsEaseCampaignCode;
                   
                    }
                    else
                    {
                    console.log("vpmsEaseCampaignCode in else:"+vpmsEaseCampaignCode);
                    pagedata["setvar"]["A_Master_Campaign_key"]=vpmsEaseCampaignCode;
                    console.log("benefit_flag_update--"+benefit_flag_update);
                    canSwipe=1;
                    
                    }
                    }});
    
    
}

function fnValidateEaseCampaignMessageC(pagedata)
{
    //change number from 14 to 13 in the alert message for pruwith you new rider mom and baby care on 22 nov 2022
    bootbox.alert({
                    
                    message: "<p class=\"text-left\">The maximum Essential Child Plus Sum Assured for EASE is RM100,000.To proceed with EASE application, please reduce Essential Child Plus Sum Assured to RM100,000 or below.<br />Otherwise, submit the application with Health Questionnaires completed from Gestational Week 13 onwards. </p>",
                    className: 'my-popup',
                    callback: function ()
                    {
                        canSwipe=1;
                        pagedata["setvar"]["A_Master_Campaign_key"]=vpmsEaseCampaignCode;
                    
                    }
                    });
    
}
//Added by ankita to set currency key in VPMS input on 26 sept 2018
function fnGetCurrencyKey(prod_name)
{
    var querySelect=new DbUtil();
    querySelect.query()
    .select()
    .column('product_currency')
    .from()
    .table('al_product_master')
    .where()
    .clause('product_name','=',prod_name);
    return querySelect;
}


function fnCampaignBonusCheck(pagedata,messageToValidate,obj_mainlife_response,obj_prodchoice_res,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel)
{
    console.log("messageToValidate:"+messageToValidate);
    bootbox.alert({
                  
                  message:messageToValidate,
                  className: 'my-popup',
                  callback: function ()
                  {
                  benefit_flag_update ="0";
                  canSwipe=1;
                  fnCallOutputAfterValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mainlife_response,obj_prodchoice_res,iSelectedRiderCount,bFirstCallFlag)
                  
                  }
                  });
    
}



/*******************************************************
 Function Name:fnCallOutputAfterBundleValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,iSelectedRiderCount,bFirstCallFlag)
 Function Description: validation for sb accumulator product.
 Parameters:
 Created By: Sachin
 Created On: 8-2-2019.
 Modified By:
 Modified On:
 Modification Reason:
 *******************************************************/

function  fnCallOutputAfterBundleValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,iSelectedRiderCount,bFirstCallFlag)
{
    bundlePage=pagedata;
    iSelectedBundleRiderCount=iSelectedRiderCount;
    var jsonAllOutput = {};
    var PRUallocatorPremiumValue = "0";
    var checkFirstCal = document.getElementById("al_sqs_details.min_insurance_premium").value;
    console.log("Paromita iSelectedRiderCount In fnCallOutputAfterValidation -->"+iSelectedRiderCount);
    console.log("decided function")
    console.log("flag value"+benefit_flag_update);
    benefit_flag_noupdate ="0";
    benefit_flag_update="0";
    product_flag_update="0";
    mlife_flag_update="0";
    slife_flag_update="0";
    tlife_flag_update="0";
    
    loading_flag_update = 0;
    loading_flag_noupdate = 0;
    console.log("flag2---"+benefit_flag_update);
    console.log("NO ERROR");
    
    
    bundlePage["VPMSFunctionNameInSequence"] = ["P_Calculate_Premium_out"];
    
    js_call_native_func("VPMSCall",bundlePage,function(resP_Calculate_Premium_out)
                        {
                        
                        console.log("resP_SI_Section02_PRUterm_out-->" +resP_Calculate_Premium_out)
var jsonresP_Calculate_Prem_Sustain_out = JSON.parse(resP_Calculate_Premium_out);
                        var objresP_Calculate_Prem_Sustain_out = jsonresP_Calculate_Prem_Sustain_out[pagedata["VPMSFunctionNameInSequence"]];
                        bundlePage["VPMSFunctionNameInSequence"]=["P_Calculate_Premium_out","P_SI_Product_Disclosure_out","P_SI_Section01_Details_out","P_SI_Section01_Details_out_Block2","P_SI_Section02_Details_out","P_SI_Section03_Details_out","P_SI_Section04_Details_out","P_SI_Section05_Details_out","P_SI_Section06_Details_out","P_SI_Section07_Details_out","P_SI_Section08_Details_out","P_SI_Section09_Details_out","P_SI_Section10_Details_out","P_SI_Section11_Details_out","P_SI_Section02_PRUterm_out","P_SI_Section12_Details_out","P_Calculate_FlexiWithdrawal_out","P_SI_Section14_Details_out","P_SI_Section13_Details_out","P_SI_Section15_Details_out","P_SI_Section16_Details_out","P_SI_Section17_Details_out","P_SI_Section18_Details_out","P_SI_Section19_Details_out"];

                        js_call_native_func("VPMSCall",bundlePage,function(resP_Calculate_Premium_out)
                                                {
                        
                        jsonAllOutput = JSON.parse(resP_Calculate_Premium_out);

                        jsonAllOutput["P_Calculate_Prem_Sustain_out"]=objresP_Calculate_Prem_Sustain_out;
                                                console.log("jsonAllOutput-->" +JSON.stringify(jsonAllOutput))
 
                        console.log("jsonAllOutput-->" +jsonAllOutput)
                        
                        var jsonEngineOutputBundle = fnBundleParseTableOutput(jsonAllOutput,iSelectedRiderCount);
                        
                       var   obj_global_engine = jsonEngineOutputBundle;
                      var   global_response  = JSON.stringify(jsonEngineOutputBundle);
                        console.log("jsonEngineOutputBundle"+ JSON.stringify(jsonEngineOutputBundle));
                        
                        
                        
                        
                        var benefit_update_data_flags = {
                        "benefit_flag_update": benefit_flag_update
                        }
                        
                        var product_update_data_flags = {
                        "product_flag_update": product_flag_update
                        }
                        var personal_update_data_flags = {
                        "mlife_flag_update": mlife_flag_update,
                        "slife_flag_update": slife_flag_update,
                        "tlife_flag_update": tlife_flag_update
                        }
                        
                        var loading_update_data_flagss = {
                        "loading_flag_update": 0,
                        "loading_flag_noupdate": 0
                        }
                        js_set_var("loading_update_flags", JSON.stringify(loading_update_data_flagss), function()
                                   {
                                   js_set_var("benefit_update_flags",JSON.stringify(benefit_update_data_flags),function()
                                              {
                                              js_set_var("product_update_flags",JSON.stringify(product_update_data_flags),function()
                                                         {
                                                         js_set_var("personal_update_flags", JSON.stringify(personal_update_data_flags), function()
                                                                    {
                                                                    js_get_var("benefit_update_flags_database", function(update_benefit_res)
                                                                               {
                                                                               var obj_update_personal_database_insert = JSON.parse(update_benefit_res);
                                                                               console.log("update_benefit_res bundle:"+obj_update_personal_database_insert["benefit_flag_update"])
                                                                               
                                                                               var benefit_update_data_flags_insert = {
                                                                               "benefit_flag_update": obj_update_personal_database_insert["benefit_flag_update"]
                                                                               }
                                                                               
                                                                    console.log("benefit_update_data_flags_insert bundle:"+benefit_update_data_flags_insert["benefit_flag_update"]);           js_set_var("benefit_update_flags_database_for_insert", JSON.stringify(benefit_update_data_flags_insert), function()
                                                                                          {
                                                                                                                                                                                                          js_set_var("bunldle_output_response",JSON.stringify(jsonEngineOutputBundle),function()
                                                                                                                                                                                                          {
                                                                                                                                                                                                                      js_get_var("bunldle_output_response",function(bundle_outputOject)
                                                                                                                                                                                                                                {
                                                                                          
                                                                    //31 jan 2023                //fnBundleOutPutResonse(jsonEngineOutput,flag_cals,loadingflag_generate,callfrom,obj_prochoice);
                                                                                                                                                                                                                     var totalResponse = JSON.parse(bundle_outputOject);
                                                                                                                                                                                                                     console.log("totalResponse:"+JSON.stringify(totalResponse));
                                                                                                                                                                                                                     var totalPrem=parseFloat(totalResponse[3]["Premium"]).toFixed(2);//Pradnya: added tofixed for def 1359 for March24 release
                                                                                                                                                                                                                                 var policyTerm=totalResponse[3]["Basic_PRUCritical_Protect_PolTerm"];
                                                                                                                                                                                                                     console.log("totalPrem:"+totalPrem);
                                                                  console.log("policyTerm:"+policyTerm);                                                                                                                                                               document.getElementById("al_rider_sqs.prusignature_ppr1.rider_premium").value=totalPrem;

                                                                                         totalPrem=parseFloat(totalPrem).toFixed(2);                               console.log("total premium:"+totalPrem);                 document.getElementById("al_sqs_details.totals_premium_ppr1").value=totalPrem;                                          console.log("total premium:"+document.getElementById("al_sqs_details.totals_premium_ppr1").value);                                              document.getElementById("al_rider_sqs.prusignature_ppr1.rider_term").value=policyTerm;

                                                                                  // fnMnMapServiceTaxForKeyman(totalPrem);
                                                          /***********************Added for defect 718 for bundle by Sachin*******************************************************/
var premiumToPay_bundle={};
if(obj_mlife["al_person_details.mlife.insu_type"] != "" &&  obj_mlife["al_person_details.mlife.insu_type"] != undefined && obj_mlife["al_person_details.mlife.insu_type"] != null && obj_mlife["al_person_details.mlife.insu_type"] != "(null)"){

 if(obj_mlife["al_person_details.mlife.insu_type"] == "keyman" || obj_mlife["al_person_details.mlife.insu_type"] == "employee" ||obj_mlife["al_person_details.mlife.insu_type"] == "partnership" || obj_mlife["al_person_details.mlife.insu_type"] == "Business Loan Insurance (for Company/LLP)"  || obj_mlife["al_person_details.mlife.insu_type"] == "Business Loan Insurance (for Sole Proprietorship/Partnership)" ){
     
                    if(arrayBundleProduct.indexOf("PRUCritical Protect") !=-1){
                        var premium_bundle=document.getElementById("al_rider_sqs.prusignature_ppr1.rider_premium").value
                       console.log("premium_bundle",premium_bundle);
                        var SSTRateBundle = parseFloat(document.getElementById("config_value_bundle").innerHTML) * 0.01;//Pradnya: added above bundle ids for def 1310,1311
                        var totalPremiumValuecomp_bundle_val=parseFloat(premium_bundle).toFixed(2);
                       $("#totalPremiumValuecomp_bundle").text(totalPremiumValuecomp_bundle_val);
                       var tempcomp = parseFloat(premium_bundle) * parseFloat(SSTRateBundle);
                       $("#taxValuecomp_bundle").text(parseFloat(Math.round(tempcomp*Math.pow(10,2))/Math.pow(10,2)).toFixed(2));
                       var totaltaxplusprem = parseFloat(tempcomp) + parseFloat(premium_bundle)
                       document.getElementById("al_person_details.total_tax_plus_prem_bundle").value=""+parseFloat(Math.round(totaltaxplusprem*Math.pow(10,2))/Math.pow(10,2)).toFixed(2);
                                                                                                                   
                    premiumToPay_bundle = {
                        "total_tax_plus_prem_bundle":parseFloat(Math.round(totaltaxplusprem*Math.pow(10,2))/Math.pow(10,2)).toFixed(2),
                        "taxValuecomp_bundle":parseFloat(Math.round(tempcomp*Math.pow(10,2))/Math.pow(10,2)).toFixed(2),
                        "totalPremiumValuecomp_bundle":parseFloat(premium_bundle).toFixed(2),
                          "taxDynamic_bundle":document.getElementById("config_value_bundle").innerHTML,
                       }
                            
                     
                       }




 }



}

                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 
                                                               /***********************************************************************/
                                                                                                                                                                                                                                 document.getElementById("al_rider_sqs.prusignature_ppr1.rider_term").value=policyTerm;
if (currentPlan == "PRUSignature Plus")
{
    pagedata["setvar"]["A_Rider_Sum_Assured_rea[0]"] = document.getElementById("al_rider_sqs.prusignature_ppr1.rider_premium").value;
    pagedata["setvar"]["A_Master_Premium_Term_key[1]"] = document.getElementById("al_sqs_details.premium_payment_period_plm_plus").value;
    
}
                                                                                                                                                                                                                                 
                                                                     var isbundleValue="Yes";
                                                                                            js_set_var("premiumToPay_bundle",JSON.stringify(premiumToPay_bundle),function()
                                                                                                {                                                                                          js_set_var("bunldle_product_flag",isbundleValue,function()
                                              {
                                                                                                                                                                                                                                                                                                                      var riderStringforBI_bundle= "al_rider_sqs.basic_plan.rider_name=basic_plan;;"
                                                                          +"al_rider_sqs.basic_plan.rider_term="+document.getElementById("al_rider_sqs.prusignature_ppr1.rider_term").value+";;"
                                                                   +"al_sqs_details.expiry_age=100;;"
                                                                                                                                                                                                                                            +"al_rider_sqs.basic_plan.rider_value="+$(escape_jq("al_rider_sqs.basic_plan_prusignature.rider_expiry_age_ppr1")).val()+";;"
                                                                          
                                                                          +"al_rider_sqs.basic_plan.rider_premium="+document.getElementById("al_rider_sqs.prusignature_ppr1.rider_premium").value+";;::";
                                                                          

                                                                                                                                                                                                                                            js_set_var("rider_data_string_bundle",JSON.stringify(riderStringforBI_bundle),function()
                                                                                                           {
                                                                                                                                                                                                                                                        var dap_flag = getCheckBoxValueAspire("al_sqs_details.premium_lump_sum");
                                                                          var dap_res="";
                                                                          if(dap_flag == "TRUE")
                                                                          {
                                                                          dap_res = 1;
                                                                          }else if(dap_flag == "FALSE")
                                                                          {
                                                                          dap_res = 0;
                                                                          }
                                                                                                                                                                                                                                                       //var fullpayIndicator="";
                                                                           //var ////fullpayoption=document.getElementById("al_rider_sqs.premium_payment_period_ppr1").value;
                                                                          
                                                                          
                                                                          
                                                                         // var fpValue=fullpayoption.options[fullpayoption.selectedIndex];
                                                                                                                                                                                                                                                       
                                                                         // var fullIndicatorVal=fpValue.value.split("_")[0]
                                                                          
                                                                         // var fullpayvalue=fpValue.text;
                                                                         // if(fullpayvalue=="Full pay"){
                                                                          
                                                                         // fullpayIndicator="Yes";
                                                                          
                                                                          
                                                                          //}
                                                                          var cal_vals ={
                                                                          "al_sqs_details.subChannel":"1",
                                                                          "al_sqs_details.premium_payment_term":document.getElementById("al_rider_sqs.premium_payment_period_ppr1").value,
                                                                          
                                                                          "al_sqs_details.dap_flag":dap_res,
                                                                          "al_sqs_details.cash_payout_option":"",
                                                                          "al_sqs_details.traditional_flag":"1",
                                                                          "al_sqs_details.gst_payable":document.getElementById("al_sqs_details.gst_payable").value,
                                                                          "al_sqs_details.survival_benefit_option1" :"",
                                                                          "al_sqs_details.survival_benefit_option2" :"",
                                                                          "al_sqs_details.survival_benefit_option3" :"",
                                                                                                                                                                                                                                                       "al_sqs_details.total_premium":document.getElementById("al_sqs_details.totals_premium_ppr1").value
                                                                          }
                                                                                                                                    js_set_var("cal_data_string_bundle",JSON.stringify(cal_vals),function()
                                                                                     {
                                                                                                                                               
                                                                            //populateContriValues(jsonEngineOutputBundle,flag_cals,loadingflag_generate,callfrom);
                                                                          });
                                                                                                                                                                                                                                                       
                                                                                   });
                                                                                                                                                                                                                                            });
                                                         });
                                                                                          });
                                                                                                                                                                                                                     });
                                                                                                                                                                                                          });
                                                                               });
                                                                    //});
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    });
                                                         });
                                              });
                                   });
                                   });
                        
                        
                        });//
    
    
    

    

}


/*******************************************************
 Function Name:fnBundleOutPutResonse(jsonEngineOutput,flag_cals,loadingflag_generate,callfrom)
 Function Description: provide extract paramaters to SB accumulator.
 Parameters:
 Created By: Sachin
 Created On: 8-2-2019.
 Modified By:
 Modified On:
 Modification Reason:
 *******************************************************/


function fnBundleOutPutResonse(jsonEngineOutput,flag_cals,loadingflag_generate,callfrom,obj_prochoice)
{
    callfromfromBundleOutput=false;

    //console.log("Policy term:"+bundleGlobalFund[4].PRUSignature_Optimiser_PolTerm);
   // bundlePage["setvar"]["A_SB_Allocator_Term_int"]=bundleGlobalFund[4].PRUSignature_Optimiser_PolTerm;
    //bundlePage["setvar"]["A_SB_Allocator_Prem_rea"]= bundleGlobalFund[3].Survival_Benefit_Income_Val;
    
    
    var iFundsCount=0;
   /* for (var sub in bunddleFundArray)
    {
        var fundValue=bundleFundRes[sub];
        
        if(fundValue != "0")
        {
            
            bundlePage["setvar"]["A_ILP_Fund_value_rea["+iFundsCount+"]"]=fundValue;
            bundlePage["setvar"]["A_Master_ILP_Fund_key["+iFundsCount+"]"]=bunddleFundArray[sub];
            
            iFundsCount++;
        }
        
    }
    bundlePage["setvar"]["A_Code_ILP_Fund_Source_key"]="";
    bundlePage["setvar"]["A_Nof_fund_int"] = iFundsCount.toString();*/
    
    
    bundlePage["VPMSFunctionNameInSequence"]=["P_Calculate_Premium_out","P_SI_Product_Disclosure_out","P_SI_Section01_Details_out","P_SI_Section01_Details_out_Block2","P_SI_Section02_Details_out","P_SI_Section03_Details_out","P_SI_Section04_Details_out","P_SI_Section05_Details_out","P_SI_Section06_Details_out","P_SI_Section07_Details_out","P_SI_Section08_Details_out","P_SI_Section09_Details_out","P_SI_Section10_Details_out","P_SI_Section11_Details_out","P_SI_Section02_PRUterm_out","P_SI_Section12_Details_out","P_SI_Section13_Details_out"];
    console.log("@@bundlePage Response"+JSON.stringify(bundlePage));
    
    js_call_native_func("VPMSCall",bundlePage,function(bundle_resP_Calculate_Premium_out)
                        {
                        
                        
                        console.log("resP_SI Final Engine output all Response-->booster  bundle_resP_Calculate_Premium_out"+bundle_resP_Calculate_Premium_out);
                        
                        jsonAllOutput = JSON.parse(bundle_resP_Calculate_Premium_out);
                        callfromfromBundleOutput=true;
                        bundleJsonOutput=jsonAllOutput;
                        console.log("Bundle jsonAllOutput"+jsonAllOutput);

                        
                        
                        var jsonEngineBundleOutput = fnParseTableOutput(jsonAllOutput,iSelectedBundleRiderCount,obj_prochoice);
                        console.log("Final Engine Output booster jsonEngineBundleOutput"+JSON.stringify(jsonEngineBundleOutput));
                        
                        js_set_var("bunldle_output_response",JSON.stringify(jsonEngineBundleOutput),function()
                                   {
                                   var isbundleValue="Yes";
                                   js_get_var("bunldle_output_response",function(bundle_outputOject)
                                              {
                                   
                                              var totalResponse = JSON.parse(bundle_outputOject);
                                              console.log("totalResponse:"+JSON.stringify(totalResponse));
                                              var totalPrem=totalResponse[3]["PRUCritical_Protect_Prem"];
                                              console.log("totalPrem:"+totalPrem);
                                             // var SusLow=dataHighLow[5]["Sustainability_Code_High"];
                                             // console.log("SusHigh"+SusHigh);
                                              // console.log("SusLow"+SusLow);
                                              
                                              
                                   
                                   js_set_var("bunldle_product_flag",isbundleValue,function()
                                              {
                                   
                                    populateContriValues(jsonEngineOutput,flag_cals,loadingflag_generate,callfrom);
                                   
                                              });
                                              });
                                   //
                                   });
                        
                        
                        });
    




}

/*******************************************************
 Function Name:fnBundleParseTableOutput(jsonAllOutput,iSelectedRiderCount)
 Function Description: Create key tag.
 Parameters:
 Created By: Sachin
 Created On: 8-2-2019.
 Modified By:
 Modified On:
 Modification Reason:
 *******************************************************/
function fnBundleParseTableOutput(jsonAllOutput,iSelectedRiderCount)
{
                console.log("In fnParseTableOutput")
                var inifiniteJSON ="";
                var jsonEngineOutputComplete ={};
                var product_output_json_1 = setJson();
                console.log("JSON name:"+product_output_json_1[localStorage.getItem("current_plan")]);
                console.log("currentPlan==>"+currentPlan);
                console.log("bundleCurrentPlan==>"+bundleCurrentPlan);
                
                if(bundleCurrentPlan!="") //Added for SB Accumulator product on date  6-2-2019 by Sachin.
                {
                inifiniteJSON = product_output_json_1[bundleCurrentPlan];
                }else
                {
                inifiniteJSON = product_output_json_1[localStorage.getItem("current_plan")];
                }
               //added by ankita on 25 jan 2023 for bundle product
                inifiniteJSON = product_output_json_1["PRUCritical Protect"];
                console.log("inifiniteJSON:"+JSON.stringify(inifiniteJSON));
               for(sub in inifiniteJSON)
               {
                   
                   var iColumnlength = inifiniteJSON[sub]["Length"];
                   var iRiderCountLength=inifiniteJSON[sub]["Length"];
                   
                   if(iColumnlength == "iRiderCount")
                   {
                       var saverRiderCount = 0;
                       var extraRiderCount = 0;
                       if(document.getElementById("al_rider_sqs.prusaver.id").checked || document.getElementById("al_rider_sqs.prusaver_kid.id").checked)
                       {
                           saverRiderCount++;
                       }
                       if(document.getElementById("al_rider_sqs.enhanced_prue_child.id").checked == true && document.getElementById("al_rider_sqs.crisis_care.id").checked != true)
                       {
                           extraRiderCount++;
                       }
                       
                       iColumnlength = ((iSelectedRiderCount - saverRiderCount + extraRiderCount) * 2) + 6;
                       if(document.getElementById("al_rider_sqs.crisis_guard.id").checked == true && (currentPlan == "PRUWealth Plus" || currentPlan == "PRUWealth Max" || currentPlan == "PRUWealth Enrich") )
                       {
                           iColumnlength=iColumnlength+2;
                       }
                       
                   }
                   
                   if(inifiniteJSON[sub]["outputResult"] == "RiderPremium")
                   {
                       jsonEngineOutputComplete[inifiniteJSON[sub]["EngineOutIndex"]]=fnParseRiderPremium(jsonAllOutput[inifiniteJSON[sub]["FunctionName"]]["result"]);
                   }
                   else if(inifiniteJSON[sub]["outputResult"].indexOf("PDS") != -1  || inifiniteJSON[sub]["outputResult"].indexOf("PDSBundleProd") != -1)
                   {
                       var PDSOutputFunction = inifiniteJSON[sub]["FunctionName"];
                       console.log("PDSOutputFunction"+PDSOutputFunction);
                       var splitOutput = PDSOutputFunction.split(";")
                       console.log("splitOutput"+splitOutput);
                       var outputStringPDS = "";
                       for(var iPDSCounter = 0; iPDSCounter < splitOutput.length; iPDSCounter++)
                       {
                           console.log("splitOutput[iPDSCounter]"+splitOutput[iPDSCounter]);
                           var PDSOutputFunction = jsonAllOutput[splitOutput[iPDSCounter]]
                           console.log("PDSOutputFunction"+PDSOutputFunction);
                           //var objPDS = JSON.parse(PDSOutputFunction)
                           var objPDS = (PDSOutputFunction)
                           console.log("objPDS:"+objPDS);
                           if(objPDS != undefined && objPDS != "undefined")
                           {
                               if(splitOutput[iPDSCounter] == "P_SI_Section02_PRUterm_out")
                               {
                                   outputStringPDS = outputStringPDS.concat("PRUterm;");
                                   console.log("outputStringPDS1:"+outputStringPDS);
                               }
                               console.log("objPDS result:"+objPDS["result"]);
                               outputStringPDS = outputStringPDS.concat(objPDS["result"]);
                               console.log("outputStringPDS2:"+outputStringPDS);
                               outputStringPDS = outputStringPDS.concat(";");
                               console.log("outputStringPDS3:"+outputStringPDS);
                           }
                           
                       }
                       
                       if(inifiniteJSON[sub]["outputResult"] == "PDSOldProduct")
                       {
                            arrPDS = [];
                            var iCount=0;
                            for(iCount= 0; iCount <= 50;iCount++) //previous it was 46 added last two index for CR 8878
                            {
                            var arrofEachPDSElement = [];
                            arrofEachPDSElement.push("0");
                            arrPDS.push(arrofEachPDSElement);
                            
                            }
                           jsonEngineOutputComplete[inifiniteJSON[sub]["EngineOutIndex"]]=fnParsePDSOldProduct(outputStringPDS);
                       }
                       else
                       {
                           jsonEngineOutputComplete[inifiniteJSON[sub]["EngineOutIndex"]]=fnParseOutputPDS(inifiniteJSON[sub]["ColumnName"],outputStringPDS);
                       }
                       
                       console.log("Engine Output"+jsonEngineOutputComplete[inifiniteJSON[sub]["EngineOutIndex"]]);
                   }
                   else if(inifiniteJSON[sub]["outputResult"] == "szDynamicRiderTable")
                   {
                       
                       console.log("In szDynamicRiderTable"+jsonAllOutput[inifiniteJSON[sub]["FunctionName"]]);
                       console.log("iColumnlength:"+iColumnlength);
                       jsonEngineOutputComplete[inifiniteJSON[sub]["EngineOutIndex"]] = fnParseDynamicColumnOutput(jsonAllOutput[inifiniteJSON[sub]["FunctionName"]],inifiniteJSON[sub]["ColumnName"],iColumnlength);
                   }
                   else
                   {
                       
                       var tableOutputFunction = inifiniteJSON[sub]["FunctionName"];
                       var skipTagFromResponse = inifiniteJSON[sub]["skipTagFromResponse"];
                       var parseTableFunction = inifiniteJSON[sub]["parseTableFunction"];
                       console.log("skipTagFromResponse:"+skipTagFromResponse);
                       var splitTableOutput = tableOutputFunction.split(";")
                       var outputStringTable = "";
                       for(var iTableCounter = 0; iTableCounter < splitTableOutput.length; iTableCounter++)
                       {
                           console.log("splitTableOutput[iTableCounter]--->"+splitTableOutput[iTableCounter])
                           var tableOutput = jsonAllOutput[splitTableOutput[iTableCounter]];
                           console.log("tableOutput--->"+tableOutput)
                           //var objTable = JSON.parse(tableOutput);
                           var objTable = (tableOutput);
                           console.log("objTable[\"result\"]=----"+objTable["result"])
                           outputStringTable = outputStringTable.concat(objTable["result"]);
                           outputStringTable = outputStringTable.concat(";");
                           console.log("outputStringTable"+outputStringTable)
                       }
                       console.log("outputStringTable : "+outputStringTable);
                       console.log("inifiniteJSON[sub][\"ColumnName\"] : "+inifiniteJSON[sub]["ColumnName"]);
                       console.log("iColumnlength : "+iColumnlength);
                      
                       jsonEngineOutputComplete[inifiniteJSON[sub]["EngineOutIndex"]] = fnParseOutputIntoTable(outputStringTable,inifiniteJSON[sub]["ColumnName"],iColumnlength,skipTagFromResponse,iRiderCountLength,parseTableFunction);
                       
                       
                   }
                   
               }
                           
              /* jsonEngineOutputComplete={"2":[["29610"]],"3":{"Sustainability_Code _High":"67777","Sustainability_Code _Low":"67777","Death_Benefit":"500000","%_of_Prem_Paid":"0","Survival_Benefit_Income_FROM":"1","Survival_Benefit_Income_TO":"17","Survival_Benefit_Income_Val":"25000","Survival_Benefit_Income_%_of_Sum_Assured":"0.05","Waiver_Benefit_Waiver_Assured":"0","Waiver_Benefit_Waiver_Parent":"0","Waiver_Benefit_Waiver_Spouse":"0","Maturity_Benefit_Maturity_Benefit":"500000","Maturity_Benefit_%_of_Sum_Assured":"100","Total_Premium_Payable":"1776600","Premium":"29610","Payment_Term":"5","Total_Prem":"29610","GST":"0","Prem_Prem":"355320","Prem_PremTerm":"5","Prem_TotalPrem":"1776600","Prem_Prem_1":"1776600","Prem_PremTerm_1":"20","Prem_TotalPrem_1":"88830","Grand_Total":"1776600","Coverage_Period":"20","Total_Commission":"88830","Gtd_Death_&_TPD_Year_1":"355320","Gtd_Death_&_TPD_Year_5":"1676600","Gtd_Death_&_TPD_Year_10":"1551600","Gtd_Death_&_TPD_Year_15":"1426600","Gtd_Death_&_TPD_Year_20":"1575000","Gtd_Death_&_TPD_Year_25":"0","Gtd_Death_&_TPD_Year_30":"0","Gtd_Death_&_TPD_Year_35":"0","Gtd_Death_&_TPD_Year_40":"0","Accidental_Death_&_TPD":"0","Gtd_Yearly_Cash_Payout_FROM":"1","Gtd_Yearly_Cash_Payout_TO":"17","Gtd_Yearly_Cash_Payout_Val":"25000","Gtd_Critical_Illness":"0","Gtd_Waiver_Assured":"0","Gtd_Waiver_Spouse":"0","Gtd_Waiver_Parent":"0","Gtd_Maturity":"500000","Total_Cash_Received_X":"0","Total_Cash_Received_Y":"0","Non_Gtd_Maturity_X":"0","Non_Gtd_Maturity_Y":"739454","Gtd_Return":"1.27","Non_Gtd_Return_X":"1.27","Non_Gtd_Return_Y":"3.18","PRUterm_Prem":"17521","PRUterm_PremTerm":"1","PRUterm_TotalPrem":"17521","PRUterm_Coverage_Period":"20","PRUterm_Total_Commission":"1752","PRUterm_Gtd_Death_&_TPD":"355320","Policy_Term":"0","Premium_Term":"0","First_Year_Premium":"0","Discount_Advanced_Premium_in_One_Lump_Sum":"0","Total_Premium":"0","X_Years":"0","Year_From":"0","Year_To":"0","Annual_Premium":"0","Gtd_Maturity_Benefit":"500000","Total_Maturity_Benefit_X":"1575000","Total_Maturity_Benefit_Y":"2314454","Cash_Payment_at_Maturity":"500000"},"4":{"GST_Policy_Year_From":"1","GST_Policy_Year_To":"5","GST_Yearly":"336495","GST_Half_Yearly":"169930","GST_Quarterly":"86645","GST_Monthly":"29610","GST_Policy_Year_From_1":"29610","GST_Policy_Year_To_1":"0"},"5":{"Survival_Benefit_Income_FROM":"1","Survival_Benefit_Income_TO":"17","Survival_Benefit_Income_Val":"25000","Survival_Benefit_Income_%_of_Sum_Assured":"0.05","Survival_Benefit_Income_FROM_1":"18","Survival_Benefit_Income_TO_1":"19","Survival_Benefit_Income_Val_1":"75000","Survival_Benefit_Income_%_of_Sum_Assured_1":"0.15","Survival_Benefit_Income_FROM_2":"20","Survival_Benefit_Income_TO_2":"20","Survival_Benefit_Income_Val_2":"1075000","Survival_Benefit_Income_%_of_Sum_Assured_2":"2.15","Gtd_Yearly_Cash_Payout_FROM":"1","Gtd_Yearly_Cash_Payout_TO":"17","Gtd_Yearly_Cash_Payout_Val":"25000","Gtd_Yearly_Cash_Payout_FROM_1":"18","Gtd_Yearly_Cash_Payout_TO_1":"19","Gtd_Yearly_Cash_Payout_Val_1":"75000","Gtd_Yearly_Cash_Payout_FROM_2":"20","Gtd_Yearly_Cash_Payout_TO_2":"20","Gtd_Yearly_Cash_Payout_Val_2":"1075000"}};*/
               
                            return jsonEngineOutputComplete;
                
                
                

}



function getCampaignDataForAirAsia(currentPlan)
{
    var querySelect=new DbUtil();
    querySelect.query()
    .select()
    .column('*')
    .from()
    .table('al_product_level_campaign')
    .where()
    .clause('product_name','=',currentPlan)
    //.and()
    //.clause('campaign_name','=','AirAsia Big Points');
    return querySelect;
}

                            
//Added by ankita to set currency key in VPMS input on 26 sept 2018
function fnGetProductMaster(prod_name)
{
    var querySelect=new DbUtil();
    querySelect.query()
    .select()
    .column('*')
    .from()
    .table('al_product_master')
    .where()
    .clause('product_name','=',prod_name);
    return querySelect;
}


function fnChangeProductCodeValue(jsonEngineOutput)
{
    jsonEngineOutput = JSON.stringify(jsonEngineOutput)
    jsonEngineOutput = jsonEngineOutput.replace(/ILS6/g,"IL06");
    jsonEngineOutput = jsonEngineOutput.replace(/STS8/g,"ST08");
    jsonEngineOutput = jsonEngineOutput.replace(/ALS2/g,"AL02");
    jsonEngineOutput = JSON.parse(jsonEngineOutput)
    return jsonEngineOutput;
}


function fnShowTargetSustainAlert(pagedata,messageToValidate,obj_mainlife_response,obj_prodchoice_res,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel)
{
    var szErrorCode = messageToValidate.split(":")[0];
    var strErrorMessage = messageToValidate.split(":")[1];
    var strFinalErrorMessage = strErrorMessage.split("//")[0];
    var reduceAge = strErrorMessage.split("//")[1];
     var checkFirstCal = document.getElementById("al_sqs_details.min_insurance_premium").value;
    var targetSustainabilityValue=pagedata["setvar"]["A_Code_TargetSust_key"];
    console.log("fnShowWarningMsg messageToValidate:"+messageToValidate+"   strErrorMessage"+strErrorMessage);
                                                         
//Added for defect 1173 by Sachin T.
var msg_maintain_selection='<span class="reduce fa fa-check">Maintain my selection</span>';
var msg_maintain_sustain='<span class="fa fa-times"></span>I want to improve target sustainability';
  //Added for defect 1173 by Sachin T.
 if(currentPlan!="PRUwith you"){
  msg_maintain_selection='<span class="reduce fa fa-check">Proceed with reduced sustainability age</span>';
  msg_maintain_sustain='<span class="fa fa-times"></span>Maintain my selected sustainability age';
 
 }
                                                         
                                                         
    if(szErrorCode.indexOf('V294')!= -1 || szErrorCode.indexOf('V294')!= "-1")
    {
        
    bootbox.confirm({


                    className: "my-popup marginleft19 widthMod",
                    message: "<p class=\"text-left\">"+strFinalErrorMessage+"</p>",
                    buttons: {
                
                    confirm: {
                   // label: '<span class="reduce fa fa-check">Proceed with reduced sustainability age</span>',//Changed for CR-18419 by Sachin T.
                    label: msg_maintain_selection,
                    
                    className: 'btn-default'
                    },
                    cancel: {
                   // label: '<span class="fa fa-times"></span>Maintain my selected sustainability age',//Changed for CR-18419 by Sachin T
                    label: msg_maintain_sustain,
                    className: 'btn-default'
                    }
                    },
                    callback: function (result)
                    {
                    canSwipe=1;
                    if(result==true)
                    {
                        var oldVPMSFunctionNameInSequence = pagedata["VPMSFunctionNameInSequence"];
                        pagedata["VPMSFunctionNameInSequence"] = ["P_Calculate_Prem_Sustain_out"];
                        js_call_native_func("VPMSCall",pagedata,function(respP_Calculate_Prem_Sustain_out)
                        {
                        pagedata["VPMSFunctionNameInSequence"] = ["P_Calculate_Premium_out"];
                        js_call_native_func("VPMSCall",pagedata,function(respP_Calculate_Premium_out)
                        {
                        //console.log("objresponsechoice:"+objresponsechoice);
                        console.log("respP_Calculate_Prem_Sustain_out:"+JSON.stringify(respP_Calculate_Prem_Sustain_out)+" respP_Calculate_Premium_out:"+JSON.stringify(respP_Calculate_Premium_out));
                        
                        pagedata["VPMSFunctionNameInSequence"]=["A_Master_Premium_Term_key"];
                        pagedata["VPMSCallType"]="choice";
                    
                        if(jsonLeftPanel != "" && (pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS2" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL08" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS3" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL14"  || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL16" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL24"))
                        {
                        //added by ankita on 8 may 2019 for pruwealth plus product
                        if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25")
                        {
                    
                            document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").readOnly = false;
                            document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").disabled=false;
                        }
                        else if(pagedata["setvar"]["A_Master_Product_Master_Key"] != "ILS3" && pagedata["setvar"]["A_Master_Product_Master_Key"] != "IL14" && pagedata["setvar"]["A_Master_Product_Master_Key"] != "IL24")//added condition for defect 7951 on 22 July 2019 by ankita
                        {
                            document.getElementById("al_sqs_details.insurance_premium").readOnly = false;
                            document.getElementById("al_sqs_details.insurance_premium").disabled=false;
                        }
                        //document.getElementById("al_sqs_details.insurance_premium").readOnly = false;
                        //document.getElementById("al_sqs_details.insurance_premium").disabled=false;
                            console.log("before if")
                        if(checkFirstCal == null || checkFirstCal == "" || checkFirstCal == "NA" || checkFirstCal == "undefined" || checkFirstCal== "0")
                        {   console.log("after if")
                            //added by ankita on 8 may 2019 for pruwealth plus product
                            if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25")
                            {
                            document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").value = jsonLeftPanel["MinimumInsurance"];
                            }
                            else
                            {
                            document.getElementById("al_sqs_details.insurance_premium").value = jsonLeftPanel["MinimumInsurance"];
                                
                            }
                            //document.getElementById("al_sqs_details.insurance_premium").value = jsonLeftPanel["MinimumInsurance"];
                        }
                        document.getElementById("al_sqs_details.total_premium_plm_plus").value = jsonLeftPanel["TotPrem"];
                        document.getElementById("al_sqs_details.min_insurance_premium").value = jsonLeftPanel["MinimumInsurance"];
                        document.getElementById("al_sqs_details.max_insurance_premium").value = jsonLeftPanel["MaximumInsurance"];
                        document.getElementById("al_sqs_details.project_sustainability_age_high").value = jsonLeftPanel["PolSustAgeHigh"];
                        document.getElementById("al_sqs_details.project_sustainability_age_low").value = jsonLeftPanel["PolSustAgeLow"];
                        }
                        pagedata["setvar"]["A_Master_ILP_TargetSust_key"] = "A"+reduceAge;
                        pagedata["setvar"]["A_Code_TargetSust_key"] = reduceAge;
						js_call_native_func("VPMSCall",pagedata,function(responsechoice)
                                   {
									    var responseParsing = JSON.parse(responsechoice);
										var objresponsechoice = (responseParsing[pagedata["VPMSFunctionNameInSequence"]]);
										console.log("objresponsechoice:"+objresponsechoice);
										console.log("objresponsechoice:"+JSON.stringify(objresponsechoice));
										var PremiumTerm = objresponsechoice[pagedata["setvar"]["A_Master_Premium_Term_key"]];
                                        
                                        if(PremiumTerm == "undefined" || PremiumTerm == undefined || PremiumTerm == "null" || PremiumTerm == "(null)" || PremiumTerm == null || PremiumTerm == '')
                                        {
                                            if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25")
                                            {
                                                PremiumTerm = (_.invert(objresponsechoice)["Full pay"]).split("_")[0];
                                                szFullPayIndicator  = "Yes";
                                            }
                                            else
                                            {
                                               PremiumTerm = "";
                                            }
                                        }
                                    
                                        console.log("PremiumTerm---"+PremiumTerm+" reduceAge---"+reduceAge);
										//pagedata["setvar"]["A_Master_ILP_TargetSust_key"] = "A"+reduceAge;
                                        if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25")
                                        {
                                            pagedata["setvar"]["A_Master_Premium_Term_key"] = PremiumTerm;
                                        }
                                        pagedata["VPMSCallType"]="compute";
										targetSustainabilityFlag = "Yes";
                                        console.log("before fnCallOutputAfterValidation"+JSON.stringify(pagedata));
                                        js_set_var("reduceAge", reduceAge, function()
                                                       {
                                                   js_set_var("reducedPremiumTerm", PremiumTerm, function()
                                                              {
                                                   js_set_var("firstAge", targetSustainabilityValue, function()
                                                     {
                                                              js_set_var("respP_Calculate_Prem_Sustain_out", respP_Calculate_Prem_Sustain_out, function()
                                                                         {
                                                                         js_set_var("respP_Calculate_Premium_out", respP_Calculate_Premium_out, function()
                                                                                    {
                                                                                    bFirstCallFlag = false;
                                                                                    //document.getElementById("al_sqs_details.min_insurance_premium").value ="";
                                                                                    
                                                                                    //pagedata["setvar"]["A_Budget_Premium_rea"] = "0";
                                                                                    //pagedata["setvar"]["A_Budget_Exc_Premium_rea"] = "0";
                                                                                    js_set_var("SupportingDocPreview","No",function()
                                                                                               {
                                                                                                js_set_var("EmailPreview","No",function()
                              {
                                                                                    fnCallValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mainlife_response,obj_prochoice,iSelectedRiderCount,bFirstCallFlag,jsonLeftPanel)
                                                                                                           });
                                                                                               });
                                                              //fnCallOutputAfterValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mainlife_response,obj_prodchoice_res,iSelectedRiderCount,bFirstCallFlag);
                                                                                    });
                                                                         });
                                                   
                                                   });
                                                       });
                                                   });
									});

                        console.log("benefit_flag_update--"+benefit_flag_update);
                                                            });
                                        });
                    }
                    else
                    {
                        targetSustainabilityFlag = "No";
                        benefit_flag_update ="1";
                    szNegativeCashValueFlag = "No";
                    
                    //added by ankita on 10 jan 2020 for defect 8934
                    pagedata["VPMSFunctionNameInSequence"] = ["P_Calculate_Prem_Sustain_out"];
                    console.log("pageData:"+JSON.stringify(pagedata));
                    
                    //Added for solution prufirst by sachin T.
//                    if(obj_solution["al_sqs_buttons_plan"]=="al_sqs_buttons.prufirst"){
//
//                       document.getElementById("al_rider_sqs.pruacci_guard.rider_value").disabled=true;
//                       document.getElementById("al_rider_sqs.pruacci_med.rider_value").disabled=true;
//
//                    }
                    
                    
                    js_call_native_func("VPMSCall",pagedata,function(resP_Calculate_Prem_Sustain_out)
                    {
                          console.log("resP_Calculate_Prem_Sustain_out-->" +resP_Calculate_Prem_Sustain_out);

                          var jsonresP_Calculate_Prem_Sustain_out = JSON.parse(resP_Calculate_Prem_Sustain_out);
                          var objresP_Calculate_Prem_Sustain_out = jsonresP_Calculate_Prem_Sustain_out[pagedata["VPMSFunctionNameInSequence"]];
                          console.log("objresP_Calculate_Prem_Sustain_out"+JSON.stringify(objresP_Calculate_Prem_Sustain_out));
                          var objSplitP_Calculate_Prem_Sustain_out = objresP_Calculate_Prem_Sustain_out["result"].split(";")
                          console.log("objSplitP_Calculate_Prem_Sustain_out"+objSplitP_Calculate_Prem_Sustain_out);
                          
                              if(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeHigh") != -1)
                              {
                                  jsonLeftPanel["PolSustAgeHigh"] =  objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeHigh"))+1];
                              }
                              else
                              {
                                  jsonLeftPanel["PolSustAgeHigh"] = "0";
                              }
                              if(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeLow") != -1)
                              {
                                  jsonLeftPanel["PolSustAgeLow"] =  objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeLow"))+1];
                              }
                              else
                              {
                                  jsonLeftPanel["PolSustAgeLow"] = "0";
                              }
                    if(objSplitP_Calculate_Prem_Sustain_out.indexOf("MaxInsPrem") != -1 && objSplitP_Calculate_Prem_Sustain_out.indexOf("InsPrem") != -1)
                                {
                                    jsonLeftPanel["InsurancePremium"] =  Math.min(objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("InsPrem"))+1],objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("MaxInsPrem"))+1]);
                                }
                                else
                                {
                                    jsonLeftPanel["InsurancePremium"] = "0";
                                }
                                if(objSplitP_Calculate_Prem_Sustain_out.indexOf("MaxBUAPrem") != -1)
                                {
                                    jsonLeftPanel["MaxBUAPrem"] =  objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("MaxBUAPrem"))+1];
                                }
                                else
                                {
                                    jsonLeftPanel["MaxBUAPrem"] = "0";
                                }
                                        
                    fnbreakPremium(pagedata,strErrorMessage,obj_mainlife_response,obj_prodchoice_res,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel);
                                        });
					}
                    }});

    }
    else if(szErrorCode.indexOf('VW09')!= -1 || szErrorCode.indexOf('VW09')!= "-1")
    {
        bootbox.confirm({
                        className: "my-popup marginleft19 widthModWarning",
                        message: "<p class=\"text-left\">"+strFinalErrorMessage+"</p>",
                        buttons: {
                        
                        
                        cancel: {
                        label: '<span class="fa fa-times">Amend my selected sustainability option </span>',
                        className: 'btn-default'
                        },
                        confirm: {
                        label: '<span class="reduce fa fa-check">Maintain my selected target sustainability option </span>',
                        className: 'btn-default'
                        }
                        },
                        callback: function (result)
                        {
                        canSwipe=1;
                        if(result==true)
                        {
                            targetSustainabilityFlag = "Yes";
                            //added by ankita on 10 jan 2020 for defect 8934
                            pagedata["VPMSFunctionNameInSequence"] = ["P_Calculate_Prem_Sustain_out"];
                            console.log("pageData:"+JSON.stringify(pagedata));
                            
                            
                            js_call_native_func("VPMSCall",pagedata,function(resP_Calculate_Prem_Sustain_out)
                            {
                                  console.log("resP_Calculate_Prem_Sustain_out def 8934 fnshowtargetsustainalert-->" +resP_Calculate_Prem_Sustain_out);

                                  var jsonresP_Calculate_Prem_Sustain_out = JSON.parse(resP_Calculate_Prem_Sustain_out);
                                  var objresP_Calculate_Prem_Sustain_out = jsonresP_Calculate_Prem_Sustain_out[pagedata["VPMSFunctionNameInSequence"]];
                                  console.log("objresP_Calculate_Prem_Sustain_out"+JSON.stringify(objresP_Calculate_Prem_Sustain_out));
                                  var objSplitP_Calculate_Prem_Sustain_out = objresP_Calculate_Prem_Sustain_out["result"].split(";")
                                  console.log("objSplitP_Calculate_Prem_Sustain_out"+objSplitP_Calculate_Prem_Sustain_out);
                                  
                                     
                                      
                            if(jsonLeftPanel != "" && (pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS2" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL08" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS3" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL14" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL16" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL24"))
                            {
                            //added by ankita on 8 may 2019 for pruwealth plus product
                            if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25")
                            {
                        
                            document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").readOnly = false;
                            document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").disabled=false;
                            }
                            else if(pagedata["setvar"]["A_Master_Product_Master_Key"] != "ILS3" && pagedata["setvar"]["A_Master_Product_Master_Key"] != "IL14" && pagedata["setvar"]["A_Master_Product_Master_Key"] != "IL24")//added condition for defect 7951 on 22 July 2019 by ankita
                            {
                            document.getElementById("al_sqs_details.insurance_premium").readOnly = false;
                            document.getElementById("al_sqs_details.insurance_premium").disabled=false;
                            }
                            
                            if(checkFirstCal == null || checkFirstCal == "" || checkFirstCal == "NA" || checkFirstCal == "undefined" || checkFirstCal== "0")
                            {
                            //added by ankita on 8 may 2019 for pruwealth plus product
                            if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25")
                            {
                            document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").value = jsonLeftPanel["MinimumInsurance"];
                            }
                            else
                            {
                            document.getElementById("al_sqs_details.insurance_premium").value = jsonLeftPanel["MinimumInsurance"];
                            }
                            
                            }
                            
                            if(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeHigh") != -1)
                            {
                                jsonLeftPanel["PolSustAgeHigh"] =  objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeHigh"))+1];
                            }
                            else
                            {
                                jsonLeftPanel["PolSustAgeHigh"] = "0";
                            }
                            if(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeLow") != -1)
                            {
                                jsonLeftPanel["PolSustAgeLow"] =  objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeLow"))+1];
                            }
                            else
                            {
                                jsonLeftPanel["PolSustAgeLow"] = "0";
                            }
                        
                            document.getElementById("al_sqs_details.total_premium_plm_plus").value = jsonLeftPanel["TotPrem"];
                            document.getElementById("al_sqs_details.min_insurance_premium").value = jsonLeftPanel["MinimumInsurance"];
                            document.getElementById("al_sqs_details.max_insurance_premium").value = jsonLeftPanel["MaximumInsurance"];
                            document.getElementById("al_sqs_details.project_sustainability_age_high").value = jsonLeftPanel["PolSustAgeHigh"];
                            document.getElementById("al_sqs_details.project_sustainability_age_low").value = jsonLeftPanel["PolSustAgeLow"];
                            }
                        fnCallOutputAfterValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mainlife_response,obj_prodchoice_res,iSelectedRiderCount,bFirstCallFlag);
                            console.log("benefit_flag_update--"+benefit_flag_update);
                                                });
                        
                        }
                        else
                        {
                            targetSustainabilityFlag = "No";
                            if(jsonLeftPanel != "" && (pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS2" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL08" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS3" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL14" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL16" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL24"))
                            {
                            //added by ankita on 8 may 2019 for pruwealth plus product
                            if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25")
                            {
                            
                            document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").readOnly = false;
                            document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").disabled=false;
                            }
                            else if(pagedata["setvar"]["A_Master_Product_Master_Key"] != "ILS3" && pagedata["setvar"]["A_Master_Product_Master_Key"] != "ILS3")//added condition for defect 7951 on 22 July 2019 by ankita
                            {
                            document.getElementById("al_sqs_details.insurance_premium").readOnly = false;
                            document.getElementById("al_sqs_details.insurance_premium").disabled=false;
                            }
                            
                            if(checkFirstCal == null || checkFirstCal == "" || checkFirstCal == "NA" || checkFirstCal == "undefined" || checkFirstCal== "0")
                            {
                            //added by ankita on 8 may 2019 for pruwealth plus product
                            if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25")
                            {
                            document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").value = jsonLeftPanel["MinimumInsurance"];
                            }
                            else
                            {
                            document.getElementById("al_sqs_details.insurance_premium").value = jsonLeftPanel["MinimumInsurance"];
                            }
                            
                            }
                        
                        //added by ankita on 10 jan 2020 for defect 8934
                      pagedata["VPMSFunctionNameInSequence"] = ["P_Calculate_Prem_Sustain_out"];
                      console.log("pageData:"+JSON.stringify(pagedata));
                      
                      
                      js_call_native_func("VPMSCall",pagedata,function(resP_Calculate_Prem_Sustain_out)
                      {
                            console.log("resP_Calculate_Prem_Sustain_out def 8934 fnshowtargetsustainalert-->" +resP_Calculate_Prem_Sustain_out);

                            var jsonresP_Calculate_Prem_Sustain_out = JSON.parse(resP_Calculate_Prem_Sustain_out);
                            var objresP_Calculate_Prem_Sustain_out = jsonresP_Calculate_Prem_Sustain_out[pagedata["VPMSFunctionNameInSequence"]];
                            console.log("objresP_Calculate_Prem_Sustain_out"+JSON.stringify(objresP_Calculate_Prem_Sustain_out));
                            var objSplitP_Calculate_Prem_Sustain_out = objresP_Calculate_Prem_Sustain_out["result"].split(";")
                            console.log("objSplitP_Calculate_Prem_Sustain_out"+objSplitP_Calculate_Prem_Sustain_out);
                            
                               
                                if(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeHigh") != -1)
                                {
                                    jsonLeftPanel["PolSustAgeHigh"] =  objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeHigh"))+1];
                                }
                                else
                                {
                                    jsonLeftPanel["PolSustAgeHigh"] = "0";
                                }
                                if(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeLow") != -1)
                                {
                                    jsonLeftPanel["PolSustAgeLow"] =  objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeLow"))+1];
                                }
                                else
                                {
                                    jsonLeftPanel["PolSustAgeLow"] = "0";
                                }
                            document.getElementById("al_sqs_details.total_premium_plm_plus").value = jsonLeftPanel["TotPrem"];
                            document.getElementById("al_sqs_details.min_insurance_premium").value = jsonLeftPanel["MinimumInsurance"];
                            document.getElementById("al_sqs_details.max_insurance_premium").value = jsonLeftPanel["MaximumInsurance"];
                            document.getElementById("al_sqs_details.project_sustainability_age_high").value = jsonLeftPanel["PolSustAgeHigh"];
                            document.getElementById("al_sqs_details.project_sustainability_age_low").value = jsonLeftPanel["PolSustAgeLow"];
                                          });
                            }
                        }
                        }});
    }
    else
    {
       
        bootbox.alert({
                      
                      message:strFinalErrorMessage,
                      className: 'my-popup',
                      callback: function ()
                      {
                      benefit_flag_update ="1";
                      canSwipe=1;
                      szNegativeCashValueFlag = "No";
                      //added by ankita on 10 jan 2020 for defect 8934
                      pagedata["VPMSFunctionNameInSequence"] = ["P_Calculate_Prem_Sustain_out"];
                      console.log("pageData:"+JSON.stringify(pagedata));
                      
                      
                      js_call_native_func("VPMSCall",pagedata,function(resP_Calculate_Prem_Sustain_out)
                      {
                            console.log("resP_Calculate_Prem_Sustain_out-->" +resP_Calculate_Prem_Sustain_out);

                            var jsonresP_Calculate_Prem_Sustain_out = JSON.parse(resP_Calculate_Prem_Sustain_out);
                            var objresP_Calculate_Prem_Sustain_out = jsonresP_Calculate_Prem_Sustain_out[pagedata["VPMSFunctionNameInSequence"]];
                            console.log("objresP_Calculate_Prem_Sustain_out"+JSON.stringify(objresP_Calculate_Prem_Sustain_out));
                            var objSplitP_Calculate_Prem_Sustain_out = objresP_Calculate_Prem_Sustain_out["result"].split(";")
                            console.log("objSplitP_Calculate_Prem_Sustain_out"+objSplitP_Calculate_Prem_Sustain_out);
                            
                                if(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeHigh") != -1)
                                {
                                    jsonLeftPanel["PolSustAgeHigh"] =  objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeHigh"))+1];
                                }
                                else
                                {
                                    jsonLeftPanel["PolSustAgeHigh"] = "0";
                                }
                                if(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeLow") != -1)
                                {
                                    jsonLeftPanel["PolSustAgeLow"] =  objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("PolSustAgeLow"))+1];
                                }
                                else
                                {
                                    jsonLeftPanel["PolSustAgeLow"] = "0";
                                }
                            

                                          if(objSplitP_Calculate_Prem_Sustain_out.indexOf("MaxInsPrem") != -1 && objSplitP_Calculate_Prem_Sustain_out.indexOf("InsPrem") != -1)
                                                      {
                                                          jsonLeftPanel["InsurancePremium"] =  Math.min(objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("InsPrem"))+1],objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("MaxInsPrem"))+1]);
                                                      }
                                                      else
                                                      {
                                                          jsonLeftPanel["InsurancePremium"] = "0";
                                                      }
                                                      if(objSplitP_Calculate_Prem_Sustain_out.indexOf("MaxBUAPrem") != -1)
                                                      {
                                                          jsonLeftPanel["MaxBUAPrem"] =  objSplitP_Calculate_Prem_Sustain_out[parseInt(objSplitP_Calculate_Prem_Sustain_out.indexOf("MaxBUAPrem"))+1];
                                                      }
                                                      else
                                                      {
                                                          jsonLeftPanel["MaxBUAPrem"] = "0";
                                                      }
                                                        
                            fnbreakPremium(pagedata,strErrorMessage,obj_mainlife_response,obj_prodchoice_res,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel);
                      
                      });
                      
                      }
                      });
        
    }
    
}


function fnbreakPremium(pagedata,strErrorMessage,obj_mainlife_response,obj_prodchoice_res,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel)
{
    var firstCal = document.getElementById("al_sqs_details.min_insurance_premium").value;
    console.log("strErrorMessage11:"+strErrorMessage);
    var res = strErrorMessage.split("//")[2];
    console.log("res11:"+res);
    var res = res.split("RM")[1];
    console.log("res22:"+res);
    var res1 = res.replace(/,/g,'');
    console.log("res1:"+res1);
    var recommendedPremium = res1.substring(0,res1.length-1)
    console.log("recommendedPremium--"+recommendedPremium)
    szNegativeCashValueFlag = "No";
    var PRUsaver = "";
    
    if(document.getElementById("al_rider_sqs.prusaver_kid.id").checked)
    {
        PRUsaver = document.getElementById("al_rider_sqs.prusaver_kid.rider_premium").value;
    }
    else if(document.getElementById("al_rider_sqs.prusaver.id").checked)
    {
        PRUsaver = document.getElementById("al_rider_sqs.prusaver.rider_premium").value;
    }
    else
    {
        PRUsaver = 0;
    }
    
    if(document.getElementById("al_sqs_details.pruallocator_premium").value != "" && document.getElementById("al_sqs_details.pruallocator_premium").value != 0  )
    {
        jsonLeftPanel["PRUallocatorPremium"] = document.getElementById("al_sqs_details.pruallocator_premium").value;
    }
    else
    {
        jsonLeftPanel["PRUallocatorPremium"] = 0;
    }
    
    //Added this below code for def 7574
    
    jsonLeftPanel["PRUallocatorPremium"] = 0;
    
    console.log("PRUsaver--"+PRUsaver+ " recommendedPremium---"+ recommendedPremium + " jsonLeftPanel[\"PRUallocatorPremium\"]--"+jsonLeftPanel["PRUallocatorPremium"]);
    //var X = parseFloat(recommendedPremium) - parseFloat(jsonLeftPanel["PRUallocatorPremium"]) - parseFloat(PRUsaver);
    
    var X = parseFloat(recommendedPremium) - parseFloat(PRUsaver);
    
    console.log("X--"+X + " jsonLeftPanel[\"MaximumInsurance\"]"+jsonLeftPanel["MaximumInsurance"])
    var Basic=0;
    var investmentPremiumVal=0;
    var PRUallocatorPremium = 0;
    if(X > jsonLeftPanel["MaximumInsurance"])
    {
        Basic = jsonLeftPanel["MaximumInsurance"];
        if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS3" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL14" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25"
           || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL24")
        {
            //PRUallocatorPremium = X - parseFloat(jsonLeftPanel["MaximumInsurance"]) + parseFloat(jsonLeftPanel["PRUallocatorPremium"]);
            PRUallocatorPremium = X - parseFloat(jsonLeftPanel["MaximumInsurance"]);
            investmentPremiumVal = parseFloat(PRUsaver);
               console.log("PRUallocatorPremium111:"+PRUallocatorPremium);
        }
        else
        {
            
            investmentPremiumVal = X - parseFloat(jsonLeftPanel["MaximumInsurance"]) + parseFloat(PRUsaver);
        }
    }
    else
    {
        Basic = X;
        investmentPremiumVal =  PRUsaver;
    }
    console.log("Basic--"+Basic+ " investmentPremiumVal--"+investmentPremiumVal+ " PRUallocatorPremium--"+PRUallocatorPremium);
    //var investmentPremiumVal = res2;
    
    document.getElementById("al_sqs_details.investment_premium").value =investmentPremiumVal;
    
    if(obj_mainlife_response["al_person_details.pre_natal_child_flg"] == "Yes" || obj_prodchoice_res["al_sqs_details.mlife.il_anb"]<=18)
    {
        
        if(document.getElementById("al_rider_sqs.prusaver_kid.id").checked)
        {
            document.getElementById("al_rider_sqs.prusaver_kid.rider_premium").value =investmentPremiumVal;
            
            document.getElementById("al_rider_sqs.prusaver_kid.payout_age").disabled=false;
            document.getElementById("al_rider_sqs.prusaver_kid.rider_premium").disabled=false;
            document.getElementById("al_rider_sqs.prusaver_kid.rider_premium").readOnly = false;
        }
        else if(document.getElementById("al_rider_sqs.prusaver.id").checked)
        {
            document.getElementById("al_rider_sqs.prusaver.rider_premium").value =investmentPremiumVal;
            document.getElementById("al_rider_sqs.prusaver.rider_premium").disabled=false;
            document.getElementById("al_rider_sqs.prusaver.rider_premium").readOnly = false;
            
        }
        else if(investmentPremiumVal != 0)
        {
            
            document.getElementById("al_rider_sqs.prusaver_kid.id").checked = true;
            document.getElementById("al_rider_sqs.prusaver_kid.rider_premium").value =investmentPremiumVal;
            if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25")
            {
                var PremiumPaymentTerm = (document.getElementById("al_sqs_details.premium_payment_period_pw_plus").value).split("_")[0];
                document.getElementById("al_rider_sqs.prusaver_kid.rider_term").value = Math.min(PremiumPaymentTerm,document.getElementById("al_rider_sqs.prusaver_kid.payout_age").value- obj_prochoice["al_sqs_details.mlife.il_anb"]);
            }
            else
            {
                document.getElementById("al_rider_sqs.prusaver_kid.rider_term").value =Math.min(document.getElementById("al_rider_sqs.basic_plan.rider_term").value,document.getElementById("al_rider_sqs.prusaver_kid.payout_age").value- obj_prochoice["al_sqs_details.mlife.il_anb"]);
            }
            
            document.getElementById("al_rider_sqs.prusaver_kid.rider_expiry_age").value = 100;
            document.getElementById("al_rider_sqs.prusaver_kid.payout_age").disabled=false;
            document.getElementById("al_rider_sqs.prusaver_kid.rider_premium").disabled=false;
            document.getElementById("al_rider_sqs.prusaver_kid.rider_premium").readOnly = false;
        }
    }
    else if(investmentPremiumVal != 0)
    {
        document.getElementById("al_rider_sqs.prusaver.id").checked = true;
        document.getElementById("al_rider_sqs.prusaver.rider_premium").value =investmentPremiumVal;
        if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25")
        {
            var PremiumPaymentTerm = (document.getElementById("al_sqs_details.premium_payment_period_pw_plus").value).split("_")[0];
            document.getElementById("al_rider_sqs.prusaver.rider_term").value =PremiumPaymentTerm;
        }
        else
        {
            document.getElementById("al_rider_sqs.prusaver.rider_term").value = document.getElementById("al_rider_sqs.basic_plan.rider_term").value;
        }
        
        document.getElementById("al_rider_sqs.prusaver.rider_expiry_age").value = 100;
        document.getElementById("al_rider_sqs.prusaver.rider_premium").disabled=false;
        document.getElementById("al_rider_sqs.prusaver.rider_premium").readOnly = false;
        
        
    }
    
    if(PRUallocatorPremium !=0)
    {
        szPRUallocatorPremiumAvailable  = "Yes";
        document.getElementById("al_sqs_details.pruallocator_premium").value = parseFloat(PRUallocatorPremium).toFixed(2);
        document.getElementById("al_rider_sqs.pruallocator.rider_premium").value = parseFloat(PRUallocatorPremium).toFixed(2); //Def 7482
        if((document.getElementById("al_sqs_details.premium_payment_period_pw_plus").value) != "undefined" && (document.getElementById("al_sqs_details.premium_payment_period_pw_plus").value) != undefined && (document.getElementById("al_sqs_details.premium_payment_period_pw_plus").value) != "null" && (document.getElementById("al_sqs_details.premium_payment_period_pw_plus").value) != null && (pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25"))
        {
            document.getElementById("al_rider_sqs.pruallocator.rider_term").value = (document.getElementById("al_sqs_details.premium_payment_period_pw_plus").value).split("_")[0];
        }
        if((document.getElementById("al_sqs_details.premium_payment_period_plm_plus").value) != "undefined" && (document.getElementById("al_sqs_details.premium_payment_period_plm_plus").value) != undefined && (document.getElementById("al_sqs_details.premium_payment_period_plm_plus").value) != "null" && (document.getElementById("al_sqs_details.premium_payment_period_plm_plus").value) != null && (pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS3" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL14" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL24"))
        {
            document.getElementById("al_rider_sqs.pruallocator.rider_term").value = (document.getElementById("al_sqs_details.premium_payment_period_plm_plus").value);
        }
    }
    document.getElementById("al_rider_sqs.basic_plan.rider_premium").value = Basic;
    if(jsonLeftPanel != "" && (pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS2" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL08" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS3" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL14" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL16" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL24"))
    {
        //added by ankita on 8 may 2019 for pruwealth plus product
        if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25")
        {
            
            document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").readOnly = false;
            document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").disabled=false;
        }
        else if(pagedata["setvar"]["A_Master_Product_Master_Key"] != "ILS3" && pagedata["setvar"]["A_Master_Product_Master_Key"] != "IL14" && pagedata["setvar"]["A_Master_Product_Master_Key"] != "IL24")//added condition for defect 7951 on 22 July 2019 by ankita
        {
            document.getElementById("al_sqs_details.insurance_premium").readOnly = false;
            document.getElementById("al_sqs_details.insurance_premium").disabled=false;
        }
        
            //added by ankita on 8 may 2019 for pruwealth plus product
           if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20")
            {
                document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").value = Basic;
            }
             else if(pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25"){//Def -1122/1121 by Paromita on 29th Aug
             
             document.getElementById("al_sqs_details.pruwealth_plus_target_bua_prem").value =parseFloat(parseFloat(Basic) + parseFloat(PRUallocatorPremium)).toFixed(2);
             document.getElementById("al_sqs_details.insurance_premium").value = parseFloat(Basic).toFixed(2);
             document.getElementById("al_sqs_details.pruallocator_premium").value = parseFloat(PRUallocatorPremium).toFixed(2);
              document.getElementById("al_sqs_details.pwp_max_bua_premium").value = parseFloat(jsonLeftPanel["MaxBUAPrem"]).toFixed(2);
             }
            else
            {
                document.getElementById("al_sqs_details.insurance_premium").value = Basic;
            }
           

        document.getElementById("al_sqs_details.total_premium_plm_plus").value = recommendedPremium;
        document.getElementById("al_sqs_details.min_insurance_premium").value = jsonLeftPanel["MinimumInsurance"];
        document.getElementById("al_sqs_details.max_insurance_premium").value = jsonLeftPanel["MaximumInsurance"];
        if(PRUallocatorPremium != 0)
        {
            document.getElementById("al_sqs_details.pruallocator_premium").value = PRUallocatorPremium;
        }
        document.getElementById("al_sqs_details.project_sustainability_age_high").value = jsonLeftPanel["PolSustAgeHigh"];
        document.getElementById("al_sqs_details.project_sustainability_age_low").value = jsonLeftPanel["PolSustAgeLow"];
    }
    
    PrusaverReset("");
}
//added by ankita for RGSP product
function fnSetRequiredInputsForRGSP(pagedata)
{
    pagedata["setvar"]["A_Master_Accumulation_Period_key"]=document.getElementById("al_sqs_details.accumulation_period").value;
    pagedata["setvar"]["A_Master_Payout_Period_key"]=document.getElementById("al_sqs_details.payout_period").value;
    if(document.getElementById("al_rider_sqs.retireguardSp.rider_premium").value == "")
    {
        pagedata["setvar"]["A_Budget_Premium_rea"]= "0";
    }
    else
    {
        pagedata["setvar"]["A_Budget_Premium_rea"]= document.getElementById("al_rider_sqs.retireguardSp.rider_premium").value;
    }
    if(document.getElementById("al_sqs_details.flexible_withdrawal_option").checked==true)
    {
        pagedata["setvar"]["A_Master_FlexiWithdrawal_boo"]="Y";
    }
    else
    {
        pagedata["setvar"]["A_Master_FlexiWithdrawal_boo"]="N";
    }
    if(document.getElementById("al_sqs_details.maximum_income_option").checked==true)
    {
        pagedata["setvar"]["A_Master_MaxIncomeOption_boo"]="Y";
    }
    else
    {
        pagedata["setvar"]["A_Master_MaxIncomeOption_boo"]="N";
    }
    pagedata["setvar"]["A_Master_Payout_Frequency_key"]="12";
    
    pagedata["setvar"]["A_Master_Payout_Option_key"]="1";
    pagedata["setvar"]["A_Master_Premium_Term_key"]="1";
    pagedata["setvar"]["A_Basic_Sum_Assured_rea"]="0";
    var totalPolicyTermRGSP=parseInt(document.getElementById("al_sqs_details.accumulation_period").value)+parseInt(document.getElementById("al_sqs_details.payout_period").value);
    console.log("totalPolicyTermRGSP:",totalPolicyTermRGSP)
    pagedata["setvar"]["A_Master_Policy_Term_key"]=""+totalPolicyTermRGSP;
    if(document.getElementById("al_sqs_details.x_perc_of_sp").value=="")
    {
        pagedata["setvar"]["A_Annual_Income_Perc_key"]="";
    }
    else
    {
      
        
        pagedata["setvar"]["A_Annual_Income_Perc_key"]=""+Math.round(document.getElementById("al_sqs_details.x_perc_of_sp").value * 1000)/100000.0;
       // Math.round(8.2*1000)/100000.0;
        //Added for defect 8953 on date 25-12-2019 by Ankita
    }
    
    return pagedata;
    
    
    
}

function fnCallPremSustainForMillionCover(pagedata,strErrorMessage,obj_mlife_res,obj_prochoice,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel)
   {
   
               //added by ankita on 10 jan 2020 for defect 8934
    pagedata["VPMSFunctionNameInSequence"] = ["P_Calculate_Prem_Sustain_out"];
    console.log("pageData fnCallPremSustainForMillionCover:"+JSON.stringify(pagedata));


    js_call_native_func("VPMSCall",pagedata,function(resP_Calculate_Prem_Sustain_out)
    {
          console.log("resP_Calculate_Prem_Sustain_out-->" +resP_Calculate_Prem_Sustain_out);

          var jsonresP_Calculate_Prem_Sustain_out = JSON.parse(resP_Calculate_Prem_Sustain_out);
          var objresP_Calculate_Prem_Sustain_out = jsonresP_Calculate_Prem_Sustain_out[pagedata["VPMSFunctionNameInSequence"]];
          console.log("objresP_Calculate_Prem_Sustain_out"+JSON.stringify(objresP_Calculate_Prem_Sustain_out));
          var objSplitP_Calculate_Prem_Sustain_out = objresP_Calculate_Prem_Sustain_out["result"].split(";")
          console.log("objSplitP_Calculate_Prem_Sustain_out"+objSplitP_Calculate_Prem_Sustain_out);
          var indexMinimumPremiumMillionCover = objSplitP_Calculate_Prem_Sustain_out.indexOf("MinInsPrem");
          console.log("indexMinimumPremium"+indexMinimumPremium);
          pagedata["setvar"]["A_Budget_Premium_rea"]=objSplitP_Calculate_Prem_Sustain_out[parseInt(indexMinimumPremiumMillionCover)+1];
          var indexPRUallocatorPremiumMillionCover = objSplitP_Calculate_Prem_Sustain_out.indexOf("ALS1");
          
          if(indexPRUallocatorPremiumMillionCover != -1)
          {
            pagedata["setvar"]["A_Budget_Exc_Premium_rea"]=objSplitP_Calculate_Prem_Sustain_out[parseInt(indexPRUallocatorPremiumMillionCover)+1];
            
          }
               console.log("After pagedata million cover:"+JSON.stringify(pagedata));
                        
    });
   
   }
  //added by ankita on 6 Feb 2020 for defect 8857 for PRUMillion Cover product
function fnMsCallPremSuatainMillionCoverOkToAmend(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mainlife_response,obj_prodchoice_res,iSelectedRiderCount,bFirstCallFlag,jsonLeftPanel,investmentPremValue)
{
    js_get_var("VPMSRiderJson",function(VPMSRiderJson)
               {
               var objVPMSRiderJson = JSON.parse(VPMSRiderJson);
               console.log("objVPMSRiderJson:"+JSON.stringify(objVPMSRiderJson));
    var fPRUSaverExist = false;
   pagedata["VPMSFunctionNameInSequence"] = ["P_Calculate_Prem_Sustain_out"];
   console.log("pageData:"+JSON.stringify(pagedata));
   
   var pagedataKeyArray= Object.keys(pagedata["setvar"]);
   for(var iCount =0;iCount < pagedataKeyArray.length; iCount++)
   {
       console.log("pagedataKeyArray[iCount]---"+pagedataKeyArray[iCount]);
       if(pagedata["setvar"][pagedataKeyArray[iCount]] == "STS6" || pagedata["setvar"][pagedataKeyArray[iCount]] == "ST24" || pagedata["setvar"][pagedataKeyArray[iCount]] == "ST38")//added ST24 by ankita on 4 dec 2020
       {
           var RiderValueKey = pagedataKeyArray[iCount].replace("A_Master_Rider_key","A_Rider_Sum_Assured_rea");
           console.log("RiderValueKey:"+RiderValueKey);
           pagedata["setvar"][RiderValueKey] = investmentPremValue;
           fPRUSaverExist = true;
       }
   }
   if(!fPRUSaverExist) //Def 10651
   {
       var nofRiderCount =  pagedata["setvar"]["A_Nof_Riders_int"];
       var idtemp = "";
       if(obj_prochoice["al_sqs_details.mlife.il_anb"] <= 18)
       {
           idtemp = "al_rider_sqs.prusaver_kid";
       }
       else
       {
           idtemp = "al_rider_sqs.prusaver"
       }
       pagedata["setvar"]["A_Master_Rider_key["+nofRiderCount+"]"] = objVPMSRiderJson["rider_row_"+idtemp.replace(/\.$/, '')];
       pagedata["setvar"]["A_Rider_Sum_Assured_rea["+nofRiderCount+"]"] = parseFloat(investmentPremValue).toString();
       szPRUsaverValue =  pagedata["setvar"]["A_Rider_Sum_Assured_rea["+nofRiderCount+"]"]
       pagedata["setvar"]["A_Code_Rider_Payage_key["+nofRiderCount+"]"] = (document.getElementById(idtemp+"payout_age") != undefined && document.getElementById(idtemp+"payout_age") != "null")? document.getElementById(idtemp+"payout_age").value :""; //Def 1113 fixed by Paromita on 10th Aug
       //objresP_Calculate_Prem_Sustain_out["InvsPrem"] = parseFloat(szPRUsaverValue).toString();
        nofRiderCount = parseInt(nofRiderCount)+1;
        pagedata["setvar"]["A_Nof_Riders_int"]= nofRiderCount.toString();
       
       iSelectedRiderCount++;
   }
    
    
   js_call_native_func("VPMSCall",pagedata,function(resP_Calculate_Prem_Sustain_out)
   {
         console.log("resP_Calculate_Prem_Sustain_out def 8934 fnvalidateofprusaver-->" +resP_Calculate_Prem_Sustain_out);

          var jsonresP_Calculate_Prem_Sustain_out = JSON.parse(resP_Calculate_Prem_Sustain_out);
                  var objresP_Calculate_Prem_Sustain_out = jsonresP_Calculate_Prem_Sustain_out[pagedata["VPMSFunctionNameInSequence"]];
                  console.log("objresP_Calculate_Prem_Sustain_out"+JSON.stringify(objresP_Calculate_Prem_Sustain_out));
                  var objSplitP_Calculate_Prem_Sustain_out = objresP_Calculate_Prem_Sustain_out["result"].split(";")
                  console.log("objSplitP_Calculate_Prem_Sustain_out"+objSplitP_Calculate_Prem_Sustain_out);
                  var indexMinimumPremiumMillionCover = objSplitP_Calculate_Prem_Sustain_out.indexOf("MinInsPrem");
                  
                  pagedata["setvar"]["A_Budget_Premium_rea"]=objSplitP_Calculate_Prem_Sustain_out[parseInt(indexMinimumPremiumMillionCover)+1];
                  //added if else by ankita on 4 ded 2020
                 var indexPRUallocatorPremiumMillionCover ="";
                       if(obj_prodchoice_res["al_sqs_details.product_name"]=="PRUmillion cover")
                       {
                            indexPRUallocatorPremiumMillionCover = objSplitP_Calculate_Prem_Sustain_out.indexOf("ALS1");
                       }
      
                      else  if(obj_prodchoice_res["al_sqs_details.product_name"]=="PRUEnhanced Cover")
                       {
                        indexPRUallocatorPremiumMillionCover = objSplitP_Calculate_Prem_Sustain_out.indexOf("AL16");
                        }
                       else
                       {
                            indexPRUallocatorPremiumMillionCover = objSplitP_Calculate_Prem_Sustain_out.indexOf("AL10");
                       }
                  //var indexPRUallocatorPremiumMillionCover = objSplitP_Calculate_Prem_Sustain_out.indexOf("ALS1");
                  
                       var newInsPremium=objSplitP_Calculate_Prem_Sustain_out[parseInt(indexMinimumPremiumMillionCover)+1];
                       newPRUAllocatorPremiumPMC="";
                       
                  if(indexPRUallocatorPremiumMillionCover != -1)
                  {
                    pagedata["setvar"]["A_Budget_Exc_Premium_rea"]=objSplitP_Calculate_Prem_Sustain_out[parseInt(indexPRUallocatorPremiumMillionCover)+1];
                       newPRUAllocatorPremiumPMC=objSplitP_Calculate_Prem_Sustain_out[parseInt(indexPRUallocatorPremiumMillionCover)+1];
                       //document.getElementById("al_sqs_details.pruallocator_premium").value=objSplitP_Calculate_Prem_Sustain_out[parseInt(indexPRUallocatorPremiumMillionCover)+1];
                       newPRUAllocatorPremiumPMC=objSplitP_Calculate_Prem_Sustain_out[parseInt(indexPRUallocatorPremiumMillionCover)+1];
                    
                  }
                       console.log("newInsPremium:"+newInsPremium+"newPRUAllocatorPremiumPMC:"+newPRUAllocatorPremiumPMC);
                       console.log("Insurance premium:"+document.getElementById("al_sqs_details.insurance_premium").value+"--newInsPremium:"+newInsPremium);
                       if((parseInt(document.getElementById("al_sqs_details.insurance_premium").value)<parseInt(newInsPremium)) || document.getElementById("al_sqs_details.insurance_premium").value == "")
                       {
                          document.getElementById("al_sqs_details.insurance_premium").value=parseFloat(newInsPremium).toFixed(2);
                       //pagedata["setvar"]["A_Budget_Premium_rea"]=document.getElementById("al_sqs_details.insurance_premium").value;
                          document.getElementById("al_rider_sqs.basic_plan.rider_premium").value=parseFloat(newInsPremium).toFixed(2);
                          pagedata["setvar"]["A_Budget_Premium_rea"]=newInsPremium;
                       }
                       else
                       {
                         pagedata["setvar"]["A_Budget_Premium_rea"]=document.getElementById("al_sqs_details.insurance_premium").value;
                       }
                       
                       console.log("before modified value allocator:"+document.getElementById("al_rider_sqs.pruallocator.rider_premium").value);
                       console.log("before modified value allocator123:"+document.getElementById("al_sqs_details.pruallocator_premium").value);
                       
                       if((parseInt(document.getElementById("al_rider_sqs.pruallocator.rider_premium").value)<parseInt(newPRUAllocatorPremiumPMC)) || ((document.getElementById("al_rider_sqs.pruallocator.rider_premium").value == 0 || document.getElementById("al_rider_sqs.pruallocator.rider_premium").value == 0.00 ||  document.getElementById("al_rider_sqs.pruallocator.rider_premium").value == "" || parseInt(document.getElementById("al_rider_sqs.pruallocator.rider_premium").value) == 0 )))
                       {
                          
                          document.getElementById("al_sqs_details.pruallocator_premium").value=newPRUAllocatorPremiumPMC;
                          document.getElementById("al_rider_sqs.pruallocator.rider_premium").value=newPRUAllocatorPremiumPMC;
                          document.getElementById("al_rider_sqs.pruallocator.rider_term").value = document.getElementById("al_sqs_details.premium_payment_period_plm_plus").value;
                       
                       //pagedata["setvar"]["A_Budget_Exc_Premium_rea"]=document.getElementById("al_rider_sqs.pruallocator.rider_premium").value;
                           if(newPRUAllocatorPremiumPMC == "")
                           {
                              pagedata["setvar"]["A_Budget_Exc_Premium_rea"]="0";
                           }
                           else
                           {
                              pagedata["setvar"]["A_Budget_Exc_Premium_rea"]=newPRUAllocatorPremiumPMC;//getting number expected intead of . error if pass blank to this vpms input
                           }
                       }
                       else
                       {
                           
                           newPRUAllocatorPremiumPMC = document.getElementById("al_sqs_details.pruallocator_premium").value;
                           
                           pagedata["setvar"]["A_Budget_Exc_Premium_rea"]=document.getElementById("al_rider_sqs.pruallocator.rider_premium").value;
                       }
                       console.log("New allocator value:"+newPRUAllocatorPremiumPMC);
                       console.log("after modified value allocator:"+document.getElementById("al_rider_sqs.pruallocator.rider_premium").value);
                       console.log("after modified value allocator123:"+document.getElementById("al_sqs_details.pruallocator_premium").value);
                       console.log("after modified value basic premium:"+document.getElementById("al_rider_sqs.basic_plan.rider_premium").value);
                       console.log("after modified value:"+JSON.stringify(pagedata));
                       szOkToAmendCVFlag="Yes";
                       //to set old value is get NA in response for pruallocator
                       //szPRUsaverValue = document.getElementById("al_sqs_details.pruallocator_premium").value;
                       szBasicPremium = document.getElementById("al_rider_sqs.basic_plan.rider_premium").value;
                       szOldAllocatorValueIfNA = document.getElementById("al_sqs_details.pruallocator_premium").value;
                       console.log("szPRUsaverValue:"+szPRUsaverValue); fnCallValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mainlife_response,obj_prodchoice_res,iSelectedRiderCount,bFirstCallFlag,jsonLeftPanel);
                       
                       
                       });
    });
               
}
               
               
function fnSetDropdownValuesForReserve(pagedata)
{
               
               var drpdownArray = {"A_Master_Payout_Age_key":"al_sqs_details.retire_age","A_Master_Payout_Frequency_key":"al_sqs_details.payout_frequency_option","A_Master_Payout_Period_key":"al_sqs_details.reserve_payout_period","A_Master_Premium_Term_key":"al_sqs_details.premium_payment_term"};
               for(sub in drpdownArray)
               {
                   console.log("subb:"+sub);
                   if(document.getElementById(drpdownArray[sub]).value!="" && document.getElementById(drpdownArray[sub]).value!="0")
                   {
                        pagedata["setvar"][sub]=document.getElementById(drpdownArray[sub]).value;
                   }
                   else
                   {
                        pagedata["setvar"][sub]="";
                   }
               
               }
               //console.log("pagedata fnSetDropdownValuesForReserve:"+pagedata);
    
               return pagedata;

}
// Added by Shivani for PRULink Supreme Sustainability pop up message
function fnPopulateInvestmentPremium(pagedata,strErrorMessage,obj_mlife_res,obj_prochoice,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel)
{
   
               bootbox.alert({
               message: strErrorMessage,
               className:'anbalert',
               buttons: {
               ok: {
               label: 'OK',
               }
               },
               callback: function(){
                             var res = strErrorMessage.match(/(\d[.]*)+/g).toString();
                                console.log("res:"+res);
                                var res1 = res.replace(',','');
                                console.log("res1:"+res1);
                                 investmentPremiumVal_next = investmentPremiumVal_next + parseInt(res1); // changed by Shivani for Def - 134 enhancement for Mar2022 release
                            
                             console.log("investmentPremiumVal_next:"+investmentPremiumVal_next);
                             
                             
                             // added changes as per the BR query 20 of Mar2022
                             document.getElementById("al_rider_sqs.prusaver.id").checked=true;
                             document.getElementById("al_rider_sqs.prusaver.rider_premium").value =investmentPremiumVal_next;
                             document.getElementById("al_rider_sqs.prusaver.rider_premium").disabled=false;
                             document.getElementById("al_rider_sqs.prusaver.rider_premium").readOnly = false;
                   
                             
               
                             //document.getElementById("al_sqs_details.investment_premium").value =investmentPremiumVal;
                           // console.log("value:"+document.getElementById("al_sqs_details.investment_premium").value);
                             //fnCallOutputAfterValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,iSelectedRiderCount,bFirstCallFlag);
               }
               })
                                                          
    
               
}

/*******************************************************
Function Name: fnMSChangeVPMSInput(pagedata)
Function Description: To pass VPMS input to all products if relationship is from Modern Family
Created By:Shivani
Created For: Modern Family Assessment CR global change to all product to pass vpms input
Created On: April 2022
*******************************************************/
               
function fnMSChangeVPMSInput(pagedata,currentPlan)
{
   console.log("Inside the function fnMSChangeVPMSInput : "+JSON.stringify(pagedata));
             console.log("currentplan: 111",currentPlan);
               //modified by ankita on 7 july for changes mentioned in production defect PRUW00182858
              var arrPremiumDriven=["PRULink Investor Account","PRUretirement growth","PRUMax Cover","PRUGlobal Series","PRUmy treasure","PRULink Supreme","PRUsignature infinite","PRUsignature prime","PRUSignature Invest","PRUsignature","PRUSignature Ace","PRUElite Invest","PRUSignature GrowthPlus","PRULink Supreme Plus","PRUSignature Plus"];
              var pagedataKeyArray= Object.keys(pagedata["setvar"]);
              /*if(currentPlan=="PRUsignature infinite" || currentPlan=="PRUMax Cover"){
                   if (pagedataKeyArray.includes("A_Budget_Premium_rea"))
                    {
                    console.log("cccccc 111111");
                    //var Basic_Sum_Assured_VPMS = document.getElementById("al_rider_sqs.prusignature_infinite.rider_premium").value;
                    //console.log("Basic_Sum_Assured_VPMS : ",Basic_Sum_Assured_VPMS);
                    
                    pagedata["setvar"]["A_Rider_Sum_Assured_rea[0]"] = document.getElementById("al_rider_sqs.prusignature_infinite.rider_premium").value;
                    //console.log("A_Rider_Sum_Assured_rea[0] : ",Basic_Sum_Assured_VPMS);
                 
          
                    
                    }
              
              }else{
              console.log("cccccc 222222");
                  if (pagedataKeyArray.includes("A_Budget_Premium_rea"))
                  {
                  if ((pagedata["setvar"]["A_Rider_Sum_Assured_rea[0]"]!== "") && (pagedata["setvar"]["A_Budget_Premium_rea"]!=="") && (pagedata["setvar"]["A_Budget_Premium_rea"]!=="0"))
                  {
                  var Basic_Sum_Assured_VPMS = pagedata["setvar"]["A_Budget_Premium_rea"];
                  console.log("Basic_Sum_Assured_VPMS : ",Basic_Sum_Assured_VPMS);
                  
                  pagedata["setvar"]["A_Rider_Sum_Assured_rea[0]"] = Basic_Sum_Assured_VPMS;
                  console.log("A_Rider_Sum_Assured_rea[0] : ",Basic_Sum_Assured_VPMS);
               
                  
                  }
                  }
              }*/
              if(arrPremiumDriven.indexOf(currentPlan)!= -1)
              {

               if(currentPlan=="PRUsignature infinite" || currentPlan=="PRUMax Cover"){
                    if (pagedataKeyArray.includes("A_Budget_Premium_rea"))
                     {
                     console.log("cccccc 111111");
                     //var Basic_Sum_Assured_VPMS = document.getElementById("al_rider_sqs.prusignature_infinite.rider_premium").value;
                     //console.log("Basic_Sum_Assured_VPMS : ",Basic_Sum_Assured_VPMS);
                     
                     pagedata["setvar"]["A_Rider_Sum_Assured_rea[0]"] = document.getElementById("al_rider_sqs.prusignature_infinite.rider_premium").value;
                     //console.log("A_Rider_Sum_Assured_rea[0] : ",Basic_Sum_Assured_VPMS);
                  
                     
                     
                     }
               
               }
               else
               {
                   if (pagedataKeyArray.includes("A_Budget_Premium_rea"))
                      {
                      if ((pagedata["setvar"]["A_Rider_Sum_Assured_rea[0]"]!== "") && (pagedata["setvar"]["A_Budget_Premium_rea"]!=="") && (pagedata["setvar"]["A_Budget_Premium_rea"]!=="0"))
                      {
                      var Basic_Sum_Assured_VPMS = pagedata["setvar"]["A_Budget_Premium_rea"];
                      console.log("Basic_Sum_Assured_VPMS : ",Basic_Sum_Assured_VPMS);
                      
                      pagedata["setvar"]["A_Rider_Sum_Assured_rea[0]"] = Basic_Sum_Assured_VPMS;
                      console.log("A_Rider_Sum_Assured_rea[0] : ",Basic_Sum_Assured_VPMS);
                   
                      
                      }
                      }
               }
              
              }
              
}

/*******************************************************
Function Name: fnCallValidationForAce
Function Description: To call validation flow for PRUSignature Ace product
Created By: Ankita
Created For: PRUSignature Ace product
Created On: Sept 2022
*******************************************************/
               
function fnCallValidationForAce(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,iSelectedRiderCount,bFirstCallFlag,jsonLeftPanel)
{
   
   console.log("Paromita iSelectedRiderCount In fnCallValidation -->"+iSelectedRiderCount);
   
   var checkFirstCal = document.getElementById("al_sqs_details.min_insurance_premium").value;
   console.log("checkFirstCal fnCallValidation--"+checkFirstCal);
   console.log("bFirstCallFlag--"+bFirstCallFlag);
   pagedata["VPMSFunctionNameInSequence"] = ["P_Validate_Pre_Benefit_out"];
   
              // pagedata["setvar"]["A_Master_Policy_Term_key"]="70";
               //pagedata["setvar"]["A_Master_Policy_Term_key[0]"]="70";
              // pagedata["setvar"]["A_Master_Policy_Term_key"]="70";
               if(parseInt(obj_prochoice["al_sqs_details.mlife.il_anb"])<=20)
               {
               pagedata["setvar"]["A_Basic_Sum_Assured_rea"]=(parseFloat(document.getElementById("al_sqs_details.insurance_premium").value) * 8).toString();
               }
               else if(parseInt(obj_prochoice["al_sqs_details.mlife.il_anb"])>=21 && parseInt(obj_prochoice["al_sqs_details.mlife.il_anb"])<=54)
               {
               pagedata["setvar"]["A_Basic_Sum_Assured_rea"]=(parseFloat(document.getElementById("al_sqs_details.insurance_premium").value) * 4).toString();
               }
               else if(parseInt(obj_prochoice["al_sqs_details.mlife.il_anb"])>=55 && parseInt(obj_prochoice["al_sqs_details.mlife.il_anb"])<=70)
               {
               pagedata["setvar"]["A_Basic_Sum_Assured_rea"]=(parseFloat(document.getElementById("al_sqs_details.insurance_premium").value) * 2).toString();
               }
               
    console.log("ankita pageData pre_validate:"+JSON.stringify(pagedata));
   js_call_native_func("VPMSCall",pagedata,function(szPreValidationError)
                   {
                           console.log("szPreValidationError:"+szPreValidationError);
                           szPreValidationError=szPreValidationError.replace(/\\r\\n/g, "<br />");//added for defect 7381 on 11 may 2019
                           console.log("szValidationError123:"+szPreValidationError);
                           szPreValidationError=szPreValidationError.replace(/\\n/g, "<br />");//Commented for Standardize eeror message for defect 5158 by ankita on 14 May 2018
                           console.log("szPreValidationError12:"+szPreValidationError);
                           var jsonszPreValidationError = JSON.parse(szPreValidationError)

                       if(fnShowValidationError(jsonszPreValidationError[pagedata["VPMSFunctionNameInSequence"]],obj_mlife_res,obj_prochoice,pagedata,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel))
                           {
                                   console.log("ankita pageData validate:"+JSON.stringify(pagedata));
                                pagedata["VPMSFunctionNameInSequence"] = ["P_Validate_Benefit_out"];
                                   js_call_native_func("VPMSCall",pagedata,function(szValidationError)
                                                       {
                                                           console.log("P_Validate_Post_Benefit_out szValidationError:"+szValidationError);
                                                           szValidationError=szValidationError.replace(/\\r\\n/g, "<br />");//added for defect 7381 on 11 may 2019
                                                           console.log("P_Validate_Post_Benefit_out szValidationError123:"+szValidationError);
                                                           szValidationError=szValidationError.replace(/\\n/g, "<br />");//Commented for Standardize eeror message for defect 5158 by ankita on 14 May 2018
                                                           console.log("P_Validate_Post_Benefit_out szValidationError124:"+szValidationError);
                                                           var jsonszValidationError = JSON.parse(szValidationError)

                                                       if(fnShowValidationError(jsonszValidationError[pagedata["VPMSFunctionNameInSequence"]],obj_mlife_res,obj_prochoice,pagedata,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel))
                                                           {
                                                       /*var pagedataKeyArray= Object.keys(pagedata["setvar"]);
                                                       var pagedataLoading=pagedata;
                                                        for(var iCount =0;iCount < pagedataKeyArray.length; iCount++)
                                                       {
                                                       console.log("pagedataKeyArray[iCount]:"+pagedataKeyArray[iCount]);
                                                       console.log("pagedataKeyArray[iCount]11:"+pagedataKeyArray[iCount].indexOf("Load_Rate"));
                                                           if (pagedataKeyArray[iCount].indexOf("Load_Rate")>-1 || pagedataKeyArray[iCount].indexOf("Load_Permille")>-1 || pagedataKeyArray[iCount].indexOf("Load_Pursuit")>-1 || pagedataKeyArray[iCount].indexOf("Load_Permille_Term")>-1 || pagedataKeyArray[iCount].indexOf("Load_Pursuit_Term")>-1 )
                                                           {
                                                           console.log("Yes");
                                                           pagedata["setvar"][pagedataKeyArray[iCount]]="0";
                                                           
                                                       
                                                           }
                                                          
                                                       }
                                                       console.log("After validate without loading:"+JSON.stringify(pagedata));*/
                                                          
                                                             pagedata["VPMSFunctionNameInSequence"] = ["P_Validate_Post_Benefit_out"];
                                                         //loading changes to pass to P_Validate_Post_Benefit_out
                                                       pagedata["changeInSetVar"]={"P_Validate_Post_Benefit_out":{"A_Death_Load_Rate_01_rea":"0","A_Death_Load_Permille_01_rea":"0","A_Death_Load_Pursuit_01_rea":"0","A_TPD_Load_Rate_01_rea":"0","A_TPD_Load_Permille_01_rea":"0","A_TPD_Load_Pursuit_01_rea":"0"
                                                       
                                                       }};
                                                       
                                                      
                                                       
                                                       console.log("ankita pageData post validate after:"+JSON.stringify(pagedata));
                                                       js_call_native_func("VPMSCall",pagedata,function(szPostValidationError)
                                                                {
                                                                                    console.log("P_Validate_Post_Benefit_out szPostValidationError:"+szPostValidationError);
                                                                               szPostValidationError=szPostValidationError.replace(/\\r\\n/g, "<br />");//added for defect 7381 on 11 may 2019
                                                                               console.log("P_Validate_Post_Benefit_out szPostValidationError12:"+szPostValidationError);
                                                                               szPostValidationError=szPostValidationError.replace(/\\n/g, "<br />");//Commented for Standardize eeror message for defect 5158 by ankita on 14 May 2018
                                                                               console.log("P_Validate_Post_Benefit_out szValidationError124:"+szPostValidationError);
                                                                               var jsonszPostValidationError = JSON.parse(szPostValidationError);
                                                                           
                                                                    console.log("ankita pageData fnShowValidationError "+JSON.stringify(pagedata));
                                                                           if(fnShowValidationError(jsonszPostValidationError[pagedata["VPMSFunctionNameInSequence"]],obj_mlife_res,obj_prochoice,pagedata,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel))
                                                                    {
                                                                    //for flow 1 i.e SustAge >= 100

                                                                                                 pagedata["VPMSFunctionNameInSequence"] = ["P_Calculate_Prem_Sustain_out"];
                                                                                                 console.log("loadingPagedataAce P_Calculate_Prem_Sustain_out:"+JSON.stringify(pagedata));
                                                                                                 
                                                                                                 //if(parseInt(reduceAge)>=80 && parseInt(reduceAge)<=99)
                                                                                         // {
                                                                                                        console.log("ankita pageData P_Calculate_Prem_Sustain_out:"+JSON.stringify(pagedata));
                                                                     //added by ankita for defect 527 changes by fatin for PRUSignature Ace product
                                                                           pagedata["changeInSetVar"]={"P_Calculate_Prem_Sustain_out":{"A_Budget_Exc_Premium_rea":"0"}};
                                                                           pagedata["VPMSFunctionNameInSequence"] = ["P_Calculate_Prem_Sustain_out"]
                                                                                              js_call_native_func("VPMSCall",pagedata,function(resP_Calculate_Prem_Sustain_out)
                                                                                                  {
                                                                                                       console.log("response of P_Calculate_Prem_Sustain_out:"+resP_Calculate_Prem_Sustain_out);
                                                                                                             console.log("loadingPagedataAce P_Validate_Post_Benefit_out:"+JSON.stringify(pagedata));
                                                                                                                  //added below block to add loading premium in VPMS input on 22 sept 2022 after confirmation from fatin
                                                                                                                  var jsonresP_Calculate_Prem_Sustain_out = JSON.parse(resP_Calculate_Prem_Sustain_out);
                                                                           var objresP_Calculate_Prem_Sustain_out = jsonresP_Calculate_Prem_Sustain_out[pagedata["VPMSFunctionNameInSequence"]];
                                                                           var objSplitP_Calculate_Prem_Sustain_out = objresP_Calculate_Prem_Sustain_out["result"].split(";")
                                                                           var indexPRUallocatorPremium = objSplitP_Calculate_Prem_Sustain_out.indexOf("AL14");
                                                                           var PRUallocatorPremiumValue = objSplitP_Calculate_Prem_Sustain_out[parseInt(indexPRUallocatorPremium)+1];
                                                                           if(indexPRUallocatorPremium != -1)
                                                                                                           {
                                                                                                           pagedata["setvar"]["A_Budget_Exc_Premium_rea"] = PRUallocatorPremiumValue;
                                                                                                           }
                                                                                                                  
                                                                                                                  //end
                                                                                                                  pagedata["VPMSFunctionNameInSequence"] = ["P_Validate_Post_Benefit_out"];
                                                                                                                  // to bypass for PAMBNEWP-10087
                                                                                                                  //fnCallOutputAfterValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mainlife_response,obj_prodchoice_res,iSelectedRiderCount,bFirstCallFlag);
                                                                                                                  js_call_native_func("VPMSCall",pagedata,function(szValidationError)
                                                                                                                                      {
                                                                                                                                          console.log("P_Validate_Post_Benefit_out szValidationError:"+szValidationError);
                                                                                                                                          szValidationError=szValidationError.replace(/\\r\\n/g, "<br />");//added for defect 7381 on 11 may 2019
                                                                                                                                          console.log("P_Validate_Post_Benefit_out szValidationError123:"+szValidationError);
                                                                                                                                          szValidationError=szValidationError.replace(/\\n/g, "<br />");//Commented for Standardize eeror message for defect 5158 by ankita on 14 May 2018
                                                                                                                                          console.log("P_Validate_Post_Benefit_out szValidationError124:"+szValidationError);
                                                                                                                                          var jsonszValidationError = JSON.parse(szValidationError)

                                                                                                                                      if(fnShowValidationError(jsonszValidationError[pagedata["VPMSFunctionNameInSequence"]],obj_mlife_res,obj_prochoice,pagedata,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel))
                                                                                                                                          {
                                                                                                                                              
                                                                                                                                                  console.log("Called main function after validation");
                                                                                                                                                  fnCallOutputAfterValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,iSelectedRiderCount,bFirstCallFlag);
                                                                                                                                              
                                                                                                                                              
                                                                                                                                          }
                                                                                                                                      });
                                                                                                                 
                                                                                                 
                                                                                                                 
                                                                                              
                                                                                                                 
                                                                                                  
                                                                                                                 
                                                                                                                 
                                                                                                  });
                                                                           
                                                                    }
                                                               
                                                                               
                                                            
                                                                               
                                                                
                                                                               
                                                                               
                                                                });



                                                           }
                                                       });
                               
                           }
                   });
           //}

    
}
            
/*******************************************************
Function Name: fnShowTargetSustainAgeAlert
Function Description: To pass value in VPMS input depends on age in alert for PRUSignature Ace product
Created By: Ankita
Created For: PRUSignature Ace product
Created On: Sept 2022
*******************************************************/
               
function fnShowTargetSustainAgeAlert(pagedata,messageToValidate,obj_mainlife_response,obj_prodchoice_res,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel)
{
               console.log("ankita pageData inside fnShowTargetSustainAgeAlert:"+JSON.stringify(pagedata));
               var szErrorCode = messageToValidate.split(":")[0];
               var strErrorMessage = messageToValidate.split(":")[1];
               var strFinalErrorMessage = strErrorMessage.split("//")[0];
               var reduceAge = strErrorMessage.split("//")[1];
               var targetSustainabilityValue=pagedata["setvar"]["A_Code_TargetSust_key"];
               console.log("fnShowWarningMsg messageToValidate:"+messageToValidate+"   strErrorMessage"+strErrorMessage);
               console.log("reduceAge:"+reduceAge);
               pagedata["setvar"]["A_Master_ILP_TargetSust_key"] = "A80";
               pagedata["setvar"]["A_Code_TargetSust_key"] = "80";
               document.getElementById("al_sqs_details.target_sustainability_age").value="80";
               //added by ankita for defect 527 changes by fatin for PRUSignature Ace product
               pagedata["changeInSetVar"]={"P_Calculate_Prem_Sustain_out":{"A_Budget_Exc_Premium_rea":"0"}};
               //console.log("loadingPagedataAce:"+JSON.stringify(pagedata));
               
               
               bootbox.alert({
                      
                      message:strFinalErrorMessage,
                      className: 'my-popup',
                      callback: function ()
                      {
                      //benefit_flag_update ="1";
                      canSwipe=1;
                      szNegativeCashValueFlag = "No";
                      
                      pagedata["VPMSFunctionNameInSequence"] = ["P_Calculate_Prem_Sustain_out"];
                      console.log("loadingPagedataAce P_Calculate_Prem_Sustain_out:"+JSON.stringify(pagedata));
                      
                      //if(parseInt(reduceAge)>=80 && parseInt(reduceAge)<=99)
              // {
                             console.log("ankita pageData P_Calculate_Prem_Sustain_out:"+JSON.stringify(pagedata));
                   pagedata["VPMSFunctionNameInSequence"] = ["P_Calculate_Prem_Sustain_out"]
                   js_call_native_func("VPMSCall",pagedata,function(resP_Calculate_Prem_Sustain_out)
                       {
                            console.log("response of P_Calculate_Prem_Sustain_out:"+resP_Calculate_Prem_Sustain_out);
                                  console.log("loadingPagedataAce P_Validate_Post_Benefit_out:"+JSON.stringify(pagedata));
                                       //added below block to add loading premium in VPMS input on 22 sept 2022 after confirmation from fatin
                                       var jsonresP_Calculate_Prem_Sustain_out = JSON.parse(resP_Calculate_Prem_Sustain_out);
var objresP_Calculate_Prem_Sustain_out = jsonresP_Calculate_Prem_Sustain_out[pagedata["VPMSFunctionNameInSequence"]];
var objSplitP_Calculate_Prem_Sustain_out = objresP_Calculate_Prem_Sustain_out["result"].split(";")
var indexPRUallocatorPremium = objSplitP_Calculate_Prem_Sustain_out.indexOf("AL14");
var PRUallocatorPremiumValue = objSplitP_Calculate_Prem_Sustain_out[parseInt(indexPRUallocatorPremium)+1];
if(indexPRUallocatorPremium != -1)
                                {
                                pagedata["setvar"]["A_Budget_Exc_Premium_rea"] = PRUallocatorPremiumValue;
                                }
                                       
                                       //end
                                       pagedata["VPMSFunctionNameInSequence"] = ["P_Validate_Post_Benefit_out"];
                                       // to bypass for PAMBNEWP-10087
                                       //fnCallOutputAfterValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mainlife_response,obj_prodchoice_res,iSelectedRiderCount,bFirstCallFlag);
                                       js_call_native_func("VPMSCall",pagedata,function(szValidationError)
                                                           {
                                                               console.log("P_Validate_Post_Benefit_out szValidationError:"+szValidationError);
                                                               szValidationError=szValidationError.replace(/\\r\\n/g, "<br />");//added for defect 7381 on 11 may 2019
                                                               console.log("P_Validate_Post_Benefit_out szValidationError123:"+szValidationError);
                                                               szValidationError=szValidationError.replace(/\\n/g, "<br />");//Commented for Standardize eeror message for defect 5158 by ankita on 14 May 2018
                                                               console.log("P_Validate_Post_Benefit_out szValidationError124:"+szValidationError);
                                                               var jsonszValidationError = JSON.parse(szValidationError)

                                                           if(fnShowValidationError(jsonszValidationError[pagedata["VPMSFunctionNameInSequence"]],obj_mainlife_response,obj_prodchoice_res,pagedata,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel))
                                                               {
                                                                   
                                                                       console.log("Called main function after validation");
                                                                       fnCallOutputAfterValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mainlife_response,obj_prodchoice_res,iSelectedRiderCount,bFirstCallFlag);
                                                                   
                                                                   
                                                               }
                                                           });
                                      
                      
                                      
                   
                                      
                       
                                      
                                      
                       });
               
               //}
                      
                      
                      }
                      });
               

}
               
function fnFetchBundleProductList(CheckShift,currentPlan)
{
    console.log("inside fnGetRiderChoice");

    var jsonRideIds ={"Payor Basic":"enhanced_prupayor_basic","PRUpayor basic":"enhanced_prupayor_basic","Payor Saver":"enhanced_prupayor_saver","PRUpayor saver":"enhanced_prupayor_saver","Parent Payor Basic":"pruparent_payor_basic","2Parent Payor Basic":"pruparent_double_payor_basic","Parent Payor Saver":"pruparent_payor_saver","2Parent Payor Saver":"pruparent_double_payor_saver","Spouse Payor Basic":"pruspouse_payor_basic","Spouse Payor Saver":"pruspouse_payor_saver","Acci Guard Plus":"pruacci_guard","Acci Med Plus":"pruacci_med","Acci Income Plus":"pruacci_income","Essential Child Plus":"enhanced_prue_child","PRUsaver kid/ PRUsaver":"prusaver_kid","Infant Care Plus":"enhanced_infant_care","PRUPayor Basic":"enhanced_prupayor_basic","PRUPayor Saver":"enhanced_prupayor_saver","Essential Child Plus\/ Crisis Care":"enhanced_prue_child","PRUSaver Kid\/ PRUSaver":"prusaver_kid","Crisis Guard 2.0":"crisis_guard","Level SA Rider 2.0":"level_sa_rider","Payor Basic 2.0":"enhanced_prupayor_basic","Payor Saver 2.0":"enhanced_prupayor_saver","Spouse Payor Basic 2.0":"pruspouse_payor_basic","Spouse Payor Saver 2.0":"pruspouse_payor_saver","Parent Payor Basic 2.0":"pruparent_payor_basic","Parent Payor Saver 2.0":"pruparent_payor_saver","Crisis Care 2.0":"crisis_care","Refund Of Premium - 100%":"rop_100","Refund Of Premium - 106%":"rop_106","PRULady Cancer Income":"prulady_cancer_income","Double Enhancer":"double_enhancer_cash","PRULegacy":"prulegacy_cash","PRUSaver (Before age 70)":"prusaver","PRUPayor Basic Plus":"enhanced_prupayor_basic","PRUPayor Saver Plus":"enhanced_prupayor_saver","PRUSpouse Payor Basic Plus":"pruspouse_payor_basic","PRUSpouse Payor Saver Plus":"pruspouse_payor_saver","Life Assured Waiver Plus":"pruwaiver","Disability Care":"disability_care","SA Booster":"incremental_sa_benefit","PRUWaiver Plus":"pruwaiver","Spouse Waiver Plus":"spouse_waiver","Parent Waiver Plus":"parent_waiver","PRUsaver (Max entry age 70 n.b.)":"prusaver","PRUMillion Med 2.0":"prumillion_med_2_0","PRUMillion Med Booster 2.0":"prumillion_med_booster_2_0"};//last three keys are added by ankita on 7 May 2019 as we are getting this name from VPMS response//added PRUSaver (Before age 70) by ankita on 4 dec 2020//mom_and_baby_care condition added by ankita on 5 dec 2022 for pruwith you product and to modify if vpms come replace mom_and_baby_care with enhanced_infant_care//enhanced_infant_care changed by ankita for infant care plus id
    


    var todayDate  = new Date();
    var todayYear  = todayDate.getFullYear();
    var todayMonth = todayDate.getMonth() + 1;
    var todayDay   = todayDate.getDate();
    var szChannelName = "AGY";
    var szSubChannelName = "AGY";//chnaged by ankita as changes sent by VPMS on 03 May 2018
    
    localStorage.setItem("current_plan",currentPlan);
    
    console.log("currentPlan:"+currentPlan);
              /* if(currentPlan==="PPR1")
               {
               currentPlan="PRUSignature Harvest Plus";
               }*/
    
    if(todayDay < 10)
    {
        todayDay = "0" + todayDay
    }
    if(todayMonth < 10)
    {
        todayMonth = "0" + todayMonth
    }
    console.log("subChannelTypeForAgencyBancaRepls:--" + subChannelTypeForAgencyBancaRepls + " channelTypeForAgencyBancaRepls:--" +channelTypeForAgencyBancaRepls);
    if(channelTypeForAgencyBancaRepls == "banca")
    {
        szChannelName = "SCB";
        if(subChannelTypeForAgencyBancaRepls =="SCB_STF")
        {
            //szSubChannelName ="SCBSTF"
            szSubChannelName ="STF"//chnaged by ankita as changes sent by VPMS on 03 May 2018
        }
        else
        {
            //szSubChannelName ="SCBFSC"
            szSubChannelName ="FSC"//chnaged by ankita as changes sent by VPMS on 03 May 2018
        }
    }
    else if(channelTypeForAgencyBancaRepls == "uob")
    {
        szChannelName = "UOB";
        //szSubChannelName = subChannelTypeForAgencyBancaRepls;
        szSubChannelName = "";//chnaged by ankita as changes sent by VPMS on 03 May 2018
        
    }
   
    console.log("currentPlan::"+currentPlan);
    var Current_date_dat = "";
    Current_date_dat = todayYear.toString()+todayMonth.toString()+todayDay.toString();
    
    var inceptionDate=obj_prochoice["al_sqs_details.Inception_dt"].split("/");
    
    if(parseInt(inceptionDate[0]) < 10)
    {
        inceptionDate[0] = "0" + parseInt(inceptionDate[0]);
    }
    if(parseInt(inceptionDate[1]) < 10)
    {
        inceptionDate[1] = "0" + parseInt(inceptionDate[1]);
    }

    var querySelect=fnGetProductMaster(currentPlan)
    querySelect.execute(function (jsonProductresponse)

                        {
    js_get_var("bundle_product_response",function(prod_choice_res)
               {
               js_get_var("main_life_response",function(main_life_response)
                          {
                          js_get_var("sec_life_response",function(sec_life_response)
                                     {
                                     js_get_var("third_life_response",function(third_life_response)
                                                {
                                                js_get_var("beneft_selection_response_bundle", function(ben_selection_res)
                                                    {
                                                       js_get_var("VPMSRiderJson",function(VPMSRiderJson)
                                                                  {
                                                                  js_get_var("fnSetPayoutPeriodDropdownCallFrom",function(fnSetPayoutPeriodDropdownCallFrom)
                                                                  {
                                                           var obj_ben_sel="";
                                                           if(ben_selection_res != "" && ben_selection_res != null && ben_selection_res != "null"  && ben_selection_res != "(null)")
                                                           {
                                                            obj_ben_sel = JSON.parse(ben_selection_res);
                                                           }
                                                                  console.log("obj_ben_sel-->"+JSON.stringify(obj_ben_sel));
                                                    var objmain_life_response=JSON.parse(main_life_response);
                                                    var dob="";
                                                    var objsec_life_response="";
                                                    var objthird_life_response="";
                                                    if(objmain_life_response["al_person_details.pre_natal_child_flg"] == "Yes")
                                                    {
                                                        dob = objmain_life_response["al_person_details.mlife.expected_delivery_dt"].split("/");
                                                    }
                                                    else
                                                    {
                                                        dob =objmain_life_response["al_person_details.mlife.dob"].split("/");
                                                    }
                                                    var sec_dob="";
                                                    var third_dob="";
                                                    var occ_sec="";
                                                    var occ_third="";
                                                    if (sec_life_response != "" && sec_life_response != null && sec_life_response != "null" && sec_life_response != "(null)")
                                                    {
                                                        objsec_life_response=JSON.parse(sec_life_response);
                                                        var dob_sec =objsec_life_response["al_person_details.slife.dob"].split("/");
                                                        sec_dob=dob_sec[2]+dob_sec[1]+dob_sec[0];
                                                        occ_sec=getOccupationCodeAndNOB(objsec_life_response["al_employee_details.slife.occupation"],"","occupation");
                                                    }
                                                    if (third_life_response != "" && third_life_response != null && third_life_response != "null" && third_life_response != "(null)")
                                                    {
                                                        objthird_life_response=JSON.parse(third_life_response);
                                                        var dob_third =objthird_life_response["al_person_details.tlife.dob"].split("/");
                                                        third_dob=dob_third[2]+dob_third[1]+dob_third[0];
                                                        occ_third=getOccupationCodeAndNOB(objthird_life_response["al_employee_details.tlife.occupation"],"","occupation");
                                                    }


                                                    var obj_prochoice="";
                                                    obj_prochoice=JSON.parse(prod_choice_res);
                                                console.log("obj_prochoice --->"+JSON.stringify(obj_prochoice));
                                                                   console.log("obj_prochoice Ins type--->"+objmain_life_response["al_person_details.mlife.insu_type"]);
                                                    
                                                    var pagedata={
                                                                  "setvar":
                                                                  {
                                                                        "A_Search_str":"",
                                                                        "A_Insured_DOB_01_dat":dob[2]+dob[1]+dob[0],
                                                                        "A_Insured_DOB_02_dat":sec_dob,
                                                                        "A_Insured_DOB_03_dat":third_dob,
                                                                        "A_Code_Occupation_01_key":getOccupationCodeAndNOB(objmain_life_response["al_employee_details.mlife.occupation"],"","occupation"),


                                                                        "A_Code_Occupation_02_key":occ_sec,
                                                                        "A_Code_Occupation_03_key":occ_third,

                                                                        "A_Policy_Inception_dat":inceptionDate[2]+inceptionDate[1]+inceptionDate[0],
                                                           
                                                                        "A_Master_Premium_Term_key":"",
                                                                        "A_Insured_Name_01_str":objmain_life_response["al_person_details.mlife.first_name"],
                                                                        "A_Insured_Name_02_str":objsec_life_response["al_person_details.slife.first_name"],
                                                                        "A_Insured_Name_03_str":objthird_life_response["al_person_details.tlife.first_name"],

                                                                        "A_Code_Gender_01_key":objmain_life_response["al_person_details.mlife.gender"]=="Male"?"M":"F",
                                                                        "A_Code_Gender_02_key":objsec_life_response["al_person_details.slife.gender"]=="Male"?"M":"F",
                                                                        "A_Code_Gender_03_key":objthird_life_response["al_person_details.tlife.gender"]=="Male"?"M":"F",
                                                                        "A_Code_Smoker_Status_01_key":objmain_life_response["al_person_details.mlife.smoke_status"]=="Smoker"?"S":"N",
                                                                        "A_Code_Smoker_Status_02_key":objsec_life_response["al_person_details.slife.smoke_status"]=="Smoker"?"S":"N",
                                                                        "A_Code_Smoker_Status_03_key":objthird_life_response["al_person_details.tlife.smoke_status"]=="Smoker"?"S":"N",
                                                                        "A_Code_Natural_Business_01_key":objmain_life_response["al_employee_details.mlife.nature_of_business"],
                                                                        "A_Code_Natural_Business_02_key":objsec_life_response["al_employee_details.slife.nature_of_business"],
                                                                        "A_Code_Natural_Business_03_key":objthird_life_response["al_employee_details.tlife.nature_of_business"],

                                                                        "A_Code_ILP_Fund_Source_key":"LF",



                                                                        "A_Rating_Date_dat":Current_date_dat,//changed by ankita on 3 July 2018(change in inputs email sent by VPMS) for defect 5781
                                                                        "A_Policy_Proposal_dat":Current_date_dat,//changed by ankita on 3 July 2018(change in inputs email sent by VPMS) for defect 5781
                                                                        "A_Code_Channel_key":szChannelName,
                                                                        "A_Code_Sub_Channel_key":szSubChannelName,
                                                                        "A_Master_Payout_Age_key":"",
                                                                        "A_Master_Payout_Frequency_key":"",
                                                                        "A_Master_Payout_Period_key":"",
                                                                        "A_Sustain_Age_High_int":"",
                                                                        "A_Sustain_Age_Low_int":"",
                                                                        "A_Master_Campaign_key":"",
                                                                        "A_Master_ILP_TargetSust_key":"",//added by ankita on 27 April 2019
                                                                        "A_Code_Insurance_Type_key":insuranceTypeCode[objmain_life_response["al_person_details.mlife.insu_type"]],
                                                                        "A_Code_Religion_key":"",//added by ankita on 9 July 2019
                                                                        "A_Master_Full_Coverage_Age_key":"",
                                                                             "A_Tran_Code_key":"NB"//added by ankita for change in potd-29239 on 4 june 2021
                                                                  
                                                                   },
                                                                  "VPMSFunctionNameInSequence":["P_Fetch_Benefit_out"],
                                                                  "VPMSCallType":"compute"

                                                                }
                                                                //added by ankita for PAMBNEWP-8825
                                                                             
                                                                             //
                                                                  //added by ankita to change logic of passing code to VPMS PRUSIgnature Vanguard onwards
                                                                if(currentPlan !== "PRUSignature Protect" && currentPlan !== "EssentialLife (SP)")//Added by sachin tupe for insu type
                                                                             {
                                                                             if(objmain_life_response["al_person_details.mlife.insu_type"]==="Business Loan Insurance (for Company/LLP)")
                                                               {
                                                                             pagedata["setvar"]["A_Code_Insurance_Type_key"]="BLCO"
                                                                             
                                                               }
                                                                             if(objmain_life_response["al_person_details.mlife.insu_type"]==="Business Loan Insurance (for Sole Proprietorship/Partnership)")
                                                                             {
                                                                                           pagedata["setvar"]["A_Code_Insurance_Type_key"]="BLSP"
                                                                                           
                                                                             }
                                                                             
                                                                             }
                                                                             
                                                                   //added by ankita for modern family CR
                                                                      if(objmain_life_response["al_person_details.mlife.insu_type_header"]=="non_business_purpose")
                                                                    {
                                                                             
                                                                             if(objmain_life_response["al_sqs_details.sec_parti_flag"] == "No")
                                                                             {
                                                                             pagedata["setvar"]["A_Code_Insurance_Type_key"]="SELF"
                                                                             
                                                                             }
                                                                             else if(objmain_life_response["al_sqs_details.sec_parti_flag"] == "Yes")
                                                                             {
                                                                             pagedata["setvar"]["A_Code_Insurance_Type_key"]=arrModernFamilyList[objsec_life_response["al_person_details.slife.relationship"]];
                                                                             }
                                                                    }
                                                                             
                                                                             //added by ankita on 7 dec 2020 as per changes requested for POTD-23607
                                                                             if(obj_prochoice["al_sqs_details.payment_backdate"]=="Yes")
                                                                             {
                                                                                 pagedata["setvar"]["A_Rating_MAR_dat"]=inceptionDate[2]+inceptionDate[1]+inceptionDate[0];
                                                                                 pagedata["setvar"]["A_Policy_Proposal_dat"]=inceptionDate[2]+inceptionDate[1]+inceptionDate[0];
                                                                             }
                                                                             else
                                                                             {
                                                                                pagedata["setvar"]["A_Rating_MAR_dat"]=Current_date_dat;
                                                                                pagedata["setvar"]["A_Policy_Proposal_dat"]=Current_date_dat;
                                                                             }
                                                           
                                                var pagedataChoiceFunction={
                                                "setvar":
                                                {
                                                
                                                "A_Search_str":"",
                                                "A_Policy_Inception_dat": inceptionDate[2]+inceptionDate[1]+inceptionDate[0],
                                                "A_Insured_DOB_01_dat":dob[2]+dob[1]+dob[0],
                                                "A_Insured_DOB_02_dat":sec_dob,
                                                "A_Insured_DOB_03_dat":third_dob,
                                                "A_Master_Premium_Term_key":"",
                                                "A_Rating_Date_dat":Current_date_dat,
                                                "A_Master_Payout_age_key":"",
                                                "A_Code_Channel_key":szChannelName,
                                                "A_Code_Sub_Channel_key":szSubChannelName,
                                                "A_Master_Payout_age_key":"",
                                                "A_Master_Policy_Term_key":"",
                                                "A_Master_Premium_Term_key":"",
                                                "A_Rating_MAR_dat":Current_date_dat,
                                                "A_Code_Insurance_Type_key":insuranceTypeCode[objmain_life_response["al_person_details.mlife.insu_type"]],
                                                "A_Code_Religion_key":"",//added by ankita on 9 July 2019
                                                "A_Master_Full_Coverage_Age_key":""
                                                },
                                                "VPMSCallType":"choice"
                                                
                                                }
                                                                             //added by ankita for modern family CR
                                                                               if(objmain_life_response["al_person_details.mlife.insu_type_header"]=="non_business_purpose")
                                                                             {
                                                                                      
                                                                                      if(objmain_life_response["al_sqs_details.sec_parti_flag"] == "No")
                                                                                      {
                                                                                      pagedataChoiceFunction["setvar"]["A_Code_Insurance_Type_key"]="SELF"
                                                                                      
                                                                                      }
                                                                                      else if(objmain_life_response["al_sqs_details.sec_parti_flag"] == "Yes")
                                                                                      {
                                                                                      pagedataChoiceFunction["setvar"]["A_Code_Insurance_Type_key"]=arrModernFamilyList[objsec_life_response["al_person_details.slife.relationship"]];
                                                                                      }
                                                                             }
                                                               //added by ankita for PAMBNEWP-8825
                                                                             //added by ankita to change logic of passing code to VPMS PRUSIgnature Vanguard onwards
                                                                             if(currentPlan !== "PRUSignature Protect" && currentPlan !== "EssentialLife (SP)")//Added by sachin tupe for insu type
                                                                             {
                                                                             
                                                                             if(objmain_life_response["al_person_details.mlife.insu_type"]==="Business Loan Insurance (for Company/LLP)")
                                                               {
                                                                             pagedataChoiceFunction["setvar"]["A_Code_Insurance_Type_key"]="BLCO"
                                                                             
                                                               }
                                                                             if(objmain_life_response["al_person_details.mlife.insu_type"]==="Business Loan Insurance (for Sole Proprietorship/Partnership)")
                                                                             {
                                                                                           pagedataChoiceFunction["setvar"]["A_Code_Insurance_Type_key"]="BLSP"
                                                                                           
                                                                             }
                                                                             }
                                                 //added by ankita on 7 dec 2020 as per changes requested for POTD-23607
                                                  if(obj_prochoice["al_sqs_details.payment_backdate"]=="Yes")
                                                  {
                                                      pagedataChoiceFunction["setvar"]["A_Rating_MAR_dat"]=inceptionDate[2]+inceptionDate[1]+inceptionDate[0];
                                                      pagedataChoiceFunction["setvar"]["A_Policy_Proposal_dat"]=inceptionDate[2]+inceptionDate[1]+inceptionDate[0];
                                                  }
                                                 else
                                                 {
                                                    pagedataChoiceFunction["setvar"]["A_Rating_MAR_dat"]=Current_date_dat;
                                                    pagedataChoiceFunction["setvar"]["A_Policy_Proposal_dat"]=Current_date_dat;
                                                 }
                                                           
                                                
                                                           
                                                if(objmain_life_response["al_sqs_details.sec_parti_flag"] == "No")
                                                {
                                                
                                                pagedata["setvar"]["A_Code_Smoker_Status_02_key"]="";
                                                pagedata["setvar"]["A_Code_Gender_02_key"]="";
                                                pagedata["setvar"]["A_Insured_DOB_02_dat"]="";
                                                pagedata["setvar"]["A_Insured_Name_02_str"]="";
                                                pagedata["setvar"]["A_Code_Nature_Business_02_key"]="";
                                                pagedata["setvar"]["A_Code_Occupation_02_key"]="";
                                                }
                                                if(objsec_life_response["al_sqs_details.third_parti_flg"] == "No")
                                                {
                                                
                                                pagedata["setvar"]["A_Code_Smoker_Status_03_key"]="";
                                                pagedata["setvar"]["A_Code_Gender_03_key"]="";
                                                pagedata["setvar"]["A_Insured_DOB_03_dat"]="";
                                                pagedata["setvar"]["A_Insured_Name_03_str"]="";
                                                pagedata["setvar"]["A_Code_Nature_Business_03_key"]="";
                                                pagedata["setvar"]["A_Code_Occupation_03_key"]="";
                                                }
                                                                  console.log("szSubChannelName:"+szSubChannelName+"szChannelName:"+szChannelName);
                                                var pagedata1={
                                                                    "setvar":
                                                                    {
                                                                        "A_Search_str":"",
                                                                        "A_Code_Sub_Channel_key":szSubChannelName,
                                                                        "A_Code_Channel_key":szChannelName,
                                                                        "A_Code_Insurance_Type_key":insuranceTypeCode[objmain_life_response["al_person_details.mlife.insu_type"]],
                                                                        "A_Code_Religion_key":"",//added by ankita on 9 July 2019
                                                                        "A_Master_Full_Coverage_Age_key":""
                                                                  

                                                                    },
                                                                    "VPMSFunctionNameInSequence":["A_Master_Product_Master_key"],
                                                                    "VPMSCallType":"choice"

                                                                  }
                                                                             //added by ankita for modern family CR
                                                                                                                                                          if(objmain_life_response["al_person_details.mlife.insu_type_header"]=="non_business_purpose")
                                                                                                                                                        {
                                                                                                                                                                 
                                                                                                                                                                 if(objmain_life_response["al_sqs_details.sec_parti_flag"] == "No")
                                                                                                                                                                 {
                                                                                                                                                                 pagedata1["setvar"]["A_Code_Insurance_Type_key"]="SELF"
                                                                                                                                                                 
                                                                                                                                                                 }
                                                                                                                                                                 else if(objmain_life_response["al_sqs_details.sec_parti_flag"] == "Yes")
                                                                                                                                                                 {
                                                                                                                                                                 pagedata1["setvar"]["A_Code_Insurance_Type_key"]=arrModernFamilyList[objsec_life_response["al_person_details.slife.relationship"]];
                                                                                                                                                                 }
                                                                                                                                                        }
                                                                //added by ankita for PAMBNEWP-8825
                                                                             //added by ankita to change logic of passing code to VPMS PRUSIgnature Vanguard onwards
                                                                              if(currentPlan !== "PRUSignature Protect" && currentPlan !== "EssentialLife (SP)")//Added by sachin tupe for insu type
                                                                             {
                                                                             if(objmain_life_response["al_person_details.mlife.insu_type"]==="Business Loan Insurance (for Company/LLP)")
                                                               {
                                                                             pagedata1["setvar"]["A_Code_Insurance_Type_key"]="BLCO"
                                                                             
                                                               }
                                                                             if(objmain_life_response["al_person_details.mlife.insu_type"]==="Business Loan Insurance (for Sole Proprietorship/Partnership)")
                                                                             {
                                                                                           pagedata1["setvar"]["A_Code_Insurance_Type_key"]="BLSP"
                                                                                           
                                                                             }
                                                                             }
                                                                             
                                               //added by ankita on 7 dec 2020 as per changes requested for POTD-23607
                                               if(obj_prochoice["al_sqs_details.payment_backdate"]=="Yes")
                                               {
                                                   pagedata1["setvar"]["A_Rating_MAR_dat"]=inceptionDate[2]+inceptionDate[1]+inceptionDate[0];
                                                   pagedata1["setvar"]["A_Policy_Proposal_dat"]=inceptionDate[2]+inceptionDate[1]+inceptionDate[0];
                                               }
                                             else
                                             {
                                                pagedata1["setvar"]["A_Rating_MAR_dat"]=Current_date_dat;
                                                pagedata1["setvar"]["A_Policy_Proposal_dat"]=Current_date_dat;
                                             }
                                                                             
                                                           
                                                                 
                                                  console.log("pagedata pagedata1 --->"+JSON.stringify(pagedata1));
                                                var pagedataFunds={
                                                                "setvar":
                                                                {
                                                                "A_Search_str":"",
                                                                "A_Code_ILP_Fund_Source_key":"LF",
                                                                "A_Policy_Inception_dat": inceptionDate[2]+inceptionDate[1]+inceptionDate[0],
                                                                "A_Insured_DOB_01_dat":dob[2]+dob[1]+dob[0],
                                                                "A_Code_Insurance_Type_key":insuranceTypeCode[objmain_life_response["al_person_details.mlife.insu_type"]],
                                                                "A_Code_Religion_key":"",//added by ankita on 9 July 2019
                                                                "A_Master_Full_Coverage_Age_key":"",
                                                                "A_Rating_MAR_dat":Current_date_dat
                                                                },
                                                                "VPMSFunctionNameInSequence":["A_Master_ILP_Fund_key"],
                                                                "VPMSCallType":"choice"
                                                
                                                                }
                                                                             //added by ankita for modern family CR
                                                                                                                                                          if(objmain_life_response["al_person_details.mlife.insu_type_header"]=="non_business_purpose")
                                                                                                                                                        {
                                                                                                                                                                 
                                                                                                                                                                 if(objmain_life_response["al_sqs_details.sec_parti_flag"] == "No")
                                                                                                                                                                 {
                                                                                                                                                                 pagedataFunds["setvar"]["A_Code_Insurance_Type_key"]="SELF"
                                                                                                                                                                 
                                                                                                                                                                 }
                                                                                                                                                                 else if(objmain_life_response["al_sqs_details.sec_parti_flag"] == "Yes")
                                                                                                                                                                 {
                                                                                                                                                                 pagedataFunds["setvar"]["A_Code_Insurance_Type_key"]=arrModernFamilyList[objsec_life_response["al_person_details.slife.relationship"]];
                                                                                                                                                                 }
                                                                                                                                                        }
                                                              //added by ankita for PAMBNEWP-8825
                                                                             //added by ankita to change logic of passing code to VPMS PRUSIgnature Vanguard onwards
                                                                              if(currentPlan !== "PRUSignature Protect" && currentPlan !== "EssentialLife (SP)")//Added by sachin tupe for insu type
                                                                             {
                                                                             if(objmain_life_response["al_person_details.mlife.insu_type"]==="Business Loan Insurance (for Company/LLP)")
                                                               {
                                                                             pagedataFunds["setvar"]["A_Code_Insurance_Type_key"]="BLCO"
                                                                             
                                                               }
                                                                             if(objmain_life_response["al_person_details.mlife.insu_type"]==="Business Loan Insurance (for Sole Proprietorship/Partnership)")
                                                                             {
                                                                                           pagedataFunds["setvar"]["A_Code_Insurance_Type_key"]="BLSP"
                                                                                           
                                                                             }
                                                                             }
                                                    //added by ankita on 7 dec 2020 as per changes requested for POTD-23607
                                                    if(obj_prochoice["al_sqs_details.payment_backdate"]=="Yes")
                                                    {
                                                        pagedataFunds["setvar"]["A_Rating_MAR_dat"]=inceptionDate[2]+inceptionDate[1]+inceptionDate[0];
                                                        pagedataFunds["setvar"]["A_Policy_Proposal_dat"]=inceptionDate[2]+inceptionDate[1]+inceptionDate[0];
                                                    }
                                                     else
                                                     {
                                                        pagedataFunds["setvar"]["A_Rating_MAR_dat"]=Current_date_dat;
                                                        pagedataFunds["setvar"]["A_Policy_Proposal_dat"]=Current_date_dat;
                                                     }
                                                                             
                                                 
                                                
                                                                             
                                                                             
                                                console.log("subChannelTypeForAgencyBancaRepls" + subChannelTypeForAgencyBancaRepls + "channelTypeForAgencyBancaRepls" +channelTypeForAgencyBancaRepls);

                                                    if(objmain_life_response["al_sqs_details.sec_parti_flag"] == "Yes")
                                                    {
                                                    pagedata["setvar"]["A_Second_Life_boo"]="Y";
                                                    pagedataChoiceFunction["setvar"]["A_Second_Life_boo"]="Y";
                                                    }
                                                    else
                                                    {
                                                    pagedata["setvar"]["A_Second_Life_boo"]="N";
                                                    pagedataChoiceFunction["setvar"]["A_Second_Life_boo"]="N";
                                                    }
                                                    if(objsec_life_response["al_sqs_details.third_parti_flg"] == "Yes")
                                                    {
                                                    pagedata["setvar"]["A_Third_Life_boo"]="Y";
                                                    }
                                                    else
                                                    {
                                                    pagedata["setvar"]["A_Third_Life_boo"]="N";
                                                    }
                                                    if(objmain_life_response["al_person_details.pre_natal_child_flg"] == "Yes")
                                                    {
                                                     pagedata["setvar"]["A_Insured_Prenatal_01_boo"]="Y";
                                                    }
                                                    else
                                                    {
                                                     pagedata["setvar"]["A_Insured_Prenatal_01_boo"]="N";
                                                    }

                                                console.log("pagedata == "+JSON.stringify(pagedata));
                                                                  
                                                                  var currencyKey = "";
                                                                  
                                                                  
                                                                  var querySelect=fnGetCurrencyKey(obj_prochoice["al_sqs_details.product_name"]);
                                                            
                                                                  
                                                                  
                                                                  querySelect.execute(function (response)
                                                                                      {
                                                                                      
                                                                                      if(response != "{}" && response != "")
                                                                                      {
                                                                                      var obj = JSON.parse(response);
                                                                                      console.log("Response:"+JSON.stringify(obj));
                                                                                      currencyKey=obj[0]['product_currency'];
                                                                                      console.log("currencyKey:"+currencyKey);
                                                                                      if(currencyKey == "RM")
                                                                                      {
                                                                                      currencyKey = "MYR";
                                                                                      }
                                                                                      pagedata1["setvar"]["A_Currency_key"] = currencyKey;
                                                                                      
                                                                                     
                                                console.log("pagedata1 == "+JSON.stringify(pagedata1));
                                                    js_call_native_func("VPMSCall",pagedata1,function(A_Master_Product_Master_key_response_bundle)
                                                                      {
                                                                        //On swipe call from product selection screen Sourabh
                                                                        console.log("A_Master_Product_Master_key_response_bundle---"+A_Master_Product_Master_key_response_bundle)
                                                                        var responseParsing_bundle = JSON.parse(A_Master_Product_Master_key_response_bundle);
                                                                        console.log("responseParsing_bundle-1--:"+JSON.stringify(responseParsing_bundle));
                                                                        console.log("responseParsing_bundle-2--"+JSON.stringify(responseParsing_bundle[pagedata1["VPMSFunctionNameInSequence"]]))
                                                                        
                                                                        var PlanCodeValue ="";
                                                                       if(PlanCode.hasOwnProperty(currentPlan))// sourabh 0404 added this if condition for checking VPMS need to remove PRUglobal series // need to change by Paromita
                                                                        {
                                                                            PlanCodeValue= PlanCode[currentPlan];
                                                                        
                                                                        }
                                                                        else
                                                                        {
                                                                            PlanCodeValue = _.invert((responseParsing_bundle[pagedata1["VPMSFunctionNameInSequence"]]))[currentPlan];
                                                                        }
                                                                        console.log("PlanCodeValue:"+PlanCodeValue);
                                                                       
                                                                    
                                                                        pagedata["setvar"]["A_Master_Product_Master_key"]= PlanCodeValue;
                                                                        pagedata["setvar"]["A_Master_Rider_key"]= PlanCodeValue;
                                                                        
                                                                        pagedataFunds["setvar"]["A_Master_Rider_key"]= PlanCodeValue;
                                                                        pagedataFunds["setvar"]["A_Master_Product_Master_key"]= PlanCodeValue;
                                                                        
                                                                        pagedataChoiceFunction["setvar"]["A_Master_Rider_key"]= PlanCodeValue;
                                                                        pagedataChoiceFunction["setvar"]["A_Master_Product_Master_key"]= PlanCodeValue;
                                                                        
                                                                        
                                                                       
                                                                        
                                                                        console.log("pagedata pagedataFunds --->"+JSON.stringify(pagedataFunds));
                                                                        js_call_native_func("VPMSCall",pagedataFunds,function(response1)
                                                                                            {
                                                                                             console.log(" pagedataFunds response1---"+response1)
                                                                                            responseParsing_bundle = JSON.parse(response1);
                                                                                            var objresponse1 = (responseParsing_bundle[pagedataFunds["VPMSFunctionNameInSequence"]]);
                                                                                            for(sub in objresponse1)
                                                                                            {
                                                                                            FundCode[sub] = "LF"
                                                                                            }
                                                                                            
                                                                                            console.log("VPMS FundCode1:"+JSON.stringify(FundCode));
                                                                                            console.log("VPMS response1 :"+objresponse1);
                                                                                            pagedataFunds["setvar"]["A_Code_ILP_Fund_Source_key"]= "GF";
                                                                                            js_call_native_func("VPMSCall",pagedataFunds,function(response3)
                                                                                                                {
                                                                                                                console.log("VPMS response3:"+response3);
                                                                                                                responseParsing_bundle = JSON.parse(response3);
                                                                                                                var objresponse3 = (responseParsing_bundle[pagedataFunds["VPMSFunctionNameInSequence"]]);
                                                                                                                for(sub1 in objresponse3)
                                                                                                                {
                                                                                                                FundCode[sub1] = "GF"
                                                                                                                }
                                                                                                                console.log("VPMS FundCode2:"+JSON.stringify(FundCode));
                                                                        

                                                                                                    
                                                                            js_set_var("bTagetSusEffective", bTagetSusEffective, function()

                                                                                       {
                                                                                       console.log("pagedata bTagetSusEffective --->"+bTagetSusEffective);
                                                                                       console.log("pagedata112 pagedata --->"+JSON.stringify(pagedata));
                                                                            js_call_native_func("VPMSCall",pagedata,function(response)
                                                                                                {
                                                                                                      console.log("VPMS1 response:"+response);
                                                                                                
                                                                                        
                                                                                                      responseParsing_bundle = JSON.parse(response);
                                                                                                      var objChoiceValues = (responseParsing_bundle[pagedata["VPMSFunctionNameInSequence"]]);
                                                                                                
                                                                                                      var per_valid_res="{";
                                                                                                
                                                                                                      var valid_riders="RiderName=";
                                                                                                      console.log("valid_riders"+valid_riders);
                                                                                                
                                                                                                      var VPMSRiderJson = {};
                                                                                                      var VPMSRiderTerm = {};

                                                                                                      
                                                                                                      var objChoiceValuesSplit = objChoiceValues["result"].split(";")
                                                                                                      console.log("Ridername-->"+objChoiceValuesSplit.length)
                                                                                                      Valid_Rider="";
                                                                                                      for(iCount = 0 ;iCount < objChoiceValuesSplit.length-1;iCount++)
                                                                                                      {
                                                                                                      
                                                                                                          console.log("objChoiceValuesSplit[iCount]-->"+objChoiceValuesSplit[iCount])
                                                                                                          var Ridername = objChoiceValuesSplit[iCount+1];
                                                                                              
                                                                                                
                                                                                                
                                                                                                          console.log("Ridername-->"+Ridername)
                                                                                                          var storeRiderName = Ridername;
                                                                                                          console.log("storeRiderName-->"+storeRiderName)
                                                                                                
                                                                                                
                                                                    console.log("jsonRideIds:"+jsonRideIds[Ridername]);
                                                                                                          if(jsonRideIds[Ridername]!= "undefined" && jsonRideIds[Ridername]!= undefined && jsonRideIds[Ridername]!= "null" && jsonRideIds[Ridername]!= null)
                                                                                                          {
                                                                                                           Element="rider_row_al_rider_sqs."+jsonRideIds[Ridername];
                                                                                                
                                                                                                            if(storeRiderName != currentPlan)
                                                                                                            {
                                                                                                                Valid_Rider+="RiderName="+jsonRideIds[Ridername]+"::Visible=Yes||";
                                                                                                            }
                                                                                                          }
                                                                                                         else
                                                                                                         {
                                                                                                          Ridername= Ridername.replace(/ /g,"_");
                                                                                                          Ridername= Ridername.replace("*","");
                                                                                                          Ridername= Ridername.toLowerCase();
                                                                        
                                                                                                
                                                                            
                                                                                                Element="rider_row_al_rider_sqs."+Ridername;
                                                                                             
                                                                                                            console.log("Current plan1:"+currentPlan);
                                                                                                            console.log("Ridername:"+Ridername);
                                                                                                            //if(storeRiderName != currentPlan)
                                                                                                            //{
                                                                      console.log("inside bundle");                                          Valid_Rider+="RiderName="+Ridername+"::Visible=Yes||";
                                                                                                            //}
                                                                                                
                                                                                                          }
                                                                                                console.log("Valid_Rider=="+Valid_Rider);
                                                                     console.log("storeRiderName:"+storeRiderName);
                                                                                                console.log("currentPlan:"+currentPlan)
                                                                                                            //if(storeRiderName != currentPlan)
                                                                                                            //{
                                                                                                                per_valid_res+='"'+Element+'":"'+Element+'",';
                                                                                                            //}
                                                                                                          VPMSRiderJson[Element]= objChoiceValuesSplit[iCount];
                                                                                                          if(objChoiceValuesSplit[iCount + 7] != "" && objChoiceValuesSplit[iCount + 7] != "undefined" && objChoiceValuesSplit[iCount + 7] != null)
                                                                                                          VPMSRiderTerm[Element] = objChoiceValuesSplit[iCount + 7]
                                                                                                          iCount = iCount + 17;
                                                                                                      
                                                                                                      }
                                                                                                      
                                                                                                console.log("per_valid_res middle-->"+per_valid_res);
                                                                                                
                                                                                                      if(per_valid_res.length>1) // condition added by supriya
                                                                                                      per_valid_res=per_valid_res.slice(0,-1);
                                                                                                      per_valid_res+="}";
                                                                                                
                                                                                                      if (per_valid_res == "{}")
                                                                                                    {
                                                                                                        per_valid_res = {"Error":"3000"};
                                                                                                    }
                                                                                                
                                                                                                
                                                                                                console.log("Plan==>"+pagedataChoiceFunction["setvar"]["A_Master_Product_Master_Key"]);
                                                                                                console.log("currentPlan==>"+currentPlan);
                                                                                                 console.log("pagedata FINAL == "+JSON.stringify(pagedata));
                                                                                                console.log("Before per_valid_res-->"+per_valid_res);
                                                                                                
                                                                                                
                                                                     
                                                                                                console.log("after per_valid_res222"+JSON.stringify(per_valid_res));
                                                                   
                                                                                               
                                                                     fnCallBundleSetFuncAfterAllChoice(per_valid_res,VPMSRiderJson,VPMSRiderTerm,A_Master_Product_Master_key_response_bundle,pagedata1,CheckShift);
                                                                                                
                                                                                                //fnCallSetFuncAfterAllChoice(per_valid_res,VPMSRiderJson,VPMSRiderTerm,A_Master_Product_Master_key_response,pagedata1,CheckShift);
                                                                                                
                                                                                                
                                                                                            });
                                                                                       });
                                                                        });
                                                                                            });
                                                                        
                                                                        
                                                                      });
                                                                                      }//added
                                                                                      });//added
                                                           });
                                                });
                                          });
               });
               });
               });
               });
                        });
}
               
function fnCallBundleSetFuncAfterAllChoice(per_valid_res,VPMSRiderJson,VPMSRiderTerm,A_Master_Product_Master_key_response,pagedata1,CheckShift)
{
   
   localStorage.setItem("current_plan",currentPlan);
   console.log("currentPlan:"+currentPlan);
   console.log("canEnterCampaign:"+canEnterCampaign);
   var air_asia_campaign="";
   var querySelect=getCampaignDataForAirAsia(currentPlan); //Abhilash
   var isCampaignActive=false;
   querySelect.execute(function(air_asia_response){
   if(air_asia_response!="{}" && air_asia_response!="")
   {
                       
         var obj=JSON.parse(air_asia_response);
           for(sub in obj){
               campaignExpDate=obj[sub]['expiry_date'];
               campaignEffeDate=obj[sub]['effective_date'];
               if(checkDateIsBetTwoDates(campaignEffeDate,campaignExpDate,fnGetDateTimeStamp())==true){
                       isCampaignActive=true;
                       campaignname=obj[sub]['campaign_name'];
                       
                        air_asia_campaign =  _.where(obj, {"campaign_name":obj[sub]['campaign_name']});
                       console.log("air_asia_campaign"+ JSON.stringify(air_asia_campaign));
               }
           }
                       
   }
                       
   js_set_var("air_asia_campaign",JSON.stringify(air_asia_campaign),function()
   {
   
   localStorage.setItem("current_plan",currentPlan);
   console.log("currentPlan:"+currentPlan);
   
   js_set_var("hideshowrider_bundle",JSON.stringify(per_valid_res),function()
              {
              js_set_var("VPMSRiderJson_bundle",JSON.stringify(VPMSRiderJson),function()
                         {
                         js_set_var("VPMSRiderTerm_bundle",JSON.stringify(VPMSRiderTerm),function()
                                    {
                                    js_set_var("szPlaneCode_bundle",JSON.stringify(_.invert(JSON.parse(A_Master_Product_Master_key_response)[pagedata1["VPMSFunctionNameInSequence"]])),function()
                                               
                                               {
                                               console.log("arrayBundleProduct:"+arrayBundleProduct);
                                              
                                               
                                               
                                               
                                               
                                               
                                              if(CheckShift=="Swp_Module")
                                               {
                                               
                                               //abhilash
                              
                                                   console.log("getCampaignDataForAirAsia"+JSON.stringify(air_asia_campaign));
                                                var campaignname="";
                                                   if(air_asia_campaign!="{}" && air_asia_campaign!="")
                                                   {
                                                  
                                               var obj2 = air_asia_campaign;
                                               console.log("obj2",obj2);
                                                   for(sub in obj2){
                                                   campaignExpDate=obj2[sub]['expiry_date'];
                                                   campaignEffeDate=obj2[sub]['effective_date'];
                                               
                                               
                                                   if(checkDateIsBetTwoDates(campaignEffeDate,campaignExpDate,fnGetDateTimeStamp())==true)
                                                       {
                                                       campaignProductName=obj2[sub]['product_name'];
                                                       campaignname=obj2[sub]['campaign_name'];
                                                       }
                                                   }
                                               
                                                                                            
                                                   if(checkDateIsBetTwoDates(campaignEffeDate,campaignExpDate,fnGetDateTimeStamp())==true)
                                                   {
                                                       if((currentPlan==campaignProductName) && (insu_type_for_nav == "individual"|| (campaignname=="upsize2" || campaignname=="platinum"))){
                                                       console.log("going to campaign vpmsjs");
                                                       menuController.loadPage("top_mysolutions_campaign",0);
                                                       }
                                                       else{
                                                       menuController.loadPage("top_mysolutions_benefit_selection",0);
                                                       }
                                                   }
                                                   else{
                                                   menuController.loadPage("top_mysolutions_benefit_selection",0);
                                                   }
                                               }
                                               else{
                                               //menuController.loadPage("top_mysolutions_benefit_selection",0); // commented by abhilash for air asia
                                               // added by Abhilash for air asia: swipe to campaign if true else swipe to benefit selection
                                               
                                                       menuController.loadPage("top_mysolutions_benefit_selection",0);
                                                  
                                               }

                                               
                                               }
                                               else if(CheckShift=="Ext_Module")
                                               {
                                                   menuController.done();
                                               }
                                               else
                                               {
                                                  console.log("stopSpinner ProcessEngineResult")
                                                  stopSpinner();//added by ankita on 3 oct 2019
                                               }
                                               
                                               
                                               
                                               });
                                    });
                         });
              
              
              
              });//
                       });
                       });
}
               

//Function to calladd Dependend Rider by parsing the rider.
function fnCallBundleOutputFunction(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,bFirstCallFlag,currentplan)
{
   var currencyKey = "";
   var querySelect=fnGetCurrencyKey(obj_prochoice["al_sqs_details.product_name"])
   querySelect.execute(function (response)
   {
                       
   if(response != "{}" && response != "")
   {
                       var obj = JSON.parse(response);
                       console.log("Response:"+JSON.stringify(obj));
                       currencyKey=obj[0]['product_currency'];
                       console.log("currencyKey:"+currencyKey);
                       if(currencyKey == "RM")
                       {
                           currencyKey = "MYR";
                       }
                       pagedata["setvar"]["A_Currency_key"] = currencyKey;
   
  
   var iSelectedRiderCount = parseInt(pagedata["setvar"]["A_Nof_Riders_int"]);
   
   console.log("Paromita iSelectedRiderCount In fnCallOutputFunction -->"+iSelectedRiderCount);
   
   pagedata["VPMSFunctionNameInSequence"]=["P_Fetch_Rider_Details_out"];
   
   if(currentplan == "PRUGlobal Series")
   {
       //added by ankita on 3 July 2019 for funds code to pass to VPMS for selected currency
       pagedata["setvar"]["A_Currency_key"]=obj_prochoice["al_sqs_details.foreign_currency"];;
       var fundCode = "";
       var querySelectFund=fnGetCodeFromSelectedFunds(obj_prochoice);
       querySelectFund.execute(function (responseFund)
           {
           
           if(responseFund != "{}" && responseFund != "")
           {
               var objFund = JSON.parse(responseFund);
               console.log("ResponseFund:"+JSON.stringify(objFund));
               var iFundsCount = 0;
               for(sub in objFund)
               {
                   console.log("objFund:"+objFund[sub]+"for sub:"+sub+"id:"+objFund[sub]["db_column"]+"fund code:"+objFund[sub]["fund_code"]);
                   var fundIdArray=objFund[sub]["db_column"];
                   var fundCode=objFund[sub]["fund_code"];
                   var fundIds = "al_sqs_details."+fundIdArray;
                   var fundValue=obj_prochoice[fundIds];
                   
                   if(fundValue != "0")
                   {
                   
                   pagedata["setvar"]["A_ILP_Fund_value_rea["+iFundsCount+"]"]=fundValue;
                   pagedata["setvar"]["A_Master_ILP_Fund_key["+iFundsCount+"]"]=fundCode;
                   
                   iFundsCount++;
                   }
               }
                               pagedata["setvar"]["A_Nof_fund_int"] = iFundsCount.toString();
           }
           
           console.log("After fund code:"+JSON.stringify(pagedata));
           js_call_native_func("VPMSCall",pagedata,function(responseRider)
                               {
                                   var jsonResponseRider = JSON.parse(responseRider);
                                   pagedata = fnAddDependentRider(pagedata,jsonResponseRider[pagedata["VPMSFunctionNameInSequence"]]); //Function to add Dependend Rider
                               
                               
                                   fnCallValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,iSelectedRiderCount,bFirstCallFlag,"");//added parameter obj_solution on 9 April 2019
                               
                               
                               
                               });
           });

   }
   else
   {
                       console.log("After dependent:"+JSON.stringify(pagedata));
   js_call_native_func("VPMSCall",pagedata,function(responseRider)
   {
       var jsonResponseRider = JSON.parse(responseRider);
       pagedata = fnAddDependentRider(pagedata,jsonResponseRider[pagedata["VPMSFunctionNameInSequence"]]); //Function to add Dependend Rider
    
       
           fnCallBundleValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,iSelectedRiderCount,bFirstCallFlag,"");//added parameter obj_solution on 9 April 2019
       
       
       
   });
                       }
                       }
                       });
}
function fnCallBundleValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,iSelectedRiderCount,bFirstCallFlag,jsonLeftPanel)
{

console.log("Paromita iSelectedRiderCount In fnCallValidation -->"+iSelectedRiderCount);

var checkFirstCal = document.getElementById("al_sqs_details.min_insurance_premium").value;
console.log("checkFirstCal fnCallValidation--"+checkFirstCal);
console.log("bFirstCallFlag--"+bFirstCallFlag);
/* if((obj_slife["al_person_details.slife.relationship"]!="Father" && obj_slife["al_person_details.slife.relationship"]!="Mother" && obj_slife["al_person_details.slife.relationship"]!="Friend" && obj_slife["al_person_details.slife.relationship"]!="Spouse" && obj_slife["al_person_details.slife.relationship"]!="Parent" && obj_slife["al_person_details.slife.relationship"]!="Legal Guardian"))
          {
fnMSChangeVPMSInput(pagedata); // Added by Shivani for Modern Family CR for MAy2022 Release
          }*/

// Sourabh when UI fields are dissable on first calculate

if((pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS2" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL03" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL08" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL10" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "ILS3" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL12" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL14" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL16" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL20" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL25" || pagedata["setvar"]["A_Master_Product_Master_Key"] == "IL24") && bFirstCallFlag == false && szOkToAmendCVFlag == "No")
{
   console.log("In Prevalidate");
   bFirstCallFlag = true;
   pagedata["VPMSFunctionNameInSequence"] = ["P_Validate_Pre_Benefit_out"];
}
else
{
   console.log("In validate");
   bFirstCallFlag = false;
   pagedata["VPMSFunctionNameInSequence"] = ["P_Validate_Benefit_out"];
}


console.log("pageData:"+JSON.stringify(pagedata));
          

js_call_native_func("VPMSCall",pagedata,function(szValidationError)
               {
                       console.log("szValidationError:"+szValidationError);
                       szValidationError=szValidationError.replace(/\\r\\n/g, "<br />");//added for defect 7381 on 11 may 2019
                       console.log("szValidationError123:"+szValidationError);
                       szValidationError=szValidationError.replace(/\\n/g, "<br />");//Commented for Standardize eeror message for defect 5158 by ankita on 14 May 2018
                       console.log("szValidationError124:"+szValidationError);
                       var jsonszValidationError = JSON.parse(szValidationError)

                   if(fnShowValidationError(jsonszValidationError[pagedata["VPMSFunctionNameInSequence"]],obj_mlife_res,obj_prochoice,pagedata,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel))
                       {
                   console.log("pagedata callfrom:"+callfrom);

                           if(bFirstCallFlag == true)
                           {
                   
                              if(callfrom == "bundle_product")
                              {
                              fnCallOutputAfterBundleValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,iSelectedRiderCount,bFirstCallFlag);
                              }
                               
                               
                               
                           }
                           else
                           {
                               pagedata["VPMSFunctionNameInSequence"] = ["P_Validate_Post_Benefit_out"];
                               js_call_native_func("VPMSCall",pagedata,function(szValidationError)
                                                   {
                                                       console.log("P_Validate_Post_Benefit_out szValidationError:"+szValidationError);
                                                       szValidationError=szValidationError.replace(/\\r\\n/g, "<br />");//added for defect 7381 on 11 may 2019
                                                       console.log("P_Validate_Post_Benefit_out szValidationError123:"+szValidationError);
                                                       szValidationError=szValidationError.replace(/\\n/g, "<br />");//Commented for Standardize eeror message for defect 5158 by ankita on 14 May 2018
                                                       console.log("P_Validate_Post_Benefit_out szValidationError124:"+szValidationError);
                                                       var jsonszValidationError = JSON.parse(szValidationError)

                                                   if(fnShowValidationError(jsonszValidationError[pagedata["VPMSFunctionNameInSequence"]],obj_mlife_res,obj_prochoice,pagedata,iSelectedRiderCount,flag_cals,loadingflag_generate,callfrom,bFirstCallFlag,jsonLeftPanel))
                                                       {

//callFromOther="bundle_product";
                                                           if(callfrom==="bundle_product")
                                                                   {
                                                           fnCallOutputAfterBundleValidation(pagedata,flag_cals,loadingflag_generate,callfrom,obj_mlife_res,obj_prochoice,iSelectedRiderCount,bFirstCallFlag);
                                                           
                                                                   
                                                                   }
                                                           
                                                           
                                                       }
                                                   });
                           }
                       }
               });
       //}


}
