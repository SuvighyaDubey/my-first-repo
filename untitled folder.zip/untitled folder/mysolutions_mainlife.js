/*******************************************************
 Page Name: Personal Details
 Created By: Pooja Dubey
 Modified by : Purva / Pramod C
 Modified Date : 07 August 2017
 Modified reason : Changes for UOB channel
 *******************************************************/
var mainLifeFlag = false; // Piyush: For defect 8890
var counter=0;
var ocArr="";
var fromMySolution = "";
var obj_mlife;
var obj_slife;
var startFromCareerkit =  false;
var obj_tlife;
var nobClass = new Array();
var third_blnk = null;
var seclife_blnk = null;
var ypfr_creation_dt = "";
var val_nob_mlife;
var val_nob_slife;
var childFlag = "";
var val_nob_tlife;
var mlife_flag_noupdate="0";
var mlife_flag_update="0";
var slife_flag_noupdate="0";
var slife_flag_update="0";
var tlife_flag_noupdate="0";
var tlife_flag_update="0";
var result_mlife;
var first_name_ck = new Array();
var person_id_ck = new Array();
var Client_id="";
var fname_mlifeval;
var fname_slifeval;
var fname_tlifeval;
var ylp_type_mlife="";
var ylp_type_slife="";
var ylp_type_tlife="";
var mlife_anb;
var pvm_check="";
var load_tsv_data="";

var replicate_res="";

var pre_natal_handle;
var relationship_mlife="";
var relationship_slife="";
var relationship_tlife="";

var client_ylp_type_mlife="";
var client_ylp_type_slife="";
var client_ylp_type_tlife="";
var person_id_delete=""
var Channel="";
var SubChannel="";
var selected_channel="";

var ANB_set="";
var prod_choice_response="";
var ddlArray=new Array("Select Relationship","Husband", "Wife", "Legal Guardian", "Brother", "Sister", "Child", "Other", "Employer","Partner","Nephew","Niece","Nephew/Niece", "Uncle", "Aunty", "Grandparents", "Grandchildren","Grandfather","Grandmother","Cousin Brother","Cousin Sister","Step Father","Step Mother","Step Child","Step Brother","Step Sister","Spouse","Legal Guardian","Parent");//change grandchild to grandchilder by ankita on 22 april 2022 for modern family CR
//var arrmatrixMale=new Array("Parent","Legal Guardian","Grandfather","Cousin Brother","Uncle","Step Father","Brother","Step Brother");
//var arrmatrixFemale=new Array("Parent","Legal Guardian","Grandmother","Cousin Sister","Aunty","Step Mother","Sister","Step Sister");

/*Variable added by Praveen on 18.02.2016 for fresh case delete*/
var client_id_fresh="";
var mlife_person_id_fresh="";
var slife_person_id_fresh="";
var tlife_person_id_fresh="";
var sqs_id_fresh="";
var elementName_populate="";
var calculatedAge;

var SQS_From_AL = "";
var response_pro_req_AL = "";
var replaceQuoteResponse = "";
var client_id_res_AL = "";
var productCertified="";
var riderCertified="";//added by ankita on 2 July for PRUwith you product (PRUmillion med rider)
var isILproduct=false;
var ilMainLifeANB="";
var ilMainLifeANB_monthly=""; //Added by Sachin for il_monthly CR.
var checkPRUwithyou="";
var invest_link_prod="";
var easeCampaignCode="";//Added by Sachin Tupe for pwy gio/sio ease campaign on date 2-08-2018.
var SecondLifeEaseCampaignCode=false;
var ThirdLifeEaseCampaignCode=false;
var vpmsEaseCampaignCode="";

var femaleGender="";
var  femaleAge="";
var female_smoke_status="";
var testData="";
var riskProfile_ranking="";
var risk_profile_level="";
var solnmyRiskProfileRanking = "";
var ribbenProduct=[];
var insu_type_for_nav = "";
var insu_type_header_for_nav = "";
var checkDateDiff="";
var anb_type="IL_Monthly"
var msqgresponseobject=""
var msqg_mainlife_response="";
var sysdate="";
var CreatedinceptiondateDate="";
var obj_priority=[];
//added by ankita on 15 jan 2023 for bundle product changes
var fetchPriorityResponse="";
var isFromMyneed=false;
/*********NOTE*************/
//FOLLOWING "ilProductLis" NEW PRODUCT "PRUsmart gain" ADDED BY SACHIN  TUPE ON 29-05-2018.
/*************************/
//Added by ankita for PRUmy treasure product
//Added by ankita for PRUsignature income product on 7 July 2018
//Added PRUEnhanced Cover similar to PRUMillion Cover 2.0 by Pradnya for July 2023 release
//Pradnya: added PRULink Supreme Plus for march24 release.
//Pradnya: added condition for PRUsignature plus for june24 release



var ilProductList = ["PRUwith you","PRUmillion cover","PRUsignature USD","PRUsignature infinite","PRUwealth gain plus","PRUgrowth","PRUsmart gain","PRUcancer X","PRUmy treasure","PRUsignature income","PRUsignature prime","PRUSignature Optimiser","PRUSignature Invest","PRULink Investor Account","PRUValue Gain","PRUGlobal Series","PRULink Cover","PRUWealth Plus","PRUMy Gift","PRUlink one","PRUaspire","LifeLink","PRUlink million","PRUcancer","PRUlife ready","PRUmy kid","PRUterm","PRUmy child","PRUlady","PRUmy legacy","PRUcash","RetireGuard (SP)","PRUcash double reward","PRUcash premier","PRUmultiple crisis cover","PRUheritage","InvestLink","InvestLink Global","Crisis Cover Plus","PRUretirement growth","PRUlink investor account","PRUmortgage","PRUterm_scb","PRUlife partner","PRUsignature","PRUmy gift","PRUaspire 2.0","PRUSenior Med","PRUsignature Reward","PRUWealth Max","PRUMax Cover","PRUSignature Reserve","EssentialLife (SP)","PRUSignature Protect","PRUEasy Protect","PRUMulti Crisis Guard","PRUCash Enrich","PRUTerm Premier","PRUSignature Assure","PRULink Growth","PRUAll Care","PRUFlexi Gain","PRUSignature Harvest","PRUGain Plus","PRUSignature Treasure","PRULink Supreme","PRUSignature Vanguard","PRUSignature Harvest Plus","PRUEnrich Gain","PRUSignature Ace","PRUElite Invest","PRUSignature Boost","PRUSignature GrowthPlus","PRUEnhanced Cover","PRUWealth Enrich","PRULink Supreme Plus","PRUSignature Plus"]; // Array of IL product//added product PRUSignature Vanguard by ankita on 8 july 2022//added product PRUSignature Harvest Plus by ankita on 8 august 2022//added product PRUSignature Ace by ankita on  5 sept 2022//condition of PRUSignature Boost added by ankita on 11 april 2023



//Abhilash: EssentialLife (SP)_SCB name changed to PRUSignature Protect on 3rd July

//Added product PRUcancer X in Array ilProductList on 4 June 18 by ankita // by sourabh on  1 april 2019 for PRUGlobal Series
//var ds_agentId="";

/*******************************************************
 Function Name: validateandSwipeRight()
 Function Description: Swipe the page from right to left
 Parameters:
 Created By: Pooja Dubey
 Created On:
 Modified By:
 Modified On:
 Modification Reason:
 *******************************************************/
//function fnMsPersonalvalidateandSwipeLeft()
//{
//    if (ValidatePersonalScreen())
//    {
//        fnMsPersonalCheckforFieldsUpdate("Swp_Module");
//    }
//}

/*******************************************************
 Function Name: validateandSwipeRight()
 Function Description: Swipe the page from left to right
 Parameters:
 Created By: Pooja Dubey
 Created On:
 Modified By:
 Modified On:
 Modification Reason:
 *******************************************************/
function fnMsPersonalvalidateandSwipeRight()
{
    //do nothing
    stopSpinner();
}

//function fnMsPersonal_Exit()
//{
//   if (ValidatePersonalScreen())
//   {
//       fnMsPersonalCheckforFieldsUpdate("Ext_Module");
//   }
//}

function fnMsSaveData()
{
    if (ValidatePersonalScreen())
    {
        alert("260");
    }
}

function fnMsViewAL() // makarand: for view al from sqs 03/08/2017 
{
//    var Al_filename=agent_id+"/"+proposal_no+"/"+"Alpdf"+proposal_no+".pdf";
    js_get_var("Al_filename", function(Al_filename)
               {
               loadShowcasePage(Al_filename,"NO","");
               });
    
    
}
//To transfer data from one page to other
function personal_life_details(flag)
{
    console.log("inside personal_life_details ");
    var anb_changed_by="";
    js_get_var("proposal_required_info", function(replicate_res)
    {
        js_get_var("ylp_id_for_sqs",function(ylp_id_for_sqs)
        {
           js_get_var("mck_client_id",function(mck_client_id)
              {
              js_get_var("clientIdsjson",function(response_fresh_ylp)
                 {
                     js_get_var("main_life_response", function(mainlife_res)
                        {
                        if(mainlife_res != "" && mainlife_res != null && mainlife_res != "null"  && mainlife_res != "(null)")
                        {
                                var obj_mlife_ch=JSON.parse(mainlife_res);
                                anb_changed_by=obj_mlife_ch["anb_changed_by"];
                        }
//        var nob_mlife = parseInt($("select[name='al_employee_details.mlife.nature_of_business']")[0].selectedIndex);  //sayali
//        val_nob_mlife = nobClass[nob_mlife - 1];
//        var nob_slife = parseInt($("select[name='al_employee_details.slife.nature_of_business']")[0].selectedIndex);
//        val_nob_slife = nobClass[nob_slife - 1];
//        var nob_tlife = parseInt($("select[name='al_employee_details.tlife.nature_of_business']")[0].selectedIndex);
//        val_nob_tlife = nobClass[nob_tlife - 1];
                                console.log("inside sqs_from_al before "+ SQS_From_AL);
                                
        if(SQS_From_AL == "Yes"){
                                console.log("sqs_from_al inside SQS_From_AL "+ SQS_From_AL);
            fname_mlifeval = document.getElementById("al_person_details.mlife.first_name_dropdown").value;
            fname_slifeval = document.getElementById("al_person_details.slife.first_name_dropdown").value;
            fname_tlifeval = document.getElementById("al_person_details.tlife.first_name_dropdown").value;
        
        }
         else if(Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)" && (replicate_res == "" || replicate_res == null || replicate_res == "null" || replicate_res == "(null)"))
        {
                                console.log("inside client id and replicate not null ");
            fname_mlifeval = document.getElementById("al_person_details.mlife.first_name_dropdown").value;
            fname_slifeval = document.getElementById("al_person_details.slife.first_name_dropdown").value;
            fname_tlifeval = document.getElementById("al_person_details.tlife.first_name_dropdown").value;
        }else if(replicate_res != "" && replicate_res != null && replicate_res != "null" && replicate_res != "(null)")
        {
                                console.log("inside replicate is null ");
            fname_mlifeval = document.getElementById("al_person_details.mlife.first_name_dropdown").value;
            fname_slifeval = document.getElementById("al_person_details.slife.first_name_dropdown").value;
            fname_tlifeval = document.getElementById("al_person_details.tlife.first_name_dropdown").value;
        }else
        {
                                console.log("inside personal_life_details else condition");
            fname_mlifeval = document.getElementById("al_person_details.mlife.first_name").value;
            fname_slifeval = document.getElementById("al_person_details.slife.first_name").value;
            fname_tlifeval = document.getElementById("al_person_details.tlife.first_name").value;
        }
               
        if (document.getElementById("al_person_details.pre_natal_child_flg").checked)
       {
            mlife_anb = "1";
       }else
       {
            mlife_anb = document.getElementById("al_person_details.mlife.anb").value;
       }
               // commented as the third life is disabled when no product is found . This is not required(Done initially when pruaspire was developed.) - DEF-2861
//        if(Channel == "Banca")
//        {
//                                console.log("in purva1....");
//            document.getElementById("al_sqs_details.third_parti_flg_yes").disabled = true;
//            document.getElementById("al_sqs_details.third_parti_flg_no").disabled = true;
//        }

        //Variable to take json data
                                
                //changes by sayali on 1-06-2017
                                
                                
                                
                val_nob_mlife = fnMsGetNobData("mlife");
                 console.log("1==>"+val_nob_mlife)
                     if(getNobValue("al_employee_details.mlife.nature_of_business")==false)
           {
             alert("Please select nature of business from the list." );
              return;
           }
          insu_type_for_nav = "";
          insu_type_header_for_nav = "";
        if($(escape_jq("al_person_details.mlife.insu_type_header")).val() == "non_business_purpose"){
            var insu_type = "individual";
        }else{
            var insu_type = $(escape_jq("al_person_details.mlife.insu_type")).val();
        }
          
          var insu_type_header = $(escape_jq("al_person_details.mlife.insu_type_header")).val()
          insu_type_for_nav = insu_type;
          insu_type_header_for_nav = insu_type_header;
        var mainlife = {
            "al_person_details.mlife.insu_type": insu_type,
            "al_person_details.mlife.insu_type_header": insu_type_header,
            "al_person_details.mlife.first_name": fname_mlifeval,
            "al_person_details.pre_natal_child_flg": getNatalStats(),
            "al_person_details.mlife.expected_delivery_dt": document.getElementById("al_person_details.mlife.expected_delivery_dt").value,
            "al_person_details.gestational_week": document.getElementById("al_person_details.gestational_week").value,
            "al_person_details.mlife.dob": document.getElementById("al_person_details.mlife.dob").value,
            "al_person_details.mlife.anb": mlife_anb,
            "al_person_details.mlife.anb_temp": mlife_anb,//Added by Sachin Tupe for il monthly product.
            "al_person_details.mlife.gender": getGender("mlife"),
            "al_person_details.mlife.smoke_status": getSmokeStats("mlife"),
            "al_employee_details.mlife.occupation": document.getElementById("al_employee_details.mlife.occupation").value,
            "al_employee_details.mlife.occupation_class": document.getElementById("al_employee_details.mlife.occupation_class").value,
            "al_employee_details.mlife.nature_of_business": val_nob_mlife,                                                              //changed by sayali
            "al_employee_details.mlife.value_nature_of_business": document.getElementById("al_employee_details.mlife.nature_of_business").value,
            "al_sqs_details.sec_parti_flag": getMlifePartiFlag(),
            "al_person_details.mlife.parent_consent": getParentConsent(),
               "pvm_qualification_check": pvm_check,
            "pamb_channel":Channel,
            "pamb_sub_channel":SubChannel,
            "client_ylp_type_mlife":client_ylp_type_mlife,
            "anb_changed_by" :anb_changed_by,
            "al_person_details.mlife.anb_il_product" :$(escape_jq("al_person_details.mlife.anb_il_product")).val(),
            "al_person_details.mlife.anb_il_product_temp":$(escape_jq("al_person_details.mlife.anb_il_product")).val(), //Added by Sachin Tupe for il monthly product.
            "al_person_details.mlife.anb_il_monthly_product" :$(escape_jq("al_person_details.mlife.anb_il_monthly_product")).val(),//Added by Sachin Tupe for il monthly product.
            "al_person_details.mlife.anb_il_monthly_product_temp" :$(escape_jq("al_person_details.mlife.anb_il_monthly_product")).val(),//Added by Sachin Tupe for il monthly product.
            "rider_certified_check": riderCertified//added by ankita on 2 July 2018 for rider certified check for PRUwith you product
        }

        console.log("il_monthly object"+mainlife);
        //Variable to take json data
                        val_nob_slife = fnMsGetNobData("slife");
                           console.log("2==>"+val_nob_slife)
                        if(document.getElementById("al_sqs_details.sec_parti_flag_yes").checked && getNobValue("al_employee_details.slife.nature_of_business")==false)
           {
           alert("Please select nature of business from the list." );
           return;
           }        
                                
        var seclife = {
            "al_person_details.slife.first_name": fname_slifeval,
            "al_person_details.slife.relationship": document.getElementById("al_person_details.slife.relationship").value,
            "al_person_details.slife.dob": document.getElementById("al_person_details.slife.dob").value,
            "al_person_details.slife.anb": document.getElementById("al_person_details.slife.anb").value,
            "al_person_details.slife.anb_temp": document.getElementById("al_person_details.slife.anb").value,//Added by Sachin Tupe for il monthly product.
            "al_person_details.slife.gender": getGender("slife"),
            "al_person_details.slife.smoke_status": getSmokeStats("slife"),
            "al_employee_details.slife.occupation": document.getElementById("al_employee_details.slife.occupation").value,
            "al_employee_details.slife.occupation_class": document.getElementById("al_employee_details.slife.occupation_class").value,
            "al_employee_details.slife.nature_of_business": val_nob_slife,
            "al_employee_details.slife.value_nature_of_business": document.getElementById("al_employee_details.slife.nature_of_business").value,
            "al_sqs_details.third_parti_flg": getSlifePartiFlag(),
            "client_ylp_type_slife":client_ylp_type_slife,
            "al_person_details.slife.anb_il_product" :$(escape_jq("al_person_details.slife.anb_il_product")).val(),
            "al_person_details.slife.anb_il_product_temp":$(escape_jq("al_person_details.slife.anb_il_product")).val(),//Added by Sachin Tupe for il monthly product.
            "al_person_details.slife.anb_il_monthly_product" :$(escape_jq("al_person_details.slife.anb_il_monthly_product")).val(),//Added by Sachin Tupe for il monthly product.
            "al_person_details.slife.anb_il_monthly_product_temp" :$(escape_jq("al_person_details.slife.anb_il_monthly_product")).val()//Added by Sachin Tupe for il monthly product.

        }

        //Variable to take json data
                                
                                
                             val_nob_tlife = fnMsGetNobData("tlife");
                              console.log("3==>"+val_nob_tlife)
 if(document.getElementById("al_sqs_details.third_parti_flg_yes").checked && getNobValue("al_employee_details.tlife.nature_of_business")==false)
           {
           alert("Please select nature of business from the list." );
           return;
           }
                                
        var thirdlife = {
            "al_person_details.tlife.first_name": fname_tlifeval,
            "al_person_details.tlife.relationship": document.getElementById("al_person_details.tlife.relationship").value,
            "al_person_details.tlife.dob": document.getElementById("al_person_details.tlife.dob").value,
            "al_person_details.tlife.anb": document.getElementById("al_person_details.tlife.anb").value,
            "al_person_details.tlife.anb_temp": document.getElementById("al_person_details.tlife.anb").value,
            "al_person_details.tlife.gender": getGender("tlife"),
            "al_person_details.tlife.smoke_status": getSmokeStats("tlife"),
            "al_employee_details.tlife.occupation": document.getElementById("al_employee_details.tlife.occupation").value,
            "al_employee_details.tlife.occupation_class": document.getElementById("al_employee_details.tlife.occupation_class").value,
            "al_employee_details.tlife.nature_of_business": val_nob_tlife,
            "al_employee_details.tlife.value_nature_of_business": document.getElementById("al_employee_details.tlife.nature_of_business").value,
            "client_ylp_type_tlife":client_ylp_type_tlife,
            "al_person_details.tlife.anb_il_product" :$(escape_jq("al_person_details.tlife.anb_il_product")).val(),
            "al_person_details.tlife.anb_il_product_temp":$(escape_jq("al_person_details.tlife.anb_il_product")).val(),//Added by Sachin Tupe for il monthly product.
            "al_person_details.tlife.anb_il_monthly_product" :$(escape_jq("al_person_details.tlife.anb_il_monthly_product")).val(),//Added by Sachin Tupe for il monthly product.
            "al_person_details.tlife.anb_il_monthly_product_temp" :$(escape_jq("al_person_details.tlife.anb_il_monthly_product")).val()//Added by Sachin Tupe for il monthly product.
        }
        
        //Variable to take updated flags
        var personal_update_data_flags = {
            "mlife_flag_update": mlife_flag_update,
            "slife_flag_update": slife_flag_update,
            "tlife_flag_update": tlife_flag_update
        }

        
        var ylp_type_handshaking_tlife = {
            "ylp_type_mlife": ylp_type_mlife,
            "ylp_type_slife": ylp_type_slife,
            "ylp_type_tlife": ylp_type_tlife
        }
               
               var ylp_type_handshaking_slife = {
               "ylp_type_mlife": ylp_type_mlife,
               "ylp_type_slife": ylp_type_slife,
               "ylp_type_tlife": ""
               }
               
               var ylp_type_handshaking_mlife = {
               "ylp_type_mlife": ylp_type_mlife,
               "ylp_type_slife": "",
               "ylp_type_tlife": ""
               }
                var pmp_proposer="ML";
                var global_person_id="";
                var persin_id= $("select[name='al_person_details.mlife.first_name_dropdown'] option:selected").index();
                         console.log("persin_id------>"+persin_id);
                 if((response_fresh_ylp!="" && response_fresh_ylp!="(null)" && response_fresh_ylp!=null && response_fresh_ylp!="null") && (mck_client_id=="" || mck_client_id=="null" || mck_client_id==null || mck_client_id=="(null)"))
                 {
                     var obj_fresh=JSON.parse(response_fresh_ylp);
                     mck_client_id=obj_fresh["client_id"];
                     global_person_id=obj_fresh["mlife_person_id"];
                 }
                 if(typeof persin_id != "undefined" && persin_id != 0)
                 {
                         global_person_id = person_id_ck[persin_id - 1];
                 }
                if(!(replicate_res == "" || replicate_res == null || replicate_res == "null" || replicate_res == "(null)"))
                  {
                      var obj_replicate=JSON.parse(replicate_res);
                      mck_client_id=obj_replicate['client_id'];
                  }
               var loadQuery = new DbUtil();
               loadQuery.query()
               .select()
               .column('*')
               .from()
               .table('careerkit_person_details')
               .where()
               .clause('ylp_id','=',ylp_id_for_sqs)
               .and()
               .clause('client_id','=',mck_client_id)
               .and()
               .clause('is_deleted','=',"No")
               .and()
               .clause('agent_id','=',ds_agentId);//Added by Pallavi for device sharing
               loadQuery.execute(function(response_ck)
               {
                    var starts_from="";
                    if(response_ck!="" && response_ck!="{}")
                     {
                                 var obj_pmp=JSON.parse(response_ck);
                                 starts_from=obj_pmp[0]["starts_from"];
                     }
                     else{
                     pmp_proposer="ML";
                     }
                     var loadQuery1 = new DbUtil();
                     loadQuery1.query()
                     .select()
                     .column('*')
                     .from()
                     .table('al_ylp_details')
                     .where()
                     .clause('ylp_id','=',ylp_id_for_sqs)
                     .and()
                     .clause('pro_person_id','=',global_person_id)
                     .and()
                     .clause('client_id','=',mck_client_id)
                     .and()
                     .clause('is_deleted','=',"No")
                     .and()
                     .clause('agent_id','=',ds_agentId);//Added by Pallavi for device sharing
                     loadQuery1.execute(function(response_ylp)
                        {
                        if(response_ylp!="" && response_ylp!="{}")
                        {
                                        pmp_proposer="ML";
                        }
                        else if(response_ck!="" && response_ck!="{}"){
                                       
                                pmp_proposer="SL";
                                     
                        }
                        else if(ylp_id_for_sqs!="" && ylp_id_for_sqs!="(null)" && ylp_id_for_sqs!=null && ylp_id_for_sqs!="null")
                        {
                            pmp_proposer="SL";
                        }
                        else{
                        pmp_proposer="ML";
                        }
                                        
                var loadQuery1 = new DbUtil();
                loadQuery1.query()
                .select()
                .column('*')
                .from()
                .table('al_ylp_details')
                .where()
                .clause('ylp_id','=',ylp_id_for_sqs)
                .and()
                .clause('client_id','=',mck_client_id)
                .and()
                .clause('is_deleted','=',"No")
                .and()
                .clause('agent_id','=',ds_agentId);//Added by Pallavi for device sharing
                loadQuery1.execute(function(response_SCBRestrictQuo)
                   {
                                   if(response_SCBRestrictQuo != null && response_SCBRestrictQuo != "" && response_SCBRestrictQuo != undefined && response_SCBRestrictQuo != "{}") {
                                   var obj_SCBRestrictQuo = JSON.parse(response_SCBRestrictQuo);
                                   ypfr_creation_dt = obj_SCBRestrictQuo[0]['ypfr_creation_dt'];
                                   console.log("ypfr_creation_dt",ypfr_creation_dt)
                                   }
                    
                            
                      var ypfr_creation_dtFlag = "Yes";
                      if((ypfr_creation_dt == "" || ypfr_creation_dt == undefined || ypfr_creation_dt == null) && Channel == "Banca"){
                       ypfr_creation_dtFlag = "No";
                      }
                    js_set_var("ypfr_creation_dtFlag",ypfr_creation_dtFlag,function()
                    {
        //native functionality call to transfer data for main life
                            js_set_var("main_life_response", JSON.stringify(mainlife), function()
                            {
                                if (getMlifePartiFlag() == "Yes")
                                {
                                    //native functionality call to transfer data for second life
                                    js_set_var("sec_life_response", JSON.stringify(seclife), function()
                                    {
                                        if (getSlifePartiFlag() == "Yes")
                                        {
                                            //native functionality call to transfer data for third life
                                            js_set_var("third_life_response", JSON.stringify(thirdlife), function()
                                            {
                                                //For the time other products not coming
                                                js_set_var("personal_update_flags", JSON.stringify(personal_update_data_flags), function()
                                                {
                                                    js_set_var("personal_update_flags_database", JSON.stringify(personal_update_data_flags), function()
                                                    {
                                                        js_set_var("mck_to_ms_ylp", JSON.stringify(ylp_type_handshaking_tlife), function()
                                                        {
                                                            generateinputstring(0, "EMPTY",flag,"","",pmp_proposer);
                                                        });
                                                    });
                                                });
                                            });
                                        }
                                        else
                                        {
                                               ylp_type_tlife = "";
                                               third_blnk = null;
                                            js_set_var("third_life_response",JSON.stringify(third_blnk),function()
                                            {
                                                js_set_var("personal_update_flags", JSON.stringify(personal_update_data_flags), function()
                                                {
                                                    js_set_var("personal_update_flags_database", JSON.stringify(personal_update_data_flags), function()
                                                    {
                                                        js_set_var("mck_to_ms_ylp", JSON.stringify(ylp_type_handshaking_slife), function()
                                                        {
                                                            generateinputstring(0, "EMPTY",flag,"","",pmp_proposer);
                                                        });
                                                    });
                                                });
                                            });
                                        }
                                    });
                                }
                                else
                                {
                                       ylp_type_slife = "";
                                       ylp_type_tlife = "";
                                       seclife_blnk = null;
                                       third_blnk = null;
                                    js_set_var("sec_life_response",JSON.stringify(seclife_blnk),function()
                                    {
                                        js_set_var("third_life_response",JSON.stringify(third_blnk),function()
                                        {
                                            js_set_var("personal_update_flags", JSON.stringify(personal_update_data_flags), function()
                                            {
                                                js_set_var("personal_update_flags_database", JSON.stringify(personal_update_data_flags), function()
                                                {
                                                    js_set_var("mck_to_ms_ylp", JSON.stringify(ylp_type_handshaking_mlife), function()
                                                    {
                                                        generateinputstring(0, "EMPTY",flag,"","",pmp_proposer);
                                                    });
                                                });
                                            });
                                        });
                                    });
                                }
                    });
                });
                                        });
                                        });
          });
                                    });
        });
  });
               });
               });
}

//To load script on load of the page
function onLoadSqsMlifePage()
{
    console.log("onLoadSqsMlifePage:"+Client_id);
    fromMySolution = "";
    ypfr_creation_dt = "";
    sysdate=document.getElementById("al_person_details.mlife.cdate").value;
    isILproduct=false;
    startFromCareerkit = false;
    ocArr="";
    replaceQuoteResponse="";
    ilMainLifeANB="";
    ilMainLifeANB_monthly=""; //Added for il monthly by sachin.
    (arrMySolutionsVisitedFlag[0]==1?arrMySolutionsVisitedFlag[0]=1:arrMySolutionsVisitedFlag[0]=2);
    SQSmarkTopMenus(0);
    disableCutCopyPaste();
    placeholderToSelect();
    msqgresponseobject="";
    msqg_mainlife_response="";
    CreatedinceptiondateDate="";
    invest_link_prod_training = "";
    is_block_MBM_checking = "No";
   //ribbenProduct=[];
    //easeCampaignCode="";
     //#Prashant 18/09/2015
    //Binds dynamic blur function
    
    
    obj_mlife="";//clear variable added by sachin T on date 21-08-2019
    obj_slife="";//clear variable added by sachin T on date 21-08-2019
    obj_tlife="";//clear variable added by sachin T on date 21-08-2019
   
    fnGlobalOnBlurCheckForSpclChar();
  
    inceptionRetrive(); //Added by Sachin Tupe for il monthly product retrival.
    
    
    ANB_set = "";
    
    
    prod_choice_response="";
    //added by ankita on 15 jan 2023 for bundle product changes
    //fetchPriorityResponse="";
    console.log(client_ylp_type_mlife+"-------"+client_ylp_type_slife+"----------"+client_ylp_type_tlife);
    console.log("client_id--->"+Client_id);
     if(Client_id == "" || Client_id == null || Client_id == "null" || Client_id == "(null)")
     {
       relationship_mlife="";
       relationship_slife="";
       relationship_tlife="";
         
       person_id_delete=""
       Channel="";
     }
    console.log("On load Client_id:"+Client_id+"--ds_agentId:"+ds_agentId+"--mck_ylp_id:"+mck_ylp_id);
    //added by ankita for defect 746 on 10 march 2023
    var productRecommendationRes=fnfetchFNPPriority(Client_id,ds_agentId,mck_ylp_id);
    productRecommendationRes.execute(function(recommendRes)//Added for solution button.
    {
                                     fetchPriorityResponse="";
    if(Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)")
        {
            if(recommendRes != "" && recommendRes != null &&  recommendRes != "null" &&  recommendRes != "(null)" && recommendRes != "{}")
            {
                       
                               var obj_recommend_res = JSON.parse(recommendRes);
                              //added by ankita on 15 jan 2023 for bundle product changes
                              fetchPriorityResponse=obj_recommend_res;
                              console.log("fetchPriorityResponse:"+fetchPriorityResponse);
            }
        }
    
               if (master_tsv_data != "" && master_tsv_data != null && master_tsv_data != "null" && master_tsv_data != "(null)" && master_tsv_data.length > 0)
               {
               load_tsv_data = JSON.parse(master_tsv_data);

              // setOptionsinOccandNob("mlife", load_tsv_data["Occupation_text"], load_tsv_data["Occupation_value"],"occupation");
               //setOptionsinOccandNob("slife", load_tsv_data["Occupation_text"], load_tsv_data["Occupation_value"],"occupation");
              // setOptionsinOccandNob("tlife", load_tsv_data["Occupation_text"], load_tsv_data["Occupation_value"],"occupation");

               /* Searchable dropdown occupation call*/
                   ocArr = MsGetOccupation(load_tsv_data["Occupation_text"],load_tsv_data["Occupation_value"]);
                   
                   console.log("ocArr :"+ocArr)
               seachableDropDownMLifeOccupation(ocArr);
               seachableDropDownSLifeOccupation(ocArr);
               seachableDropDownTLifeOccupation(ocArr);

               //setOptionsinOccandNob("mlife", load_tsv_data["Nob_text"], load_tsv_data["Nob_value"],"nature_of_business");
              // setOptionsinOccandNob("slife", load_tsv_data["Nob_text"], load_tsv_data["Nob_value"],"nature_of_business");
               //setOptionsinOccandNob("tlife", load_tsv_data["Nob_text"], load_tsv_data["Nob_value"],"nature_of_business");
               
               /* Searchable dropdown nature of business call*/
                   
                   
                   
                   var nobObj= MsGetNob(load_tsv_data["Nob_text"],load_tsv_data["Nob_value"]);
                   console.log("nobObj :"+nobObj)
               seachableDropDownMLifeNature(nobObj[0]);
               seachableDropDownSLifeNature(nobObj[0]);
               seachableDropDownTLifeNature(nobObj[0]);
               }

                   
            document.getElementById("al_person_details.mlife.expected_delivery").style.display = 'none';
            document.getElementById("gestational_week").style.display = 'none';
            document.getElementById("al_person_details.mlife.dob").disabled = true;
            document.getElementById("al_person_details.slife.dob").disabled = true;
            document.getElementById("al_person_details.tlife.dob").disabled = true;
            document.getElementById("al_person_details.mlife.anb").disabled = true;
            document.getElementById("al_person_details.slife.anb").disabled = true;
            document.getElementById("al_person_details.tlife.anb").disabled = true;
//    js_set_var("master_matrix_tsv_data",master_matrix_tsv_data,function() Commented by Paromita
//                 {
    
    var msqgData=fngetBasicMsqgPlan();
    var mainlife_msqg_indicator=fnMSGetMSQGindicator();
    stopSpinner();
    mainlife_msqg_indicator.execute(function(msqgData_response)
    {
        if (msqgData_response != "{}" && msqgData_response != "")
            {
                var MSQGMedIndicatorObj = JSON.parse(msqgData_response);
                msqg_mainlife_response = MSQGMedIndicatorObj['0']['msqg_suspense_ind'];
            }
                                    
    msqgData.execute(function(msqgresponse)
              {
                    if(msqgresponse != "" && msqgresponse != null && msqgresponse != "null"  && msqgresponse != "(null)") {
                     
                     
                     msqgresponseobject = JSON.parse(msqgresponse);
                     
                     }
    js_get_var("isSQSFromAL",function(isSQSFromAL) //makarand: CALEAL option 2 10/08/2017
               {
               SQS_From_AL = isSQSFromAL;
    js_get_var("LoginAgentId",function(agent_id)
               {
               //ds_agentId=agent_id;
    
    js_get_var("clientIdsjson",function(response_fresh)
        {
            if(Client_id=="" || Client_id=="null" || Client_id==null || Client_id=="(null)")
               {
                   if(response_fresh!="" && response_fresh!="(null)" && response_fresh!=null && response_fresh!="null")
                   {
                       var obj_fresh=JSON.parse(response_fresh);
                       client_id_fresh=obj_fresh["client_id"];
                       mlife_person_id_fresh=obj_fresh["mlife_person_id"];
                       slife_person_id_fresh=obj_fresh["slife_person_id"];
                       tlife_person_id_fresh=obj_fresh["tlife_person_id"];
                       sqs_id_fresh=obj_fresh["sqs_id"];
                   }
               }
        js_set_var("from_benefit_page","",function() //Added for PWY_EASE Campaign by Sachin.
        {
        js_get_var("prod_choice_response",function(res_pr_choice)
            {
            if(res_pr_choice!="(null)" && res_pr_choice!=null && res_pr_choice!="")
               {
                   prod_choice_response=res_pr_choice;
                   
                   if(prod_choice_response!="(null)" && prod_choice_response!=null && prod_choice_response!="")
                   {
                   var productDetailsObj=JSON.parse(prod_choice_response);
                   if(productDetailsObj!="(null)" && productDetailsObj!=null && productDetailsObj!="")
                   {
					   
					   
                   //if(productDetailsObj["al_sqs_details.product_name"] == "PRUwith you"){ // If condition changes for handel IL product dynamically.
                   if((ilProductList.indexOf(productDetailsObj["al_sqs_details.product_name"])>=0)){
                   isILproduct=true;// product choice response flag set to true if product is IL. 14122017
                   }
                   }
                   }
               }
            js_get_var("proposal_required_info", function(response_pro_req)
            {
                       replaceQuoteResponse=response_pro_req;
                var ylp_id="";
                                       if(response_pro_req != "" && response_pro_req != null && response_pro_req != "null" && response_pro_req != "(null)")
                                       {
                                           var obj = JSON.parse(response_pro_req);
                                           ylp_id=obj['ylp_id'];
                                           
                                       }
                                       var productRecommendationRes=fnfetchFNPPriority(Client_id,ds_agentId,ylp_id);
                                           productRecommendationRes.execute(function(recommendRes)//Added for solution button.
                                           {
                                                                            
                                       if(response_pro_req != "" && response_pro_req != null && response_pro_req != "null" && response_pro_req != "(null)")
                                               {
                                                   if(recommendRes != "" && recommendRes != null &&  recommendRes != "null" &&  recommendRes != "(null)" && recommendRes != "{}")
                                                   {
                                                              
                                                                      var obj_recommend_res = JSON.parse(recommendRes);
                                                                     //added by ankita on 15 jan 2023 for bundle product changes
                                                                     fetchPriorityResponse=obj_recommend_res;
                                                                     console.log("fetchPriorityResponse replace quote:"+fetchPriorityResponse);
                                                   }
                                               }
                   var PVMSelect = getPVMQualification(ds_agentId);
                   PVMSelect.execute(function(res_pvm)
                    {
                         if(res_pvm != "" && res_pvm != null && res_pvm != "null"  && res_pvm != "(null)")
                         {
                         var obj_pvm = JSON.parse(res_pvm);
                         
                         pvm_check = obj_pvm[0]['pvm_qualification'];
                                     
                        productCertified=obj_pvm[0]['product_certified'];
                        riderCertified=obj_pvm[0]['rider_certified'];
                        invest_link_prod=obj_pvm[0]['invest_link_prod'];
                         if(obj_pvm[0]['product_certified'].indexOf("AILP_Yes") !== -1){
                         invest_link_prod_training="Yes";
                         }else{
                         invest_link_prod_training="No";
                         }
                                     
                         if(checkContractDateValid(obj_pvm[0]['appointment_date'])){
                             console.log("inside checkContractDateValid")
                             if(obj_pvm[0]['product_certified'].indexOf("MBM_Yes") == -1 && (channelTypeForAgencyBancaRepls == "agency" || channelTypeForAgencyBancaRepls == "fa")){
                                 console.log("inside product_certified true condition")
                                 is_block_MBM_checking = "Yes"
                             }else{
                                 console.log("inside product_certified false condition")
                                 is_block_MBM_checking = "No";
                             }
                         }
                         console.log("outside checkContractDateValid")
                        
                        console.log("riderCertified"+ riderCertified);
                        console.log("invest_link_prod"+ invest_link_prod);
                        console.log("productCertified"+productCertified);
                                     //Temporary commented
                     Channel = obj_pvm[0]['agent_channel']; //To change from Channelz to Channel and set global variable to blank when give for encryption
                    selected_channel= Channel;//TODO 26-06-2018
                     SubChannel=obj_pvm[0]['agent_sub_channel'];//sr added for new channel 31-jan-2017
                     console.log("SubChannel-SR-->"+SubChannel);
                                
               /*     if(Channel == "Banca")
                    {
                                     // below line comented by pramod chavan for replace quote scenario not disabled prenatal check box. TODO
                       // document.getElementById("al_person_details.pre_natal_child_flg").disabled = false;
                    }*/
                      var x = document.getElementById("al_person_details.mlife.insu_type");
                                     console.log("--businessloan_partnership--"+arrConfigData['0']["businessloan_partnership"] +"--businessloan_company--"+arrConfigData['0']["businessloan_company"]);
                                     //2new
                                     if(arrConfigData['0']["businessloan_partnership"]!="Yes"){
                                     x.remove(5);
                                     
                                     }
                                     if(arrConfigData['0']["businessloan_company"]!="Yes"){
                                     x.remove(4);
                                     
                                     }
                                     if(arrConfigData['0']["partnership"]!="Yes"){
                                              x.remove(3);
                                        
                                           }
                                               if(arrConfigData['0']["employee"]!="Yes"){
                                               x.remove(2);
                                           }
                                           if(arrConfigData['0']["keyman"]!="Yes"){
                                           
                                           x.remove(1);
                                           }
                                     
                                         
                                           if(arrConfigData['0']["employee"]!="Yes" && arrConfigData['0']["keyman"]!="Yes"&& arrConfigData['0']["partner"]!="Yes" && arrConfigData['0']["businessloan_company"]!="Yes" && arrConfigData['0']["businessloan_partnership"]!="Yes")//2new
                                           {
                                           x.value="select";
                                           x.disabled=true;
                                           $(escape_jq("al_person_details.mlife.insu_type")).addClass("selectMandatory");
                                           $(escape_jq("al_person_details.mlife.insu_type")).removeClass("selectRedMandatory");
                                           
                                           }                }

                    //Get main life data
                    js_get_var("main_life_response", function(mainlife_res)
                    {
                        if (mainlife_res != "" && mainlife_res != null && mainlife_res != "null" && mainlife_res != "(null)" && mainlife_res.length > 0)
                        {
                               fromMySolution = true;
                            obj_mlife = JSON.parse(mainlife_res);
                               console.log("mainlife_res from AL"+JSON.stringify(mainlife_res));
                               ilMainLifeANB=parseInt(obj_mlife["al_person_details.mlife.anb_il_product"]);// get IL ANB for Mlife.
                               ilMainLifeANB_monthly=parseInt(obj_mlife["al_person_details.mlife.anb_il_monthly_product"]);//Added by Sachin Tupe for il monthly CR.
                               

                            //Taking parsed json object in a variable
                           if(Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)" && (replicate_res == "" || replicate_res == null || replicate_res == "null" || replicate_res == "(null)"))
                           {
                               document.getElementById("al_person_details.mlife.first_name_dropdown").value = obj_mlife["al_person_details.mlife.first_name"];
                               if(obj_mlife["al_person_details.mlife.insu_type"] != undefined && obj_mlife["al_person_details.mlife.insu_type"] != "" && obj_mlife["al_person_details.mlife.insu_type"] != null && obj_mlife["al_person_details.mlife.insu_type"] != "null" && obj_mlife["al_person_details.mlife.insu_type"] != "(null)" && obj_mlife["al_person_details.mlife.insu_type"] != "individual"){
                               document.getElementById("al_person_details.mlife.insu_type").value = obj_mlife["al_person_details.mlife.insu_type"];
                               $(escape_jq("al_person_details.mlife.insu_type")).attr("disabled","true");
                               }
                               if(obj_mlife["al_person_details.mlife.insu_type"] == "individual"){
                               $(escape_jq("al_person_details.mlife.insu_type")).addClass("colorGray")
                                $(escape_jq("al_person_details.mlife.insu_type")).removeClass("mandatory");
                               $(escape_jq("al_person_details.mlife.insu_type")).removeClass("selectRedMandatory");
                               }
                               if(obj_mlife["al_person_details.mlife.insu_type_header"] != undefined && obj_mlife["al_person_details.mlife.insu_type_header"] != "" && obj_mlife["al_person_details.mlife.insu_type_header"] != null && obj_mlife["al_person_details.mlife.insu_type_header"] != "null" && obj_mlife["al_person_details.mlife.insu_type_header"] != "(null)"){
                               document.getElementById("al_person_details.mlife.insu_type_header").value = obj_mlife["al_person_details.mlife.insu_type_header"];
                               $(escape_jq("al_person_details.mlife.insu_type_header")).attr("disabled","true");
                               if(obj_mlife["al_person_details.mlife.insu_type_header"] == "non_business_purpose"){
                                $(escape_jq("al_person_details.mlife.insu_type")).attr("disabled","true");
                               }
                               }
                               setTimeout(function(){
                               
                               fnMsDisableDropdownChange("");
                               var key_mlife = obj_mlife["al_person_details.mlife.first_name"];
                                           },10);
                            }else if(response_pro_req != "" && response_pro_req != null && response_pro_req != "null" && response_pro_req != "(null)") //Dropdowns will be shown on the Replace Quote as per the new condition
                               {
                               document.getElementById("al_person_details.mlife.first_name_dropdown").value = obj_mlife["al_person_details.mlife.first_name"];
                               if(obj_mlife["al_person_details.mlife.insu_type"] != undefined && obj_mlife["al_person_details.mlife.insu_type"] != "" && obj_mlife["al_person_details.mlife.insu_type"] != null && obj_mlife["al_person_details.mlife.insu_type"] != "null" && obj_mlife["al_person_details.mlife.insu_type"] != "(null)"&& obj_mlife["al_person_details.mlife.insu_type"] != "individual"){
                               document.getElementById("al_person_details.mlife.insu_type").value = obj_mlife["al_person_details.mlife.insu_type"];
                               $(escape_jq("al_person_details.mlife.insu_type")).attr("disabled","true");
                               }
                               if(obj_mlife["al_person_details.mlife.insu_type"] == "individual"){
                               $(escape_jq("al_person_details.mlife.insu_type")).addClass("colorGray")
                                $(escape_jq("al_person_details.mlife.insu_type")).removeClass("mandatory");
                               $(escape_jq("al_person_details.mlife.insu_type")).removeClass("selectRedMandatory");
                               }
                               if(obj_mlife["al_person_details.mlife.insu_type_header"] != undefined && obj_mlife["al_person_details.mlife.insu_type_header"] != "" && obj_mlife["al_person_details.mlife.insu_type_header"] != null && obj_mlife["al_person_details.mlife.insu_type_header"] != "null" && obj_mlife["al_person_details.mlife.insu_type_header"] != "(null)"){
                               document.getElementById("al_person_details.mlife.insu_type_header").value = obj_mlife["al_person_details.mlife.insu_type_header"];
                               $(escape_jq("al_person_details.mlife.insu_type_header")).attr("disabled","true");
                               if(obj_mlife["al_person_details.mlife.insu_type_header"] == "non_business_purpose"){
                                $(escape_jq("al_person_details.mlife.insu_type")).attr("disabled","true");
                               }
                               }
                               setTimeout(function(){
                                          
                                          fnMsDisableDropdownChange("");
                                          var key_mlife = obj_mlife["al_person_details.mlife.first_name"];
                                          },1);
                               
                            }else if((isSQSFromAL == "Yes") &&(mainlife_res != "" && mainlife_res != null && mainlife_res != "null" && mainlife_res != "(null)")){
                               
                               console.log("isSQSFromAL if");
                               document.getElementById("view_al_btn").style.display = 'block';
                               document.getElementById("al_person_details.mlife.first_name_dropdown").value = obj_mlife["al_person_details.mlife.first_name"];
                               if(obj_mlife["al_person_details.mlife.insu_type"] != undefined && obj_mlife["al_person_details.mlife.insu_type"] != "" && obj_mlife["al_person_details.mlife.insu_type"] != null && obj_mlife["al_person_details.mlife.insu_type"] != "null" && obj_mlife["al_person_details.mlife.insu_type"] != "(null)"&& obj_mlife["al_person_details.mlife.insu_type"] != "individual"){
                               document.getElementById("al_person_details.mlife.insu_type").value = obj_mlife["al_person_details.mlife.insu_type"];
                               }
                               if(obj_mlife["al_person_details.mlife.insu_type"] == "individual"){
                               $(escape_jq("al_person_details.mlife.insu_type")).addClass("colorGray")
                                $(escape_jq("al_person_details.mlife.insu_type")).removeClass("mandatory");
                               $(escape_jq("al_person_details.mlife.insu_type")).removeClass("selectRedMandatory");
                               }
                               if(obj_mlife["al_person_details.mlife.insu_type_header"] != undefined && obj_mlife["al_person_details.mlife.insu_type_header"] != "" && obj_mlife["al_person_details.mlife.insu_type_header"] != null && obj_mlife["al_person_details.mlife.insu_type_header"] != "null" && obj_mlife["al_person_details.mlife.insu_type_header"] != "(null)"){
                               document.getElementById("al_person_details.mlife.insu_type_header").value = obj_mlife["al_person_details.mlife.insu_type_header"];
                                if(obj_mlife["al_person_details.mlife.insu_type_header"] == "non_business_purpose"){
                                 $(escape_jq("al_person_details.mlife.insu_type")).attr("disabled","true");
                                }
                               }
                               setTimeout(function(){
                                          
                                          fnMsDisableDropdownChange("");
                                          var key_mlife = obj_mlife["al_person_details.mlife.first_name"];
                                          },1);

                               
                               
                            }else
                           {
                               console.log("response_pro_req else");
                               if(obj_mlife["al_person_details.mlife.insu_type"] != undefined && obj_mlife["al_person_details.mlife.insu_type"] != "" && obj_mlife["al_person_details.mlife.insu_type"] != null && obj_mlife["al_person_details.mlife.insu_type"] != "null" && obj_mlife["al_person_details.mlife.insu_type"] != "(null)"&& obj_mlife["al_person_details.mlife.insu_type"] != "individual"){
                                    document.getElementById("al_person_details.mlife.insu_type").value = obj_mlife["al_person_details.mlife.insu_type"];
                               }
                               if(obj_mlife["al_person_details.mlife.insu_type"] == "individual"){
                               $(escape_jq("al_person_details.mlife.insu_type")).addClass("colorGray")
                                $(escape_jq("al_person_details.mlife.insu_type")).removeClass("mandatory");
                               $(escape_jq("al_person_details.mlife.insu_type")).removeClass("selectRedMandatory");
                               }
                               if(obj_mlife["al_person_details.mlife.insu_type_header"] != undefined && obj_mlife["al_person_details.mlife.insu_type_header"] != "" && obj_mlife["al_person_details.mlife.insu_type_header"] != null && obj_mlife["al_person_details.mlife.insu_type_header"] != "null" && obj_mlife["al_person_details.mlife.insu_type_header"] != "(null)"){
                                    document.getElementById("al_person_details.mlife.insu_type_header").value = obj_mlife["al_person_details.mlife.insu_type_header"];
                                   if(obj_mlife["al_person_details.mlife.insu_type_header"] == "non_business_purpose"){
                                    $(escape_jq("al_person_details.mlife.insu_type")).attr("disabled","true");
                                   }
                               }
                               
                                document.getElementById("al_person_details.mlife.first_name").value = obj_mlife["al_person_details.mlife.first_name"];
                           }
                               fnMnROACheckMandatoryFields(); //Anjali: Def - 2674

                    if (obj_mlife["al_person_details.pre_natal_child_flg"] == "Yes")
                    {
                        document.getElementById("al_person_details.pre_natal_child_flg").checked = true;
                        //document.getElementById("al_person_details.mlife.expected_delivery").style.display = 'block';
                        document.getElementById("gestational_week").style.display = 'block';
                        document.getElementById("al_person_details.mlife.expected_delivery").style.display = 'block';
                        document.getElementById("al_person_details.mlife.expected_delivery_dt").style.display='block';
                        document.getElementById("al_person_details.gestational_week").style.display='block';
                        document.getElementById("al_person_details.gestational_week").disabled=true;
                        document.getElementById("al_person_details.mlife.expected_delivery_dt").disabled=true;
                        document.getElementById("al_person_details.mlife.dtofbirth").style.display = 'none';
                        document.getElementById("al_person_details.mlife.dob").style.display='none';
                        document.getElementById("al_person_details.mlife.anb_block").style.display='none';
                        
                       document.getElementById("al_person_details.mlife.gender_male").checked = true;// Production Defect---->PRUW00035203 Pramod Chavan: 01022018
						document.getElementById("al_person_details.mlife.gender_female").disabled = true;// Production Defect---->PRUW00035203*/ //TODO 22-05-2018
                               
                               if (Client_id == "" || Client_id == null || Client_id == "null" || Client_id == "(null)")
                               {                            document.getElementById("al_person_details.mlife.first_name").disabled=true;
                               }
                    } else if (obj_mlife["al_person_details.pre_natal_child_flg"] == "No")
                    {
                        document.getElementById("al_person_details.pre_natal_child_flg").checked = false;
                        document.getElementById("gestational_week").style.display = 'none';
                        document.getElementById("al_person_details.mlife.expected_delivery").style.display = 'none';
                        document.getElementById("al_person_details.mlife.expected_delivery_dt").style.display='none';     
                        document.getElementById("al_person_details.gestational_week").style.display='none';
                        document.getElementById("al_person_details.mlife.dtofbirth").style.display = 'block';
                        document.getElementById("al_person_details.mlife.dob").style.display='block';
                        document.getElementById("al_person_details.mlife.anb_block").style.display='block';
                               if (Client_id == "" || Client_id == null || Client_id == "null" || Client_id == "(null)")
                               {
                               document.getElementById("al_person_details.mlife.first_name").disabled=false;
                               }
                    }

                    document.getElementById("al_person_details.mlife.expected_delivery_dt").value = obj_mlife["al_person_details.mlife.expected_delivery_dt"];
                    document.getElementById("al_person_details.gestational_week").value = obj_mlife["al_person_details.gestational_week"];
                    document.getElementById("al_person_details.mlife.dob").value = obj_mlife["al_person_details.mlife.dob"];
                    document.getElementById("al_person_details.mlife.anb").value = obj_mlife["al_person_details.mlife.anb"];
                    document.getElementById("al_person_details.mlife.anb_il_product").value = obj_mlife["al_person_details.mlife.anb_il_product"];// for IL ANB changes.
                    document.getElementById("al_person_details.mlife.anb_il_monthly_product").value = obj_mlife["al_person_details.mlife.anb_il_monthly_product"];// for IL ANB changes.

                               
                             //  console.log("il monthly"+obj_mlife["al_person_details.mlife.anb_il_monthly_product"]);
                               ANB_set = obj_mlife["al_person_details.mlife.anb"];
                               
                               console.log("ANB_set 1 :: "+ANB_set);

                    if ((obj_mlife["al_person_details.mlife.anb"] <= 16 && !isILproduct) || (ilMainLifeANB <= 16 && isILproduct))
                    {
                               console.log("Inside less 16 28 march");
                        if((document.getElementById("al_person_details.mlife.anb").value > 16 && document.getElementById("al_person_details.mlife.anb").value < 19 && !isILproduct) || (ilMainLifeANB > 16 && ilMainLifeANB < 19 && isILproduct))// && Channel != "Banca" )
                        {
                               console.log("Inside less 16 28 march1");
                       $("input[name='third_life'][value='Yes']").prop('checked',false);
                       $("input[name='third_life'][value='No']").prop('checked',true);
                       if(document.getElementById("al_person_details.slife.relationship").value == "Spouse")
                               {
                               console.log("--------->in spouse")
                                    document.getElementById("third_life_party_flag").style.display = 'none';
                               }
                               else
                               {
                               console.log("Inside less 16 28 march2");
                                    document.getElementById("third_life_party_flag").style.display = 'block';
                               }
                       }
                               //else if((document.getElementById("al_person_details.mlife.anb").value > 16 && document.getElementById("al_person_details.mlife.anb").value < 19) && Channel == "Banca" )
//                               else if(Channel == "Banca")
//                       {
//                           document.getElementById("third_life_party_flag").style.display = 'none';
//                       }
                               else
                        {
                            $("input[name='third_life'][value='Yes']").prop('checked',false);
                            $("input[name='third_life'][value='No']").prop('checked',true);
                               
                            document.getElementById("third_life_party_flag").style.display = 'block';
                        }
                    } else 
                    {
                               if( obj_slife["al_person_details.slife.relationship"] != undefined &&  obj_slife["al_person_details.slife.relationship"] != "undefined" &&  obj_slife["al_person_details.slife.relationship"] != null &&  obj_slife["al_person_details.slife.relationship"] != "null" &&  obj_slife["al_person_details.slife.relationship"] != "" && (obj_slife["al_person_details.slife.relationship"] == "Spouse" ||  obj_slife["al_person_details.slife.relationship"] == "SELECT" ||  obj_slife["al_person_details.slife.relationship"] == "Select" ||  obj_slife["al_person_details.slife.relationship"] == "select"))
                               {
                               console.log("7.in display none");
                                    $("input[name='third_life'][value='Yes']").prop('checked',false);
                                    $("input[name='third_life'][value='No']").prop('checked',true);
                                    document.getElementById("third_life_party_flag").style.display = 'none';
                               console.log("in Load On Sqs");
                               }
                    }

                    if (obj_mlife["al_person_details.mlife.gender"] == "Male")
                    {
                        document.getElementById("al_person_details.mlife.gender_male").checked = true;
                        document.getElementById("al_person_details.mlife.gender_female").checked = false;
                    } else if (obj_mlife["al_person_details.mlife.gender"] == "Female")
                    {
                        document.getElementById("al_person_details.mlife.gender_male").checked = false;
                        document.getElementById("al_person_details.mlife.gender_female").checked = true;
                    }

                    if (obj_mlife["al_person_details.mlife.smoke_status"] == "Smoker")
                    {
                        document.getElementById("al_person_details.mlife.smoke_status_yes").checked = true;
                        document.getElementById("al_person_details.mlife.smoke_status_no").checked = false;
                    } else if (obj_mlife["al_person_details.mlife.smoke_status"] == "Non-Smoker")
                    {
                        document.getElementById("al_person_details.mlife.smoke_status_yes").checked = false;
                        document.getElementById("al_person_details.mlife.smoke_status_no").checked = true;
                    }
// TODO occupation new list
                            document.getElementById("al_employee_details.mlife.occupation").value = obj_mlife["al_employee_details.mlife.occupation"];
                               
                               $(".occupationSearchMLifeText").val(obj_mlife["al_employee_details.mlife.occupation"]);
                               getNatureOfBusinessList('al_employee_details.mlife.occupation','al_employee_details.mlife.nature_of_business','al_employee_details.mlife.occupation_class','natureSearchMLifeText','mlife');//Added by Paromita on 14 Aug 2017
                               
                               
                               
                               if(((Channel=="Agency" || Channel=="FA") && ((ANB_set <= 15 && !isILproduct)|| (obj_mlife["al_person_details.mlife.anb_il_product"] <= 15 && isILproduct))) && document.getElementById("al_employee_details.mlife.occupation").value  == "Child") // Piyush (03/12/2018): Changes has been done for New channel
                               {
                               $(".occupationSearchMLifeText").attr("disabled",true);
                               $(".natureSearchMLifeText").attr("disabled",true);
                               }else if(((Channel!="Agency" || Channel!="FA" ) && ((ANB_set <= 16 && !isILproduct)|| (obj_mlife["al_person_details.mlife.anb_il_product"] <= 16 && isILproduct))) && document.getElementById("al_employee_details.mlife.occupation").value  == "Child"){ // Piyush (03/12/2018): Changes has been done for New channel
                               $(".occupationSearchMLifeText").attr("disabled",true);
                               $(".natureSearchMLifeText").attr("disabled",true);
                               }
                              
                            document.getElementById("al_employee_details.mlife.occupation_class").value = obj_mlife["al_employee_details.mlife.occupation_class"];
                            document.getElementById("al_employee_details.mlife.nature_of_business").value = obj_mlife["al_employee_details.mlife.value_nature_of_business"];
                               console.log("naure of busi solutin"+obj_mlife["al_employee_details.mlife.value_nature_of_business"]);
                               //var nob_set_data = $(".natureSearchMLife").find("option:selected").text();
                               var nob_set_data =obj_mlife["al_employee_details.mlife.value_nature_of_business"]; //changed by sayali
                               
                               $(".natureSearchMLifeText").val(nob_set_data);
                               
                               //Changed by Paromita on 14 Aug 2017 for new occupation list
                               if(document.getElementById("al_employee_details.mlife.occupation").value  == "Housewife" || document.getElementById("al_employee_details.mlife.occupation").value  == "Child" || document.getElementById("al_employee_details.mlife.occupation").value  == "Student" || document.getElementById("al_employee_details.mlife.occupation").value  == "Retiree" || document.getElementById("al_employee_details.mlife.occupation").value  == "Pensioner" || document.getElementById("al_employee_details.mlife.occupation").value  == "Unemployed") //|| document.getElementById("al_employee_details.mlife.occupation").value  == "Student Pilot-2" || document.getElementById("al_employee_details.mlife.occupation").value  == "Pilot (Student)-2")
                               {
                                    /*if(document.getElementById("al_employee_details.mlife.nature_of_business").value  == "H00003" || document.getElementById("al_employee_details.mlife.nature_of_business").value  == "C00005" || document.getElementById("al_employee_details.mlife.nature_of_business").value  == "S00007" || document.getElementById("al_employee_details.mlife.nature_of_business").value  == "R00005" || document.getElementById("al_employee_details.mlife.nature_of_business").value  == "T00010")
                               {*/
                               document.getElementById("al_employee_details.mlife.nature_of_business").disabled=true;
                               $(".natureSearchMLifeText").attr("disabled","true");
                               //}
                               }else
                               {
                               if(response_pro_req != "" && response_pro_req != null && response_pro_req != "null" && response_pro_req != "(null)")
                               {
                                    console.log("nob disabled3===");
                                   document.getElementById("al_employee_details.mlife.nature_of_business").disabled=true;
                                   $(".natureSearchMLifeText").attr("disabled","true");

                               }else
                               {
                               
                                   $(".natureSearchMLifeText").removeAttr("disabled");
                               }
                               
                               }

                            if (obj_mlife["al_sqs_details.sec_parti_flag"] == "Yes")
                            {
                                document.getElementById("al_sqs_details.sec_parti_flag_yes").checked = true;
                                document.getElementById("al_sqs_details.sec_parti_flag_no").checked = false;
                               
                               //if(document.getElementById("al_person_details.mlife.anb").value < 17)
                               //Added By Rahul Patil on 01.10.2015 for PRUterm
                               if(Channel != "Banca" && Channel != "UOB") // changed by Purva / Pramod C on 07th Aug 2017 for UOB channel
                               {
                                   if((document.getElementById("al_person_details.mlife.anb").value < 16 && !isILproduct) || (ilMainLifeANB < 16 && isILproduct))
                                   {
                                       document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = true;
                                       document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = true;
                                   }else
                                   {
                                       document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = false;
                                       document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = false;
                                   }
                               }
                               else
                               {
                                   if((document.getElementById("al_person_details.mlife.anb").value < 17 && !isILproduct) || (ilMainLifeANB < 17 && isILproduct))
                                   {
                                   document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = true;
                                   document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = true;
                                   }else
                                   {
                                   document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = false;
                                   document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = false;
                                   }
                               }

                        $(".collapseTwo").attr("id", "collapseTwo");
                        $(".second_life").addClass("normal_panel");
                        $(".second_life").removeClass("disabled_panel");
                    } else if (obj_mlife["al_sqs_details.sec_parti_flag"] == "No")
                    {
                               //if(document.getElementById("al_person_details.mlife.anb").value < 17)
                               //Added By Rahuil Patil on 01.10.2015 for PRUterm
                               if(Channel != "Banca" && Channel != "UOB") //changed by Purva / Praod C on 07th Aug 2017 for UOB
                               {
                                   if((document.getElementById("al_person_details.mlife.anb").value < 16 && !isILproduct) || (ilMainLifeANB < 16 && isILproduct))
                                   {
                                   document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = true;
                                   document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = true;
                                   }else
                                   {
                                   document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = false;
                                   document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = false;
                                   }
                               }
                               else
                               {
                                   if((document.getElementById("al_person_details.mlife.anb").value < 17 && !isILproduct) || (ilMainLifeANB < 17 && isILproduct))
                                   {
                                   document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = true;
                                   document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = true;
                                   }else
                                   {
                                   document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = false;
                                   document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = false;
                                   }
                               }
                               
                        document.getElementById("al_sqs_details.sec_parti_flag_yes").checked = false;
                        document.getElementById("al_sqs_details.sec_parti_flag_no").checked = true;
                               
                        SetValuesnull();
                        $(".collapseTwo").attr("id", "");
                        $(".collapseThree").attr("id", "");
                        $(".second_life,.third_life").addClass("disabled_panel");
                        $(".second_life,.third_life").removeClass("normal_panel").removeClass("active_panel");
                        $("input[name='third_life'][value='Yes']").prop('checked',false);
                        $("input[name='third_life'][value='No']").prop('checked',true);
                    }
                               if(Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)" && (replicate_res == "" || replicate_res == null || replicate_res == "null" || replicate_res == "(null)"))
                               {
                               
                               if(obj_mlife["al_person_details.pre_natal_child_flg"] == "No")
                               {
                               fnMsCheckValidationonload("al_person_details.mlife.dob",obj_mlife["al_person_details.mlife.anb"],"obj_mlife",obj_mlife);
                               }
                               }else
                               {
                               fnMsCheckValidationonload("al_person_details.mlife.dob",obj_mlife["al_person_details.mlife.anb"],"obj_mlife",obj_mlife);
                               }
                               /*@Following if condition il condition commented by Sachin tupe for defect 5691*******/
                               if(((obj_mlife["al_person_details.mlife.anb"] >= 11) && (obj_mlife["al_person_details.mlife.anb"] <= 16)) && !isILproduct)/****|| (((ilMainLifeANB >= 11) && (ilMainLifeANB <= 16)) || ((ilMainLifeANB_monthly >= 11) && (ilMainLifeANB_monthly <= 16)))****/ //)// && Channel == "Banca")// IL product condition added for IL ANB changes ,//Added by Sachin for il_monthly CR.
                               {
                               document.getElementById("parent_consent_block").style.display="block";
                               if(obj_mlife["al_person_details.mlife.parent_consent"] == "Yes")
                               {
                               document.getElementById("al_person_details.mlife.parent_consent_yes").checked=true;
                               document.getElementById("al_person_details.mlife.parent_consent_no").checked=false;
                               fnMsDisableLives("al_person_details.mlife.parent_consent_yes");
                               }else if(obj_mlife["al_person_details.mlife.parent_consent"] == "No")
                               {
                               document.getElementById("al_person_details.mlife.parent_consent_yes").checked=false;
                               document.getElementById("al_person_details.mlife.parent_consent_no").checked=true;
                               console.log("fnMsDisableLives2")
                                fnMsDisableLives("al_person_details.mlife.parent_consent_no");
                               }else if(obj_mlife["al_person_details.mlife.parent_consent"] == "")
                               {
                               // TODO
                               document.getElementById("al_person_details.mlife.parent_consent_yes").checked=false;
                               document.getElementById("al_person_details.mlife.parent_consent_no").checked=true;
                               document.getElementById("al_sqs_details.sec_parti_flag_yes").checked=true;
                               $(".collapseTwo").attr("id", "collapseTwo");
                               $(".second_life").addClass("normal_panel");
                               $(".second_life").removeClass("disabled_panel");

                               }
                               }
                               else if((((ilMainLifeANB >= 11) && (ilMainLifeANB <= 16)) || ((ilMainLifeANB_monthly >= 11) && (ilMainLifeANB_monthly <= 16))) && isILproduct) //Added for defect 5691 by Sachin Tupe on date 09-08-2018
                               {
                               document.getElementById("parent_consent_block").style.display="block";
                               if(obj_mlife["al_person_details.mlife.parent_consent"] == "Yes")
                               {
                               document.getElementById("al_person_details.mlife.parent_consent_yes").checked=true;
                               document.getElementById("al_person_details.mlife.parent_consent_no").checked=false;
                               fnMsDisableLives("al_person_details.mlife.parent_consent_yes");
                               }else if(obj_mlife["al_person_details.mlife.parent_consent"] == "No")
                               {
                               document.getElementById("al_person_details.mlife.parent_consent_yes").checked=false;
                               document.getElementById("al_person_details.mlife.parent_consent_no").checked=true;
                               console.log("fnMsDisableLives2")
                                fnMsDisableLives("al_person_details.mlife.parent_consent_no");
                               }else if(obj_mlife["al_person_details.mlife.parent_consent"] == "")
                               {
                               // TODO
                               document.getElementById("al_person_details.mlife.parent_consent_yes").checked=false;
                               document.getElementById("al_person_details.mlife.parent_consent_no").checked=true;
                               document.getElementById("al_sqs_details.sec_parti_flag_yes").checked=true;
                               $(".collapseTwo").attr("id", "collapseTwo");
                               $(".second_life").addClass("normal_panel");
                               $(".second_life").removeClass("disabled_panel");

                               }
                               }else
                               {
                               document.getElementById("parent_consent_block").style.display="none";
                               document.getElementById("al_person_details.mlife.parent_consent_yes").checked=false;
                               document.getElementById("al_person_details.mlife.parent_consent_no").checked=true;
                               }
                }else//Added for solution button
                    {
                               fromMySolution = false;
                               console.log("@@ribbenProduct"+ribbenProduct);
                           ribbenProduct=[];
                  }

                               
               var mlifenobChk=document.getElementById("al_employee_details.mlife.nature_of_business").value;
               var mlifeOccCheck=document.getElementById("al_employee_details.mlife.occupation").value;
               
               console.log("mlifenobChk----"+mlifenobChk+"---mlifeOccCheck-----"+mlifeOccCheck);
               if((mlifenobChk!="Select" && mlifenobChk!="select" && mlifenobChk!="" && mlifenobChk!= "Child"&& mlifenobChk!= "Housewife"&& mlifenobChk!="Pensioner"&& mlifenobChk!="Retiree"&& mlifenobChk!="Student"&& mlifenobChk!="Student Pilot"&& mlifenobChk!="Unemployed" && mlifenobChk!= "Nature of Business") && (insurence_type_gb=="keyman"|| insurence_type_gb=="employee" || insurence_type_gb=="partnership" || insurence_type_gb == "Business Loan Insurance (for Company/LLP)" || insurence_type_gb == "Business Loan Insurance (for Sole Proprietorship/Partnership)"))
               {
               document.getElementById("al_employee_details.mlife.nature_of_business").disabled=true;
               }
               
               
               if((mlifeOccCheck!="Select" && mlifeOccCheck!="select" && mlifeOccCheck!="" && mlifeOccCheck!= "Child"&& mlifeOccCheck!= "Housewife"&& mlifeOccCheck!="Pensioner"&& mlifeOccCheck!="Retiree"&& mlifeOccCheck!="Student"&& mlifeOccCheck!="Student Pilot"&& mlifeOccCheck!="Unemployed") && (insurence_type_gb=="keyman"|| insurence_type_gb=="employee" || insurence_type_gb=="partnership" || insurence_type_gb == "Business Loan Insurance (for Company/LLP)" || insurence_type_gb == "Business Loan Insurance (for Sole Proprietorship/Partnership)"))
               {
               document.getElementById("al_employee_details.mlife.occupation").disabled=true;
               }
                               
                               
                if (obj_mlife["al_sqs_details.sec_parti_flag"] == "Yes")
                               {
                              
                //Get second life data
                js_get_var("sec_life_response", function(seclife_res)
                {
                    if (seclife_res != "" && seclife_res != null && seclife_res != "null" && seclife_res != "(null)")
                    {
                        obj_slife = JSON.parse(seclife_res);

                                //Taking parsed json object in a variable
                               if(Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)" && (replicate_res == "" || replicate_res == null || replicate_res == "null" || replicate_res == "(null)"))
                               {
                                   document.getElementById("al_person_details.slife.first_name_dropdown").value = obj_slife["al_person_details.slife.first_name"];
                                    setTimeout(function(){
                                   
                                   fnMsDisableDropdownChange("");
                                   var key_slife = obj_slife["al_person_details.slife.first_name"];
                                               },1);
                           }else if(response_pro_req != "" && response_pro_req != null && response_pro_req != "null" && response_pro_req != "(null)") //Dropdowns will be shown on the Replace Quote as per the new condition
                           {
                               document.getElementById("al_person_details.slife.first_name_dropdown").value = obj_slife["al_person_details.slife.first_name"];
                               setTimeout(function(){
                                      
                                      fnMsDisableDropdownChange("");
                                      var key_slife = obj_slife["al_person_details.slife.first_name"];
                                      },1);
                           }else if(isSQSFromAL == "Yes"){
                           // changes made by pramod chavan for EAL/CAL internal defect
                           document.getElementById("al_person_details.slife.first_name_dropdown").value = obj_slife["al_person_details.slife.first_name"];
                           setTimeout(function(){
                                      
                                      fnMsDisableDropdownChange("");
                                      var key_slife = obj_slife["al_person_details.slife.first_name"];
                                      },1);
                           }else
                                   {
                                        document.getElementById("al_person_details.slife.first_name").value = obj_slife["al_person_details.slife.first_name"];
                                   }
                           fnMnROACheckMandatoryFields(); //Anjali: Def - 2674
                           
                               // document.getElementById("al_person_details.slife.relationship").value = obj_slife["al_person_details.slife.relationship"];
                           //Added new code for internal defect on relationship blank
                           if(obj_slife["al_person_details.slife.relationship"] == "Spouse" && ((obj_mlife["al_person_details.mlife.anb"] <= 16 && !isILproduct) || (ilMainLifeANB <= 16 && isILproduct)))
                           {
                           
                           
                               var slifeRelationArray=["Legal Guardian","Parent","Select Relationship"];
                               document.getElementById("al_person_details.slife.relationship").options.length=0;
                               var dropdownsliferel=document.getElementById("al_person_details.slife.relationship");
                               
                               for(var i=slifeRelationArray.length-1;i>=0;i--)
                               {
                                   var optn1=document.createElement("option");
                                   optn1.value=slifeRelationArray[i];
                                   optn1.text=slifeRelationArray[i];
                                   dropdownsliferel.appendChild(optn1);
                               }
                           
                           }
                           else
                           {
                                document.getElementById("al_person_details.slife.relationship").value = obj_slife["al_person_details.slife.relationship"];
                           }

                                document.getElementById("al_person_details.slife.dob").value = obj_slife["al_person_details.slife.dob"];
                           
                                document.getElementById("al_person_details.slife.anb").value = obj_slife["al_person_details.slife.anb"];
                           document.getElementById("al_person_details.slife.anb_il_product").value = obj_slife["al_person_details.slife.anb_il_product"];// IL ANB changes. Pramod Chavan: 12122017
                            document.getElementById("al_person_details.slife.anb_il_monthly_product").value = obj_slife["al_person_details.slife.anb_il_monthly_product"];
                                   
                                if((obj_mlife["al_person_details.mlife.anb"] > 18 && !isILproduct) || (ilMainLifeANB > 18 && isILproduct))
                                {
                           console.log("value 123456:"+document.getElementById("al_person_details.slife.relationship").value);
                                   //to add here 16 feb 2022
                          //if(obj_slife["al_person_details.slife.relationship"] !== "Parent")
                           //{
                           //commented by ankita for modern family CR after backswipe and front swipe it gets disable
                          
                           //document.getElementById("al_person_details.slife.relationship").disabled = true;
                           //}
                                    console.log("1 disable");
                                }else
                                {
                                    if(relationship_mlife=="C")
                                    {
                                       // document.getElementById("al_person_details.slife.relationship").disabled = true;//def-3444
                                        document.getElementById("al_person_details.slife.first_name_dropdown").disabled=true;
                                    console.log("2 disable");
                                    }
                                   else{
                                     document.getElementById("al_person_details.slife.relationship").disabled = false;
                                   }
                                }

                        if (obj_slife["al_person_details.slife.gender"] == "Male")
                        {
                            document.getElementById("al_person_details.slife.gender_male").checked = true;
                            document.getElementById("al_person_details.slife.gender_female").checked = false;
                           if(relationship_mlife!="" && client_ylp_type_mlife == "lo")
                           {
                           document.getElementById("al_person_details.slife.gender_female").disabled = true;
                           }
                        } else if (obj_slife["al_person_details.slife.gender"] == "Female")
                        {
                            document.getElementById("al_person_details.slife.gender_male").checked = false;
                            document.getElementById("al_person_details.slife.gender_female").checked = true;
                           //modern family by ankita 
                           if(relationship_mlife!="" && client_ylp_type_mlife == "lo")
                           {
                           document.getElementById("al_person_details.slife.gender_male").disabled = true;
                           }
                        }

                        if (obj_slife["al_person_details.slife.smoke_status"] == "Smoker")
                        {
                            document.getElementById("al_person_details.slife.smoke_status_yes").checked = true;
                            document.getElementById("al_person_details.slife.smoke_status_no").checked = false;
                        } else if (obj_slife["al_person_details.slife.smoke_status"] == "Non-Smoker")
                        {
                            document.getElementById("al_person_details.slife.smoke_status_yes").checked = false;
                            document.getElementById("al_person_details.slife.smoke_status_no").checked = true;
                        }

                           // TODO changes to be made for new occupation
                                document.getElementById("al_employee_details.slife.occupation").value = obj_slife["al_employee_details.slife.occupation"];
                                   $(".occupationSearchSLifeText").val(obj_slife["al_employee_details.slife.occupation"]);
                           getNatureOfBusinessList('al_employee_details.slife.occupation','al_employee_details.slife.nature_of_business','al_employee_details.slife.occupation_class','natureSearchSLifeText','slife'); //Added by Paromita on 14 Aug 2017 for occupation List change
                                document.getElementById("al_employee_details.slife.occupation_class").value = obj_slife["al_employee_details.slife.occupation_class"];
                                document.getElementById("al_employee_details.slife.nature_of_business").value = obj_slife["al_employee_details.slife.value_nature_of_business"];
                                  // var nob_set_data_slife = $(".natureSearchSLife").find("option:selected").text();
                           console.log("nature of bui s life"+obj_slife["al_employee_details.slife.value_nature_of_business"]);
                                     var nob_set_data_slife = obj_slife["al_employee_details.slife.value_nature_of_business"];    //chnaged by sayali
                                   $(".natureSearchSLifeText").val(nob_set_data_slife);
                           //Changed by Paromita on 14 Aug 2017 for new occupation list
                           if(document.getElementById("al_employee_details.slife.occupation").value  == "Housewife" || document.getElementById("al_employee_details.slife.occupation").value  == "Child" || document.getElementById("al_employee_details.slife.occupation").value  == "Student" || document.getElementById("al_employee_details.slife.occupation").value  == "Retiree" || document.getElementById("al_employee_details.slife.occupation").value  == "Pensioner" || document.getElementById("al_employee_details.slife.occupation").value  == "Unemployed") //|| document.getElementById("al_employee_details.slife.occupation").value  == "Student Pilot-2" || document.getElementById("al_employee_details.slife.occupation").value  == "Pilot (Student)-2")
                           {
                                   /*if(document.getElementById("al_employee_details.slife.nature_of_business").value  == "H00003" || document.getElementById("al_employee_details.slife.nature_of_business").value  == "C00005" || document.getElementById("al_employee_details.slife.nature_of_business").value  == "S00007" || document.getElementById("al_employee_details.slife.nature_of_business").value  == "R00005" || document.getElementById("al_employee_details.slife.nature_of_business").value  == "T00010")
                                   {*/
                                        console.log("nob disabled2==");
                                   document.getElementById("al_employee_details.slife.nature_of_business").disabled=true;
                                   $(".natureSearchSLifeText").attr("disabled","true");
                                   //}
                                   }else
                                   {
                                   if(response_pro_req != "" && response_pro_req != null && response_pro_req != "null" && response_pro_req != "(null)")
                                   {
                                       console.log("nob disabled1==")
                                       document.getElementById("al_employee_details.slife.nature_of_business").disabled=true;
                                       $(".natureSearchSLifeText").attr("disabled","true");
                                   }else
                                   {
                           
                                       $(".natureSearchSLifeText").removeAttr("disabled");
                                   }
                                   }
                           
                           fnMsCheckValidationonload("al_person_details.slife.dob",obj_slife["al_person_details.slife.anb"],"obj_slife",obj_slife);
                           console.log("gender onload:"+obj_slife["al_person_details.slife.gender"]);
                           //added by ankita on 20 april 2022 for modern family//added condition of lo by ankita on 21 april 2022//added client_ylp_type_mlife=="" for case starts from my solution and backswipe clear issue
                           if(obj_slife["al_person_details.slife.gender"]!="" && parseInt(obj_mlife["al_person_details.mlife.anb_il_product"])>16 && (client_ylp_type_mlife==="lo" || relationship_mlife===""))
                           {
                           var arrReturn=fnSelectRelationShipList();
                           console.log("--arrReturn:"+arrReturn);
                           var valueArray_Relationship_solution="";
                           if(obj_slife["al_person_details.slife.gender"]=="Male")
                           {
                               
                               valueArray_Relationship_solution=arrReturn[0];
                           //added legal guardian by ankita for defect 324
                               valueArray_Relationship_solution.push("Legal Guardian");
                               
                           }
                           if(obj_slife["al_person_details.slife.gender"]=="Female")
                           {
                               
                               valueArray_Relationship_solution=arrReturn[2];
                           //added legal guardian by ankita for defect 324
                           valueArray_Relationship_solution.push("Legal Guardian");
                               
                           }
                           
                           console.log("valueArray_Relationship_solution:"+valueArray_Relationship_solution);
                           //fnloadRelationshipSelectBox("al_person_details.slife.relationship", valueArray_Relationship_solution,valueArray_Relationship_solution,"mySolutions");\
                          
                           console.log(" 1446 valueArray_Relationship_solution:"+valueArray_Relationship_solution);
                           //added by ankita for modern family CR to remain spouse parent and legal guardian after backswipe
                           if((relationship_mlife=="" && client_ylp_type_mlife==""))
                           {
                             valueArray_Relationship_solution.push("Spouse");
                             valueArray_Relationship_solution.push("Parent");
                             valueArray_Relationship_solution.push("Legal Guardian");
                           }
                           
                           //added spouse condition by ankita for modern family CR on 25 april 2022
                           if(client_ylp_type_mlife==="you" || client_ylp_type_slife === "spouse" || client_ylp_type_mlife==="spouse")
                           {
                           console.log("inside issue");
                             //valueArray_Relationship_solution=["Spouse"];
                           //added legal guardian by ankita for defect 324
                             valueArray_Relationship_solution.push("Spouse");
                             valueArray_Relationship_solution.push("Legal Guardian");
                           }
                           //added by ankita for defect 324
                           var keyIndex = valueArray_Relationship_solution.indexOf("Father");
                           valueArray_Relationship_solution.splice(keyIndex, 1);
                           var keyIndex = valueArray_Relationship_solution.indexOf("Mother");
                           valueArray_Relationship_solution.splice(keyIndex, 1);
                           
                           //added by ankita on 21 april 2022 for modern family CR for child relationship//change sequence by ankita on 9 dec for internal iaaue of front swipe and backswipe relationship was getting clear
                                                     if(relationship_mlife==="C" && client_ylp_type_mlife==="lo")
                                                     {
                                                        valueArray_Relationship_solution=["Select Relationship","Parent","Legal Guardian"];
                                                     
                                                     }
                           
                           console.log("valueArray_Relationship_solution:"+valueArray_Relationship_solution);
                           var ddloption = document.getElementById("al_person_details.slife.relationship");
                           //console.log("options ddloption "+ddloption);
                           console.log("Ankita true inside all dropdown set2");
                           ddloption.options.length=0;
                           for(var i = 0; i < valueArray_Relationship_solution.length; i++)
                           {
                               var optn=document.createElement("option");
                               optn.value=valueArray_Relationship_solution[i];
                               optn.text=valueArray_Relationship_solution[i];
                               ddloption.appendChild(optn);
                           }
                               document.getElementById("al_person_details.slife.relationship").disabled = false;
                           //document.getElementById("al_person_details.slife.relationship").value=obj_slife["al_person_details.slife.relationship"];
                           if(relationship_mlife!="" && client_ylp_type_mlife == "lo" && relationship_mlife!="C")
                           {
                           document.getElementById("al_person_details.slife.relationship").disabled = true;
                              //document.getElementById("al_person_details.slife.relationship").value=obj_slife["al_person_details.slife.relationship"];
                           }
                          //added by ankita for modern family CR on 21 april 2022
                           document.getElementById("al_person_details.slife.relationship").value=obj_slife["al_person_details.slife.relationship"];
                           }
                           //added by ankita on 21 april 2022 for modern family cr to handle spouse relationship when to populate data from my needs to my solution module backswipe and frontswipe clearing issue
                           if((client_ylp_type_slife==="spouse" || client_ylp_type_slife==="you") && client_ylp_type_mlife!=="lo")
                           {
                              console.log("disabled 1"); document.getElementById("al_person_details.slife.relationship").value="Spouse";
                              document.getElementById("al_person_details.slife.relationship").disabled=true;
                               
                           }
                           //added by ankita on 28 march 2023 for internal issue of backswipe
                           if(document.getElementById("al_person_details.slife.relationship").value!="Parent")
                           {
                           console.log("in display none");
                              document.getElementById("third_life_party_flag").style.display = 'none';
                           }
                       if((parseInt(document.getElementById("al_person_details.mlife.anb_il_product").value)>18))
                           {
                           document.getElementById("third_life_party_flag").style.display = 'none';
                           }
                           //added by ankita on 25 april 2022 for modern family CR
                           //3 june
                           /*if(client_ylp_type_slife==="spouse" && client_ylp_type_mlife==="lo")
                           {
                             document.getElementById("al_person_details.slife.relationship").value="Spouse";
                              
                                 console.log("disabled 5");
                             document.getElementById("al_person_details.slife.relationship").disabled=true;
                           }*/
                           
                           
                        if (obj_slife["al_sqs_details.third_parti_flg"] == "Yes")
                        {
                            $("input[name='third_life'][value='Yes']").prop('checked',true);
                            $("input[name='third_life'][value='No']").prop('checked',false);
                            $(".collapseThree").attr("id", "collapseThree");
                            $(".third_life").addClass("normal_panel");
                            $(".third_life").removeClass("disabled_panel");
                        } else if (obj_slife["al_sqs_details.third_parti_flg"] == "No")
                        {
                            $("input[name='third_life'][value='Yes']").prop('checked',false);
                            $("input[name='third_life'][value='No']").prop('checked',true);
                            $(".collapseThree").attr("id", "");
                            $(".third_life").addClass("disabled_panel");
                            $(".third_life").removeClass("normal_panel");
                        }
                           
                       
                    }
                           
                     if (obj_slife["al_sqs_details.third_parti_flg"] == "Yes")
                           {
                    //Get third life data
                    js_get_var("third_life_response", function(thirdlife_res)
                    {
                        if (thirdlife_res != "" && thirdlife_res != null && thirdlife_res != "null" && thirdlife_res != "(null)")
                        {
                            obj_tlife = JSON.parse(thirdlife_res);
                               
                                    //Taking parsed json object in a variable
                                       if(Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)" && (replicate_res == "" || replicate_res == null || replicate_res == "null" || replicate_res == "(null)"))
                                       {
                                    document.getElementById("al_person_details.tlife.first_name_dropdown").value = obj_tlife["al_person_details.tlife.first_name"];
                               
                               
                               fnMsDisableDropdownChange("");
                               var key_tlife = obj_tlife["al_person_details.tlife.first_name"];
                               $(".slifefnamedrop option[value='+key_tlife+']").prop('disabled','disabled');
                               $(".mlifefnamedrop option[value='+key_tlife+']").prop('disabled','disabled');
                               }else if(response_pro_req != "" && response_pro_req != null && response_pro_req != "null" && response_pro_req != "(null)") //Dropdowns will be shown on the Replace Quote as per the new condition
                               {
//                               if(isSQSFromAL == "Yes")
//                               {
//                               console.log("inside isSQSFromAL" + isSQSFromAL);
//                               var name = obj_mlife["al_person_details.mlife.first_name"];
//                               console.log("inside mlife.first_name" + name);
//                               document.getElementById("al_person_details.mlife.first_name_dropdown").value = obj_mlife["al_person_details.mlife.first_name"];
//                               }
                               //else{
                                   document.getElementById("al_person_details.tlife.first_name_dropdown").value = obj_tlife["al_person_details.tlife.first_name"];
                                   
                                   
                                   fnMsDisableDropdownChange("");
                                   var key_tlife = obj_tlife["al_person_details.tlife.first_name"];
                                   $(".slifefnamedrop option[value='+key_tlife+']").prop('disabled','disabled');
                                   $(".mlifefnamedrop option[value='+key_tlife+']").prop('disabled','disabled');
//                               }
                               }else
                               {
                                    document.getElementById("al_person_details.tlife.first_name").value = obj_tlife["al_person_details.tlife.first_name"];
                               }
                               fnMnROACheckMandatoryFields(); //Anjali: Def - 2674
                            document.getElementById("al_person_details.tlife.relationship").value = obj_tlife["al_person_details.tlife.relationship"];
                            document.getElementById("al_person_details.tlife.dob").value = obj_tlife["al_person_details.tlife.dob"];
                            document.getElementById("al_person_details.tlife.anb").value = obj_tlife["al_person_details.tlife.anb"];
                               document.getElementById("al_person_details.tlife.anb_il_product").value = obj_tlife["al_person_details.tlife.anb_il_product"];// IL ANB changes. Pramod Chavan: 12122017
                               
                               document.getElementById("al_person_details.tlife.anb_il_monthly_product").value = obj_tlife["al_person_details.tlife.anb_il_monthly_product"];
                              
                               

                            if (obj_tlife["al_person_details.tlife.gender"] == "Male")
                            {
                                document.getElementById("al_person_details.tlife.gender_male").checked = true;
                                document.getElementById("al_person_details.tlife.gender_female").checked = false;
                            } else if (obj_tlife["al_person_details.tlife.gender"] == "Female")
                            {
                                document.getElementById("al_person_details.tlife.gender_male").checked = false;
                                document.getElementById("al_person_details.tlife.gender_female").checked = true;
                            }

                            if (obj_tlife["al_person_details.tlife.smoke_status"] == "Smoker")
                            {
                                document.getElementById("al_person_details.tlife.smoke_status_yes").checked = true;
                                document.getElementById("al_person_details.tlife.smoke_status_no").checked = false;
                            } else if (obj_tlife["al_person_details.tlife.smoke_status"] == "Non-Smoker")
                            {
                                document.getElementById("al_person_details.tlife.smoke_status_yes").checked = false;
                                document.getElementById("al_person_details.tlife.smoke_status_no").checked = true;
                            }

                                //TODO changes to be made for new occupation
                                    document.getElementById("al_employee_details.tlife.occupation").value = obj_tlife["al_employee_details.tlife.occupation"];
                                       $(".occupationSearchTLifeText").val(obj_tlife["al_employee_details.tlife.occupation"]);
                               getNatureOfBusinessList('al_employee_details.tlife.occupation','al_employee_details.tlife.nature_of_business','al_employee_details.tlife.occupation_class','natureSearchTLifeText','tlife'); //Added by Paromita on 14 Aug 2017 for occupation List change
                                    document.getElementById("al_employee_details.tlife.occupation_class").value = obj_tlife["al_employee_details.tlife.occupation_class"];
                                    document.getElementById("al_employee_details.tlife.nature_of_business").value = obj_tlife["al_employee_details.tlife.value_nature_of_business"];
                                       //var nob_set_data_tlife = $(".natureSearchTLife").find("option:selected").text();
                               
                                  var nob_set_data_tlife = obj_tlife["al_employee_details.tlife.value_nature_of_business"];
                                       $(".natureSearchTLifeText").val(nob_set_data_tlife);
                                       
                                   //Changed by Paromita on 14 Aug 2017 for new occupation list
                                   if(document.getElementById("al_employee_details.tlife.occupation").value  == "Housewife" || document.getElementById("al_employee_details.tlife.occupation").value  == "Child" || document.getElementById("al_employee_details.tlife.occupation").value  == "Student" || document.getElementById("al_employee_details.tlife.occupation").value  == "Retiree" || document.getElementById("al_employee_details.tlife.occupation").value  == "Pensioner" || document.getElementById("al_employee_details.tlife.occupation").value  == "Unemployed") //|| document.getElementById("al_employee_details.tlife.occupation").value  == "Student Pilot-2" || document.getElementById("al_employee_details.tlife.occupation").value  == "Pilot (Student)-2")
                                   {
                                       /*if(document.getElementById("al_employee_details.tlife.nature_of_business").value  == "H00003" || document.getElementById("al_employee_details.tlife.nature_of_business").value  == "C00005" || document.getElementById("al_employee_details.tlife.nature_of_business").value  == "S00007" || document.getElementById("al_employee_details.tlife.nature_of_business").value  == "R00005" || document.getElementById("al_employee_details.tlife.nature_of_business").value  == "T00010")
                                       {*/
                                       document.getElementById("al_employee_details.tlife.nature_of_business").disabled=true;
                                       $(".natureSearchTLifeText").attr("disabled","true");
                                       //}
                                       }else
                                       {
                                       if(response_pro_req != "" && response_pro_req != null && response_pro_req != "null" && response_pro_req != "(null)")
                                       {
                               
                                       document.getElementById("al_employee_details.tlife.nature_of_business").disabled=true;
                                       $(".natureSearchTLifeText").attr("disabled","true");
                                       }else
                                       {
                                       document.getElementById("al_employee_details.tlife.nature_of_business").disabled=false;
                                       $(".natureSearchTLifeText").removeAttr("disabled");
                                       }
                                       }
                               fnMsCheckValidationonload("al_person_details.tlife.dob",obj_tlife["al_person_details.tlife.anb"],"obj_tlife",obj_tlife)
                                }
                               
                               
                               
                               
                               
                                       
                                js_get_var("personal_update_flags", function(update_personal_res)
                                {
                                    if (update_personal_res != "" && update_personal_res != null && update_personal_res != "null" && update_personal_res != "(null)")
                                    {
                                        var obj_update_personal = JSON.parse(update_personal_res);

                                        if(obj_update_personal["mlife_flag_update"] == "1")
                                        {
                                            mlife_flag_update = "1";
                                        }else if(obj_update_personal["slife_flag_update"] == "1")
                                        {
                                            slife_flag_update = "1";
                                        }else if(obj_update_personal["tlife_flag_update"] == "1")
                                        {
                                            tlife_flag_update = "1";
                                        }
                                    }
                                           checkNameDDDisplayNoneOrNot()
                                });
                            });
                            }
                           checkNameDDDisplayNoneOrNot()
                        });
                        }
                               checkNameDDDisplayNoneOrNot()
                    });
                });
            });
            });
        });////
                   });
    });
  });
               });
               });//end of msqg
});
                                     });
    
    
    
    
    
    /******ANB_json = [{
                "anb_type" : arrConfigData['0']["anb_type"],
                "IL_monthly_start_Date" : arrConfigData['0']["IL_monthly_start_Date"],
                "IL_monthly_end_Date" : arrConfigData['0']["IL_monthly_end_Date"],
                "IL_monthly_inc_period" : arrConfigData['0']["IL_monthly_inc_period"]
                }]**********/
                                
}





function fnMsGetNobData(personType)
{
    var val_nob=""
    console.log("personType nob"+personType);
    var natureValue=document.getElementById("al_employee_details."+personType+".nature_of_business").value;
    console.log("natureValue"+natureValue);
    if(natureValue == "")
    {
      val_nob = "Select"
    }
    var nobObj= MsGetNob(load_tsv_data["Nob_text"],load_tsv_data["Nob_value"]);
   // console.log(" my solution nobObj" +JSON.stringify(nobObj));
    var nobObjOne=nobObj[1];
    //console.log(" my solution nobObj2" +JSON.stringify(nobObjOne));
      val_nob = nobObjOne[natureValue];
    if(val_nob == undefined || val_nob == null)
    {
        val_nob = ""
    }
    console.log(" inside object val_nob_mlife  "+val_nob_mlife);
    return  val_nob;
}



function fnMsCheckClientForHanshaking()
{
    js_get_var("main_life_response", function(mlife_res)
               {
               js_get_var("LoginAgentId",function(agent_id)
                          {
                         // ds_agentId=agent_id;
    js_get_var("sec_life_response", function(slife_res)
               {
               js_get_var("third_life_response", function(tlife_res)
                          {
    js_get_var("mck_client_id", function(client_id_res)
    {
               client_id_res_AL = client_id_res;
        js_get_var("proposal_required_info", function(response_pro_req)
        {
                   response_pro_req_AL = response_pro_req;
            js_get_var("isSQSFromAL", function(isSQSFromAL){
                   console.log("mlife_res -->"+JSON.stringify(mlife_res)+" slife_res -->"+JSON.stringify(slife_res));
            replicate_res = response_pro_req;
                       //makarand: for CAL EAl requote
// mlife_res variable added in below if condition for backswipe condition data popoulate from object changes made by pramod chavan on 12102017
               
               if (isSQSFromAL == "Yes" && (mlife_res == "null" || mlife_res == null || mlife_res == "" || mlife_res == "(null)") && (response_pro_req == "null" || response_pro_req == null || response_pro_req == "" || response_pro_req == "(null)") && (client_id_res == "null" || client_id_res == null || client_id_res == "" || client_id_res == "(null)")){
                       document.getElementById("al_person_details.mlife.first_name").style.display='none';
                       document.getElementById("al_person_details.slife.first_name").style.display='none';
                       document.getElementById("al_person_details.tlife.first_name").style.display='none';
                       document.getElementById("al_person_details.mlife.first_name_dropdown").style.display='block';
                       document.getElementById("al_person_details.slife.first_name_dropdown").style.display='block';
                       document.getElementById("al_person_details.tlife.first_name_dropdown").style.display='block';
                       document.getElementById("al_person_details.pre_natal_child_flg").disabled=true;
                       document.getElementById("view_al_btn").style.display = 'block';
                       
                       console.log("Al_proposal_no --> "+Al_proposal_no);
                       var AlSelectQuery = fnMPAlSelectQuery('al_letter_details',Al_proposal_no);
                       AlSelectQuery.execute(function (response){
                             if(response != "" && response !=null && response !="{}"){
                                 var obj=JSON.parse(response);
                                 var option = null;
                                 var mlife_Al_data = null;
                                 var slife_Al_data = null;
                                 var tlife_Al_data = null;
                                 first_name_ck = [];
                                 person_id_ck = [];
                                 
                                 for (sub in obj)
                                 {
                                 var objSub = obj[sub];
                                 var elementsArray = Object.keys(objSub);
                                 
                                 console.log("elementsArray -->"+JSON.stringify(elementsArray)+" elementsArray.length -->"+elementsArray.length);
                                 for(var i=0 ;i< elementsArray.length; i++)
                                 {
                                 if(elementsArray[i] == "LIFE_ASSURED_NAME")
                                 {
                                    first_name_ck.push(obj[sub][elementsArray[i]]);
                                    mlife_Al_data = obj[sub][elementsArray[i]];
                                 
                                 }else if(elementsArray[i] == "PROPOSER_NAME"){
                                     if(obj[sub][elementsArray[i]] != "null" && obj[sub][elementsArray[i]] != null && obj[sub][elementsArray[i]] != "" && obj[sub][elementsArray[i]] != "(null)")
                                             {
                                             first_name_ck.push(obj[sub][elementsArray[i]]);
                                             slife_Al_data = obj[sub][elementsArray[i]];
                                             }
                                    
                                 }
                                 else if(elementsArray[i] == "slife_name"){
                                     if(obj[sub][elementsArray[i]] != "null" && obj[sub][elementsArray[i]] != null && obj[sub][elementsArray[i]] != "" && obj[sub][elementsArray[i]] != "(null)")
                                     {
                                         first_name_ck.push(obj[sub][elementsArray[i]]);
                                         slife_Al_data = obj[sub][elementsArray[i]];
                                     }
                                 
                                 }
                                 else if(elementsArray[i] == "JOINT_PARENT_NAME"){
                                     if(obj[sub][elementsArray[i]] != "" && obj[sub][elementsArray[i]] != "null" && obj[sub][elementsArray[i]] != null && obj[sub][elementsArray[i]] != "(null)")
                                     {
                                     console.log("elementsArray[i] for tlife -->>" +obj[sub][elementsArray[i]]);
                                     first_name_ck.push(obj[sub][elementsArray[i]]);
                                     tlife_Al_data = obj[sub][elementsArray[i]];
                                     }

                                 }
                                console.log("first_name_ck -->"+JSON.stringify(first_name_ck)+" mlife_Al_data -->"+mlife_Al_data+" slife_Al_data -->"+slife_Al_data+" tlife_Al_data -->"+tlife_Al_data);

                                 }
                                 }
                                 
                                 for (i=0;i<first_name_ck.length;i++)
                                 {
                                 option += '<option value="'+ first_name_ck[i] + '">' + first_name_ck[i] + '</option>';
                                 }
                                 
                                 $('.fnamedrop').append(option).prop('selected', 'selected');
                                 $('.snamedrop').append(option).prop('selected', 'selected');
                                 $('.tnamedrop').append(option).prop('selected', 'selected');
                             }
                            onLoadSqsMlifePage();
                                             
                                             
                             if(mlife_res == "" || mlife_res == null || mlife_res == "null"  || mlife_res == "(null)"){
                                 if(!(mlife_Al_data == "" || mlife_Al_data == null || mlife_Al_data == "null" || mlife_Al_data == "(null)")){
                                    
                                     PopulateValuesForAlSqs("mlife");
                                 }
                             }
                             if(mlife_res == "" || mlife_res == null || mlife_res == "null"  || mlife_res == "(null)"){
                                             if(!(slife_Al_data == "" || slife_Al_data == null || slife_Al_data == "null" || slife_Al_data == "(null)")){
                             
                                             PopulateValuesForAlSqs("slife");
                                             }
                             }
                             if(mlife_res == "" || mlife_res == null || mlife_res == "null"  || mlife_res == "(null)"){
                                             if(!(tlife_Al_data == "" || tlife_Al_data == null || tlife_Al_data == "null" || tlife_Al_data == "(null)")){
                             
                                             PopulateValuesForAlSqs("tlife");
                                             }
                             }


                        });
               }
            else if((client_id_res != "" && client_id_res != null && client_id_res != "null" && client_id_res != "(null)") && (response_pro_req == "null" || response_pro_req == null || response_pro_req == "" || response_pro_req == "(null)"))
            {
                       console.log("client_id_res---"+client_id_res)
                 var iskeyManflag = "";
                   var youAndspouseDetails = "";
                Client_id = client_id_res;
                
                document.getElementById("al_person_details.mlife.first_name").style.display='none';
                document.getElementById("al_person_details.slife.first_name").style.display='none';
                document.getElementById("al_person_details.tlife.first_name").style.display='none';
                document.getElementById("al_person_details.mlife.first_name_dropdown").style.display='block';
                document.getElementById("al_person_details.slife.first_name_dropdown").style.display='block';
                document.getElementById("al_person_details.tlife.first_name_dropdown").style.display='block';
                document.getElementById("al_person_details.pre_natal_child_flg").disabled=true;
                   
                var querySelect = new DbUtil();
                
                querySelect.query()
                .select()
                .column('*')
                .from()
                .table('careerkit_person_details AS t1,careerkit_employee_details AS t3')
                .where()
                .clause('t1.person_id','==','t3.person_id')
                .and()
                .clause('t1.client_id','=',Client_id)
                .and()
                .clause('t1.is_deleted','=','No')
                .and()
               .clause('t1.ylp_type','!=','partner')
                .and()
                .clause('t1.agent_id','=',ds_agentId)
                .and()
                .clause('t3.agent_id','=',ds_agentId);//Added by Pallavi for device sharing
                
                querySelect.execute(function (response)
                {
                    if(response != "" && response !=null && response !="{}")
                    {
                        var obj=JSON.parse(response);
                        var option = null;
                        first_name_ck = [];
                        person_id_ck = [];
                        
                        for (sub in obj)
                        {
                            var objSub = obj[sub];
                            var elementsArray = Object.keys(objSub);
                            
                            for(var i=0 ;i< elementsArray.length; i++)
                            {
                                if(elementsArray[i] == "first_name")
                                {
                                    first_name_ck.push(obj[sub][elementsArray[i]]);
                                    if(youAndspouseDetails == ""){
                                    youAndspouseDetails = obj[sub]["ylp_type"]+"||"+obj[sub][elementsArray[i]];
                                    }else{
                                    youAndspouseDetails = youAndspouseDetails+"||"+obj[sub]["ylp_type"]+"||"+obj[sub][elementsArray[i]];
                                    }
                                    
                                }else if(elementsArray[i] == "person_id")
                                {
                                    person_id_ck.push(obj[sub][elementsArray[i]]);
                                    }
                                   else if(elementsArray[i] == "insurence_type")
                                {
                                    if(obj[sub][elementsArray[i]] == "keyman" || obj[sub][elementsArray[i]] == "employee" || obj[sub][elementsArray[i]]=="partnership" || obj[sub][elementsArray[i]] == "Business Loan Insurance (for Company/LLP)" || obj[sub][elementsArray[i]] == "Business Loan Insurance (for Sole Proprietorship/Partnership)")//2new
                                    {
                                    iskeyManflag = true
                                    }
                                }                                }
                            }
                       
                        document.getElementById("youAndspouseDetails").value=youAndspouseDetails;
                        var tempName = "";
                        var tempYou = youAndspouseDetails.split("||");
                        if(tempYou.indexOf("you") != -1){
                            tempName =tempYou[tempYou.indexOf("you")+1]
                        }
                        for (i=0;i<first_name_ck.length;i++)
                        {
                            if(iskeyManflag == true){
                                if(first_name_ck[i] == tempName){
                                    option += '<option value="'+ first_name_ck[i] + '">' + first_name_ck[i] + '</option>';
                                }
                            }else{
                                    option += '<option value="'+ first_name_ck[i] + '">' + first_name_ck[i] + '</option>';
                            }
                        }
                        
                        $('.fnamedrop').append(option).prop('selected', 'selected');
                        $('.snamedrop').append(option).prop('selected', 'selected');;
                        $('.tnamedrop').append(option).prop('selected', 'selected');;
                    }
                                    
                    onLoadSqsMlifePage();
                    
                });
            }
            else if(response_pro_req != "" && response_pro_req != null && response_pro_req != "null" && response_pro_req != "(null)")
            {
                       console.log("response_pro_req---",response_pro_req)
                   var obj_person_id = "";
                   var obj = JSON.parse(response_pro_req);
                   e_reference_id=obj['e_reference_id'];
                   sqs_id=obj['sqs_id'];
                   ylp_id=obj['ylp_id'];
                
                   agent_id=obj['agent_id'];
                   proposal_mode=obj['proposal_mode'];
                   client_id=obj['client_id'];
                   
                   Client_id = client_id;
                   // change table name careerkit_person_details to ylp_person_details from below query for replace quote case. 04122017 changes made by pramod chavan.
                   
                   var querySelect = new DbUtil();
                   
                   querySelect.query()
                   .select()
                   .column('*')
                   .from()
                   .table('ylp_person_details AS t1,ylp_employee_details AS t3')
                   .where()
                   .clause('t1.person_id','==','t3.person_id')
                   .and()
                   .clause('t1.client_id','=',Client_id)
                   .and()
                   .clause('t1.ylp_id','=',ylp_id)
                   .and()
                   .clause('t1.is_deleted','=','No')
                   .and()
                   .clause('t1.agent_id','=',ds_agentId)
                   .and()
                   .clause('t3.agent_id','=',ds_agentId);//Added by Pallavi for device sharing
                   
                   querySelect.execute(function (responses)
                    {
                                       if(responses != "" && responses !=null && responses !="{}")
                                       {
                   var objs=JSON.parse(responses);
                   var option = null;
                   first_name_ck = [];
                   person_id_ck = [];
                   
                   for (sub in objs)
                   {
                       var objSub = objs[sub];
                       var elementsArray = Object.keys(objSub);
                       
                       for(var i=0 ;i< elementsArray.length; i++)
                       {
                           if(elementsArray[i] == "first_name")
                           {
                                first_name_ck.push(objs[sub][elementsArray[i]]);
                           
                           }else if(elementsArray[i] == "person_id")
                           {
                                person_id_ck.push(objs[sub][elementsArray[i]]);
                           }
                       }
                   }
                                       
                                       
                   
                   for (i=0;i<first_name_ck.length;i++)
                   {
                   option += '<option value="'+ first_name_ck[i] + '">' + first_name_ck[i] + '</option>';
                   }
                   
                   $('.fnamedrop').append(option).prop('selected', 'selected');
                   $('.snamedrop').append(option).prop('selected', 'selected');;
                   $('.tnamedrop').append(option).prop('selected', 'selected');;
                                       
                                       }
                   
                onLoadSqsMlifePage();
                   
                

                document.getElementById("al_person_details.mlife.first_name").style.display='none';
                document.getElementById("al_person_details.slife.first_name").style.display='none';
                document.getElementById("al_person_details.tlife.first_name").style.display='none';
                document.getElementById("al_person_details.mlife.first_name_dropdown").style.display='block';
                document.getElementById("al_person_details.slife.first_name_dropdown").style.display='block';
                document.getElementById("al_person_details.tlife.first_name_dropdown").style.display='block';
                document.getElementById("al_person_details.pre_natal_child_flg").disabled=true;
                   
                var querySelect = new DbUtil();

                querySelect.query()
                querySelect.select()
                querySelect.column('*')
                querySelect.from()
                querySelect.table('al_sqs_details')
                querySelect.where()
                querySelect.clause('sqs_id','=',sqs_id)
                querySelect.and()
                querySelect.clause('client_id','=',Client_id)
             if(channelTypeForAgencyBancaRepls!='banca'){
                querySelect.and()
                querySelect.clause('is_deleted','=','No')
            }
                querySelect.and()
                querySelect.clause('agent_id','=',ds_agentId);//Added by Pallavi for device sharing

                querySelect.execute(function (response)
                {
                    if(response != "" && response !=null && response !="{}")
                    {
                        var obj=JSON.parse(response);
                                    
                        js_get_var("mck_to_ms_ylp", function(person_id_res)
                        {
                            if(person_id_res != "" && person_id_res !=null && person_id_res !="{}")
                            {
                                obj_person_id = JSON.parse(person_id_res);
                            }
                                   
                        var mlife_person_id_replicate = obj[0]['mlife_person_id'];
                                    ylp_type_mlife = mlife_person_id_replicate;
                                    
                        var slife_person_id_replicate = obj[0]['slife_person_id'];
                        if(slife_person_id_replicate != "" && slife_person_id_replicate != "null")
                        {
                            ylp_type_slife = slife_person_id_replicate;
                        }else
                        {
                            if(!(person_id_res == null || person_id_res == "" || person_id_res == "null" || person_id_res =="{}"))
                            {
                                   if(obj_person_id["ylp_type_slife"] != "" && obj_person_id["ylp_type_slife"] != "null")
                                   {
                                        ylp_type_slife = obj_person_id["ylp_type_slife"];
                                   }else
                                   {
                                        ylp_type_slife = "";
                                   }
                            }else
                           {
                                   ylp_type_slife = "";
                           }
                        }
                                    
                        var tlife_person_id_replicate = obj[0]['tlife_person_id'];
                        if(tlife_person_id_replicate != "" && tlife_person_id_replicate != "null")
                        {
                            ylp_type_tlife = tlife_person_id_replicate;
                        }
                        else
                        {
                                   if(!(person_id_res == null || person_id_res == "" || person_id_res == "null" || person_id_res =="{}"))
                            {
                                if(obj_person_id["ylp_type_tlife"] != "" && obj_person_id["ylp_type_tlife"] != "null" && obj_person_id["ylp_type_tlife"] != null)
                                {
                                   ylp_type_tlife = obj_person_id["ylp_type_tlife"];
                                }else
                                {
                                   ylp_type_tlife = "";
                                }
                            }else
                            {
                                   ylp_type_tlife = "";
                            }
                        }
                                    
                                    
                                   if(mlife_res == "" || mlife_res == null || mlife_res == "null"  || mlife_res == "(null)")
                                   {
                        if(!(mlife_person_id_replicate == "" || mlife_person_id_replicate == null || mlife_person_id_replicate == "null"))
                        {
                                   console.log("mlife_res:: "+mlife_res);
                                   
                            PopulateValuesForReplicate(mlife_person_id_replicate,"mlife",obj,Client_id,response_pro_req);
                                  
                        }
                        
                        if(!(slife_person_id_replicate == "" || slife_person_id_replicate == null || slife_person_id_replicate == "null"))
                        {
                                   console.log("slife_res:: "+slife_res);
//                                   if(slife_res == "" || slife_res == null || slife_res == "null"  || slife_res == "(null)")
//                                   {
                                   setTimeout(function(){
                            if((document.getElementById("al_person_details.mlife.anb").value >= 11 && document.getElementById("al_person_details.mlife.anb").value <= 16) || (document.getElementById("al_person_details.mlife.anb_il_product").value >= 11 && document.getElementById("al_person_details.mlife.anb_il_product").value <= 16) || (document.getElementById("al_person_details.mlife.anb_il_monthly_product").value >= 11 && document.getElementById("al_person_details.mlife.anb_il_monthly_product").value <= 16))
                                   {
                                   if(document.getElementById("al_person_details.mlife.parent_consent_yes").checked)
                                   {
                                   fnMsDisableLives("al_person_details.mlife.parent_consent_yes");
                                   }else
                                   {
                                   PopulateValuesForReplicate(slife_person_id_replicate,"slife",obj,Client_id,response_pro_req);
                                   }
                                   }else
                                   {
                                PopulateValuesForReplicate(slife_person_id_replicate,"slife",obj,Client_id,response_pro_req);
                                   }
                                              },1);
//                                   }
                        }
                        
                        if(!(tlife_person_id_replicate == "" || tlife_person_id_replicate == null || tlife_person_id_replicate == "null"))
                        {
                                   console.log("tlife_res:: "+tlife_res);
//                                   if(tlife_res == "" || tlife_res == null || tlife_res == "null" || tlife_res == "(null)")
//                                   {
                                   if((Channel == "Banca" || Channel == "UOB") && document.getElementById("al_person_details.mlife.parent_consent_yes").checked) //condition changed by Purva/Pramod C  on 07th Aug 2017 for UOB
                                   {
                                    //do nothing
                                   }else
                                   {
                            PopulateValuesForReplicate(tlife_person_id_replicate,"tlife",obj,Client_id,response_pro_req);
                                   }
//                                   }
                        }
                                    }
                                   
                                               });
                    }
                });
                                       
                 setTimeout(function(){
                  
                  fnMsDisableForm();
                  },400);
                   
                                       
                                       });
               }else if(isSQSFromAL == "Yes"){
                       // this condition added by pramod chavan for EAL/CAL internal defect 
                       Client_id = client_id_res;
                       
                       document.getElementById("al_person_details.mlife.first_name").style.display='none';
                       document.getElementById("al_person_details.slife.first_name").style.display='none';
                       document.getElementById("al_person_details.tlife.first_name").style.display='none';
                       document.getElementById("al_person_details.mlife.first_name_dropdown").style.display='block';
                       document.getElementById("al_person_details.slife.first_name_dropdown").style.display='block';
                       document.getElementById("al_person_details.tlife.first_name_dropdown").style.display='block';
                       document.getElementById("al_person_details.pre_natal_child_flg").disabled=true;
                       
                       var AlSelectQuery = fnMPAlSelectQuery('al_letter_details',Al_proposal_no);
                       AlSelectQuery.execute(function (response){
                                             if(response != "" && response !=null && response !="{}"){
                                           var obj=JSON.parse(response);
                                           var option = null;
                                           first_name_ck = [];
                                           person_id_ck = [];
                                             var mlife_Al_data = null;
                                             var slife_Al_data = null;
                                             var tlife_Al_data = null;
                                           for (sub in obj)
                                           {
                                           var objSub = obj[sub];
                                           var elementsArray = Object.keys(objSub);
                                           
                                           for(var i=0 ;i< elementsArray.length; i++)
                                           {
                                             
                                             
                                           if(elementsArray[i] == "LIFE_ASSURED_NAME")
                                           {
                                             if(obj[sub][elementsArray[i]] != "" && obj[sub][elementsArray[i]] != "null"){
                                             mlife_Al_data=obj[sub][elementsArray[i]];
                                           first_name_ck.push(obj[sub][elementsArray[i]]);
                                             }
                                           }else if(elementsArray[i] == "PROPOSER_NAME")
                                             {
                                             if(obj[sub][elementsArray[i]] != "" && obj[sub][elementsArray[i]] != "null"){
                                             slife_Al_data=obj[sub][elementsArray[i]];
                                             first_name_ck.push(obj[sub][elementsArray[i]]);
                                             }
                                             }else if(elementsArray[i] == "slife_name")
                                             {
                                             if(obj[sub][elementsArray[i]] != "" && obj[sub][elementsArray[i]] != "null"){
                                             slife_Al_data=obj[sub][elementsArray[i]];
                                             first_name_ck.push(obj[sub][elementsArray[i]]);
                                             }
                                             }else  if(elementsArray[i] == "JOINT_PARENT_NAME")
                                             {
                                             if(obj[sub][elementsArray[i]] != "" && obj[sub][elementsArray[i]] != "null"){
                                             tlife_Al_data=obj[sub][elementsArray[i]];
                                             first_name_ck.push(obj[sub][elementsArray[i]]);
                                             }
                                             }
                                            /*else if(elementsArray[i] == "person_id")
                                           {
                                           person_id_ck.push(obj[sub][elementsArray[i]]);
                                           }*/
                                           }
                                           }
                                             
                                            for (i=0;i<first_name_ck.length;i++)
                                           {
                                           option += '<option value="'+ first_name_ck[i] + '">' + first_name_ck[i] + '</option>';
                                           }
                                           
                                           $('.fnamedrop').append(option).prop('selected', 'selected');
                                           $('.snamedrop').append(option).prop('selected', 'selected');;
                                           $('.tnamedrop').append(option).prop('selected', 'selected');;
                                           }
                                           
                                           onLoadSqsMlifePage();
                                             console.log("cal eal defect--->"+mlife_res+"----"+slife_Al_data+"----"+tlife_Al_data);
                                             if(mlife_res == "" || mlife_res == null || mlife_res == "null"  || mlife_res == "(null)"){
                                             if(!(mlife_Al_data == "" || mlife_Al_data == null || mlife_Al_data == "null" || mlife_Al_data == "(null)")){
                                             
                                             PopulateValuesForAlSqs("mlife");
                                             }
                                             }
                                             if(mlife_res == "" || mlife_res == null || mlife_res == "null"  || mlife_res == "(null)"){
                                             if(!(slife_Al_data == "" || slife_Al_data == null || slife_Al_data == "null" || slife_Al_data == "(null)")){
                                             
                                             PopulateValuesForAlSqs("slife");
                                             }
                                             }
                                             if(mlife_res == "" || mlife_res == null || mlife_res == "null"  || mlife_res == "(null)"){
                                             if(!(tlife_Al_data == "" || tlife_Al_data == null || tlife_Al_data == "null" || tlife_Al_data == "(null)")){
                                             
                                             PopulateValuesForAlSqs("tlife");
                                             }
                                             }
                                           });
                       
                       }
            else
            {
                document.getElementById("al_person_details.mlife.first_name").style.display='block';
                document.getElementById("al_person_details.slife.first_name").style.display='block';
                document.getElementById("al_person_details.tlife.first_name").style.display='block';
                document.getElementById("al_person_details.mlife.first_name_dropdown").style.display='none';
                document.getElementById("al_person_details.slife.first_name_dropdown").style.display='none';
                document.getElementById("al_person_details.tlife.first_name_dropdown").style.display='none';
                document.getElementById("al_person_details.pre_natal_child_flg").disabled=false;

                onLoadSqsMlifePage();
                Client_id = client_id_res;
            }
            
            
                       
                       
           });
        });
    });
                          });
               });
               });
               
        });
}

function loadOccupationsSqs(occupationScript, personType)
{
    var lines = occupationScript.split("\n");
    var occClass = new Array();
    var occEnglish = new Array();
    var occMalay = new Array();

    for (i = 0; i < lines.length; i++)
    {
        var subParts = lines[i].split("\t");
        occClass[i] = subParts[0];
        occEnglish[i] = subParts[1];
        occMalay[i] = subParts[2];
    }

    var targetElement = document.getElementById("al_employee_details." + personType + ".occupation");

    setOptionsOcc(targetElement, occEnglish, occEnglish);

    //Disabled fields
    document.getElementById("al_employee_details.mlife.occupation_class").disabled = true;
    document.getElementById("al_employee_details.slife.occupation_class").disabled = true;
    document.getElementById("al_employee_details.tlife.occupation_class").disabled = true;
}

function setOptionsOcc(targetElement, occArray, valueArray)
{
    for (var j = 0; j < occArray.length; j++)
    {
        var optn = document.createElement("OPTION");
        optn.text = occArray[j];
        optn.value = valueArray[j];
        targetElement.appendChild(optn);
    }
}

function loadNatureBusi(nobScript, personType)
{
    var lines = nobScript.split("\n");
    
    var nobEnglish = new Array();

    for (i = 0; i < lines.length; i++) {
        var subParts = lines[i].split("\t");
        nobClass[i] = subParts[0];
        nobEnglish[i] = subParts[1];
    }

    var targetElement = document.getElementById("al_employee_details." + personType + ".nature_of_business");
    
    setOptionsNob(targetElement, nobEnglish, nobClass);

}

function setOptionsNob(targetElement, nobArray, valueArray) {
    
    for (var j = 0; j < nobArray.length; j++) {
        var optn = document.createElement("OPTION");
        if(nobArray[j]!=undefined && nobArray[j]!='undefined' && valueArray[j]!=undefined && valueArray[j]!='undefined')  //chaned by sayali.it was giving undefined in options
        {
            optn.text = nobArray[j];
            optn.value = valueArray[j];
            targetElement.appendChild(optn);
        }
    }
}

//Get natal status
function getNatalStats() {
    var natal_chk;

    if (document.getElementById("al_person_details.pre_natal_child_flg").checked) {
        natal_chk = "Yes";
    } else {
        natal_chk = "No";
    }

    return natal_chk;
}

//Get Gender
function getGender(personType) {
    var gender_chk_res;

    if (document.getElementById("al_person_details." + personType + ".gender_male").checked) {
        gender_chk_res = "Male";
    } else if (document.getElementById("al_person_details." + personType + ".gender_female").checked) {
        gender_chk_res = "Female";
    }
    return gender_chk_res;
}

//Get Smoke stats
function getSmokeStats(personType) {
    var smoke_stats_res;

    if (document.getElementById("al_person_details." + personType + ".smoke_status_yes").checked) {
        smoke_stats_res = "Smoker";
    } else if (document.getElementById("al_person_details." + personType + ".smoke_status_no").checked) {
        smoke_stats_res = "Non-Smoker";
    }
    return smoke_stats_res;
}

//Get mlife Parti Flag
function getMlifePartiFlag() {
    var parti_chk_mlife;

    if (document.getElementById("al_sqs_details.sec_parti_flag_yes").checked) {
        parti_chk_mlife = "Yes";
    } else if (document.getElementById("al_sqs_details.sec_parti_flag_no").checked) {
        parti_chk_mlife = "No";
    }
    return parti_chk_mlife;
}

//Get mlife Parti Flag
function getParentConsent() {
    var parti_chk_mlife;
    //if (document.getElementById("al_person_details.mlife.anb").value >= 11 && document.getElementById("al_person_details.mlife.anb").value <= 16)// && Channel == "Banca")
   // {
        if (document.getElementById("al_person_details.mlife.parent_consent_yes").checked) {
            parti_chk_mlife = "Yes";
        } else if (document.getElementById("al_person_details.mlife.parent_consent_no").checked) {
            parti_chk_mlife = "No";
      //  }
    }
        else
    {
        parti_chk_mlife = "";
    }
    return parti_chk_mlife;
}

//Get slife Parti Flag
function getSlifePartiFlag() {
    var parti_chk_slife;

    if (document.getElementById("al_sqs_details.third_parti_flg_yes").checked) {
        parti_chk_slife = "Yes";
    } else if (document.getElementById("al_sqs_details.third_parti_flg_no").checked) {
        parti_chk_slife = "No";
    }
    console.log("parti_chk_slife :- "+parti_chk_slife);
    return parti_chk_slife;
}

//Hide and show validations on pre natal selected
function validate_pre_natal(data_repl) {
    if(pre_natal_handle=="Yes")
    {
        document.getElementById("al_person_details.pre_natal_child_flg").checked=true;
    }
    console.log("-----1221-------->"+document.getElementById("al_person_details.pre_natal_child_flg").checked);
    if(document.getElementById("al_person_details.pre_natal_child_flg").checked)
    {
        //setTimeout(function(){ResetFieldsonAnbChange("")},10);
        document.getElementById("al_person_details.pre_natal_child_flg").checked = true;
        document.getElementById("al_person_details.mlife.first_name").value = "Child";
        document.getElementById("gestational_week").style.display = 'block';
        document.getElementById("al_person_details.mlife.first_name").disabled = true;
        document.getElementById("al_person_details.mlife.expected_delivery").style.display = 'block';
        document.getElementById("al_person_details.mlife.expected_delivery_dt").style.display = 'block';
        document.getElementById("al_person_details.mlife.expected_delivery_dt").disabled = true;
        document.getElementById("al_person_details.gestational_week").style.display = 'block';
        document.getElementById("al_person_details.gestational_week").disabled = true;
        document.getElementById("al_person_details.mlife.anb").value = "1";
        document.getElementById("al_person_details.mlife.anb_il_product").value = "0";
        document.getElementById("al_person_details.mlife.anb_block").style.display = 'none';
        document.getElementById("al_person_details.mlife.dtofbirth").style.display = 'none';
        document.getElementById("al_person_details.mlife.dob").value = "";
        document.getElementById("al_person_details.mlife.gender_male").checked = true;
        document.getElementById("al_person_details.mlife.gender_female").disabled = true;
        document.getElementById("al_person_details.mlife.smoke_status_no").checked = true;
        document.getElementById("al_person_details.mlife.smoke_status_yes").disabled = true;
        
        //Added by Paromita on 14 Aug 2017 FOR NEW OCCUPATION LIST
        fnMsSolSelectElement("Child", "al_employee_details.mlife.occupation");
        $(".occupationSearchMLifeText").val("Child");
        $(".occupationSearchMLifeText").attr("disabled","true");
        document.getElementById("al_employee_details.mlife.occupation").disabled = true;
        fnMsSolSelectElement("Child","al_employee_details.mlife.nature_of_business");
        $(".natureSearchMLifeText").val("Child");
        /***/
        console.log("childee1");
        $(".natureSearchMLifeText").attr("disabled","true");
        document.getElementById("al_employee_details.mlife.nature_of_business").disabled = true;
        //Added by Paromita on 14 Aug 2017 FOR NEW OCCUPATION LIST
        /*var res_occ_class = document.getElementById("al_employee_details.mlife.occupation").value.split("-");
        document.getElementById("al_employee_details.mlife.occupation_class").value = res_occ_class[1];*/
    fngetOccupationClassFromMatrix("al_employee_details.mlife.occupation","al_employee_details.mlife.nature_of_business","al_employee_details.mlife.occupation_class")

        ANB_set = 1;
        
        if(document.getElementById("al_person_details.slife.gender_male").checked == true)
        {
            $("input[name='tlife_gender'][value='Male']").prop('checked',false);
            $("input[name='tlife_gender'][value='Female']").prop('checked',true);
        }else{
            $("input[name='tlife_gender'][value='Male']").prop('checked',true);
            $("input[name='tlife_gender'][value='Female']").prop('checked',false);
        }

        document.getElementById("al_sqs_details.sec_parti_flag_yes").checked = true;
        document.getElementById("al_sqs_details.sec_parti_flag_no").checked = false;
        document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = true;
        $(".collapseTwo").attr("id", "collapseTwo");
        $(".second_life").addClass("normal_panel");
        $(".second_life").removeClass("disabled_panel");

       	$( "select[name='al_person_details.slife.relationship']" ).find('option[value="Spouse"]').remove();
         document.getElementById("al_person_details.slife.relationship").value="Parent";
        document.getElementById("al_person_details.slife.relationship").disabled = false;
        
        if(document.getElementById("al_person_details.mlife.gender_male").checked == true)
        {
            document.getElementById("third_life_party_flag").style.display = 'block';
            document.getElementById("al_sqs_details.third_parti_flg_yes").disabled = true;
            document.getElementById("al_sqs_details.third_parti_flg_no").disabled = true;
            $("input[name='third_life'][value='Yes']").prop('checked',true);
            $("input[name='third_life'][value='No']").prop('checked',false);
            $(".collapseThree").attr("id", "collapseThree");
            $(".third_life").addClass("normal_panel");
            $(".third_life").removeClass("disabled_panel");
        }
        
        if (Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)" && (replicate_res == "" || replicate_res == null || replicate_res == "null" || replicate_res == "(null)"))
        {
            console.log("---->09");
            fnMsPersonalPopulateValues("al_person_details.slife.first_name_dropdown","slife")
            document.getElementById("al_person_details.slife.first_name_dropdown").disabled=true;
        }else if(replicate_res != "" && replicate_res != null && replicate_res != "null" && replicate_res != "(null)")
        {
            console.log("---->10");
            fnMsPersonalPopulateValues("al_person_details.slife.first_name_dropdown","slife")
            document.getElementById("al_person_details.slife.first_name_dropdown").disabled=true;
        }
        
        ClearData();
    }
    else
    {
        if (data_repl == "" || data_repl == null || data_repl == "null" || data_repl == "(null)" || data_repl == "{}")
        {
            if (Client_id == "" || Client_id == null || Client_id == "null" || Client_id == "(null)")
            {
                ResetFieldsonAnbChange("");
            }
            
            if(document.getElementById("al_person_details.mlife.first_name").value.length > 0)
            {
                document.getElementById("al_person_details.mlife.first_name").value = "";
            }
            document.getElementById("al_person_details.mlife.first_name").disabled = false;
        }
        
        document.getElementById("gestational_week").style.display = 'none';

        document.getElementById("al_person_details.mlife.expected_delivery").style.display = 'none';
        document.getElementById("al_person_details.mlife.expected_delivery_dt").value = "";
        document.getElementById("al_person_details.gestational_week").style.display = 'none';
        document.getElementById("al_person_details.gestational_week").value = "Gestational Week";
        document.getElementById("al_person_details.mlife.dtofbirth").style.display = 'block';
        document.getElementById("al_person_details.mlife.anb_block").style.display = 'block';
        document.getElementById("al_person_details.mlife.dob").style.display = 'block';
        //document.getElementById("al_person_details.mlife.anb").value = ""; changes made by pramod chavan for DEF-3918 on 07092017

        $("input[name='tlife_gender'][value='Male']").prop('checked',true);
        $("input[name='tlife_gender'][value='Female']").prop('checked',false);
        
        if (data_repl != "" && data_repl != null && data_repl != "null" && data_repl != "(null)" && data_repl.length > 0)
        {
            document.getElementById("al_person_details.mlife.gender_female").disabled = true;
            document.getElementById("al_person_details.mlife.smoke_status_yes").disabled = true;
        }else
        {
            document.getElementById("al_person_details.mlife.gender_female").disabled = false;
            document.getElementById("al_person_details.mlife.smoke_status_yes").disabled = false;
        }
        
        if (Client_id == "" || Client_id == null || Client_id == "null" || Client_id == "(null)")
        {
            $(".occupationSearchMLifeText").removeAttr("disabled");
            document.getElementById("al_employee_details.mlife.occupation").disabled = false;
            $(".natureSearchMLifeText").removeAttr("disabled");
            document.getElementById("al_employee_details.mlife.nature_of_business").disabled = false;
            fnMsSolSelectElement("Occupation", "al_employee_details.mlife.occupation");
            $(".occupationSearchMLifeText").val("");
            fnMsSolSelectElement("Nature of Business", "al_employee_details.mlife.nature_of_business");
            $(".natureSearchMLifeText").val("");
            document.getElementById("al_employee_details.mlife.occupation_class").value = "";
        }
        // Below line commented by pramod chavan on 19042017 for occupation class blank issued
        //document.getElementById("al_employee_details.mlife.occupation_class").value = "";
        
        if((document.getElementById("al_person_details.mlife.anb").value > 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value > 16 && isILproduct))
        {
            document.getElementById("al_sqs_details.sec_parti_flag_yes").checked = false;
            document.getElementById("al_sqs_details.sec_parti_flag_no").checked = true;
            document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = false;
            document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = false;
            $(".collapseTwo").attr("id", "");
            $(".collapseThree").attr("id", "");
            $(".second_life,.third_life").addClass("disabled_panel");
            $(".second_life,.third_life").removeClass("normal_panel").removeClass("active_panel");
        
            console.log("reltion155:"+document.getElementById("al_person_details.slife.relationship").disabled);
            //commented below by ankita on 9 april for modrn family cr
            /*var ddloption = document.getElementById("al_person_details.slife.relationship");
            
            //console.log("options ddloption "+ddloption);
            ddloption.options.length=0;
            for(var i = 0; i < ddlArray.length; i++)
            {
                var optn=document.createElement("option");
                optn.value=ddlArray[i];
                optn.text=ddlArray[i];
                ddloption.appendChild(optn);
//                if(ddloption[k].value == 'Spouse')            {
//                    break;
//                }
//                else
//                {
//                    $( "select[name='al_person_details.slife.relationship']" ).prepend("<option value='Spouse' selected='Spouse'>Spouse</option>");
//                }
            }*/
            console.log("reltion1556:"+document.getElementById("al_person_details.slife.relationship").disabled);
            if((document.getElementById("al_person_details.mlife.anb").value==17 || document.getElementById("al_person_details.mlife.anb").value==18) && !isILproduct)
            {
                if(client_ylp_type_mlife=="lo" && (Client_id!="" && Client_id!=null && Client_id!="null"))
                {
                    document.getElementById("al_person_details.slife.relationship").value = "Parent";
                    document.getElementById("al_person_details.slife.relationship").disabled = false; // changes made by pramod chavan "True" to "False" for prodcution defect---PRUW00037533
                    console.log("3 disable");
                }

            }else if((document.getElementById("al_person_details.mlife.anb_il_product").value==17 || document.getElementById("al_person_details.mlife.anb_il_product").value==18) && isILproduct)
            {
                //to check ankita
                if(client_ylp_type_mlife=="lo" && (Client_id!="" && Client_id!=null && Client_id!="null"))
                {
                    document.getElementById("al_person_details.slife.relationship").value = "Parent";
                    document.getElementById("al_person_details.slife.relationship").disabled = false; // changes made by pramod chavan "True" to "False" for prodcution defect---PRUW00037533
                    console.log("3 disable");
                }
                
            }
            else
            {
                //commented by ankita for modern family CR on 9 april 2022
                //document.getElementById("al_person_details.slife.relationship").value="Spouse";
                //commented by ankita on 8 april for modern family CR
                //document.getElementById("al_person_details.slife.relationship").disabled = true;
                console.log("4 disable");
                //added by ankita on 26 jan 2022
                 if((document.getElementById("al_person_details.mlife.anb_il_product").value >= 17 && document.getElementById("al_person_details.mlife.anb_il_product").value <= 60))
                 {
                 /*var ddloption = document.getElementById("al_person_details.slife.relationship");
                 //console.log("options ddloption "+ddloption);
                 console.log("Ankita true inside all dropdown set2");
                 ddloption.options.length=0;
                 for(var i = 0; i < ddlArray.length; i++)
                 {
                     var optn=document.createElement("option");
                     optn.value=ddlArray[i];
                     optn.text=ddlArray[i];
                     ddloption.appendChild(optn);
                 }
                     document.getElementById("al_person_details.slife.relationship").disabled = false;
                     document.getElementById("al_person_details.slife.relationship").options[2].selected=true;*/
                     //modify by ankita for mdern family CR on 9 april 2022
                     //if(client_ylp_type_mlife=="lo" || (Client_id=="" || Client_id==null || Client_id=="null"))
                     
                          if((Client_id=="" || Client_id==null || Client_id=="null"))
                                {
                                   
                     document.getElementById("al_person_details.slife.relationship").disabled = false;
                                    
                                    
                         //document.getElementById("al_person_details.slife.relationship").options[2].selected=true;
                                }
                 }
            }
            if((document.getElementById("al_person_details.mlife.anb").value == 17 || document.getElementById("al_person_details.mlife.anb").value ==18) && !isILproduct)
            {
                document.getElementById("al_sqs_details.third_parti_flg_yes").disabled = false;
                document.getElementById("al_sqs_details.third_parti_flg_no").disabled = false;
            }else if((document.getElementById("al_person_details.mlife.anb_il_product").value == 17 || document.getElementById("al_person_details.mlife.anb_il_product").value ==18) && isILproduct)
            {
                document.getElementById("al_sqs_details.third_parti_flg_yes").disabled = false;
                document.getElementById("al_sqs_details.third_parti_flg_no").disabled = false;
            }
            $("input[name='third_life'][value='Yes']").prop('checked',false);
            $("input[name='third_life'][value='No']").prop('checked',true);
            $(".collapseThree").attr("id", "");
            $(".third_life").addClass("disabled_panel");
            $(".third_life").removeClass("normal_panel");
        }else
        {
            document.getElementById("al_sqs_details.third_parti_flg_yes").disabled = false;
            document.getElementById("al_sqs_details.third_parti_flg_no").disabled = false;
            
            $("input[name='third_life'][value='Yes']").prop('checked',false);
            $("input[name='third_life'][value='No']").prop('checked',true);
            $(".collapseThree").attr("id", "");
            $(".third_life").addClass("disabled_panel");
            $(".third_life").removeClass("normal_panel");
        }
        
        if((document.getElementById("al_person_details.mlife.anb").value >16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value >16 && isILproduct))
        {
            console.log("ANB_set 2 :: "+ANB_set);
            if((ANB_set <= 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <=16 && isILproduct))
            {
                console.log("ANB_set 3 :: "+ANB_set);
                fnMsSolSelectElement("Occupation", "al_employee_details.mlife.occupation");
                $(".occupationSearchMLifeText").val("");
                fnMsSolSelectElement("Nature of Business", "al_employee_details.mlife.nature_of_business");
                $(".natureSearchMLifeText").val("");//Prashant 23/12/2016
                document.getElementById("al_employee_details.mlife.occupation_class").value = "";

            }
        }
        //added by ankita on 25 march 2022 for modern family CR
       //change slife to mlife
        //modified if condition for defect 226
        if(parseInt(document.getElementById("al_person_details.mlife.anb_il_product").value) > 16)
        {
            if(relationship_mlife=="C")
            {
                fnGetRelationshipList('al_person_details.mlife.anb_il_product','al_person_details.slife.anb_il_product','','al_person_details.slife.relationship','al_person_details.slife.gender_male','al_person_details.slife.gender_female','mySolutionsChildCase');
                
            }
            else
            {
                //if else modified by ankita on 21 april 2022 for spouse scenario for modern family CR
                if(client_ylp_type_mlife==="lo")
                {
                    fnGetRelationshipList('al_person_details.mlife.anb_il_product','al_person_details.slife.anb_il_product','','al_person_details.slife.relationship','al_person_details.slife.gender_male','al_person_details.slife.gender_female','mySolutions');
                }
                else if((client_ylp_type_slife==="spouse" || client_ylp_type_slife==="you") && client_ylp_type_mlife!=="lo")
                {
                    console.log("disabled 3");
                    fnGetRelationshipList('al_person_details.mlife.anb_il_product','al_person_details.slife.anb_il_product','','al_person_details.slife.relationship','al_person_details.slife.gender_male','al_person_details.slife.gender_female','mySolutions');//TODO on date 29-09-2022
                    
                    document.getElementById("al_person_details.slife.relationship").value="Spouse";
                   document.getElementById("al_person_details.slife.relationship").disabled=true;
                    
                }
            }
        }
        /*if(document.getElementById("al_person_details.mlife.anb_il_product").value < 16)
        {
            console.log("Inside validate_pre_natal");
            var arrMatrix=new Array();
            var arrmatrix1Options = document.getElementById("al_person_details.slife.relationship");
         if(document.getElementById("al_person_details.slife.gender_male").checked)
          {
         arrmatrix1Options.options.length=0;
              arrMatrix=arrmatrixMale;
              //var arrmatrix1=["Parent","Legal Guardian","Grandfather","Cousin Brother","Uncle","Step Father","Brother","Step Brother"];
          }
         if(document.getElementById("al_person_details.slife.gender_female").checked)
         {
         arrmatrix1Options.options.length=0;
             arrMatrix=arrmatrixFemale;
         //var arrmatrix1=["Parent","Legal Guardian","Grandmother","Cousin Sister","Aunty","Step Mother","Sister","Step Brother"];
         }
             
         for(var i = 0; i < arrMatrix.length; i++)
         {
             var optn=document.createElement("option");
             optn.value=arrMatrix[i];
             optn.text=arrMatrix[i];
             arrmatrix1Options.appendChild(optn);
         }
        
        
        
        
           /* if(client_ylp_type_mlife=="lo" || (Client_id=="" || Client_id==null || Client_id=="null"))
                       {
            document.getElementById("al_person_details.slife.relationship").disabled = false;
                //document.getElementById("al_person_details.slife.relationship").options[2].selected=true;
                       }*/
            
        
        //}
        
        //end here

    }
}

function ValidatePersonalScreen(flag) {
    if (!(document.getElementById("al_person_details.pre_natal_child_flg").checked))
    {
        if (Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)" && (replicate_res == "" || replicate_res == null || replicate_res == "null" || replicate_res == "(null)"))
        {
            if (document.getElementById("al_person_details.mlife.first_name_dropdown").value == "Select") {
                alert("203", "Main Life");
                return false;
            }
        }else if (Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)" && (replicate_res != "" && replicate_res != null && replicate_res != "null" && replicate_res != "(null)"))
        {
            if (document.getElementById("al_person_details.mlife.first_name_dropdown").value == "Select") {
                alert("203", "Main Life");
                return false;
            }
        }
        //makarand:

        else if ((response_pro_req_AL == "" || response_pro_req_AL == null || response_pro_req_AL == "null" || response_pro_req_AL == "(null)") && (client_id_res_AL == "" || client_id_res_AL == null || client_id_res_AL == "null" || client_id_res_AL == "(null)") && (SQS_From_AL == "Yes"))
        {
            console.log("inside validate else if function");
            if (document.getElementById("al_person_details.mlife.first_name_dropdown").value == "Select") {
                alert("203", "Main Life");
                return false;
            }
        }

        else
        {

        if (!(isAlpanumericWithApostrophe("al_person_details.mlife.first_name")))
        {
            alert("201", "Main Life");
            return false;
        }

        if(!(checkSingleChar("al_person_details.mlife.first_name")))
        {
            alert("201", "Main Life");
            return false;
        }

        if (!(CheckSpace("al_person_details.mlife.first_name"))) {
            alert("201", "Main Life");
            return false;
        }

        if (!(BlankSpaceValidate("al_person_details.mlife.first_name"))) {
            alert("202", "Main Life");
            return false;
        }
        }
        

        if (document.getElementById("al_person_details.mlife.dob").value == "") {
            alert("204", "Main Life");
            return false;
        }
        if(document.getElementById("al_person_details.mlife.anb").value<=0)
        {
            alert("713","Main Life");
            return false;
        }
    } else if (document.getElementById("al_person_details.pre_natal_child_flg").checked) {
        if (document.getElementById("al_person_details.mlife.expected_delivery_dt").value == "") {
            alert("210", "Main Life");
            return false;
        }
       
        if (document.getElementById("al_person_details.slife.relationship").value == "Parent" && document.getElementById("al_person_details.slife.gender_female").checked)
        {
            //change 46 to 47 as mother age to max allow is 46 by ankita on 7 dec 2022 for pruwith you new rider changes
            if (((document.getElementById("al_person_details.slife.anb_il_product").value <= 18 || document.getElementById("al_person_details.slife.anb_il_product").value >= 46) && isILproduct && Channel!=="Agency" && Channel!=="FA")) {
                alert("222");//change 46 to 47 as mother age to max allow is 46 by ankita on 7 dec 2022 for pruwith you new rider changes
                //Please ensure mother's age is between 19 and 45
                return false;
            }
            //change 46 to 47 as mother age to max allow is 46 by ankita on 7 dec 2022 for pruwith you new rider changes
            if (((document.getElementById("al_person_details.slife.anb_il_product").value <= 18 || document.getElementById("al_person_details.slife.anb_il_product").value >= 47) && isILproduct && (Channel==="Agency" || Channel==="FA"))) {
                alert("870");//change 46 to 47 as mother age to max allow is 46 by ankita on 7 dec 2022 for pruwith you new rider changes
                //Please ensure mother's age is between 19 and 45
                return false;
            }
            //change 46 to 47 as mother age to max allow is 46 by ankita on 7 dec 2022 for pruwith you new rider changes
            if (((document.getElementById("al_person_details.slife.anb").value <= 18 || document.getElementById("al_person_details.slife.anb").value >= 46) && !isILproduct && Channel!=="Agency" && Channel!=="FA")) {
                
                
                alert("222");//change 46 to 47 as mother age to max allow is 46 by ankita on 7 dec 2022 for pruwith you new rider changes
                return false;
            }
            //change 46 to 47 as mother age to max allow is 46 by ankita on 7 dec 2022 for pruwith you new rider changes
            if (((document.getElementById("al_person_details.slife.anb").value <= 18 || document.getElementById("al_person_details.slife.anb").value >= 47) && !isILproduct && (Channel==="Agency" || Channel==="FA"))) {
                
                
                alert("870");//change 46 to 47 as mother age to max allow is 46 by ankita on 7 dec 2022 for pruwith you new rider changes
                return false;
            }
        }
        else if (document.getElementById("al_person_details.tlife.relationship").value == "Parent" && document.getElementById("al_person_details.tlife.gender_female").checked && document.getElementById("al_person_details.tlife.dob").value !="")
        {
            //For defect 5837 Sourabh/Paromita on 05 july 2018 Last movement of signoff
            /*if ((document.getElementById("al_person_details.tlife.anb_il_monthly_product").value <= 17 || document.getElementById("al_person_details.tlife.anb_il_monthly_product").value >= 46) && !isILproduct)
            {
                console.log("al_person_details.tlife.anb_il_monthly_product was missing so added");
                alert("746");
                return false;
            }*/
            // ANB criteria change for DEF-4451 18 to 17 in below if condition. Pramod Chavan: 07012018
            //change 46 to 47 as mother age to max allow is 46 by ankita on 7 dec 2022 for pruwith you new rider changes
			if (((document.getElementById("al_person_details.tlife.anb_il_product").value <= 17 || document.getElementById("al_person_details.tlife.anb_il_product").value >= 46) && isILproduct && Channel!=="Agency" && Channel!=="FA"))
                
            {
                 console.log("111 was missing so added");
                alert("746");//change 46 to 47 as mother age to max allow is 46 by ankita on 7 dec 2022 for pruwith you new rider changes
                return false;
            }
            //change 46 to 47 as mother age to max allow is 46 by ankita on 7 dec 2022 for pruwith you new rider changes
            if (((document.getElementById("al_person_details.tlife.anb_il_product").value <= 17 || document.getElementById("al_person_details.tlife.anb_il_product").value >= 47) && isILproduct && (Channel==="Agency" || Channel==="FA")))
                
            {
                 console.log("111 was missing so added");
                alert("871");//change 46 to 47 as mother age to max allow is 46 by ankita on 7 dec 2022 for pruwith you new rider changes
                return false;
            }
            // ANB criteria change for DEF-4451 18 to 17 in below if condition. Pramod Chavan: 07012018
            //change 46 to 47 as mother age to max allow is 46 by ankita on 7 dec 2022 for pruwith you new rider changes
            if ((document.getElementById("al_person_details.tlife.anb").value <= 17 || document.getElementById("al_person_details.tlife.anb").value >= 46) && !isILproduct && (Channel!=="Agency" && Channel!=="FA"))
            {
                 console.log("222 was missing so added");
                alert("746");//change 46 to 47 as mother age to max allow is 46 by ankita on 7 dec 2022 for pruwith you new rider changes
                return false;
            }
            //change 46 to 47 as mother age to max allow is 46 by ankita on 7 dec 2022 for pruwith you new rider changes
            if ((document.getElementById("al_person_details.tlife.anb").value <= 17 || document.getElementById("al_person_details.tlife.anb").value >= 47) && !isILproduct && (Channel==="Agency" || Channel==="FA"))
            {
                 console.log("222 was missing so added");
                alert("871");//change 46 to 47 as mother age to max allow is 46 by ankita on 7 dec 2022 for pruwith you new rider changes
                return false;
            }
        }
        else if (!(document.getElementById("al_person_details.slife.relationship").value == "Parent" && document.getElementById("al_person_details.slife.gender_female").checked))
        {
            if (!(document.getElementById("al_person_details.tlife.relationship").value == "Parent" && document.getElementById("al_person_details.tlife.gender_female").checked))
            {
                alert("223");
                //Mother Details are Mandatory
                return false;
            }
            else if(document.getElementById("al_person_details.tlife.relationship").value == "Parent" && document.getElementById("al_person_details.tlife.gender_female").checked)//def-4560 by sachin on 16-03-2018
                {
                    alert("223");
                    //Mother Details are Mandatory
                    return false;

                }
        }
        
    }
    
    if((document.getElementById("al_person_details.mlife.insu_type").value=="" ||document.getElementById("al_person_details.mlife.insu_type").value=="select") && document.getElementById("al_person_details.mlife.insu_type_header").value!="non_business_purpose")
    {
        alert("782");
        return false;
    }
    if((document.getElementById("al_person_details.mlife.anb").value > 70 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value > 70 && isILproduct))
    {
        if(Channel == "Banca" || Channel == "UOB") //changed by Purva / Pramod C on 07th Aug 2017 for UOB
        {
            alert("288");
            return false;
        }
    }
    
    
    var ilAnbCondition;
     var osAnbCondition;
    
    ilAnbCondition=document.getElementById("al_person_details.mlife.anb_il_product").value;
    
   
    osAnbCondition=document.getElementById("al_person_details.mlife.anb").value;
    
//    if((document.getElementById("al_person_details.mlife.anb").value==17 || document.getElementById("al_person_details.mlife.anb").value==18) && document.getElementById("al_sqs_details.sec_parti_flag_no").checked && (Client_id!="" && Client_id!=null && Client_id!="null") && client_ylp_type_mlife=="lo")
    // old if condition changed for IL ANB changes. 14122017
    
    if((osAnbCondition==17 || osAnbCondition==18) && !isILproduct && document.getElementById("al_sqs_details.sec_parti_flag_no").checked && (Client_id!="" && Client_id!=null && Client_id!="null") && client_ylp_type_mlife=="lo")
    {
        
        alert("356");
        return false;
        
    }else if(isILproduct && (ilAnbCondition==17 || ilAnbCondition==18) && document.getElementById("al_sqs_details.sec_parti_flag_no").checked && (Client_id!="" && Client_id!=null && Client_id!="null") && client_ylp_type_mlife=="lo")
    {
        
        alert("356");
        return false;
        
    }
    
    //Replace Quote changes
    if ((Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)") || (replicate_res != "" && replicate_res != null && replicate_res != "null" && replicate_res != "(null)"))
    {
        
        if(client_ylp_type_mlife == "lo" && relationship_mlife == "C")
        {
            if(typeof pre_natal_handle == "undefined" || pre_natal_handle=="")
            {
                pre_natal_handle = "No";
                
                if((document.getElementById("al_person_details.mlife.anb").value <=16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <=16 && isILproduct))
                {
                    client_ylp_type_mlife = "lo";
                }
            }
            
            if(relationship_mlife == "C" && ((pre_natal_handle == "No" && ((document.getElementById("al_person_details.mlife.anb").value <=18 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <=18 && isILproduct) )) || pre_natal_handle == "Yes"))
            {
                if(document.getElementById("al_person_details.slife.relationship").value != "Parent" && document.getElementById("al_person_details.slife.relationship").value != "Legal Guardian")
                {
                    if((relationship_slife == "" || typeof relationship_slife == "undefined") && document.getElementById("al_person_details.slife.relationship").value == "Spouse")
                    {
                        if(document.getElementById("al_person_details.slife.gender_female").checked)
                        {
                            alert("278","Wife","second life")
                            return false;
                        }else if(document.getElementById("al_person_details.slife.gender_male").checked)
                        {
                            alert("278","Husband","second life")
                            return false;
                        }
                    }
                }
                
                if(document.getElementById("al_sqs_details.third_parti_flg_yes").checked)
                {
                    if((document.getElementById("al_person_details.tlife.relationship").value != "Legal Guardian" && document.getElementById("al_person_details.tlife.relationship").value != "Parent"))
                    {
                        alert("278",fnMsReturnRelationshipValue(relationship_tlife),"third life")
                        return false;
                    }
                }
            }
            /*else if(relationship_mlife == "C" && ((document.getElementById("al_person_details.mlife.anb").value >18 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value >18 && isILproduct)) && Channel != "Banca")//Banca condition added by ankita on 31 jan 2022
            {
                alert("271");
                return false;
            }*/
            //commented by ankita on 13 april 2022 for modern family
            else if(relationship_mlife == "H" && ((document.getElementById("al_person_details.mlife.anb").value > 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value > 16 && isILproduct) ))
            {
                if(document.getElementById("al_person_details.slife.relationship").value != "Spouse")
                {
                    alert("278",fnMsReturnRelationshipValue(relationship_slife),"second life")
                    return false;
                }
            }else if(relationship_mlife == "H" && ((document.getElementById("al_person_details.mlife.anb").value <= 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <= 16 && isILproduct)) )
            {
                alert("278",fnMsReturnRelationshipValue(relationship_slife),"second life")
                return false;
            }
            
            else if(relationship_mlife == "W" && ((document.getElementById("al_person_details.mlife.anb").value > 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value > 16 && isILproduct)) )
            {
                if(document.getElementById("al_person_details.slife.relationship").value != "Spouse")
                {
                    alert("278",fnMsReturnRelationshipValue(relationship_slife),"second life")
                    return false;
                }
            }else if(relationship_mlife == "W" && ((document.getElementById("al_person_details.mlife.anb").value <= 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <= 16 && isILproduct)) )
            {
                alert("278",fnMsReturnRelationshipValue(relationship_slife),"second life")
                return false;
            }
            else
            {
                //added by ankita on 31 jan 2022 for parent relationship CR
               /* if(Channel !== "Banca")
                {
                alert("278",fnMsReturnRelationshipValue(relationship_mlife),"main life")
                return false;
                }*/
            }
            
            if(document.getElementById("al_person_details.slife.relationship").value == "" || document.getElementById("al_person_details.slife.relationship").value == "undefined")
            {
                alert("278",fnMsReturnRelationshipValue(relationship_slife),"second life")
                return false;
            }
        }
        else if(client_ylp_type_mlife == "lo" && relationship_mlife == "R")//added by ankita on 14 april for modern family CR
        {
            alert("278",fnMsReturnRelationshipValue(relationship_mlife),"main life")
            return false;
        }
        
        
        //commented below code for modern family CR by ankita on 25 march 2022
        /*else if(client_ylp_type_mlife == "lo" && relationship_mlife != "C")
        {
            alert("278",fnMsReturnRelationshipValue(relationship_mlife),"main life")
            return false;
        }*/
        
        
        
        if(relationship_mlife != "C" && relationship_mlife != "H" && relationship_mlife != "W" && relationship_mlife != "F" && relationship_mlife != "M" && relationship_mlife != "" && typeof relationship_mlife != "undefined" && (relationship_mlife == "G" && client_ylp_type_mlife=="lo"))
        {
            // && (relationship_mlife == "G" && client_ylp_type_mlife=="lo") this condition added by pramod chavan for handeled Legal Guardian relationship. on 23052017
            alert("278",fnMsReturnRelationshipValue(relationship_mlife),"main life")
            return false;
        }
        
        
    }
    if (!(document.getElementById("al_person_details.mlife.gender_male").checked) && !(document.getElementById("al_person_details.mlife.gender_female").checked)) {
        alert("206");
        return false;
    }

    if (!(document.getElementById("al_person_details.mlife.smoke_status_yes").checked) && !(document.getElementById("al_person_details.mlife.smoke_status_no").checked)) {
        alert("209", "Main Life");
        return false;
    }

    if (!(getOccupationValue("al_employee_details.mlife.occupation"))) {
        alert("207", "Main Life");
        return false;
    }

    if (!(getNobValue("al_employee_details.mlife.nature_of_business"))) {
        alert("208", "Main Life");
        
        return false;
    }
    else if($(".natureSearchMLifeText").val() == "Nature of Business" )
    {
        $(".natureSearchMLifeText").val('');
        alert("208","Main Life");
       return false;
    }
    
    if(!(checkNob("al_employee_details.mlife.nature_of_business")))
       {
           $(".natureSearchMLifeText").val('');
         alert("208", "Main Life");
       
             return false;

       }
    

    if (getMlifePartiFlag() == "Yes") {

        //Replace Quote changes
        if ((Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)") || (replicate_res != "" && replicate_res != null && replicate_res != "null" && replicate_res != "(null)"))
        {
            if (document.getElementById("al_person_details.slife.first_name_dropdown").value == "Select") {
                alert("203", "Second Life");
                return false;
            }
            
            if(typeof relationship_slife != "undefined" && relationship_slife != "" && relationship_slife != "H" && relationship_mlife != "W" && relationship_slife != "F" && relationship_slife != "M" && client_ylp_type_slife == "lo" )
            {
                alert("278",fnMsReturnRelationshipValue(relationship_slife),"second life")
                return false;
            }
            
            if(client_ylp_type_slife == "lo" && relationship_slife != "C")
            {
                alert("278",fnMsReturnRelationshipValue(relationship_slife),"second life")
                return false;
            }

        }else if (Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)" && (replicate_res != "" && replicate_res != null && replicate_res != "null" && replicate_res != "(null)"))
        {
            if (document.getElementById("al_person_details.slife.first_name_dropdown").value == "Select") {
                alert("203", "Second Life");
                return false;
            }
        }
        else if ((response_pro_req_AL == "" || response_pro_req_AL == null || response_pro_req_AL == "null" || response_pro_req_AL == "(null)") && (client_id_res_AL == "" || client_id_res_AL == null || client_id_res_AL == "null" || client_id_res_AL == "(null)") && (SQS_From_AL == "Yes"))
        {
            console.log("inside validate else if function");
            if (document.getElementById("al_person_details.mlife.first_name_dropdown").value == "Select") {
                alert("203", "Main Life");
                return false;
            }
        }

        else
        {

        if (!(isAlpanumericWithApostrophe("al_person_details.slife.first_name"))) {
            alert("201", "Second Life");
            return false;
        }
        
        if(!(checkSingleChar("al_person_details.slife.first_name")))
        {
            alert("201", "Second Life");
            return false;
        }
        
        if (!(CheckSpace("al_person_details.slife.first_name"))) {
            alert("201", "Second Life");
            return false;
        }

        if (!(BlankSpaceValidate("al_person_details.slife.first_name"))) {
            alert("202", "Second Life");
            return false;
        }
        }
        //Added By Rahul on 16.09.2015 for PRUterm
        if (((document.getElementById("al_person_details.mlife.anb").value < 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value < 16 && isILproduct)) && (document.getElementById("al_person_details.slife.relationship").value == "Spouse"))
        {
            if(Channel != "Banca" && Channel != "UOB")//changed by Purva / Pramoc C on 07th August 2017 for UOB
            {
                alert("268");
                return false;
            }
        }
        
        if (document.getElementById("al_person_details.slife.dob").value == "") {
            alert("204", "Second Life");
            return false;
        }

        if (!(document.getElementById("al_person_details.slife.gender_male").checked) && !(document.getElementById("al_person_details.slife.gender_female").checked)) {
            alert("206");
            return false;
        }

        if (!(document.getElementById("al_person_details.slife.smoke_status_yes").checked) && !(document.getElementById("al_person_details.slife.smoke_status_no").checked)) {
            alert("209", "Second Life");
            return false;
        }

        if (!(getOccupationValue("al_employee_details.slife.occupation"))) {
            alert("207", "Second Life");
            return false;
        }
        
        if (!(getNobValue("al_employee_details.slife.nature_of_business"))) {
            alert("208", "Second Life");
            return false;
        }
        else if($(".natureSearchSLifeText").val() == "Nature of Business")
        {
             $(".natureSearchSLifeText").val('');
             alert("208","Second Life");
             return false;
        }
        
        if(!(checkNob("al_employee_details.slife.nature_of_business")))
        {
            $(".natureSearchSLifeText").val('');
            alert("208", "Second Life");
            
            return false;
            
        }


        if(Channel == "Banca" || Channel == "UOB") //changed by Purva / Pramod C on 07th Aug 2017 for UOB
        {
            if(document.getElementById("al_person_details.slife.relationship").value=="Select Relationship")
            {
                alert("350");
                return false;
            }
            if((client_ylp_type_mlife=="you" && client_ylp_type_slife=="spouse")&& document.getElementById("al_person_details.slife.relationship").value!="Spouse")
            {
                alert("278",document.getElementById("al_person_details.slife.relationship").value,"second life")
                return false;
            }
            if((document.getElementById("al_person_details.mlife.anb").value > 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value > 16 && isILproduct))
            {
                if((getGender("mlife") == getGender("slife")) && document.getElementById("al_person_details.slife.relationship").value=="Spouse")
                {
                    alert("235");
                    return false;
                }
            }
            if(document.getElementById("al_person_details.slife.relationship").value=="Select Relationship")
            {
                alert("350");
                return false;
            }
            if((client_ylp_type_mlife=="you" && client_ylp_type_slife=="spouse")&& document.getElementById("al_person_details.slife.relationship").value!="Spouse")
            {
                alert("278",document.getElementById("al_person_details.slife.relationship").value,"second life")
                return false;
            }
            
            //Added for internal issue on date 23-09-2022 by Sachin
            if(document.getElementById("al_person_details.slife.anb_il_product").value!="")
            {
              document.getElementById("al_person_details.slife.anb").value=document.getElementById("al_person_details.slife.anb_il_product").value;
            }
            
            if((document.getElementById("al_person_details.slife.anb").value<=0 && !isILproduct) || (document.getElementById("al_person_details.slife.anb_il_product").value<=0 && isILproduct))
            {
                alert("713","Second Life");
                return false;
            }
        }else
        {
            if((document.getElementById("al_person_details.mlife.anb").value > 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value > 16  && isILproduct))
            {
                if((getGender("mlife") == getGender("slife")) && document.getElementById("al_person_details.slife.relationship").value=="Spouse")
                {
                    alert("235");
                    return false;
                }
            }
            if(document.getElementById("al_person_details.slife.relationship").value=="Select Relationship")
            {
                alert("350");
                return false;
            }
            if((client_ylp_type_mlife=="you" && client_ylp_type_slife=="spouse")&& document.getElementById("al_person_details.slife.relationship").value!="Spouse")
            {
                alert("278",document.getElementById("al_person_details.slife.relationship").value,"second life")
                return false;
            }
        }
        
        //Added for internal issue on date 23-09-2022 by Sachin
         if(document.getElementById("al_person_details.slife.anb_il_product").value!="")
            {
                document.getElementById("al_person_details.slife.anb").value=document.getElementById("al_person_details.slife.anb_il_product").value;
            }
        if((document.getElementById("al_person_details.slife.anb").value<=0 && !isILproduct) || (document.getElementById("al_person_details.slife.anb_il_product").value<=0 && isILproduct))
        {
            alert("713","Second Life");
            return false;
        }
    }

    if (getSlifePartiFlag() == "Yes") {
        //Replace Quote Changes
        if ((Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)") || (replicate_res != "" && replicate_res != null && replicate_res != "null" && replicate_res != "(null)"))
        {
            if (document.getElementById("al_person_details.tlife.first_name_dropdown").value == "Select") {
                alert("203", "Third Life");
                return false;
            }
            
            if(typeof relationship_tlife != "undefined" && relationship_tlife != "" && relationship_tlife != "H" && relationship_tlife != "W" && relationship_tlife != "F" && relationship_tlife != "M" && client_ylp_type_tlife == "lo" )
            {
                alert("278",fnMsReturnRelationshipValue(relationship_tlife),"third life")
                return false;
            }
            
            if(client_ylp_type_tlife == "lo" && relationship_tlife != "C")
            {
                alert("278",fnMsReturnRelationshipValue(relationship_tlife),"third life")
                return false;
            }
        }else if (Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)" && (replicate_res != "" && replicate_res != null && replicate_res != "null" && replicate_res != "(null)"))
        {
            if (document.getElementById("al_person_details.tlife.first_name_dropdown").value == "Select") {
                alert("203", "Third Life");
                return false;
            }
        }
        else if ((response_pro_req_AL == "" || response_pro_req_AL == null || response_pro_req_AL == "null" || response_pro_req_AL == "(null)") && (client_id_res_AL == "" || client_id_res_AL == null || client_id_res_AL == "null" || client_id_res_AL == "(null)") && (SQS_From_AL == "Yes"))
        {
            console.log("inside validate else if function");
            if (document.getElementById("al_person_details.mlife.first_name_dropdown").value == "Select") {
                alert("203", "Main Life");
                return false;
            }
        }

        else
        {
        if (!(isAlpanumericWithApostrophe("al_person_details.tlife.first_name"))) {
            alert("201", "Third Life");
            return false;
        }
        
        if(!(checkSingleChar("al_person_details.tlife.first_name")))
        {
            alert("201", "Third Life");
            return false;
        }

        if (!(CheckSpace("al_person_details.tlife.first_name"))) {
            alert("201", "Third Life");
            return false;
        }

        if (!(BlankSpaceValidate("al_person_details.tlife.first_name"))) {
            alert("202", "Third Life");
            return false;
        }
        }
        
        if (document.getElementById("al_person_details.tlife.dob").value == "") {
            alert("204", "Third Life");
            return false;
        }

        if (!(document.getElementById("al_person_details.tlife.gender_male").checked) && !(document.getElementById("al_person_details.tlife.gender_female").checked)) {
            alert("206");
            return false;
        }

        if (!(document.getElementById("al_person_details.tlife.smoke_status_yes").checked) && !(document.getElementById("al_person_details.tlife.smoke_status_no").checked)) {
            alert("209", "Third Life");
            return false;
        }

        if (!(getOccupationValue("al_employee_details.tlife.occupation"))) {
            alert("207", "Third Life");
            return false;
        }

        if (!(getNobValue("al_employee_details.tlife.nature_of_business"))) {
            alert("208", "Third Life");
            return false;
        }
        else if($(".natureSearchTLifeText").val() == "Nature of Business")
        {
            $(".natureSearchTLifeText").val('');
            alert("208","Third Life");
            return false;
        }
        
        if(!(checkNob("al_employee_details.tlife.nature_of_business")))
        {
            $(".natureSearchTLifeText").val('');
            alert("208", "Third Life");
            
            return false;
            
        }


        if(document.getElementById("al_person_details.slife.relationship").value == "Parent" && document.getElementById("al_person_details.tlife.relationship").value == "Parent")
        {
            if((getGender("slife") == "Male" && getGender("tlife") == "Male") || (getGender("slife") == "Female" && getGender("tlife") == "Female"))
            {
                alert("225");
                return false;
            }
        }
        
        if((document.getElementById("al_person_details.tlife.anb").value<=0 && !isILproduct) || (document.getElementById("al_person_details.tlife.anb_il_product").value<=0 && isILproduct))
        {
            alert("713","Third Life");
            return false;
        }
    }
    if(flag=="Ext_Module")
    {
       if(prod_choice_response!="(null)" && prod_choice_response!=null && prod_choice_response!="")
       {
           var obj_pr_res=JSON.parse(prod_choice_response);
           if(obj_pr_res!="(null)" && obj_pr_res!=null && obj_pr_res!="")// condition for production choice screen
           {
           if((obj_pr_res["al_sqs_details.product_name"] == "PRUlink one" || obj_pr_res["al_sqs_details.product_name"] == "PRUlife ready"
               || obj_pr_res["al_sqs_details.product_name"] == "PRUmy child" || obj_pr_res["al_sqs_details.product_name"] == "PRUmy kid"
               || obj_pr_res["al_sqs_details.product_name"] == "LifeLink" || obj_pr_res["al_sqs_details.product_name"] == "PRUlink million"
               || obj_pr_res["al_sqs_details.product_name"] == "PRUmy legacy" || obj_pr_res["al_sqs_details.product_name"] == "PRUheritage"
               || obj_pr_res["al_sqs_details.product_name"] == "PRUsignature" || obj_pr_res["al_sqs_details.product_name"] == "PRUwealth" || obj_pr_res["al_sqs_details.product_name"] == "PRUsignature infinite" 
               || obj_pr_res["al_sqs_details.product_name"] == "PRUmy gift" || obj_pr_res["al_sqs_details.product_name"] == "PRUsignature USD"
               || obj_pr_res["al_sqs_details.product_name"] == "PRUmillion cover" || obj_pr_res["al_sqs_details.product_name"] == "PRUmy treasure" || obj_pr_res["al_sqs_details.product_name"] == "PRUsignature income" || obj_pr_res["al_sqs_details.product_name"] == "PRULink Growth")
              && obj_pr_res["al_sqs_details.payment_backdate"]=="Yes")//Condition Added by ankita for PRUmy treasure product//Condition Added by ankita for PRUsignature income product

           {
               // In above if condition pru-signature product added by Pramod Chavan on 10022017 beacuase This product is not allow for backdate
               // In above if condition PRUwealth product added by Pramod Chavan on 15032017 beacuase This product is not allow for backdate
               
               alert("717",obj_pr_res["al_sqs_details.product_name"]);
               return false;
               
               //Note: please add product name in array "backDateProductList" declared in mysolution_product_choice.js if product is not applicable for backdate.
           }
           }
       }
    }
    //added by ankita on 14 april 2022 for modern family CR as per changes on PAMBNEWP-1597
    if(parseInt(document.getElementById("al_person_details.mlife.anb_il_product").value) < 17)
    {
        //change relationship_mlife to html id by ankita for internal issue
        if(document.getElementById("al_person_details.slife.relationship").value=="Brother" || document.getElementById("al_person_details.slife.relationship").value=="Sister" || document.getElementById("al_person_details.slife.relationship").value=="Nephew" || document.getElementById("al_person_details.slife.relationship").value=="Niece" || document.getElementById("al_person_details.slife.relationship").value=="Uncle" || document.getElementById("al_person_details.slife.relationship").value=="Aunty" || document.getElementById("al_person_details.slife.relationship").value=="Grandfather" || document.getElementById("al_person_details.slife.relationship").value=="Grandmother" || document.getElementById("al_person_details.slife.relationship").value=="Grandchildren" || document.getElementById("al_person_details.slife.relationship").value=="Cousin Brother" || document.getElementById("al_person_details.slife.relationship").value=="Cousin Sister" || document.getElementById("al_person_details.slife.relationship").value=="Step Father" || document.getElementById("al_person_details.slife.relationship").value=="Step Mother" || document.getElementById("al_person_details.slife.relationship").value=="Step Child" || document.getElementById("al_person_details.slife.relationship").value=="Father" || document.getElementById("al_person_details.slife.relationship").value=="Mother")
        {
            alert("861");
            return false;
        }
        
    }
    if(document.getElementById("al_person_details.slife.relationship").value === "Friend")//added by ankita for modern family CR
    {
        alert("278","Friend","main life")
        return false;
    }
    return true;
    // TODO
//    if ((Client_id == "" || Client_id == null || Client_id == "null" || Client_id == "(null)") && (replicate_res == "" || replicate_res == null || replicate_res == "null" || replicate_res == "(null)"))
//    {
//        alert("duplicate record");
//        return false;
//    }
    
                              
    
                                                   }
    


/*******************************************************
 Function Name: fnMsCheckExistingClient()
 Function Description: check if client allready exist or not in careerkit_person_details
 Parameters:
 Created By: Pramod Chavan
 Created On: 08-Sep-2017
 Modified By:
 Modified On:
 Modification Reason:
 *******************************************************/
function fnMsCheckExistingClient(firstName, dob, gender, smokeStatus, occupation) {
    var loadQuery = new DbUtil();
    loadQuery.query()
    .select()
    .column('*')
    .from()
    .table('careerkit_person_details AS t1,careerkit_employee_details AS t2')
    .where()
    .clause('t1.person_id','==','t2.person_id')
    .and()
    .clause('t1.is_deleted','=','No')
    .and()
    .clause('t1.agent_id', '=', ds_agentId)
    .and()
    .clause('t2.agent_id', '=', ds_agentId)
    .and()
    .clause('t1.first_name','=',firstName)
    .and()
    .clause('t1.dob','=',dob)
    .and()
    .clause('t1.gender','=',gender)
    .and()
    .clause('t1.smoke_status','=',smokeStatus)
    .and()
    .clause('t2.occupation','=',occupation)
    return loadQuery;
}


function setOptionsinOccandNob(persontype, textArray, valueArray,fieldtype)
{
	var selectElements = document.getElementById("al_employee_details." + persontype + "." +fieldtype);
    for (var j = 0; j < textArray.length; j++)
    {
        var optn = document.createElement("OPTION");
        optn.text = textArray[j];
        optn.value = valueArray[j];
        selectElements.appendChild(optn);
    }
    document.getElementById("al_employee_details.mlife.occupation_class").disabled = true;
    document.getElementById("al_employee_details.slife.occupation_class").disabled = true;
    document.getElementById("al_employee_details.tlife.occupation_class").disabled = true;
}

//modified by sayali to get the occupation values from the tsv.
function MsGetOccupation(textArray,valueArray)
{
    var occText=new Array();
    var occValue=new Array();
    
    for (var j = 0; j < textArray.length; j++)
    {
        var optn = document.createElement("OPTION");
         occText[j] = textArray[j];
         occValue[j] = valueArray[j];
       
    }
   
    document.getElementById("al_employee_details.mlife.occupation_class").disabled = true;
    document.getElementById("al_employee_details.slife.occupation_class").disabled = true;
    document.getElementById("al_employee_details.tlife.occupation_class").disabled = true;
    return  occText;
}



function MsGetNob(textArray,valueArray)
{
    var nobText={};
    var nobValue={};
    var nobList=new Array();
    for (var j = 0; j < textArray.length; j++)
    {
        nobList[j]=textArray[j];
        nobText[textArray[j]]=valueArray[j];
        nobValue[valueArray[j]]=textArray[j];
    }
    return {0:nobList, 1:nobText ,2:nobValue};
}



//Get Occupation Value
function getOccupationValue(id) {
    if (document.getElementById(id).value == "Select") {
        document.getElementById(id+"_class").value="";
        return false;
    }
    else if(document.getElementById(id).value == "")
    {
        return false;
    }
    return true;
}
//changed by sayali to check the nob value on 14-6-17
//Get Nob Value
function getNobValue(id)
{
        if(document.getElementById(id).value=="Select"|| document.getElementById(id).value=="")
        {
            return false;
        }
        else
        {
            return true;
        }
}


function checkNob(id)
{
    var flag=0;
    var CheckNob= MsGetNob(load_tsv_data["Nob_text"],load_tsv_data["Nob_value"]);
    var str=CheckNob[0];
    for(var j = 0; j < str.length; j++)
    {
           if(str[j]==document.getElementById(id).value)
           {
               flag = 1;
           }
    }
    if(flag == 0)
    {
        
        return false;
    }
    return true;
}

//Function for additional white spaces and empty string
function BlankSpaceValidate(id)
{
    var flag = 0;
    var strText = document.getElementById(id).value;

    if (strText == "")
    {
        return false;
    }
    return true;
}

function CheckSpace(id)
{
    var flag = 0;
    var strText = document.getElementById(id).value;

    if (strText != "") 
    {
        var strArr = strText.split(" ");

        for (var i = 0; i < strArr.length; i++)
        {
            if (strArr[i].length == 0)
            {
                flag = 1;
            }
        }
    }

    if (flag == 1) 
    {
        return false;
    }
    return true;
}

//Hide and showon seclife selected
function Active_life()
{
    if (document.getElementById("al_sqs_details.sec_parti_flg_yes").checked)
    {
        document.getElementById("collapseTwo").disabled = true;
    }
    else
    {
        document.getElementById("collapseTwo").disabled = false;
    }
}

//Date Picker dialogue from native
function fnMsPersonalopenDatePickerDialog(elId,persontype)
{
    if($(escape_jq("al_person_details.mlife.insu_type_header")+" option:selected").html() == "Proposal Purpose" || ($(escape_jq("al_person_details.mlife.insu_type_header")+" option:selected").html() == "Business Purpose" && $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Insurance Type"))
    {
        return false;
    }
     ocArr = MsGetOccupation(load_tsv_data["Occupation_text"],load_tsv_data["Occupation_value"]);
    console.log("Calling from My Solutions"+persontype);
    checkPRUwithyou="";
    var pagedata =
    {
        "element_id": elId,
        "element_value":$(escape_jq(elId)).val()
    }
    var OldDateOfBirth = document.getElementById(elId).value;
    var oldAnb=document.getElementById("al_person_details.mlife.anb_il_product").value;
    console.log("@oldAnb----"+oldAnb);
    var NewDateofBirth = "";
    console.log("old DOB "+OldDateOfBirth);
    console.log("new DOB "+NewDateofBirth);
    var day_res="";
    js_call_native_func("OpenDatePicker", pagedata, function(response)
    {
                        
                        var obj = JSON.parse(response);
                        console.log("response==="+response);
                        if (obj["date"] != "")
                        {
                        console.log("obj['date']=="+obj["date"]);
                        console.log("obj['element_id']=="+obj["element_id"]);
                        var elementName = obj["element_id"];

                        if(document.getElementById(elementName).value != "")
                        {
                        if(obj["date"] == document.getElementById(elementName).value)
                        {
                        console.log("@Obtained Age"+document.getElementById(elementName).value);
                            document.getElementById(elementName).value = obj["date"];
                        
                        
                        // ClearData();//Added for check defect 8584 on date 12-12-2019.
                        }else
                        {
                            document.getElementById(elementName).value = obj["date"];
                        
//                        if(!((elementName == "al_person_details.slife.dob") || (elementName == "al_person_details.tlife.dob") || (elementName == "al_person_details.mlife.expected_delivery_dt")))
//                        {
                            //ResetFieldsonAnbChange("Checkdata");
                            ClearData();
                       // }
                        }
                        }else
                        {
                        document.getElementById(elementName).value = obj["date"];
                        }
                        day_res = document.getElementById(elementName).value.split("/");
                        console.log("@day_res"+day_res);
                        
                        if((ANB_json[0]["anb_type"]=="IL_Daily") && (ANB_json[0]["anb_type"]!="" && ANB_json[0]["anb_type"]!='undefined' && ANB_json[0]["anb_type"]!=undefined && ANB_json[0]["anb_type"]!="{}"))
                        {
                        fnMsCalculateANBforILproducts(persontype);// calculate IL product ANB. changes made by pramod chavan: 09122017
                        }else if(ANB_json[0]["anb_type"]=="IL_Monthly" && (ANB_json[0]["anb_type"]!="" && ANB_json[0]["anb_type"]!='undefined' && ANB_json[0]["anb_type"]!=undefined && ANB_json[0]["anb_type"]!="{}"))
                        {
                        
                        fnMsCalculateANBforIL_monthlyproducts(persontype) ;//TODO 1-06-2018
                        }
                        CheckDate(elementName, obj["date"], day_res[0], day_res[1], day_res[2],persontype,"change","dob"); //commited for OS to IL product Conversion date 19-06-2019
                        var insurence_type = $(escape_jq("al_person_details.mlife.insu_type")).val()
                        if((insurence_type == "keyman" || insurence_type == "employee" || insurence_type == "partnership" || insurence_type == "Business Loan Insurance (for Company/LLP)" || insurence_type == "Business Loan Insurance (for Sole Proprietorship/Partnership)")){
                        var arrOccupation = _.filter(ocArr,
                                                     function(occ){
                                                     return (occ!= "Child"&& occ!= "Housewife"&& occ!="Pensioner"&& occ!="Retiree"&& occ!="Student"&& occ!="Student Pilot"&& occ!="Unemployed");
                                                     });
                        console.log("arrOccupation----"+arrOccupation)
                        seachableDropDownMLifeOccupation(arrOccupation,insurence_type);
                        }
                        if((insurence_type == "keyman" || insurence_type == "employee" || insurence_type == "partnership" || insurence_type == "Business Loan Insurance (for Company/LLP)" || insurence_type == "Business Loan Insurance (for Sole Proprietorship/Partnership)") && childFlag == true ){
                            $(".collapseTwo").attr("id", "");
                            $(".collapseThree").attr("id", "");
                            $(".second_life,.third_life").addClass("disabled_panel");
                            $(".second_life,.third_life").removeClass("normal_panel").removeClass("active_panel");
                            $(escape_jq("al_sqs_details.sec_parti_flag_yes")).prop('checked',false);
                            $(escape_jq("al_sqs_details.sec_parti_flag_no")).prop('checked',true);
                            $("input[name='third_life'][value='Yes']").prop('checked',false);
                            $("input[name='third_life'][value='No']").prop('checked',true);
                            $("input[name='second_life'][value='Yes']").attr("disabled", true)
                            $("input[name='second_life'][value='No']").attr("disabled", true)
                            $(escape_jq("al_person_details.pre_natal_child_flg")).attr("disabled", true)
                            $(escape_jq("al_person_details.pre_natal_child_flg")).attr("checked", false)
                            SetValuesnull();
//                            validate_pre_natal();
                            document.getElementById(elId).value = OldDateOfBirth;
                        document.getElementById("al_person_details.mlife.anb_il_product").value=oldAnb;//added for defect 9434 on date 1-06-2020.
                       
                            return false;
                        
                        }
                   NewDateofBirth = document.getElementById(elementName).value;
                   console.log("after setting old DOB "+OldDateOfBirth);
                   console.log("after setting new DOB "+NewDateofBirth);
                   if(OldDateOfBirth == NewDateofBirth)
                   {
                       var DOBChangedFlag = "No";
                   }
                   else
                   {
                      var DOBChangedFlag = "Yes";
                   }
                   if(elementName == "al_person_details.mlife.dob")
                   {
                      js_set_var("mlife_DOB_changed",DOBChangedFlag,function(response)
                      {
                          console.log("after setting mlife DOB to native");
                      });
                   }
                    if(elementName == "al_person_details.slife.dob")
                    {
                    js_set_var("slife_DOB_changed",DOBChangedFlag,function(response)
                       {
                       console.log("after setting mlife DOB to native");
                       });
                    }
                    if(elementName == "al_person_details.tlife.dob")
                    {
                      js_set_var("tlife_DOB_changed",DOBChangedFlag,function(response)
                       {
                       console.log("after setting mlife DOB to native");
                       });
                    }


    }
                      
                        var mlifeAge = document.getElementById("al_person_details.mlife.anb_il_product").value;
                        var slifeAge = document.getElementById("al_person_details.slife.anb_il_product").value;
                        var tlifeAge = document.getElementById("al_person_details.tlife.anb_il_product").value;
                        
                 
                        
                        if(mainLifeFlag == false)
                        fnLifeChangesAnb('mlife');// sunday cr
                        fnLifeChangesAnb('slife');
                        fnLifeChangesAnb('tlife');
                        console.log("element name"+elementName);
                        if(document.getElementById("al_person_details.pre_natal_child_flg").checked && (elementName != "al_person_details.slife.dob" && elementName != "al_person_details.tlife.dob"))//Added for defect 8890.
                        {
                        mainLifeFlag = true;
                        console.log("CreatedinceptiondateDate"+CreatedinceptiondateDate);
                        var incepDate=CreatedinceptiondateDate.split("/");
                        
                        var temp_PrenatalANB =fnMsCalculateANBForPrenatal(parseInt(day_res[0]), parseInt(day_res[1]), parseInt(day_res[2]),parseInt(incepDate[0]), parseInt(incepDate[1]),  parseInt(incepDate[2]));//Added for defect 8890
                        console.log("@temp_PrenatalANB"+temp_PrenatalANB);
                        
                        document.getElementById("al_person_details.mlife.anb_il_product").value =temp_PrenatalANB;
                        
                        
                        }else{
                        mainLifeFlag = false;
                        }
                        
                        
                        
                        console.log("@prev mainlife"+obj_mlife["al_person_details.mlife.anb_il_product"]+"__"+"@prev slife"+obj_slife["al_person_details.slife.anb_il_product"]+"--"+"@prev tlife"+obj_tlife["al_person_details.tlife.anb_il_product"]);
                        
                        console.log("@Changed mainlife Age"+document.getElementById("al_person_details.mlife.anb_il_product").value+"----"+"@changed slife Age"+document.getElementById("al_person_details.slife.anb_il_product").value+"----"+"@changed tlife Age"+document.getElementById("al_person_details.tlife.anb_il_product").value)
                        //added by ankita for modern family CR on 11 april 2022
                        //changed condition by ankita on 28 april 2022 for defect 238
                        //change by ankita on 8 dec change for prod defect internal issue
                        if(persontype=="mlife")
                        {
                         fnGetRelationshipList('al_person_details.mlife.anb_il_product','al_person_details.slife.anb_il_product','','al_person_details.slife.relationship','al_person_details.slife.gender_male','al_person_details.slife.gender_female','mySolutions');
                        }
                      
                        if((obj_mlife["al_person_details.mlife.anb_il_product"]!=undefined && obj_mlife["al_person_details.mlife.anb_il_product"]!='undefined' && obj_mlife["al_person_details.mlife.anb_il_product"]!=null && obj_mlife["al_person_details.mlife.anb_il_product"]!='null' && obj_mlife["al_person_details.mlife.anb_il_product"]!="") && persontype=="mlife" && DOBChangedFlag!="Yes"){
                        
                        if(document.getElementById("al_person_details.mlife.anb_il_product").value!=obj_mlife["al_person_details.mlife.anb_il_product"]){
                        
                         ClearData();
                        }
                        
                        
                        }else if((obj_slife["al_person_details.slife.anb_il_product"]!=undefined && obj_slife["al_person_details.slife.anb_il_product"]!='undefined' && obj_slife["al_person_details.slife.anb_il_product"]!=null && obj_slife["al_person_details.slife.anb_il_product"]!='null' && obj_slife["al_person_details.slife.anb_il_product"]!="")  && persontype=="slife" && DOBChangedFlag!="Yes") {
                        
                        
                        if(document.getElementById("al_person_details.slife.anb_il_product").value!=obj_slife["al_person_details.slife.anb_il_product"]){
                        
                        ClearData();
                        }
                        
                        
                        
                        }
                        else if((obj_tlife["al_person_details.tlife.anb_il_product"]!=undefined && obj_tlife["al_person_details.tlife.anb_il_product"]!='undefined' && obj_tlife["al_person_details.tlife.anb_il_product"]!=null && obj_tlife["al_person_details.tlife.anb_il_product"]!='null' && obj_tlife["al_person_details.tlife.anb_il_product"]!="")  && persontype=="mlife" && DOBChangedFlag!="Yes") {
                        
                        
                        if(document.getElementById("al_person_details.tlife.anb_il_product").value!=obj_tlife["al_person_details.tlife.anb_il_product"]){
                        
                        ClearData();
                        }
                        
                        
                        
                        }
                        
                        
                        
                        });
}


function getOccuandclass(occ_id, nob_id, occ_classid,nob_idtext,persontype,changeflg)
{
    console.log("Inside getOccuandclass occ_id-> "+occ_id+" nob_id "+nob_id+" occ_classid "+occ_classid+" nob_idtext "+nob_idtext+" persontype "+persontype+" changeflg "+changeflg)
    if (master_matrix_tsv_data != "" && master_matrix_tsv_data != null && master_matrix_tsv_data != "null" && master_matrix_tsv_data != "(null)" && master_matrix_tsv_data.length > 0)
    {
       var load_matrix_tsv_data = JSON.parse(master_matrix_tsv_data);

    //Changed by Paromita on 14 Aug 2017 for new occupation List
    if (document.getElementById(occ_id).value == "Housewife")
    {
        fnMsSolSelectElement("Housewife", nob_id);
        $("."+nob_idtext).val("Housewife");
        $("."+nob_idtext).attr("disabled","true");
        document.getElementById(nob_id).disabled = true;
    }
    else if (document.getElementById(occ_id).value == "Student")
    {
        fnMsSolSelectElement("Student", nob_id);
        $("."+nob_idtext).val("Student");
        $("."+nob_idtext).attr("disabled","true");
        document.getElementById(nob_id).disabled = true;
    }
    else if (document.getElementById(occ_id).value == "Child")
    {
        fnMsSolSelectElement("Child", nob_id);
        $("."+nob_idtext).val("Child");
        $("."+nob_idtext).attr("disabled","true");
        document.getElementById(nob_id).disabled = true;
    }
    else if (document.getElementById(occ_id).value == "Retiree")
    {
        fnMsSolSelectElement("Retiree", nob_id);
        $("."+nob_idtext).val("Retiree");
        $("."+nob_idtext).attr("disabled","true");
        document.getElementById(nob_id).disabled = true;
    }
    else if (document.getElementById(occ_id).value == "Pensioner")
    {
        fnMsSolSelectElement("Pensioner", nob_id);
        $("."+nob_idtext).val("Pensioner");
        $("."+nob_idtext).attr("disabled","true");
        document.getElementById(nob_id).disabled = true;
    }
    else if (document.getElementById(occ_id).value == "Unemployed")
    {
        fnMsSolSelectElement("Unemployed", nob_id);
        $("."+nob_idtext).val("Unemployed");
        $("."+nob_idtext).attr("disabled","true");
        document.getElementById(nob_id).disabled = true;
    }
    else if (document.getElementById(occ_id).value == "Student Pilot-2")
    {
        fnMsSolSelectElement("Student", nob_id);
        $("."+nob_idtext).val("Student");
        $("."+nob_idtext).attr("disabled","true");
        document.getElementById(nob_id).disabled = true;
    }
    else if (document.getElementById(occ_id).value == "Pilot (Student)-2")
    {
        fnMsSolSelectElement("Student", nob_id);
        $("."+nob_idtext).val("Student");
        $("."+nob_idtext).attr("disabled","true");
        document.getElementById(nob_id).disabled = true;
    }
    else
    {
        //SelectElement("Select", nob_id);
        //$("."+nob_idtext).val("");
        $("."+nob_idtext).removeAttr("disabled");
        document.getElementById(nob_id).disabled = false;
    }

   /* var res_occ = document.getElementById(occ_id).value.split("-");
    document.getElementById(occ_classid).value = res_occ[1];*/
                               
    if (document.getElementById(occ_id).value == "Select")
    {
        document.getElementById(occ_classid).value = null;
        document.getElementById(occ_classid).disabled = true;
    }
    
    if(document.getElementById(occ_id).value != "Select" &&  document.getElementById(occ_id).value != "" &&  document.getElementById(nob_id).value != "" )
    {
        var key = document.getElementById(occ_id).value +"_"+ document.getElementById(nob_id).value;
        console.log("getOccuandclass key:"+key)
        document.getElementById(occ_classid).value = load_matrix_tsv_data["matrix1"][key];
        document.getElementById(occ_classid).disabled = true;
        var isDataClearForILProduct=true;
        if(prod_choice_response!="(null)" && prod_choice_response!=null && prod_choice_response!="")
        {
            var productObjResponse=JSON.parse(prod_choice_response);
            if(productObjResponse!="(null)" && productObjResponse!=null && productObjResponse!="")
            {
                if((ilProductList.indexOf(productObjResponse["al_sqs_details.product_name"])>=0)/*productObjResponse["al_sqs_details.product_name"] == "PRUwith you"*/){
                    //Below code merge from jan hot fix for DEF-5397 changes made by pramod chavan.
                    if(((obj_mlife["al_person_details.mlife.anb_il_product"]<= 15 && obj_mlife["al_person_details.mlife.anb"]>=16) || (obj_mlife["al_person_details.mlife.anb_il_product"]>= 16 && obj_mlife["al_person_details.mlife.anb"]<=15)) && (obj_mlife["pamb_channel"]=="Agency" || obj_mlife["pamb_channel"]=="FA" )){ // Piyush (03/12/2018): Changes has been done for New channel
                        // DEF-4816
                    isDataClearForILProduct=false;// product choice response object not set to null if product is IL product
                    }else if(((obj_mlife["al_person_details.mlife.anb_il_product"]<= 16 && obj_mlife["al_person_details.mlife.anb"]>=17) || (obj_mlife["al_person_details.mlife.anb_il_product"]>= 17 && obj_mlife["al_person_details.mlife.anb"]<=16)) && obj_mlife["pamb_channel"]!="Agency" && obj_mlife["pamb_channel"]!="FA"){ // Piyush (03/12/2018): Changes has been done for New channel
                        // DEF-4816
                        isDataClearForILProduct=false;// product choice response object not set to null if product is IL product
                    }
		// isDataClearForILProduct=false;// product choice response object not set to null if product is IL product// old code
                }
            }
        }
    
        if(obj_mlife["al_employee_details.mlife.occupation_class"] != undefined)
        {
            if(obj_mlife["al_employee_details.mlife.occupation_class"] != document.getElementById("al_employee_details.mlife.occupation_class").value && isDataClearForILProduct)
            {
                
                ClearData();
            }
        }
    }
    if(Client_id!="" && Client_id!="null" && Client_id!=null && Client_id!="(null)")
    {
        onchangeDeleteExistingQuotation(Client_id,occ_id.split(".")[1],"occupation");
    }
    else
    {
        onchangeDeleteExistingQuotation(client_id_fresh,occ_id.split(".")[1],"occupation");
    }
    }
}

function ClearDataonChange(persontype,comefrom,changeflg)
{
    var obj;
    if(persontype == "mlife")
    {
        obj = obj_mlife;
    }
    else if(persontype == "slife")
    {
        obj = obj_slife;
    }
    else if(persontype == "tlife")
    {
        obj = obj_tlife;
    }

    if(obj["al_person_details."+persontype+".gender"] != undefined)
    {
            if(obj["al_person_details."+persontype+".gender"] != getGender(persontype))
            {
                ClearData();
            }
    }
    
    if(obj["al_person_details."+persontype+".smoke_status"] != undefined)
    {
        if(obj["al_person_details."+persontype+".smoke_status"] != getSmokeStats(persontype))
        {
            ClearData();
        }
    }
    
    //added changeflg!="smoker" by ankita for not to refresh or not to change current relationship if smoking status is changed.
    //modified condition by ankita for PAMBNEWP-14733 on 27 march 2023
    //Pradnya: removed changeflg!="smoker" from below if on 22Feb24 for quotaton deletion alert on changing smoking status- PRUW00232193
    if(comefrom=="change"  && !(persontype === "tlife" && changeflg==="gender"))
    {
        //add here 12345
        //added by ankita on 25 march 2022 for modern family CR
        
        if(parseInt(document.getElementById("al_person_details.mlife.anb_il_product").value) > 16 && changeflg!="smoker")//Pradnya: added changeflg!="smoker" on 22Feb24 for quotaton deletion alert on changing smoking status- PRUW00232193
        {
            console.log("cleardataonchange fnGetRelationshipList");
        fnGetRelationshipList('al_person_details.mlife.anb_il_product','al_person_details.slife.anb_il_product','','al_person_details.slife.relationship','al_person_details.slife.gender_male','al_person_details.slife.gender_female','mySolutions');
        }
        
        /*if(document.getElementById("al_person_details.mlife.anb_il_product").value < 16)
        {
            console.log("Inside cleardataonchange");
            var arrMatrix=new Array();
            var arrmatrix1Options = document.getElementById("al_person_details.slife.relationship");
         if(document.getElementById("al_person_details.slife.gender_male").checked)
          {
         arrmatrix1Options.options.length=0;
              arrMatrix=arrmatrixMale;
              //var arrmatrix1=["Parent","Legal Guardian","Grandfather","Cousin Brother","Uncle","Step Father","Brother","Step Brother"];
          }
         if(document.getElementById("al_person_details.slife.gender_female").checked)
         {
         arrmatrix1Options.options.length=0;
             arrMatrix=arrmatrixFemale;
         //var arrmatrix1=["Parent","Legal Guardian","Grandmother","Cousin Sister","Aunty","Step Mother","Sister","Step Brother"];
         }
             
         for(var i = 0; i < arrMatrix.length; i++)
         {
             var optn=document.createElement("option");
             optn.value=arrMatrix[i];
             optn.text=arrMatrix[i];
             arrmatrix1Options.appendChild(optn);
         }
        
        
        
        
            if(client_ylp_type_mlife=="lo" || (Client_id=="" || Client_id==null || Client_id=="null"))
                       {
            document.getElementById("al_person_details.slife.relationship").disabled = false;
                //document.getElementById("al_person_details.slife.relationship").options[2].selected=true;
                       }
            
        
        }*/
        if(Client_id!="" && Client_id!="null" && Client_id!=null && Client_id!="(null)")
        {
            onchangeDeleteExistingQuotation(Client_id,persontype,changeflg);
        }
        else
        {
             onchangeDeleteExistingQuotation(client_id_fresh,persontype,changeflg);
        }
    }
}

function SetValuesnull(callfrom)//change by ankita on 8 dec change for prod defect internal issue
{
    var getIlMlifeANB=document.getElementById("al_person_details.mlife.anb_il_product").value; // Added for IL ANB changes. "OR" condition added in below if condition variable name="getIlMlifeANB"
    if(getMlifePartiFlag() == "No")
	{
        //if(document.getElementById("al_person_details.mlife.anb").value < 17)
        //Added By Rahul Patil on 01.10.2015 for PRUterm
        if(Channel != "Banca" && Channel != "UOB") //changed by Purva / Pramod C on 07th Aug 2017 for UOB
        {
            if(document.getElementById("al_person_details.mlife.anb").value < 16 || getIlMlifeANB < 16)//Rahul For PRUterm
            {
                if(!(document.getElementById("al_person_details.mlife.parent_consent_yes").checked))
                {
                    document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = true;
                    document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = true;
                }
            }else
            {
                document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = false;
                document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = false;
            }
        }
        else
        {
            if(document.getElementById("al_person_details.mlife.anb").value < 17 || getIlMlifeANB < 17)//Rahul For PRUterm
            {
                if(!(document.getElementById("al_person_details.mlife.parent_consent_yes").checked))
                {
                    document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = true;
                    document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = true;
                }
            }else
            {
                document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = false;
                document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = false;
            }
        }
        
        
		document.getElementById("al_person_details.slife.first_name").value = "";
        document.getElementById("al_person_details.slife.first_name_dropdown").value = "Select";
        relationship_slife = "";//Pratik on 18/08/15
        fnMsDisableDropdownChange("");
        if((Client_id == "" || Client_id == null || Client_id == "null" || Client_id == "(null)") && (replicate_res == "" || replicate_res == null || replicate_res == "null" || replicate_res == "(null)"))
        {
            if((document.getElementById("al_person_details.mlife.anb").value > 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value > 16 && isILproduct))
            {
                if((document.getElementById("al_person_details.mlife.anb").value==17 || document.getElementById("al_person_details.mlife.anb").value==18) && !isILproduct)
                {
                    if(client_ylp_type_mlife=="lo" && (Client_id!="" && Client_id!=null && Client_id!="null"))
                    {
                        document.getElementById("al_person_details.slife.relationship").value = "Parent";
                        document.getElementById("al_person_details.slife.relationship").disabled = false; // changes made by pramod chavan "True" to "False" for prodcution defect---PRUW00037533
                        console.log("5 disable");
                    }

                }else if((document.getElementById("al_person_details.mlife.anb_il_product").value==17 || document.getElementById("al_person_details.mlife.anb_il_product").value==18) && isILproduct)
                {
                    if(client_ylp_type_mlife=="lo" && (Client_id!="" && Client_id!=null && Client_id!="null"))
                    {
                        document.getElementById("al_person_details.slife.relationship").value = "Parent";
                        document.getElementById("al_person_details.slife.relationship").disabled = false; // changes made by pramod chavan "True" to "False" for prodcution defect---PRUW00037533
                        console.log("5 disable");
                    }
                    
                }
                else
                {
                    //commented by ankita on 10 april 2022 for modern family CR
                    //document.getElementById("al_person_details.slife.relationship").value = "Spouse";
                    //document.getElementById("al_person_details.slife.relationship").disabled = true;
                    console.log("6 disable");
                }
            }else{
                document.getElementById("al_person_details.slife.relationship").value = "Parent";  
                document.getElementById("al_person_details.slife.relationship").disabled = false;
                
                if(document.getElementById("al_sqs_details.third_parti_flg_yes").checked)
                {
                    document.getElementById("al_person_details.tlife.relationship").value = "Parent";
                    document.getElementById("al_person_details.tlife.relationship").disabled = false;
                }

            }
        }else if((Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)") || (replicate_res != "" && replicate_res != null && replicate_res != "null" && replicate_res != "(null)"))
        {
            if(typeof pre_natal_handle == "undefined" || pre_natal_handle=="")
            {
                
                pre_natal_handle = "No";
                if((document.getElementById("al_person_details.mlife.anb").value <=16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <=16 && isILproduct))
                {
                    client_ylp_type_mlife = "lo";
                }
//                else if(document.getElementById("al_person_details.mlife.anb").value <=16 && Channel == "Banca")
//                {
//                    client_ylp_type_mlife = "lo";
//                }
            }
            
            if(((document.getElementById("al_person_details.mlife.anb").value > 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value > 16 && isILproduct)) && (typeof relationship_mlife == "undefined" || relationship_mlife == "" || relationship_mlife == "H" || relationship_mlife == "W" || relationship_mlife == "F" || relationship_mlife == "M" ))
            {
                if((document.getElementById("al_person_details.mlife.anb").value==17 || document.getElementById("al_person_details.mlife.anb").value==18) && !isILproduct)
                {
                    if(client_ylp_type_mlife=="lo" && (Client_id!="" && Client_id!=null && Client_id!="null"))
                    {
                        document.getElementById("al_person_details.slife.relationship").value = "Parent";
                        document.getElementById("al_person_details.slife.relationship").disabled = false; // changes made by pramod chavan "True" to "False" for prodcution defect---PRUW00037533
                        console.log("7 disable");
                    }

                }else if((document.getElementById("al_person_details.mlife.anb_il_product").value==17 || document.getElementById("al_person_details.mlife.anb_il_product").value==18) && isILproduct)
                {
                    if(client_ylp_type_mlife=="lo" && (Client_id!="" && Client_id!=null && Client_id!="null"))
                    {
                        document.getElementById("al_person_details.slife.relationship").value = "Parent";
                        document.getElementById("al_person_details.slife.relationship").disabled = false; // changes made by pramod chavan "True" to "False" for prodcution defect---PRUW00037533
                        console.log("7 disable");
                    }
                    
                }
                else
                {
                    document.getElementById("al_person_details.slife.relationship").value = "Spouse";
                    ////commented by ankita for modern family as relationship was getting disable for you spouse scenario
                    document.getElementById("al_person_details.slife.relationship").disabled = true;
                    console.log("8 disable");
                }
            }else if(((pre_natal_handle == "No" && ((document.getElementById("al_person_details.mlife.anb").value <=16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <=16 && isILproduct))) || pre_natal_handle == "Yes") && (relationship_mlife == "C") && client_ylp_type_mlife == "lo"){
                if(relationship_slife == "F" || relationship_slife == "M" || relationship_slife == "" || typeof relationship_slife == "undefined")
                {
                document.getElementById("al_person_details.slife.relationship").value = "Parent";
                document.getElementById("al_person_details.slife.relationship").disabled = false;
                    
                    if(document.getElementById("al_sqs_details.third_parti_flg_yes").checked)
                    {
                        document.getElementById("al_person_details.tlife.relationship").value = "Parent";
                        document.getElementById("al_person_details.tlife.relationship").disabled = false;
                    }

                }else
                {
                    console.log("relationship_mlife in validations :: "+relationship_mlife+" --- "+relationship_slife);
                    document.getElementById("al_person_details.slife.relationship").value = "Select Relationship";
                    //commented by ankita on 8 april 2022
                    //document.getElementById("al_person_details.slife.relationship").disabled = true;
                    console.log("9 disable");
                }
            }
            else
            {
                console.log("relationship_mlife in validations other :: "+relationship_mlife+" --- "+relationship_slife);
                document.getElementById("al_person_details.slife.relationship").value = "Select Relationship";
                //commented by ankita for modern family on 8 april 2022
                //document.getElementById("al_person_details.slife.relationship").disabled = true;
                console.log("10 disable");
            }
        }
		document.getElementById("al_person_details.slife.dob").value = "";
		document.getElementById("al_person_details.slife.anb").value = "";
		document.getElementById("al_person_details.slife.gender_male").checked = true;
		document.getElementById("al_person_details.slife.gender_female").checked = false;
		document.getElementById("al_person_details.slife.smoke_status_yes").checked = false;
		document.getElementById("al_person_details.slife.smoke_status_no").checked = true;
		document.getElementById("al_employee_details.slife.occupation").value = "Select";
         $(".occupationSearchSLifeText").val("");//Prashant 23.12.2016
	    document.getElementById("al_employee_details.slife.occupation_class").value = "";
	    document.getElementById("al_employee_details.slife.nature_of_business").value = "Select";
        $(".natureSearchSLifeText").val("");//Prashant 23/12/2016
	    document.getElementById("al_sqs_details.sec_parti_flag_no").checked = true;
	    document.getElementById("al_sqs_details.sec_parti_flag_yes").checked = false;

        if((document.getElementById("al_person_details.mlife.anb").value > 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value > 16 && isILproduct))
        {
                var isChecked = jQuery("input[name=third_life]:checked").val();
                if(!isChecked)
                {
                }else
                {
                    if(isChecked == "Yes")
                    {
                        $("input[name='third_life'][value='Yes']").prop('checked',false);
                        $("input[name='third_life'][value='No']").prop('checked',true);
                    }
                }
       }
        
            $('.mlifefnamedrop,.slifefnamedrop,.tlifefnamedrop').children().each(function(){
                 $(this).prop('disabled',false)
                                                                                 });
    }
    
    if((getSlifePartiFlag() == "No" && getMlifePartiFlag() == "No") || getSlifePartiFlag() == "No")
	{
        //added By Rahul Patil obn 01.10.2015 for PRUterm
        if(Channel != "Banca" && Channel != "UOB") //changed by Purva / Pramod C on 07th Aug 2017 for UOB
        {
        if((document.getElementById("al_person_details.mlife.anb").value < 16 && !isILproduct) || (getIlMlifeANB < 16 && isILproduct))
        {
            document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = true;
            document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = true;
        }else
        {
            document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = false;
            document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = false;
        }
        }
        else
        {
            if((document.getElementById("al_person_details.mlife.anb").value < 17 && !isILproduct) || (getIlMlifeANB < 17 && isILproduct))
            {
                document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = true;
                document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = true;
            }else
            {
                document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = false;
                document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = false;
            }
        }
        if((document.getElementById("al_person_details.mlife.anb").value == 17 || document.getElementById("al_person_details.mlife.anb").value == 18) &&  !isILproduct)
        {
            if(client_ylp_type_mlife=="lo" && (Client_id!="" && Client_id!=null && Client_id!="null") && relationship_mlife=="C")
            {
                document.getElementById("al_person_details.slife.relationship").value = "Parent";
                document.getElementById("al_person_details.slife.relationship").disabled = false; // changes made by pramod chavan "True" to "False" for prodcution defect---PRUW00037533
                console.log("11 disable");
                document.getElementById("third_life_party_flag").style.display="block";
                fnMsDisableDropdownChange("");
            }
            //else is commented by Paro  for def 8344 (and else was added for automation purpose)
//            else
//            {
//                console.log("Spouse not able select-->");
//                document.getElementById("al_person_details.slife.relationship").value = "Select Relationship";
//                document.getElementById("al_person_details.slife.relationship").disabled = false;
//            }
        }else if((document.getElementById("al_person_details.mlife.anb_il_product").value == 17 || document.getElementById("al_person_details.mlife.anb_il_product").value == 18) &&  isILproduct)
        {
            if(client_ylp_type_mlife=="lo" && (Client_id!="" && Client_id!=null && Client_id!="null") && relationship_mlife=="C")
            {
                document.getElementById("al_person_details.slife.relationship").value = "Parent";
                document.getElementById("al_person_details.slife.relationship").disabled = false; // changes made by pramod chavan "True" to "False" for prodcution defect---PRUW00037533
                console.log("11 disable");
                document.getElementById("third_life_party_flag").style.display="block";
                fnMsDisableDropdownChange("");
            }
            //else is commented by Paro  for def 8344 (and else was added for automation purpose)
//            else
//            {
//                 console.log("Spouse not able select-->11");
//                document.getElementById("al_person_details.slife.relationship").value = "Select Relationship";
//                document.getElementById("al_person_details.slife.relationship").disabled = false;
//            }
        }
       // Below function commented for DEF-5109
            //ClearData(); //added for production defect on 16-03-2016 by sachin
			document.getElementById("al_person_details.tlife.first_name").value = "";
        document.getElementById("al_person_details.tlife.first_name_dropdown").value = "Select";
			document.getElementById("al_person_details.tlife.relationship").value = "Parent";
			document.getElementById("al_person_details.tlife.dob").value = "";
			document.getElementById("al_person_details.tlife.anb").value = "";
			document.getElementById("al_person_details.tlife.gender_male").checked = true;
			document.getElementById("al_person_details.tlife.gender_female").checked = false;
			document.getElementById("al_person_details.tlife.smoke_status_yes").checked = false;
			document.getElementById("al_person_details.tlife.smoke_status_no").checked = true;
           document.getElementById("al_employee_details.tlife.nature_of_business").value = "Select";
           $(".natureSearchTLifeText").val("");//Prashant 23/12/2016
			document.getElementById("al_employee_details.tlife.occupation").value = "Select";
            $(".occupationSearchTLifeText").val("");//Prashant 23.12.2016
			document.getElementById("al_employee_details.tlife.occupation_class").value = "";
         fnMsDisableDropdownChange("noclicked");
           
        //to add here
        console.log("Channel setvaluesnull:"+Channel+"--ANB:"+document.getElementById("al_person_details.mlife.anb_il_product").value);
        
        
            console.log("Inside banca isILproduct:"+isILproduct);
        if(document.getElementById("al_person_details.mlife.anb_il_product").value >= 17 && document.getElementById("al_person_details.mlife.anb_il_product").value <= 60)
        {
        
            console.log("setvalues null1:"+document.getElementById("al_person_details.slife.relationship").disabled);
            if(client_ylp_type_mlife=="lo" || (Client_id=="" || Client_id==null || Client_id=="null"))
                   {
                       //commented by ankita on 10 april 2022
        //document.getElementById("al_person_details.slife.relationship").disabled = false;
            //document.getElementById("al_person_details.slife.relationship").options[2].selected=true;
                   }
            console.log("setvalues null12:"+document.getElementById("al_person_details.slife.first_name_dropdown").disabled);
        }
        //}
        
        //added by ankita on 25 march 2022 for modern family CR
       /*if(parseInt(document.getElementById("al_person_details.slife.anb_il_product").value) > 16)
       {
           console.log("setvaluesnull fnGetRelationshipList:"+relationship_mlife);
          //added by ankita on 10 april 2022
       if((relationship_mlife=="" || relationship_mlife=="undefined") || (replicate_res != "" && replicate_res != null && replicate_res != "null" && replicate_res != "(null)"))
       {
fnGetRelationshipList('al_person_details.mlife.anb_il_product','al_person_details.slife.anb_il_product','','al_person_details.slife.relationship','al_person_details.slife.gender_male','al_person_details.slife.gender_female','mySolutions');
       }
           if(relationship_mlife=="C")
           {
               fnGetRelationshipList('al_person_details.mlife.anb_il_product','al_person_details.slife.anb_il_product','','al_person_details.slife.relationship','al_person_details.slife.gender_male','al_person_details.slife.gender_female','mySolutionsChildCase');
               
           }
       }
        //added by ankita on 21 april 2022 for modern family cr to handle spouse relationship when to populate data from my needs to my solution module
        if((client_ylp_type_slife==="spouse" || client_ylp_type_slife==="you") && client_ylp_type_mlife!=="lo")
        {
            console.log("disabled 2");
            document.getElementById("al_person_details.slife.relationship").value="Spouse";
           document.getElementById("al_person_details.slife.relationship").disabled=true;
            
        }*/
        //22 april issue
        console.log("gender setvaluenull:"+document.getElementById("al_person_details.slife.gender_female").checked);
        console.log("setvalues null123:"+document.getElementById("al_person_details.slife.first_name_dropdown").disabled);
        //change by ankita on 8 dec change for prod defect internal issue
        if(parseInt(document.getElementById("al_person_details.mlife.anb_il_product").value) > 16 && callfrom!="change")
        {
            if(relationship_mlife=="C")
            {
                fnGetRelationshipList('al_person_details.mlife.anb_il_product','al_person_details.slife.anb_il_product','','al_person_details.slife.relationship','al_person_details.slife.gender_male','al_person_details.slife.gender_female','mySolutionsChildCase');
                
            }
            else
            {
                //if else modified by ankita on 21 april 2022 for spouse scenario for modern family CR
                //change by ankita on 8 dec change for prod defect internal issue
                /*if(client_ylp_type_mlife==="lo")
                {
                    fnGetRelationshipList('al_person_details.mlife.anb_il_product','al_person_details.slife.anb_il_product','','al_person_details.slife.relationship','al_person_details.slife.gender_male','al_person_details.slife.gender_female','mySolutions');
                }*/
                if((client_ylp_type_slife==="spouse" || client_ylp_type_slife==="you") && client_ylp_type_mlife!=="lo")
                {
                    console.log("disabled 3 setvaluesnull");
                
                    document.getElementById("al_person_details.slife.relationship").value="Spouse";
                   document.getElementById("al_person_details.slife.relationship").disabled=true;
                    
                }
            }
        }
         console.log("setvalues null124:"+document.getElementById("al_person_details.slife.first_name_dropdown").disabled);
         //added by ankita on 18 april 2022 for modern family CR
        //added by ankita for defect 305

        //added by ankita for defect 321 of third life flag
         if(parseInt(document.getElementById("al_person_details.mlife.anb_il_product").value) < 17 && document.getElementById("al_person_details.pre_natal_child_flg").checked===false && (document.getElementById("al_sqs_details.third_parti_flg_yes").checked==true) && (document.getElementById("al_sqs_details.third_parti_flg_yes").checked==false) && (document.getElementById("al_sqs_details.third_parti_flg_no").checked==true) && (document.getElementById("al_sqs_details.third_parti_flg_no").checked==false))

         {
             console.log("Less anb modern family");
             if((relationship_mlife!=="" && relationship_mlife!=="C" && document.getElementById("al_employee_details.mlife.occupation").value!="Child"))
             {
                 fnGetRelationshipList('al_person_details.mlife.anb_il_product','al_person_details.slife.anb_il_product','','al_person_details.slife.relationship','al_person_details.slife.gender_male','al_person_details.slife.gender_female','mySolutionsOcc');
             }
             
             
         }
        console.log("setvalues null124:"+document.getElementById("al_person_details.slife.first_name_dropdown").disabled);
        if(document.getElementById("al_person_details.pre_natal_child_flg").checked===true)
        {
            document.getElementById("al_person_details.slife.relationship").value="Parent";
            
        }
        /*if(document.getElementById("al_person_details.mlife.anb_il_product").value < 16)
        {
            var arrMatrix=new Array();
            var arrmatrix1Options = document.getElementById("al_person_details.slife.relationship");
         if(document.getElementById("al_person_details.slife.gender_male").checked)
          {
         arrmatrix1Options.options.length=0;
              arrMatrix=arrmatrixMale;
              //var arrmatrix1=["Parent","Legal Guardian","Grandfather","Cousin Brother","Uncle","Step Father","Brother","Step Brother"];
          }
         if(document.getElementById("al_person_details.slife.gender_female").checked)
         {
         arrmatrix1Options.options.length=0;
             arrMatrix=arrmatrixFemale;
         //var arrmatrix1=["Parent","Legal Guardian","Grandmother","Cousin Sister","Aunty","Step Mother","Sister","Step Brother"];
         }
             
         for(var i = 0; i < arrMatrix.length; i++)
         {
             var optn=document.createElement("option");
             optn.value=arrMatrix[i];
             optn.text=arrMatrix[i];
             arrmatrix1Options.appendChild(optn);
         }
        
        
        
        
           /* if(client_ylp_type_mlife=="lo" || (Client_id=="" || Client_id==null || Client_id=="null"))
                       {
            document.getElementById("al_person_details.slife.relationship").disabled = false;
                //document.getElementById("al_person_details.slife.relationship").options[2].selected=true;
                       }*/
            
        
       // }
        
        //end here
        
        if(document.getElementById("al_person_details.mlife.anb").value < 16 || getIlMlifeANB < 16)
            {
                if(((document.getElementById("al_person_details.mlife.anb").value > 16 && document.getElementById("al_person_details.mlife.anb").value < 19) || (getIlMlifeANB > 16 && getIlMlifeANB < 19)) && (Channel != "Banca" && Channel != "UOB") )//changed by Purva / Pramod C on 07th Aug 2017 for UOB
                {
                    $("input[name='third_life'][value='Yes']").prop('checked',false);
                    $("input[name='third_life'][value='No']").prop('checked',true);
                }else
                {
                    $("input[name='third_life'][value='Yes']").prop('checked',false);
                    $("input[name='third_life'][value='No']").prop('checked',true);
                }
            }
        
        
		}
    /*else
    {
        
	ClearData(); //added for production defect on 16-03-2016 by sachin
        document.getElementById("al_person_details.tlife.first_name").value = "";
        document.getElementById("al_person_details.tlife.first_name_dropdown").value = "Select";
        document.getElementById("al_person_details.tlife.relationship").value = "Parent";
        document.getElementById("al_person_details.tlife.dob").value = "";
        document.getElementById("al_person_details.tlife.anb").value = "";
        document.getElementById("al_person_details.tlife.gender_male").checked = true;
        document.getElementById("al_person_details.tlife.gender_female").checked = false;
        document.getElementById("al_person_details.tlife.smoke_status_yes").checked = false;
        document.getElementById("al_person_details.tlife.smoke_status_no").checked = true;
        document.getElementById("al_employee_details.tlife.nature_of_business").value = "Select";
        $(".natureSearchTLifeText").val("");//Prashant 23/12/2016
        document.getElementById("al_employee_details.tlife.occupation").value = "Select";
        $(".occupationSearchTLifeText").val("");//Prashant 23.12.2016
    }*/
    fnMsDisableDropdownChange("spouse");
    var insurence_type = $(escape_jq("al_person_details.mlife.insu_type")).val()
    if(insurence_type == "keyman" || insurence_type == "employee" || insurence_type == "partnership" || insurence_type == "Business Loan Insurance (for Company/LLP)" || insurence_type == "Business Loan Insurance (for Sole Proprietorship/Partnership)"){
        $(".collapseTwo").attr("id", "");
        $(".collapseThree").attr("id", "");
        $(".second_life,.third_life").addClass("disabled_panel");
        $(".second_life,.third_life").removeClass("normal_panel").removeClass("active_panel");
        $(escape_jq("al_sqs_details.sec_parti_flag_yes")).prop('checked',false);
        $(escape_jq("al_sqs_details.sec_parti_flag_no")).prop('checked',true);
        $("input[name='third_life'][value='Yes']").prop('checked',false);
        $("input[name='third_life'][value='No']").prop('checked',true);
        $("input[name='second_life'][value='Yes']").attr("disabled", true)
        $("input[name='second_life'][value='No']").attr("disabled", true)
        $(escape_jq("al_person_details.pre_natal_child_flg")).attr("disabled", true)
    }
    console.log("setvalues null125:"+document.getElementById("al_person_details.slife.first_name_dropdown").disabled);
}

//Dynamically set dropdown onchange
function fnMsSolSelectElement(valueToSelect,id)
{
        var dd_sel = document.getElementById(id);
    dd_sel.value = valueToSelect;
    console.log("dd_sel   " +JSON.stringify(dd_sel));
}
var tempExecute = 0;
//Validation   aniket to change
function CheckDate(DateValueId, DateValue, day, month, year,persontype,comefrom,changeflg)
{
    childFlag = "";
    console.log("in checkDate"+DateValueId+"----"+DateValue)
    
    console.log("persontype-->"+persontype);
    console.log("ist parameter-->"+DateValueId);
    console.log("2nd parameter-->"+DateValue);
    console.log("3rd parameter-->"+day);
    console.log("4rd parameter-->"+month);
    console.log("5rd parameter-->"+year);
    console.log("6rd parameter-->"+comefrom);
    console.log("7rd parameter-->"+changeflg);
    //console.log("7rd parameter-->",tempExecute);

    
    
    
    var oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
    var date1;
    var inceptiondate;
    var dd1;
    var mm1;
    var yyyy1;

    var ageYears;
    var ageMonths;
    var ageDays;

    if (DateValueId == "al_sqs_details.Inception_dt") {
        if(document.getElementById("al_sqs_details.payment_backdate_yes").checked)
        {
            var currentdate = new Date();
            if(sysdate!=""){
                 currentdate = new Date(sysdate);
            }else{
                 currentdate = new Date();
            }
            var dateFrom = "01/"+ (currentdate.getMonth()+1) +"/" +currentdate.getFullYear();//prev date
            console.log("dateFrom"+dateFrom);
            var dateTo = getCurrentDate();//currentdate
            var dateCheck = DateValue;

            var d1 = dateFrom.split("/");
            var d2 = dateTo.split("/");
            var c = dateCheck.split("/");
            

            var from = new Date(d1[2], d1[1]-1, d1[0]);  // -1 because months are from 0 to 11
            var to   = new Date(d2[2], d2[1]-1, d2[0]);
            var check = new Date(c[2], c[1]-1, c[0]);
        }
    } else {
        var date_sel_invalid = 0;
        var pay_date = "No";
        
        if (pay_date == "No") {
            date1 = new Date(eval(year), eval(month) - 1, eval(day)); //-1 is done by deepak on 2_12_2013 for dec array is retiurn 11
            console.log("date1 find-->"+date1);
            if(sysdate!=""){
                inceptiondate = new Date(sysdate);
            }else{
                inceptiondate = new Date();
            }
            //inceptiondate = new Date();
            console.log("inceptiondate find-->"+inceptiondate);
            dd1 = inceptiondate.getDate();
            console.log("inceptiondate  ddl find-->"+inceptiondate);
            mm1 = inceptiondate.getMonth() + 1; //January is 0!
            yyyy1 = inceptiondate.getFullYear();
            
            //For Future Date Cal
            if (DateValueId == "al_person_details.mlife.dob" || DateValueId == "al_person_details.slife.dob" || DateValueId == "al_person_details.tlife.dob") {
              
                var anb_reset = DateValueId.split(".");
                
                //Temporarily Commented for Future Date Selection
                if (eval(year) > eval(yyyy1)) {
                    date_sel_invalid = 1;
                    alert("215");
                    
                    document.getElementById(DateValueId).value="";
                    document.getElementById(anb_reset[0]+"."+anb_reset[1]+".anb").value="";
                    return false;
                } else if (eval(year) == eval(yyyy1) && eval(month) > eval(mm1)) {
                    date_sel_invalid = 1
                    alert("215");
                    document.getElementById(DateValueId).value="";
                    document.getElementById(anb_reset[0]+"."+anb_reset[1]+".anb").value="";
                    return false;
                } else if (eval(year) == eval(yyyy1) && eval(month) == eval(mm1) && eval(day) > eval(dd1)) {
                    date_sel_invalid = 1
                    alert("215");
                    document.getElementById(DateValueId).value="";
                    document.getElementById(anb_reset[0]+"."+anb_reset[1]+".anb").value="";
                    return false;
                }
            }
        }
        
        if (eval(date_sel_invalid) == 0) {
            if (DateValueId == "al_person_details.mlife.dob") {
                checkDateDiff="";
                var dobdate = new Date();
                dobdate.setFullYear(date1.getFullYear(), date1.getMonth(), date1.getDate());
                var today = new Date();
                if(sysdate!=""){
                     today = new Date(sysdate);
                }
                else{
                     today = new Date();
                }
                var diffDate = (today - dobdate) / (1000 * 60 * 60 * 24);
                checkDateDiff=diffDate;
                console.log("diffDate"+diffDate);
            }
            
            /***************************************Following code is original code for OS But commited for OS to IL Conversion***********
            if (dd1 > 15 && mm1 == 12) {
                yyyy1 = eval(yyyy1) + 1
                mm1 = 1;
                dd1 = 1;
            } else {
                if (dd1 > 15 && mm1 < 12) {
                    mm1 = eval(mm1) + 1;
                    dd1 = 1;
                } else
                    dd1 = 1;
            }
            /*********************************************************************************/
            
            if(ANB_json[0]["anb_type"]=="IL_Monthly" && (ANB_json[0]["anb_type"]!="" && ANB_json[0]["anb_type"]!='undefined' && ANB_json[0]["anb_type"]!=undefined && ANB_json[0]["anb_type"]!="{}")) { //This code added for OS to IL Conversion By Sachin T on Date 19-06-2019
                
                
                if(dd1>=2)
                {
                    mm1 = eval(mm1)+1 ;
                    dd1 = 1 ;
                }
                else
                {
                    dd1 = 1 ;
                }
                
                
                if(mm1 > 12)
                {
                    mm1= 1;
                    yyyy1 =eval(yyyy1)+1;
                }
                
                
            }
            
            
            console.log("$#Inception Date---> "+mm1+"/"+dd1+"/"+yyyy1)
            
            
            
            
            
            
            
            ageYears = yyyy1 - date1.getFullYear();
            ageMonths = mm1 - date1.getMonth() + 1;
            ageDays = dd1 - date1.getDate();
            
            if (DateValueId == "al_person_details.mlife.dob")
            {
                var monthOfDOB = date1.getMonth() + 1;
                var dayOfDOB = date1.getDate();
                var monthOfInception = mm1;
                var dayOfInception = dd1;
                var yearOfDOB = date1.getFullYear();
                console.log("yearOfDob"+yearOfDOB);
                var yearOfInception = yyyy1;
                
                var DobinDays = (monthOfDOB * 31) + dayOfDOB;
                console.log("DobinDays"+DobinDays);
                var InceptioninDays = (monthOfInception * 31) + dayOfInception;
                
                if (DobinDays < InceptioninDays) {
                    calculatedAge = yearOfInception - yearOfDOB + 1;
                } else {
                    calculatedAge = yearOfInception - yearOfDOB;
                }
                if (calculatedAge < 1 && DateValueId == "al_person_details.mlife.expected_delivery_dt") {
                        calculatedAge = 1;
                }
                 document.getElementById("al_person_details.mlife.anb").value = calculatedAge;
                 document.getElementById("al_person_details.mlife.anb_il_product").value = calculatedAge;//Added for OS to IL Conversion by Sachin T.
                 document.getElementById("al_person_details.mlife.anb_il_monthly_product").value = calculatedAge;//Added for OS to IL Conversion by Sachin T.
                
                
                
                
                ageYears = document.getElementById("al_person_details.mlife.anb").value;
                var ilANB=document.getElementById("al_person_details.mlife.anb_il_product").value; // added for IL ANB changes. Pramod Chavan: 14122017
                var ilANB_monthly=document.getElementById("al_person_details.mlife.anb_il_monthly_product").value;//Added for il monthly by Sachin Tupe.on 26-06-2018.
                console.log("ilANB---->"+ilANB);
                if((ageYears >=11 && ageYears <=16) || ((ilANB >=11 && ilANB <=16) || (ilANB_monthly >=11 && ilANB_monthly <=16) ))// && Channel == "Banca")
                {
                    var insurence_type = $(escape_jq("al_person_details.mlife.insu_type")).val()
                    if(insurence_type == "keyman" || insurence_type == "employee" || insurence_type == "partnership" || insurence_type == "Business Loan Insurance (for Company/LLP)" || insurence_type == "Business Loan Insurance (for Sole Proprietorship/Partnership)"){
                        childFlag = true;
                        
                        alert("Not Valid Age. Please Select Valid Age");
                        return false;
                        
                    }else{
                        childFlag = false;
                    }
                    document.getElementById("parent_consent_block").style.display="block";
                    if(document.getElementById("al_person_details.mlife.parent_consent_yes").checked)
                    {
                        fnMsDisableLives("al_person_details.mlife.parent_consent_yes");
                    }else
                    {
                        console.log("fnMsDisableLives1")
                         fnMsDisableLives("al_person_details.mlife.parent_consent_no");
                    }
                }else
                {
                    document.getElementById("parent_consent_block").style.display="none";
                    document.getElementById("al_person_details.mlife.parent_consent_yes").checked=false;
                    document.getElementById("al_person_details.mlife.parent_consent_no").checked=true;
                }
                if ((ageYears > 16 && ageYears <= 70 && !isILproduct) || (ilANB > 16 && ilANB <= 70 && isILproduct)) // changed by yogesh 0n 7.10.13
                {
                    $(".occupationSearchMLifeText").attr("disabled",false);
                    $(".natureSearchMLifeText").attr("disabled",false);
                    if(document.getElementById(DateValueId).value == "")
                    {
                        document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = false;
                        document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = false;
                        $(".collapseThree").attr("id", "");
                        $(".third_life").addClass("disabled_panel");
                        $(".third_life").removeClass("normal_panel").removeClass("active_panel");

                    }
                    
                    if((document.getElementById("al_person_details.mlife.anb").value >16 && !isILproduct) || (ilANB >16 && isILproduct) && (Channel == "Agency" || Channel == "FA" ))// Piyush (03/12/2018): Changes has been done for New channel
                    {
                     
                        if(ANB_set <= 16 && ANB_set != "")
                        {
                            console.log("ANB_set 8 :: "+ANB_set);

                        }
                        else if(ANB_set=="")
                        {
                            console.log("ANB_set 7 :: "+ANB_set);
                            fnMsSolSelectElement("Occupation", "al_employee_details.mlife.occupation");
                            $(".occupationSearchMLifeText").val("");//Prashant 23.12.2016
                            fnMsSolSelectElement("Nature of Business", "al_employee_details.mlife.nature_of_business");
                            $(".natureSearchMLifeText").val("");//Prashant 23/12/2016
                            document.getElementById("al_employee_details.mlife.occupation_class").value = "";
                            
                        }
                        //if(document.getElementById("al_person_details.mlife.anb").value ==17 || document.getElementById("al_person_details.mlife.anb").value ==18) Commented by Rahul on 05-11-2015
                        if((document.getElementById("al_person_details.mlife.anb").value ==16 && !isILproduct) || (ilMainLifeANB ==16 && isILproduct))
                        {
                            var insurence_type = $(escape_jq("al_person_details.mlife.insu_type")).val()
                            if(insurence_type == "keyman" || insurence_type == "employee" || insurence_type == "partnership" || insurence_type == "Business Loan Insurance (for Company/LLP)" || insurence_type == "Business Loan Insurance (for Sole Proprietorship/Partnership)"){
                               
                                childFlag = true;
                                alert("Not Valid Age. Please Select Valid Age");
                                return false;
                                
                            }else{
                                childFlag = false;
                            }
                            console.log("ANB_set 17 :: "+ANB_set);
                            //Added by Paromita on 14 Aug 2017 FOR NEW OCCUPATION LIST
                            fnMsSolSelectElement("Child", "al_employee_details.mlife.occupation");
                            $(".occupationSearchMLifeText").val("Child");
                            //$(".natureSearchMLifeText").attr("disabled",true);
                            fnMsSolSelectElement("Child","al_employee_details.mlife.nature_of_business");
                            /***/
                            console.log("childee2");

                            $(".natureSearchMLifeText").val("Child");
                        }
                    }
                    else if(((document.getElementById("al_person_details.mlife.anb").value >16 && !isILproduct) || (ilMainLifeANB >16 && isILproduct)) && (Channel == "Banca" || Channel == "UOB"))//changed by Purva / Pramod C on 07th Aug 2017 for UOB
                    {
                        console.log("ANB_set 9 :: "+ANB_set);
                        if(((ANB_set <= 16 && !isILproduct) || (ilMainLifeANB <= 16 && isILproduct)) && (Channel == "Banca" || Channel == "UOB") && ANB_set != "")//changed by Purva / Pramod C on 07th Aug 2017 for UOB
                        {
                            console.log("ANB_set 10 :: "+ANB_set);
                            fnMsSolSelectElement("Occupation", "al_employee_details.mlife.occupation");
                            $(".occupationSearchMLifeText").val("");//Prashant 23.12.2016
                            
                            fnMsSolSelectElement("Nature of Business", "al_employee_details.mlife.nature_of_business");
                            $(".natureSearchMLifeText").val("");//Prashant 23/12/2016
                           
                            document.getElementById("al_employee_details.mlife.occupation_class").value = "";

                        }
                    }
                    
                    document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = false;
                    document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = false;
                    
                    $("input[name='third_life'][value='Yes']").prop('checked',false);
                    $("input[name='third_life'][value='No']").prop('checked',true);
                }

                else if (ageYears <= 16 || ilANB <= 16)

                {   console.log("ageYears = "+ageYears);
                    //For Junvenile Cases
                    //Added by Paromita on 14 Aug 2017 FOR NEW OCCUPATION LIST

                    //last or condition of > 16 added by ankita on 30 jan 2022
                    if(((ageYears <= 16 && !isILproduct) || (ilANB <= 16 && isILproduct)) && Channel!="Agency" && Channel!="FA" || (Channel=="Banca" && ilANB > 16 && isILproduct)){   // Piyush(03/12/2018) : Added this changes for new channel FA
                    console.log("Inside jan 22 set occupation");
                        var insurence_type = $(escape_jq("al_person_details.mlife.insu_type")).val()
                        if(insurence_type == "keyman" || insurence_type == "employee" || insurence_type == "partnership" || insurence_type == "Business Loan Insurance (for Company/LLP)" || insurence_type == "Business Loan Insurance (for Sole Proprietorship/Partnership)"){
                            
                            childFlag = true;
                            alert("Not Valid Age. Please Select Valid Age");
                            return false;
                            
                        }else{
                            childFlag = false;
                        }
                    fnMsSolSelectElement("Child", "al_employee_details.mlife.occupation");
                    $(".occupationSearchMLifeText").val("Child");
                    $(".occupationSearchMLifeText").attr("disabled",true);
                   
                    fnMsSolSelectElement("Child","al_employee_details.mlife.nature_of_business");
                    console.log("childee3");

                    $(".natureSearchMLifeText").val("Child");
                     $(".natureSearchMLifeText").attr("disabled",true);

                    }
                    else if((Channel=="Agency" || Channel=="FA" ) && ((ageYears <= 15 && !isILproduct)|| (ilANB <= 15 && isILproduct)))  // Piyush(03/12/2018) : Added this changes for new channel FA
                    {
                        var insurence_type = $(escape_jq("al_person_details.mlife.insu_type")).val()
                        if(insurence_type == "keyman" || insurence_type == "employee" || insurence_type == "partnership" || insurence_type == "Business Loan Insurance (for Company/LLP)" || insurence_type == "Business Loan Insurance (for Sole Proprietorship/Partnership)"){
                            childFlag = true;
                            alert("Not Valid Age. Please Select Valid Age");
                            return false;
                            
                        }else{
                            childFlag = false;
                        }
                        fnMsSolSelectElement("Child", "al_employee_details.mlife.occupation");
                        $(".occupationSearchMLifeText").val("Child");
                        $(".occupationSearchMLifeText").attr("disabled",true);
                        //$(".natureSearchMLifeText").attr("disabled",true);
                        fnMsSolSelectElement("Child","al_employee_details.mlife.nature_of_business");
                        console.log("childee3");
                        
                        $(".natureSearchMLifeText").val("Child");
                        $(".natureSearchMLifeText").attr("disabled",true);
 
                    }

                    /*
                    var res_occ_class = document.getElementById("al_employee_details.mlife.occupation").value.split("-");
                    document.getElementById("al_employee_details.mlife.occupation_class").value = res_occ_class[1];*/
                    
                    //Added by Paromita on 14 Aug 2017 for new Occupation list
                    fngetOccupationClassFromMatrix("al_employee_details.mlife.occupation","al_employee_details.mlife.nature_of_business","al_employee_details.mlife.occupation_class")
                    
                    ANB_set =  document.getElementById("al_person_details.mlife.anb").value;
                    console.log("ANB_set 11 :: "+ANB_set);

                    document.getElementById("al_sqs_details.sec_parti_flag_yes").checked = true;
                    document.getElementById("al_sqs_details.sec_parti_flag_no").checked = false;
                    document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = true;
                    $(".collapseTwo").attr("id", "collapseTwo");
                    $(".second_life").addClass("normal_panel");
                    $(".second_life").removeClass("disabled_panel");
                    
                    if(document.getElementById("al_person_details.slife.gender_male").checked == true && document.getElementById("al_person_details.slife.gender_female").checked == false && document.getElementById("al_person_details.pre_natal_child_flg").checked == true)
                    {
                        document.getElementById("third_life_party_flag").style.display = 'block';
                        document.getElementById("al_sqs_details.third_parti_flg_yes").disabled = true;
                        document.getElementById("al_sqs_details.third_parti_flg_no").disabled = true;
                      
                        //if(document.getElementById().checked)
                        $("input[name='third_life'][value='Yes']").prop('checked',true);
                        $("input[name='third_life'][value='No']").prop('checked',false);
                        $(".collapseThree").attr("id", "collapseThree");
                        $(".third_life").addClass("normal_panel");
                        $(".third_life").removeClass("disabled_panel");
                    }
                    else if(document.getElementById("al_person_details.slife.gender_female").checked == true && document.getElementById("al_person_details.slife.gender_male").checked == false && document.getElementById("al_person_details.pre_natal_child_flg").checked == true)
                    {
                        //code commented by Praveen for third life enable for banca
//                        if(!Channel == "Banca")
//                        {
                            document.getElementById("third_life_party_flag").style.display = 'block';
                            document.getElementById("al_sqs_details.third_parti_flg_yes").disabled = false;
                            document.getElementById("al_sqs_details.third_parti_flg_no").disabled = false;
                            $("input[name='third_life'][value='Yes']").prop('checked',false);
                            $("input[name='third_life'][value='No']").prop('checked',true);
                            $(".collapseThree").attr("id", "");
                            $(".third_life").addClass("disabled_panel");
                            $(".third_life").removeClass("normal_panel");
                        //change by ankita on 8 dec change for prod defect internal issue
                            SetValuesnull(comefrom);
//                        }else if(Channel == "Banca")
//                        {
//                            document.getElementById("third_life_party_flag").style.display = 'none';
//                        }
                        
                    }
                    
                }
                else if(((ageYears <= 15 && !isILproduct) || (ilANB <= 15 && isILproduct)) && (Channel == "Agency" || Channel == "FA"))// Piyush (03/12/2018): Changes has been done for New channel
                {
                    //Added by Paromita on 14 Aug 2017 for new Occupation list
                    var insurence_type = $(escape_jq("al_person_details.mlife.insu_type")).val()
                    if(insurence_type == "keyman" || insurence_type == "employee" || insurence_type == "partnership" || insurence_type == "Business Loan Insurance (for Company/LLP)" || insurence_type == "Business Loan Insurance (for Sole Proprietorship/Partnership)"){
                        
                        childFlag = true;
                        alert("Not Valid Age. Please Select Valid Age");
                        return false;
                        
                    }else{
                        childFlag = false;
                    }
                    fnMsSolSelectElement("Child", "al_employee_details.mlife.occupation");
                    $(".occupationSearchMLifeText").val("Child");
                    fnMsSolSelectElement("Child","al_employee_details.mlife.nature_of_business");
                    console.log("childee44");

                    $(".natureSearchMLifeText").val("Child");
                    /*
                    var res_occ_class = document.getElementById("al_employee_details.mlife.occupation").value.split("-");
                    document.getElementById("al_employee_details.mlife.occupation_class").value = res_occ_class[1];*/
                fngetOccupationClassFromMatrix("al_employee_details.mlife.occupation","al_employee_details.mlife.nature_of_business","al_employee_details.mlife.occupation_class")
                    
                }
                else if(((ageYears == 16 || ageYears == 17 || ageYears == 18) && !isILproduct) || ((ilANB == 16 || ilANB == 17 || ilANB == 18) && isILproduct))
                {
                    $(".occupationSearchMLifeText").attr("disabled",false);
                    $(".natureSearchMLifeText").attr("disabled",false);
                    
                    if(Channel == "Agency" || Channel == "FA")// Piyush (03/12/2018): Changes has been done for New channel
                    {
                        document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = false;
                        document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = false;
                        if((ageYears > 16 && !isILproduct) || (ilANB > 16 && isILproduct))
                        {
                            document.getElementById("al_sqs_details.sec_parti_flag_no").checked = true;//Added By Rahul on 01.10.2015 for PRUterm
                            $(".collapseTwo").attr(
                                                   "id", "");
                            $(".collapseThree")
                            .attr("id", "");
                            $(
                              ".second_life,.third_life")
                            .addClass(
                                      "disabled_panel");
                            $(
                              ".second_life,.third_life")
                            .removeClass(
                                         "normal_panel")
                            .removeClass(
                                         "active_panel");
                            $(
                              "#al_sqs_details.third_parti_flg_no")
                            .prop(
                                  "checked",
                                  true);
                            $(
                              "#al_sqs_details.third_parti_flg_yes")
                            .prop(
                                  "checked",
                                  false);
                            //change by ankita on 8 dec change for prod defect internal issue
                            SetValuesnull(comefrom);
                            
                        }
                        else
                        {
                            document.getElementById("al_sqs_details.sec_parti_flag_yes").checked = true;//Added By Rahul on 01.10.2015 for PRUterm
                            $(".collapseTwo").attr(
                                                   "id",
                                                   "collapseTwo");
                            $(".second_life")
                            .addClass(
                                      "normal_panel");
                            $(".second_life")
                            .removeClass(
                                         "disabled_panel");
                            //change by ankita on 8 dec change for prod defect internal issue
                            SetValuesnull(comefrom);
                        }
                       if( $(".occupationSearchMLifeText").val() == "Child") //Added by Paromita on 14 Aug 2017 for new Occupation list
                       {
                        $(".occupationSearchMLifeText").val("");
                        document.getElementById("al_employee_details.mlife.occupation_class").value = "";
                        $(".natureSearchMLifeText").val("");
                       }
                    }
                }
                else if(((ageYears == 17 || ageYears == 18)&& !isILproduct) ||((ilANB == 17 || ilANB == 18) && isILproduct))
                {
                    $(".occupationSearchMLifeText").attr("disabled",false);
                    $(".natureSearchMLifeText").attr("disabled",false);
                    
                    if(Channel == "Banca" || Channel == "UOB")//changed by Purva / Pramod C on 07th Aug 2017 for UOB
                    {
                        if((ANB_set <= 16 && ANB_set!="" && !isILproduct) ||(ilANB <= 16 && isILproduct))
                        {
                            console.log("ANB_set 28 :: "+ANB_set);
                            fnMsSolSelectElement("Occupation", "al_employee_details.mlife.occupation");
                            $(".occupationSearchMLifeText").val("");//Prashant 23.12.2016
                            fnMsSolSelectElement("Nature of Business", "al_employee_details.mlife.nature_of_business");
                            $(".natureSearchMLifeText").val("");//Prashant 23/12/2016
                            document.getElementById("al_employee_details.mlife.occupation_class").value = "";
                        }
                    }
                    
                    ANB_set =  document.getElementById("al_person_details.mlife.anb").value;
                    console.log("ANB_set 12 :: "+ANB_set);
                    if(document.getElementById(DateValueId).value == "")
                    {
                        document.getElementById("al_sqs_details.sec_parti_flag_yes").checked = false;
                        document.getElementById("al_sqs_details.sec_parti_flag_no").checked = true;
                        document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = false;
                        document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = false;
                        $(".collapseTwo").attr("id", "");
                        $(".collapseThree").attr("id", "");
                        $(".second_life,.third_life").addClass("disabled_panel");
                        $(".second_life,.third_life").removeClass("normal_panel").removeClass("active_panel");
                    }
                    document.getElementById("relationship_slife other ::relationship_slife other ::").disabled = false;
                    document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = false;
                    $("input[name='third_life'][value='Yes']").prop('checked',false);
                    $("input[name='third_life'][value='No']").prop('checked',true);
                    
                    //code commented by Praveen for third life enable for banca
//                    if(Channel != "Banca")
//                    {
                        document.getElementById("third_life_party_flag").style.display = 'block';
//                    }else if(Channel == "Banca")
//                    {
//                        document.getElementById("third_life_party_flag").style.display = 'none';
//                    }
                    
                    if((document.getElementById("al_person_details.mlife.anb").value >16 && !isILproduct) || (ilANB >16 && isILproduct))
                    {
                        console.log("ANB_set 13 :: "+ANB_set);
                        if((ANB_set <= 16 && !isILproduct) || (ilANB <= 16 && isILproduct))
                        {
                            console.log("ANB_set 14 :: "+ANB_set);
                            fnMsSolSelectElement("Occupation", "al_employee_details.mlife.occupation");
                            $(".occupationSearchMLifeText").val("");//Prashant 23.12.2016
                            fnMsSolSelectElement("Nature of Business", "al_employee_details.mlife.nature_of_business");
                            $(".natureSearchMLifeText").val("");//Prashant 23/12/2016
                            document.getElementById("al_employee_details.mlife.occupation_class").value = "";

                        }
                    }
                }
                else if ((ageYears > 70 && !isILproduct) || (ilANB > 70  && isILproduct))
                { console.log("@main2")
                    $(".occupationSearchMLifeText").attr("disabled",false);
                    $(".natureSearchMLifeText").attr("disabled",false);
                    if((document.getElementById("al_person_details.mlife.anb").value >16 && !isILproduct) ||(ilANB >16 && isILproduct))
                    {
                        console.log("ANB_set 17 :: "+ANB_set);
                        if((ANB_set <= 16 && !isILproduct) || (ilANB <= 16 && isILproduct))
                        {
                            console.log("ANB_set 18 :: "+ANB_set);
                            fnMsSolSelectElement("Occupation", "al_employee_details.mlife.occupation");
                            $(".occupationSearchMLifeText").val("");//Prashant 23.12.2016
                            fnMsSolSelectElement("Nature of Business", "al_employee_details.mlife.nature_of_business");
                            $(".natureSearchMLifeText").val("");//Prashant 23/12/2016
                            document.getElementById("al_employee_details.mlife.occupation_class").value = "";

                        }
                    }
                    document.getElementById("al_sqs_details.sec_parti_flag_yes").checked = false;
                    document.getElementById("al_sqs_details.sec_parti_flag_no").checked = true;
                    document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = false;
                    document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = false;
                    $(".collapseTwo").attr("id", "");
                    $(".collapseThree").attr("id", "");
                    $(".second_life,.third_life").addClass("disabled_panel");
                    $(".second_life,.third_life").removeClass("normal_panel").removeClass("active_panel");
                    $("input[name='third_life'][value='Yes']").prop('checked',false);
                    $("input[name='third_life'][value='No']").prop('checked',true);
                    if(tempExecute==0)
                    {  tempExecute++;
                        alert("216","70");
                    }
                    
                    document.getElementById("al_person_details.mlife.anb").value = "";
                    document.getElementById("al_person_details.mlife.dob").value = "";
                    
                    return false;
                }
                
                if (ageYears <= 16 || (ilANB <=16 || ilANB_monthly <=16))
                {
                    if (Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)" && (replicate_res == "" || replicate_res == null || replicate_res == "null" || replicate_res == "(null)"))
                    {
                        js_get_var("proposal_required_info", function(response_pro_req)
                        {
                            js_get_var("ylp_id_for_sqs", function(res_ylp)
                            {
                                document.getElementById("al_person_details.mlife.anb").value = calculatedAge;
                                if(document.getElementById("al_person_details.mlife.anb").value <= 16 || (ilANB <=16 || ilANB_monthly <=16))
                                {
                                       if((document.getElementById("al_person_details.mlife.anb").value >= 11 && document.getElementById("al_person_details.mlife.anb").value <= 16) || ((ilANB >= 11 && ilANB <= 16) || (ilANB_monthly >= 11 && ilANB_monthly <= 16)))
                                       {
                                    if(!(document.getElementById("al_person_details.mlife.parent_consent") == null && document.getElementById("al_person_details.mlife.parent_consent") == "null"))
                                    {
                                       if(document.getElementById("al_person_details.mlife.parent_consent_no").checked)
                                       {
                                       console.log("---->1");
                                       fnMsPersonalPopulateValues("al_person_details.slife.first_name_dropdown","slife")
                                       
                                       if(res_ylp != "" && res_ylp != null && res_ylp != "null" && res_ylp != "(null)")
                                       {
                                       document.getElementById("al_person_details.slife.first_name_dropdown").disabled=true;
                                       }else
                                       {
                                       document.getElementById("al_person_details.slife.first_name_dropdown").disabled=false;
                                       }
                                       }else if(document.getElementById("al_person_details.mlife.parent_consent_yes").checked)
                                       {
                                       fnMsDisableLives("al_person_details.mlife.parent_consent_yes");
                                       }
                                   }
                                   }else if(document.getElementById("al_person_details.mlife.anb").value <= 11 || ilANB <=11)
                                   {
                                       console.log("---->2")
                                       fnMsPersonalPopulateValues("al_person_details.slife.first_name_dropdown","slife")
                                       
                                       if(res_ylp != "" && res_ylp != null && res_ylp != "null" && res_ylp != "(null)")
                                       {
                                       document.getElementById("al_person_details.slife.first_name_dropdown").disabled=true;
                                       }else
                                       {
                                       document.getElementById("al_person_details.slife.first_name_dropdown").disabled=false;
                                       }
                                    }
                                }
                                   if((document.getElementById("al_person_details.mlife.anb").value > 16 && !isILproduct) ||(ilANB > 16 && isILproduct))
                                   {
                                       $(".occupationSearchMLifeText").attr("disabled",false);
                                       $(".natureSearchMLifeText").attr("disabled",false);
                                   }
                           });
                       });
                    }
                    
                    if((Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)") || (replicate_res != "" && replicate_res != null && replicate_res != "null" && replicate_res != "(null)"))
                    {
                        if(typeof pre_natal_handle == "undefined" || pre_natal_handle=="")
                        {
                                pre_natal_handle = "No";
                                if((document.getElementById("al_person_details.mlife.anb").value <=16 && !isILproduct) || (ilANB <=16 && isILproduct))
                                {
                                    client_ylp_type_mlife = "lo";
                                }
//                                else if(document.getElementById("al_person_details.mlife.anb").value <=16 && Channel == "Banca")
//                                {
//                                    client_ylp_type_mlife = "lo";
//                                }
                        }
                        
                        console.log("prenatal handle :: "+pre_natal_handle+" === "+document.getElementById("al_person_details.mlife.anb").value+" ==== "+relationship_mlife+" ---  "+client_ylp_type_mlife);
                        if(((document.getElementById("al_person_details.mlife.anb").value > 16 && !isILproduct) || (ilANB > 16 && isILproduct)) && (typeof relationship_mlife == 'undefined' || relationship_mlife == "" || relationship_mlife == "H" || relationship_mlife == "W" || relationship_mlife == "F" || relationship_mlife == "M"))
                        {
                            if((document.getElementById("al_person_details.mlife.anb").value==17 || document.getElementById("al_person_details.mlife.anb").value==18)  && !isILproduct)
                            {
                                if(client_ylp_type_mlife=="lo" && (Client_id!="" && Client_id!=null && Client_id!="null"))
                                {
                                    document.getElementById("al_person_details.slife.relationship").value = "Parent";
                                    document.getElementById("al_person_details.slife.relationship").disabled = false; // changes made by pramod chavan "True" to "False" for prodcution defect---PRUW00037533
                                    console.log("12 disable");
                                }

                            }else if((ilMainLifeANB==17 || ilMainLifeANB==18) && isILproduct)
                            {
                                if(client_ylp_type_mlife=="lo" && (Client_id!="" && Client_id!=null && Client_id!="null"))
                                {
                                    document.getElementById("al_person_details.slife.relationship").value = "Parent";
                                    document.getElementById("al_person_details.slife.relationship").disabled = false; // changes made by pramod chavan "True" to "False" for prodcution defect---PRUW00037533
                                    console.log("12 disable");
                                }
                                
                            }
                            else
                            {
                                document.getElementById("al_person_details.slife.relationship").value = "Spouse";
                                document.getElementById("al_person_details.slife.relationship").disabled = true;
                                console.log("13 disable");
                            }
                        }else if(((document.getElementById("al_person_details.mlife.anb").value == 16 && !isILproduct) || (ilANB == 16 && isILproduct)) && (client_ylp_type_mlife == "you"  || client_ylp_type_mlife == "spouse") && (typeof relationship_mlife == 'undefined' || relationship_mlife == "" || relationship_mlife == "H" || relationship_mlife == "W" || relationship_mlife == "F" || relationship_mlife == "M"))
                        {
                            document.getElementById("al_person_details.slife.relationship").value = "Parent";
                            document.getElementById("al_person_details.slife.relationship").disabled = false; // changes made by pramod chavan "True" to "False" for prodcution defect---PRUW00037533
                            console.log("14 disable");
                        }else if(((pre_natal_handle == "No" && ((document.getElementById("al_person_details.mlife.anb").value <=16 && !isILproduct) || (ilANB <=16 && isILproduct))) || pre_natal_handle == "Yes") && (relationship_mlife == "C") && client_ylp_type_mlife == "lo"){
                            
                            if(relationship_slife == "F" || relationship_slife == "M" || relationship_slife == "" || typeof relationship_slife == "undefined")
                            {
                                document.getElementById("al_person_details.slife.relationship").value = "Parent";
                                document.getElementById("al_person_details.slife.relationship").disabled = false;
                                
                                if(document.getElementById("al_sqs_details.third_parti_flg_yes").checked)
                                {
                                    document.getElementById("al_person_details.tlife.relationship").value = "Parent";
                                    document.getElementById("al_person_details.tlife.relationship").disabled = false;
                                }
                                
                            }else
                            {
                                console.log("relationship_mlife in validations 2 :: "+relationship_mlife+" --- "+relationship_slife);
                                document.getElementById("al_person_details.slife.relationship").value = "Select Relationship";
                               //commented by ankita on 8 april 2022
                                //document.getElementById("al_person_details.slife.relationship").disabled = true;
                                console.log("15 disable");
                            }
                        }else
                        {
                            console.log("relationship_mlife in validations 3 :: "+relationship_mlife+" --- "+relationship_slife);
                            document.getElementById("al_person_details.slife.relationship").value = "Select Relationship";
                            document.getElementById("al_person_details.slife.relationship").disabled = false;
                            console.log("16 disable");
                        }
                    }
                    
                        document.getElementById("third_life_party_flag").style.display = 'block';

                    if (((ageYears <= 16 && !isILproduct) || (ilANB <= 16 && isILproduct)) && document.getElementById("al_person_details.pre_natal_child_flg").checked == true)
                    {
                        $("input[name='third_life'][value='Yes']").prop('checked',true);
                        $("input[name='third_life'][value='No']").prop('checked',false);
                        
                        $( "select[name='al_person_details.slife.relationship']" ).find('option[value="Spouse"]').remove();
                        document.getElementById("al_person_details.slife.relationship").value="Parent";
                        document.getElementById("al_person_details.slife.relationship").disabled = false;
                    }else if (((ageYears <= 16 && !isILproduct) || (ilANB <= 16 && isILproduct)) && document.getElementById("al_person_details.pre_natal_child_flg").checked == false)
                    {

                        $( "select[name='al_person_details.slife.relationship']" ).find('option[value="Spouse"]').remove();
                         document.getElementById("al_person_details.slife.relationship").value="Parent";
                        document.getElementById("al_person_details.slife.relationship").disabled = false;
                    }
                    else
                    {
                        console.log("cheked modern family1 5108 ddlArray");
                        //to check 16 may 2022
                        //commented by ankita on 20 april 2022 for modern family CR as it was displaying old list
                       /* var ddloption = document.getElementById("al_person_details.slife.relationship");
                        //console.log("options ddloption "+ddloption);
                        ddloption.options.length=0;
                        for(var i = 0; i < ddlArray.length; i++)
                        {
                            var optn=document.createElement("option");
                            optn.value=ddlArray[i];
                            optn.text=ddlArray[i];
                            ddloption.appendChild(optn);
                            
                        }*/
                        document.getElementById("al_person_details.slife.relationship").disabled = false;
				    }
                } else
                {
                    document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = false;
                    document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = false;
                    //$(".collapseTwo").attr("id", "");
                    $(".collapseThree").attr("id", "");
                    $(".third_life").addClass("disabled_panel");
                    $(".third_life").removeClass("normal_panel").removeClass("active_panel");
                    $("input[name='third_life'][value='Yes']").prop('checked',false);
                    $("input[name='third_life'][value='No']").prop('checked',true);
                    
                    $("input[name='tlife_gender'][value='Male']").prop('checked',true);
                    $("input[name='tlife_gender'][value='Female']").prop('checked',false);
                    console.log("cheked modern famil2 5108 ddlArray");
                    //to check 16 may 2022
                    /*var ddloption = document.getElementById("al_person_details.slife.relationship");
                    //console.log("options ddloption "+ddloption);
                    ddloption.options.length=0;
                    for(var i = 0; i < ddlArray.length; i++)
                    {
                        var optn=document.createElement("option");
                        optn.value=ddlArray[i];
                        optn.text=ddlArray[i];
                        ddloption.appendChild(optn);
                    }*/
                    
                    if((Client_id == "" || Client_id == null || Client_id == "null" || Client_id == "(null)") && (replicate_res == "" || replicate_res == null || replicate_res == "null" || replicate_res == "(null)"))
                    {
                        if((document.getElementById("al_person_details.mlife.anb").value > 16 && !isILproduct) || (ilANB > 16 && isILproduct))
                        {
                            if((document.getElementById("al_person_details.mlife.anb").value==17 || document.getElementById("al_person_details.mlife.anb").value==18)  && !isILproduct)
                            {
                                if(client_ylp_type_mlife=="lo" && (Client_id!="" && Client_id!=null && Client_id!="null"))
                                {
                                    document.getElementById("al_person_details.slife.relationship").value = "Parent";
                                    document.getElementById("al_person_details.slife.relationship").disabled = false; // changes made by pramod chavan "True" to "False" for prodcution defect---PRUW00037533
                                    console.log("17 disable");
                                }
                            }else if((ilANB == 17 || ilANB == 18) && isILproduct)
                            {
                                if(client_ylp_type_mlife=="lo" && (Client_id!="" && Client_id!=null && Client_id!="null"))
                                {
                                    document.getElementById("al_person_details.slife.relationship").value = "Parent";
                                    document.getElementById("al_person_details.slife.relationship").disabled = false; // changes made by pramod chavan "True" to "False" for prodcution defect---PRUW00037533
                                    console.log("17 disable");
                                }
                            }
                            else
                            {
                               //commented by ankita on 10 april 2022 //document.getElementById("al_person_details.slife.relationship").value="Spouse";
                                //document.getElementById("al_person_details.slife.relationship").disabled = true;
                                console.log("18 disable");
                            }
                        }
                    }else if((Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)") || (replicate_res != "" && replicate_res != null && replicate_res != "null" && replicate_res != "(null)"))
                    {
                        if(typeof pre_natal_handle == "undefined" || pre_natal_handle=="")
                        {
                             console.log("client_ylp_type_mlife11--->"+client_ylp_type_mlife)
                                pre_natal_handle = "No";
                                if((document.getElementById("al_person_details.mlife.anb").value <=16 && !isILproduct) || (ilANB <=16 && isILproduct))
                                {
                                    client_ylp_type_mlife = "lo";
                                }
                        }
                        
                        if(((document.getElementById("al_person_details.mlife.anb").value > 16 && !isILproduct) || (ilANB > 16 && isILproduct)) && (typeof relationship_mlife == 'undefined' || relationship_mlife == "" || relationship_mlife == "H" || relationship_mlife == "W" || relationship_mlife == "F" || relationship_mlife == "M"))
                        {
                           //commented by ankita for defect 226 //setTimeout(function(){document.getElementById("al_person_details.slife.relationship").value = "Spouse";},0.1);
                            //commented by ankita for modern family as relationship was getting disable for you spouse scenario
                            document.getElementById("al_person_details.slife.relationship").disabled = true;
                            console.log("19 disable");
                        }else if(((document.getElementById("al_person_details.mlife.anb").value == 16 && !isILproduct) || (ilANB == 16 && isILproduct)) && (client_ylp_type_mlife == "you"  || client_ylp_type_mlife == "spouse") && (typeof relationship_mlife == 'undefined' || relationship_mlife == "" || relationship_mlife == "H" || relationship_mlife == "W" || relationship_mlife == "F" || relationship_mlife == "M"))
                        {
                            document.getElementById("al_person_details.slife.relationship").value = "Parent";
                            document.getElementById("al_person_details.slife.relationship").disabled = false; // changes made by pramod chavan "True" to "False" for prodcution defect---PRUW00037533
                            console.log("20 disable");
                        }else if(((pre_natal_handle == "No" && ((document.getElementById("al_person_details.mlife.anb").value <=18 && !isILproduct) || (ilANB <=18 && isILproduct))) || pre_natal_handle == "Yes") && (relationship_mlife == "C") && client_ylp_type_mlife == "lo")
                        {
                            if(relationship_slife == "F" || relationship_slife == "M" || relationship_slife == "" || typeof relationship_slife == "undefined")
                            {
                                document.getElementById("al_person_details.slife.relationship").value = "Parent";
                                document.getElementById("al_person_details.slife.relationship").disabled = false;
                                
                                if(document.getElementById("al_sqs_details.third_parti_flg_yes").checked)
                                {
                                    document.getElementById("al_person_details.tlife.relationship").value = "Parent";
                                    document.getElementById("al_person_details.tlife.relationship").disabled = false;
                                }

                            }else
                            {
                                console.log("relationship_mlife in validations 4:: "+relationship_mlife+" --- "+relationship_slife);
                                document.getElementById("al_person_details.slife.relationship").value = "Select Relationship";
                               
                                //commented by ankita on 8 april 2022
                                //document.getElementById("al_person_details.slife.relationship").disabled = true;
                                console.log("21 disable");
                            }
                        }else
                        {
                            console.log("relationship_mlife in validations 5:: "+relationship_mlife+" --- "+relationship_slife);
                            //commented by ankita for modern family CR on 8 april 2022
                            //document.getElementById("al_person_details.slife.relationship").value = "Select Relationship";
                            //document.getElementById("al_person_details.slife.relationship").disabled = true;
                            console.log("22 disable");
                        }
                        
                        //added for defect 226 by ankita on 26 april 2022
                        
                          /* if(replicate_res != "" && replicate_res != null && replicate_res != "null" && replicate_res != "(null)")
                           {
                               fnGetRelationshipList('al_person_details.mlife.anb_il_product','al_person_details.slife.anb_il_product','','al_person_details.slife.relationship','al_person_details.slife.gender_male','al_person_details.slife.gender_female','mySolutions');
                           
                             var gender="";
                             if(document.getElementById("al_person_details.slife.gender_male").checked)
                             {
                            
                             gender="Male";
                             }
                             if(document.getElementById("al_person_details.slife.gender_female").checked)
                             {
                             gender="Female";
                             }
                             console.log("gender 9319 checkdate:"+gender+"--relationship_mlife:"+relationship_mlife);
                             var returnValueRelation=fnMsPopulateRelationship(relationship_mlife,gender);
                            console.log("returnValueRelation:"+returnValueRelation);
                            
                        setTimeout(function(){document.getElementById("al_person_details.slife.relationship").value = returnValueRelation;},0.1);
                        //document.getElementById("al_person_details.slife.relationship").value=returnValueRelation;
                             console.log("disabled 4");
                             document.getElementById("al_person_details.slife.relationship").disabled=true;
                             console.log("relation:"+document.getElementById("al_person_details.slife.relationship").value);
                           }*/
                            
                        
                    }
                    
                    //end here
                    if((document.getElementById("al_person_details.slife.relationship").value == "Spouse" ||  document.getElementById("al_person_details.slife.relationship").value == "Select Relationship" ))//Added By Rahul on 05-11-2015 and modified by Praveen on 01.04.2016
                    {
                        console.log("8.in display none");
                        document.getElementById("third_life_party_flag").style.display = 'none';
                    }
                    else
                    {
                        document.getElementById("third_life_party_flag").style.display = 'block';
                    }
                }
                if(((document.getElementById("al_person_details.mlife.anb").value == 17 || document.getElementById("al_person_details.mlife.anb").value == 18)  && !isILproduct) && document.getElementById("al_sqs_details.sec_parti_flag_yes").checked && (Client_id!="" && Client_id!=null && Client_id!="null") && relationship_mlife=="C")
                {
                    console.log("---->3");
                    fnMsPersonalPopulateValues("al_person_details.slife.first_name_dropdown","slife")
                }else if(((ilANB == 17 || ilANB == 18)  && isILproduct) && document.getElementById("al_sqs_details.sec_parti_flag_yes").checked && (Client_id!="" && Client_id!=null && Client_id!="null") && relationship_mlife=="C")
                {
                    console.log("---->3");
                    fnMsPersonalPopulateValues("al_person_details.slife.first_name_dropdown","slife")
                }
                
            }
            //added by ankita on 26 jan 2022
            /*console.log("Channel:"+Channel+"--ilANB:"+ilANB);
            if(Channel === "Banca")
            {
                console.log("Inside banca isILproduct:"+isILproduct);
            if(ilANB >= 17 && ilANB <= 60)
            {
            /*var ddloption = document.getElementById("al_person_details.slife.relationship");
            //console.log("options ddloption "+ddloption);
            console.log("Ankita true inside all dropdown set2");
            ddloption.options.length=0;
            for(var i = 0; i < ddlArray.length; i++)
            {
                var optn=document.createElement("option");
                optn.value=ddlArray[i];
                optn.text=ddlArray[i];
                ddloption.appendChild(optn);
            }*/
            
            
            
            /*if(client_ylp_type_mlife=="lo" && (Client_id!="" && Client_id!=null && Client_id!="null"))
            {
                document.getElementById("al_person_details.slife.relationship").value = "Parent";
                //document.getElementById("al_person_details.slife.relationship").disabled = false; // changes made by pramod chavan "True" to "False" for prodcution defect---PRUW00037533
                console.log("3 disable");
            }*/
               /* if(client_ylp_type_mlife=="lo" || (Client_id=="" || Client_id==null || Client_id=="null"))
                           {
                document.getElementById("al_person_details.slife.relationship").disabled = false;
                    document.getElementById("al_person_details.slife.relationship").options[2].selected=true;
                           }
                
            }
            }*/
            //end here
            console.log("Channel:"+Channel+"--ilANB:"+ilANB);
            //added by ankita on 25 march 2022 for modern family CR
            /*if(parseInt(document.getElementById("al_person_details.mlife.anb_il_product").value) > 16)
            {
                console.log("checkdate fnGetRelationshipList:"+relationship_mlife);
                //added by ankita on 10 april 2022
             if((relationship_mlife=="" || relationship_mlife=="undefined") || (replicate_res != "" && replicate_res != null && replicate_res != "null" && replicate_res != "(null)"))
             {
                 fnGetRelationshipList('al_person_details.mlife.anb_il_product','al_person_details.slife.anb_il_product','','al_person_details.slife.relationship','al_person_details.slife.gender_male','al_person_details.slife.gender_female','mySolutions');
             }
            }*/
            //added condition of tlife by ankita for defect 291
            //change by ankita on 8 dec change for prod defect internal issue
          console.log("persontype:"+persontype+"-comefrom:"+comefrom);
           //modified condition by ankita for PAMBNEWP-14733 on 27 march 2023
            /*if(parseInt(document.getElementById("al_person_details.mlife.anb_il_product").value) > 16 && persontype!=="tlife" && comefrom!="change")
           {
               console.log("inside relationship 5607")
               if(relationship_mlife=="C")
               {
                   fnGetRelationshipList('al_person_details.mlife.anb_il_product','al_person_details.slife.anb_il_product','','al_person_details.slife.relationship','al_person_details.slife.gender_male','al_person_details.slife.gender_female','mySolutionsChildCase');
                   
               }
               else
               {
                   //if else modified by ankita on 21 april 2022 for spouse scenario for modern family CR
                   if(client_ylp_type_mlife==="lo")
                   {
                       fnGetRelationshipList('al_person_details.mlife.anb_il_product','al_person_details.slife.anb_il_product','','al_person_details.slife.relationship','al_person_details.slife.gender_male','al_person_details.slife.gender_female','mySolutions');
                   }
                   else if((client_ylp_type_slife==="spouse" || client_ylp_type_slife==="you") && client_ylp_type_mlife!=="lo")
                   {
                       console.log("disabled 3 checkdate");
    
                       document.getElementById("al_person_details.slife.relationship").value="Spouse";
                      document.getElementById("al_person_details.slife.relationship").disabled=true;
                       
                   }
               }
           }*/
           //modified condition by ankita for PAMBNEWP-14733 on 27 march 2023
            if(parseInt(document.getElementById("al_person_details.mlife.anb_il_product").value) > 16 && persontype!=="tlife" && comefrom!="change")
            {
            if((client_ylp_type_slife==="spouse" || client_ylp_type_slife==="you") && client_ylp_type_mlife!=="lo")
                           {
                               console.log("disabled 3 checkdate");
            
                               document.getElementById("al_person_details.slife.relationship").value="Spouse";
                              document.getElementById("al_person_details.slife.relationship").disabled=true;
                               
                           }
            }
            
            //added by ankita on 18 april 2022 for modern family CR
            //added condition of tlife by ankita for defect 291
            //added condition of prenatal by ankita for defect 305
            console.log("persontype:"+person_type);
            if(parseInt(document.getElementById("al_person_details.mlife.anb_il_product").value) < 17 &&  document.getElementById("al_sqs_details.third_parti_flg_yes").checked==false &&  document.getElementById("al_person_details.pre_natal_child_flg").checked===false)
            {
                console.log("Less anb modern family");
                if((relationship_mlife!=="" && relationship_mlife!=="C" && document.getElementById("al_employee_details.mlife.occupation").value!="Child"))
                {
                    fnGetRelationshipList('al_person_details.mlife.anb_il_product','al_person_details.slife.anb_il_product','','al_person_details.slife.relationship','al_person_details.slife.gender_male','al_person_details.slife.gender_female','mySolutionsOcc');
                }
                else if((comefrom==="change"))
                {
                    fnGetRelationshipList('al_person_details.mlife.anb_il_product','al_person_details.slife.anb_il_product','','al_person_details.slife.relationship','al_person_details.slife.gender_male','al_person_details.slife.gender_female','mySolutions');
                    
                }
                
            }
            if(document.getElementById("al_person_details.pre_natal_child_flg").checked===true)
            {
                document.getElementById("al_person_details.slife.relationship").value="Parent";
                
            }
            
           /* if(ilANB < 16)
            {
                var arrMatrix=new Array();
                var arrmatrix1Options = document.getElementById("al_person_details.slife.relationship");
             if(document.getElementById("al_person_details.slife.gender_male").checked)
              {
             arrmatrix1Options.options.length=0;
                  arrMatrix=arrmatrixMale;
                  //var arrmatrix1=["Parent","Legal Guardian","Grandfather","Cousin Brother","Uncle","Step Father","Brother","Step Brother"];
              }
             if(document.getElementById("al_person_details.slife.gender_female").checked)
             {
             arrmatrix1Options.options.length=0;
                 arrMatrix=arrmatrixFemale;
             //var arrmatrix1=["Parent","Legal Guardian","Grandmother","Cousin Sister","Aunty","Step Mother","Sister","Step Brother"];
             }
                 
             for(var i = 0; i < arrMatrix.length; i++)
             {
                 var optn=document.createElement("option");
                 optn.value=arrMatrix[i];
                 optn.text=arrMatrix[i];
                 arrmatrix1Options.appendChild(optn);
             }
            
            
            
            
                if(client_ylp_type_mlife=="lo" || (Client_id=="" || Client_id==null || Client_id=="null"))
                           {
                document.getElementById("al_person_details.slife.relationship").disabled = false;
                    //document.getElementById("al_person_details.slife.relationship").options[2].selected=true;
                           }
                
            
            }*/
            
            //end here
            if (DateValueId == "al_person_details.slife.dob")
            {
                var monthOfDOB = date1.getMonth() + 1;
                var dayOfDOB = date1.getDate();
                var monthOfInception = mm1;
                var dayOfInception = dd1;
                var yearOfDOB = date1.getFullYear();
                var yearOfInception = yyyy1;
                
                var DobinDays = (monthOfDOB * 31) + dayOfDOB;
                var InceptioninDays = (monthOfInception * 31) + dayOfInception;
                
                if (DobinDays < InceptioninDays) {
                    calculatedAge = yearOfInception - yearOfDOB + 1;
                } else {
                    calculatedAge = yearOfInception - yearOfDOB;
                }
                if (calculatedAge < 1) {
                    calculatedAge = 1;
                }
                document.getElementById("al_person_details.slife.anb").value = calculatedAge;
                
                document.getElementById("al_person_details.slife.anb_il_product").value=calculatedAge//Added for OS to IL Conversion by Sachin T.
                document.getElementById("al_person_details.slife.anb_il_monthly_product").value=calculatedAge//Added for OS to IL Conversion by Sachin T.
                
                
                
                var Mlanb = document.getElementById("al_person_details.mlife.anb").value;
                var MlanbIL = document.getElementById("al_person_details.mlife.anb_il_product").value;
                var Slanb = document.getElementById("al_person_details.slife.anb").value;
                var SlanbIL = document.getElementById("al_person_details.slife.anb_il_product").value;
                //Commented by Paromita for defect 5431 on 3 July 2018
                
                /*** @
                following code commented by Sachin Tupe for remove condtion of message "Age Next Birthday for spouse should be between 20 and 40 (inclusive)" for agency channel.
                 on date 30 july 2018.
                 
                 
            @****/
             /**  if((Channel != "Banca" && Channel != "UOB") && (checkPRUwithyou!="PRUwith you" && checkPRUwithyou!="PRUcancer X"))//changed by Purva / Pramod C on 07th Aug 2017 for UOB,2..Sachin Tupe for defect 5589 on 21-06-2018.
                {
                    
                    if ((Slanb < 20 || (SlanbIL < 20 && isILproduct)) && (document.getElementById("al_person_details.slife.relationship").value == "Spouse"))//Added checkPRUwithyou varible by
                        {
                            alert("392");
                            fnMsDisableDropdownChange("spouse");
                            document.getElementById("al_person_details.slife.anb").value = "";
                            document.getElementById("al_person_details.slife.dob").value = "";
                            return false;
                        }
                }*****/
                
                if(Channel == "Banca" /*|| Channel == "UOB" changed for defect 5084 by sachin T.*/)//changed by Purva / Pramod C on 07th Aug 2017 for UOB
                {
                    if(document.getElementById("al_person_details.pre_natal_child_flg").checked)
                    {
                        if(getGender("slife")=="Female")
                        {
                            //change anb 19 to 17 for modern family CR by ankita on 3 may 2022
                             if((Slanb<17 && !isILproduct) || (SlanbIL < 17 && isILproduct))
                             {
                                 alert("224","17");
                                 document.getElementById("al_person_details.slife.anb").value = "";
                                 document.getElementById("al_person_details.slife.dob").value = "";
                                 return false;
                             }
                            else if((Slanb>45 && !isILproduct) || (SlanbIL > 45 && isILproduct))
                            {
                                alert("216","45");
                                document.getElementById("al_person_details.slife.anb").value = "";
                                document.getElementById("al_person_details.slife.dob").value = "";
                                return false;
                            }
                        }
                        else if(getGender("slife")=="Male")
                        {
                            //change anb 19 to 17 for modern family CR by ankita on 3 may 2022
                            if((Slanb<17 && !isILproduct) || (SlanbIL < 17 && isILproduct))
                            {
                                alert("224","17");
                                document.getElementById("al_person_details.slife.anb").value = "";
                                document.getElementById("al_person_details.slife.dob").value = "";
                                return false;
                            }
                            //Following 70 value to changes to 100 for "PAMBNEWP-4410 Allowed Assured above age 70 v0.3_Half" by sachin on 5-4-2022
                            else if((Slanb>100 && !isILproduct) || (SlanbIL > 100 && isILproduct))
                            {
                              //  alert("216","70");
                                alert("216","100")
                                document.getElementById("al_person_details.slife.anb").value = "";
                                document.getElementById("al_person_details.slife.dob").value = "";
                                return false;
                            }
                        }
                    }
                    else if(!document.getElementById("al_person_details.pre_natal_child_flg").checked)
                    {
                        if((Mlanb<=18 && !isILproduct) || (MlanbIL<=18 && isILproduct))
                        {
                            //change anb 19 to 17 for modern family CR by ankita on 3 may 2022
                            if((Slanb<17 && !isILproduct) || (SlanbIL< 17 && isILproduct))
                            {
                                alert("224","17");
                                document.getElementById("al_person_details.slife.anb").value = "";
                                document.getElementById("al_person_details.slife.dob").value = "";
                                return false;
                            }
                            //Following 70 value to changes to 100 for "PAMBNEWP-4410 Allowed Assured above age 70 v0.3_Half" by sachin on 5-4-2022
                            else if((Slanb>100 && !isILproduct) || (SlanbIL> 100 && isILproduct))
                            {
                                //alert("216","70");
                                alert("216","100");
                                document.getElementById("al_person_details.slife.anb").value = "";
                                document.getElementById("al_person_details.slife.dob").value = "";
                                return false;
                            }
                        }
                        else if((Slanb<17 && !isILproduct) || (SlanbIL < 17 && isILproduct))// 7406 sachin july release//change anb 19 to 17 for modern family CR by ankita on 3 may 2022
                        {
                            
                            alert("224","17");
                            document.getElementById("al_person_details.slife.anb").value = "";
                            document.getElementById("al_person_details.slife.dob").value = "";
                            return false;
                        }
                        //Following 70 value to changes to 100 for "PAMBNEWP-4410 Allowed Assured above age 70 v0.3_Half" by sachin on 5-4-2022
                        else if((Slanb>100 && !isILproduct) || (SlanbIL> 100 && isILproduct))//1111 else if added by SR for def 7872 CR pratibha on call confirmation july release
                        {
                            //alert("216","70");
                            alert("216","100")
                            document.getElementById("al_person_details.slife.anb").value = "";
                            document.getElementById("al_person_details.slife.dob").value = "";
                            return false;
                        }
                      /***  else if ((Mlanb > 18 && Mlanb <= 30 && !isILproduct) || (MlanbIL > 18 && MlanbIL <= 30 && isILproduct))
                        {
                            if ((Slanb < 20 || Slanb > 40) && !isILproduct && (document.getElementById("al_person_details.slife.relationship").value == "Spouse"))
                            {
                                alert("286");
                                document.getElementById("al_person_details.slife.anb").value = "";
                                document.getElementById("al_person_details.slife.dob").value = "";
                                return false;
                            }else if ((SlanbIL < 20 || SlanbIL > 40) && isILproduct && (document.getElementById("al_person_details.slife.relationship").value == "Spouse"))
                            {
                                alert("286");
                                document.getElementById("al_person_details.slife.anb").value = "";
                                document.getElementById("al_person_details.slife.dob").value = "";
                                return false;
                            }
                        }********/
                         //below else if condition is removed for def-5949 and 6288 20 60 alert by sourabh and sachin on 28-sept-2018
                      /* else if ((Mlanb >= 31 && Mlanb <= 70 && !isILproduct) || (MlanbIL >= 31 && MlanbIL <= 70 && isILproduct))
                        {
                            console.log("!isILproduct"+!isILproduct);
                            if((Slanb < 20 || Slanb > 60) && !isILproduct)
                            {
                                alert("287");
                                document.getElementById("al_person_details.slife.anb").value = "";
                                document.getElementById("al_person_details.slife.dob").value = "";
                                return false;
                            }else if((SlanbIL < 20 || SlanbIL > 60) && isILproduct)
                            {
                                
                                alert("287");
                                document.getElementById("al_person_details.slife.anb").value = "";
                                document.getElementById("al_person_details.slife.dob").value = "";
                                return false;
                            }*/
                            /************Following code commented by Sachin tupe for defect 5431 on date 06-08-2018
                            else
                                if ((Slanb >= 31 || Slanb <= 50) && !isILproduct)
                                {
                                    if((Slanb - Mlanb) > 10)
                                    {
                                        alert("221");
                                        document.getElementById("al_person_details.slife.anb").value = "";
                                        document.getElementById("al_person_details.slife.dob").value = "";
                                        return false;
                                    }
                                }else if ((SlanbIL >= 31 || SlanbIL <= 50) && isILproduct)
                                {
                                    if((SlanbIL - MlanbIL) > 10)
                                    {
                                        alert("221");
                                        document.getElementById("al_person_details.slife.anb").value = "";
                                        document.getElementById("al_person_details.slife.dob").value = "";
                                        return false;
                                    }
                                }//
                             **************************************************************************/
                       // }
                    }
                
                if (document.getElementById("al_person_details.slife.relationship").value == "Parent" && document.getElementById("al_person_details.slife.gender_female").checked && document.getElementById("al_person_details.pre_natal_child_flg").checked == true)
                {
                   
                    if ((document.getElementById("al_person_details.slife.anb_il_product").value <= 18 || document.getElementById("al_person_details.slife.anb_il_product").value >= 46) && isILproduct) {
                        document.getElementById("al_person_details.slife.anb").value = "";
                        document.getElementById("al_person_details.slife.dob").value = "";
                        alert("222");
                        return false;
                    }
                    
                    
                    
                    
                    if ((document.getElementById("al_person_details.slife.anb").value <= 18 || document.getElementById("al_person_details.slife.anb").value >= 46) && !isILproduct) {
                        alert("222");
                        document.getElementById("al_person_details.slife.anb").value = "";
                        document.getElementById("al_person_details.slife.dob").value = "";
                        return false;
                    }
                }
                }
                //Following 70 value to changes to 100 for "PAMBNEWP-4410 Allowed Assured above age 70 v0.3_Half" by sachin on 5-4-2022
                else if ((Slanb > 100 && !isILproduct) || (SlanbIL> 100 && isILproduct))
                {
                   // alert("216","70");
                    alert("216","100")
                    //Changed on 22.10.14 from mlife to slife
                    document.getElementById("al_person_details.slife.anb").value = "";
                    document.getElementById("al_person_details.slife.dob").value = "";
                    return false;
                }
                else if (((Slanb < 17 && !isILproduct) || (SlanbIL < 17 && isILproduct)) && document.getElementById("al_person_details.pre_natal_child_flg").checked == true)
                {//chenged by Rahul 18 to 19 on 21-12-2015
                    document.getElementById("al_person_details.slife.anb").value = "";
                    document.getElementById("al_person_details.slife.dob").value = "";
                    alert("710");
                    return false;
                }
                else if (((Slanb < 17 && !isILproduct) || (SlanbIL < 17 && isILproduct)))
                {//chenged by Praveen 18 to 19 on 11-01-2016
                    document.getElementById("al_person_details.slife.anb").value = "";
                    document.getElementById("al_person_details.slife.dob").value = "";
                    alert("710");
                    return false;
                }

            }
            
            if (DateValueId == "al_person_details.tlife.dob")
            {
                var monthOfDOB = date1.getMonth() + 1;
                var dayOfDOB = date1.getDate();
                var monthOfInception = mm1;
                var dayOfInception = dd1;
                var yearOfDOB = date1.getFullYear();
                var yearOfInception = yyyy1;
                
                var DobinDays = (monthOfDOB * 31) + dayOfDOB;
                var InceptioninDays = (monthOfInception * 31) + dayOfInception;
                
                if (DobinDays < InceptioninDays)
                {
                    calculatedAge = yearOfInception - yearOfDOB + 1;
                }
                else
                {
                    calculatedAge = yearOfInception - yearOfDOB;
                }
                
                if (calculatedAge < 1)
                {
                    calculatedAge = 1;
                }
                document.getElementById("al_person_details.tlife.anb").value = calculatedAge;
                document.getElementById("al_person_details.tlife.anb_il_monthly_product").value = calculatedAge;//Added for OS to IL Conversion by Sachin T.
                var Tlanb = document.getElementById("al_person_details.tlife.anb").value
                var TlanbIL = document.getElementById("al_person_details.tlife.anb_il_product").value;// added for IL ANB changes.
                
                    if ((Tlanb < 18 && !isILproduct) || (TlanbIL < 18 && isILproduct))
                    {
                        alert("224","18");
                        document.getElementById("al_person_details.tlife.anb").value = "";
                        document.getElementById("al_person_details.tlife.dob").value = "";
                        return false;
                    }
                    else if ((Tlanb > 70 && !isILproduct) || (TlanbIL> 70 && isILproduct))
                    {
                        alert("216","70");
                        document.getElementById("al_person_details.tlife.anb").value = "";
                        document.getElementById("al_person_details.tlife.dob").value = "";
                        return false;
                    }
                else if(Channel=="Banca" || Channel == "UOB")//changed by Purva / Pramod C on 07th Aug 2017 for UOB
                {
                    if(document.getElementById("al_person_details.pre_natal_child_flg").checked)
                    {
                        if(getGender("tlife")=="Female")
                        {
                            // changes 19 to 18 for DEF-4451
                            if((Tlanb<18 && !isILproduct) ||( TlanbIL<18 && isILproduct))
                            {
                                alert("224","18");
                                document.getElementById("al_person_details.tlife.anb").value = "";
                                document.getElementById("al_person_details.tlife.dob").value = "";
                                return false;
                            }
                            else if((Tlanb>45 && !isILproduct) || (TlanbIL> 45 && isILproduct))
                            {
                                alert("216","45");
                                document.getElementById("al_person_details.tlife.anb").value = "";
                                document.getElementById("al_person_details.tlife.dob").value = "";
                                return false;
                            }
                        }
                        else if(getGender("tlife")=="Male")
                        {
                            if((Tlanb<18 && !isILproduct) || (TlanbIL<18 && isILproduct))
                            {
                                alert("224","18");
                                document.getElementById("al_person_details.tlife.anb").value = "";
                                document.getElementById("al_person_details.tlife.dob").value = "";
                                return false;
                            }
                            else if((Tlanb>70 && !isILproduct) || (TlanbIL> 70 && isILproduct))
                            {
                                alert("216","70");
                                document.getElementById("al_person_details.tlife.anb").value = "";
                                document.getElementById("al_person_details.tlife.dob").value = "";
                                return false;
                            }
                        }
                    }
                    else if(!document.getElementById("al_person_details.pre_natal_child_flg").checked)
                    {
                        if ((Tlanb < 18 && !isILproduct) || (TlanbIL < 18 && isILproduct))
                        {
                            alert("224","18");
                            document.getElementById("al_person_details.tlife.anb").value = "";
                            document.getElementById("al_person_details.tlife.dob").value = "";
                            return false;
                        }
                        else if ((Tlanb > 70 && !isILproduct) || (TlanbIL> 70 && isILproduct))
                        {
                            alert("216","70");
                            document.getElementById("al_person_details.tlife.anb").value = "";
                            document.getElementById("al_person_details.tlife.dob").value = "";
                            return false;
                        }
                    }
                }
            }
            else
            {
                document.getElementById(DateValueId).value = "";
            }
        }
    }

    if (DateValueId == "al_person_details.mlife.expected_delivery_dt")
    {
        date1 = new Date(eval(year), eval(month-1), eval(day)); // -1 added by pramod chavan for Production defect PRUW00037432
        console.log("consider date1-->"+date1);
        var systemdate = new Date();
        if(sysdate!=""){
             systemdate = new Date(sysdate);
        }else{
             systemdate = new Date();
        }
        var dd = systemdate.getDate();
        var mm = systemdate.getMonth(); //January is 0!
       var yyyy = systemdate.getFullYear();
       var date2 = new Date(eval(yyyy), eval(mm), eval(dd));
        var diffDays = Math.round(Math.abs((date1.getTime() - date2.getTime()) / (oneDay)))
        console.log("difference date"+diffDays);
        var weeks = eval(diffDays) / 7;
        console.log("weeks is"+weeks);
        var weekstr = weeks;
        
        console.log("weekstr :: "+weekstr)
        //weekstr = Math.ceil(weekstr);//added by sachin production def- 11-9-2017
        weekstr = Math.floor(weekstr);//added by sachin production def- 11-9-2017
        //channel condition of agency added by ankita for pruwith you new rider changes of mom and baby care on 26 nov 2022
        /*if(Channel=="Agency" || Channel==="FA")
        {
            weekstr = 45 - weekstr;
        }
        else
        {*/
            weekstr = 40 - weekstr;
        //}
        //weekstr = 40 - weekstr;
        console.log("after 40- "+weekstr);
         weekstr = Math.floor(weekstr);
         
        /*if(weekstr >= 17 && weekstr < 35)
        {
            console.log("in check 17");
            weekstr = Math.floor(weekstr);
            console.log("week condi"+weekstr );
        }else
        {
            console.log("in else part of condition")
            weekstr = Math.ceil(weekstr);
            console.log("math ceil value"+weekstr);
        }
*/
        var diffYears = date1.getFullYear() - yyyy;
        console.log("differ year"+diffYears);
        var diffMonths = date1.getMonth() - mm;
        console.log("differ months"+diffMonths);
        var diffDays = date1.getDate() - dd;
        console.log("differ day"+diffDays);
        var diffDaysNumber;
        var diffMonthsNumber;
        
        if (diffYears < 0)
        {
            alert("217");
            document.getElementById(DateValueId).value = "";
            document.getElementById("al_person_details.gestational_week").value = "Gestational Week";
            return;
        }
        
        var months = (diffYears * 12 + diffMonths);
        if (diffDays > -1)
        {
            console.log(" in if differ day > -1");
            diffMonthsNumber = months;
            console.log("in condi differ months"+diffMonthsNumber);
            months += '.' + diffDays;
            console.log("dotted months"+months);
            diffDaysNumber = diffDays;
            console.log("founded day difference"+diffDaysNumber);
        }
        else if (diffDays <= -1)
        {
            months--;
            diffMonthsNumber = months;
            months += '.' + (new Date(date1.getFullYear(), date1.getMonth(), 0).getDate() + diffDays);
            diffDaysNumber = new Date(date1.getFullYear(), date1.getMonth(), 0).getDate() + diffDays;
        }
        console.log("weekstr:"+weekstr+"--diffMonthsNumber:"+diffMonthsNumber);
        if (diffMonthsNumber < 0 || weekstr<=0)
        {
            //condition added by ankita on 25 nov 2022 for pruwith you product changes of mom and baby care rider
            /*if(Channel==="Agency" || Channel==="FA")
            {
               alert("869");
            }
            else
            {*/
               alert("218");
           // }
            
            document.getElementById(DateValueId).value = "";
            document.getElementById("al_person_details.gestational_week").value = "Gestational Week";
            return;
        }
        else
        {
            if ((weekstr >= 14 && weekstr <= 40) && (easeCampaignCode=="" && (easeCampaignCode!="EASE1" || easeCampaignCode!="EASE2")) && Channel!="Agency" && Channel!="FA") //checked 18 week to 14 for PRUwith you product by sachin on 19 Dec 2017//agency condition added by ankita on 25 nov 2022 for pruwith you product changes of mom and baby care rider
            {
                console.log("if weel greater than 18 ")
                document.getElementById(DateValueId).value = DateValue;
                console.log("obtained date"+DateValue);
                
                document.getElementById("al_person_details.gestational_week").value = weekstr;
                console.log("required week value"+weekstr);
            }
            else if ((weekstr >= 13 && weekstr <= 45) && (easeCampaignCode=="" && (easeCampaignCode!="EASE1" || easeCampaignCode!="EASE2")) && (Channel==="Agency" || Channel==="FA"))//condition added by ankita on 25 nov 2022 for pruwith you product changes of mom and baby care rider
            {
                console.log("if weel greater than 18 ")
                document.getElementById(DateValueId).value = DateValue;
                console.log("obtained date"+DateValue);
                
                document.getElementById("al_person_details.gestational_week").value = weekstr;
                console.log("required week value"+weekstr);
            }
            else if ((weekstr >= 13 && weekstr <= 45) && (Channel==="UOB" || Channel=="Banca"))//Pradnya: for nov23 release for min13 GW CR //Pradnya: added banca for def 1408 for may release for PRUsignature assure
            {
                console.log("if weel greater than 18 ")
                document.getElementById(DateValueId).value = DateValue;
                console.log("obtained date"+DateValue);
                
                document.getElementById("al_person_details.gestational_week").value = weekstr;
                console.log("required week value"+weekstr);
            }
                                           
        /*    else if(weekstr < 18) //this else if condition is old for all product
            {
                alert("277");
                document.getElementById("al_person_details.gestational_week").value = "Gestational Week";
                document.getElementById(DateValueId).value = "";
                return false;
            }*/
            else if((weekstr < 14) && (easeCampaignCode=="" && (easeCampaignCode!="EASE1" || easeCampaignCode!="EASE2")) && Channel!="Agency" && Channel!="FA" && Channel!="UOB" && Channel!="Banca") //this else if condition is for PRUwith you  and  all product by sachin 19-DEC-2017//Pradnya: added UOB for nov23 release for PRUlink cover ,Pradnya: added banca for def 1408 for may release for PRUsignature assure
            {
                alert("277");
                document.getElementById("al_person_details.gestational_week").value = "Gestational Week";
                document.getElementById(DateValueId).value = "";
                return false;
            }
            else if((weekstr < 13) && (easeCampaignCode=="" && (easeCampaignCode!="EASE1" || easeCampaignCode!="EASE2")) && (Channel==="Agency" || Channel==="FA" || Channel == "UOB" || Channel == "Banca"))//Pradnya: added UOB for nov23 release for PRUlink cover //added by ankita for pruwith you new riders on 29 nov 2022 //Pradnya: added banca for def 1408 for may release for PRUsignature assure
            {
                alert("868");
                document.getElementById("al_person_details.gestational_week").value = "Gestational Week";
                document.getElementById(DateValueId).value = "";
                return false;
            }
            /********************************************************************************************************************************************************************
            else if((easeCampaignCode!="" && (easeCampaignCode=="EASE1" || easeCampaignCode=="EASE2")) &&(femaleGender!="F" || femaleAge>40 || female_smoke_status!="No"))
            {
                    alert("277");
                    document.getElementById("al_person_details.gestational_week").value = "Gestational Week";
                    document.getElementById(DateValueId).value = "";
                    return false;
            
            }
            *******************************************************************************************************************************************************************/
            else if(weekstr > 40)//channel condition added by ankita for pruwith you new rider mom and baby care on 30 nov 2022
            {
                alert("218");
                document.getElementById("al_person_details.gestational_week").value = "Gestational Week";
                document.getElementById(DateValueId).value = "";
                return false;
            }
            /*else if(weekstr > 45 && (Channel==="Agency" || Channel==="FA"))//condition added by ankita for pruwith you new rider mom and baby care on 30 nov 2022
            {
                alert("869");
                document.getElementById("al_person_details.gestational_week").value = "Gestational Week";
                document.getElementById(DateValueId).value = "";
                return false;
            }*/
            else if(easeCampaignCode!="" && (easeCampaignCode=="EASE1" || easeCampaignCode=="EASE2"))
            {
                console.log("EASE CAMPAIGN CODE ")
                document.getElementById(DateValueId).value = DateValue;
                console.log("obtained date"+DateValue);
                
                document.getElementById("al_person_details.gestational_week").value = weekstr;
                console.log("required week value"+weekstr);
            
            }
        }
    }
    else
    {
        console.log("in else part");
        document.getElementById(DateValueId).value = DateValue;
        console.log("Datevalue"+DateValue);
    }
    
    if(document.getElementById("al_person_details.mlife.parent_consent_yes").checked && ((document.getElementById("al_person_details.mlife.anb").value >= 11 && document.getElementById("al_person_details.mlife.anb").value <= 16  && !isILproduct) || ((ilANB >= 11 && ilANB <= 16) ||(ilANB_monthly >= 11 && ilANB_monthly <= 16) && isILproduct)))
    {
        console.log("9.in display none");
        document.getElementById("third_life_party_flag").style.display = 'none';
    }
    if(document.getElementById("al_person_details.mlife.anb").value > 18 || ilANB >18)
    {
        console.log("1.in display none prod issue");
        document.getElementById("al_sqs_details.third_parti_flg_no").checked = true;
        document.getElementById("al_sqs_details.third_parti_flg_yes").checked = false;
        document.getElementById("third_life_party_flag").style.display="none";
                                           //change by ankita on 8 dec change for prod defect internal issue
        SetValuesnull(comefrom);
        $(".collapseThree").attr("id", "");
        $(".third_life").addClass("disabled_panel");
        $(".third_life").removeClass("normal_panel").removeClass("active_panel");
    }
    else if((((document.getElementById("al_person_details.mlife.anb").value == 18 || document.getElementById("al_person_details.mlife.anb").value == 17) && !isILproduct) || ((document.getElementById("al_person_details.mlife.anb_il_product").value == 18 || document.getElementById("al_person_details.mlife.anb_il_product").value == 17) && isILproduct)) && (document.getElementById("al_person_details.slife.relationship").value == "Spouse" || document.getElementById("al_person_details.slife.relationship").value == "Select Relationship" || document.getElementById("al_person_details.slife.relationship").value == "SELECT RELATIONSHIP" || document.getElementById("al_person_details.slife.relationship").value == "select relationship" || document.getElementById("al_person_details.slife.relationship").value == ""))
    {
        console.log("10.in display none");
                                           console.log("2.in display none prod issue");
        document.getElementById("al_sqs_details.third_parti_flg_no").checked = true;
        document.getElementById("al_sqs_details.third_parti_flg_yes").checked = false;
        document.getElementById("third_life_party_flag").style.display="none";
                                           //change by ankita on 8 dec change for prod defect internal issue
        SetValuesnull(comefrom);
        $(".collapseThree").attr("id", "");
        $(".third_life").addClass("disabled_panel");
        $(".third_life").removeClass("normal_panel").removeClass("active_panel");
//
        document.getElementById("al_person_details.slife.relationship").disabled = false;// added for defect 8687 9-12-2019.
    }
    else if(document.getElementById("al_person_details.slife.relationship").value == "Parent" || document.getElementById("al_person_details.slife.relationship").value == "Legal Guardian")
    {
        console.log("3.in display none prod issue");
        document.getElementById("third_life_party_flag").style.display = "block";
    }
    if((Client_id == "" || Client_id == null || Client_id == "null" || Client_id == "(null)") && (replicate_res == "" || replicate_res == null || replicate_res == "null" || replicate_res == "(null)"))
    {
        if(((document.getElementById("al_person_details.mlife.anb").value >15 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value >15 && isILproduct)) && (Channel == "Agency" || Channel == "FA") && DateValueId == "al_person_details.mlife.dob")// Piyush (03/12/2018): Changes has been done for New channel
        {
            console.log("ANB_set 17 agency :: "+ANB_set);
            $(".occupationSearchMLifeText").attr("disabled",false);
            $(".natureSearchMLifeText").attr("disabled",false);
            
                console.log("ANB_set 18 :: "+ANB_set);
                fnMsSolSelectElement("Occupation", "al_employee_details.mlife.occupation");
                $(".occupationSearchMLifeText").val("");//Prashant 23.12.2016
                fnMsSolSelectElement("Nature of Business", "al_employee_details.mlife.nature_of_business");
                $(".natureSearchMLifeText").val("");//Prashant 23/12/2016
                document.getElementById("al_employee_details.mlife.occupation_class").value = "";
                
            
        }
    }
    else if((Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)") || (replicate_res != "" && replicate_res != null && replicate_res != "null" && replicate_res != "(null)"))
    {
        if(((document.getElementById("al_person_details.mlife.anb").value >15 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value >15 && isILproduct)) && (Channel == "Agency" || Channel == "FA") && DateValueId == "al_person_details.mlife.dob") // Piyush (03/12/2018): Changes has been done for New channel
        {
            console.log("ANB_set 17 agency :: "+ANB_set);
            $(".occupationSearchMLifeText").attr("disabled",false);
            $(".natureSearchMLifeText").attr("disabled",false);
        }
        
    }


    if(comefrom=="change" && (DateValueId != "al_sqs_details.Inception_dt" && DateValueId!="al_person_details.mlife.expected_delivery_dt"))
    {
        if(Client_id!="" && Client_id!="null" && Client_id!=null && Client_id!="(null)")
        {
            onchangeDeleteExistingQuotation(Client_id,persontype,changeflg);
        }
        else
        {
            onchangeDeleteExistingQuotation(client_id_fresh,persontype,changeflg);
        }
    }

}


//Check Validations on ANB onload   aniket to change
function fnMsCheckValidationonload(DateValueId,ageYears,obj_chk,obj_res)
{
    var oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
    var date1;
    var inceptiondate;
    var dd1;
    var mm1;
    var yyyy1;

    var ageMonths;
    var ageDays;
    
    if (DateValueId == "al_person_details.mlife.dob")
    {
        if ((ageYears > 18 && ageYears <= 70 && !isILproduct) || (ilMainLifeANB > 18 && ilMainLifeANB <= 70 && isILproduct)) // changed by yogesh 0n 7.10.13
        {
            if(document.getElementById(DateValueId).value == "")
            {
                document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = false;
                document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = false;
                $(".collapseThree").attr("id", "");
                $(".third_life").addClass("disabled_panel");
                $(".third_life").removeClass("normal_panel").removeClass("active_panel");
            }
            
            if((document.getElementById("al_person_details.mlife.anb").value >16 && !isILproduct) || (ilMainLifeANB >16 && isILproduct))
            {
                console.log("ANB_set 21 :: "+ANB_set);
                if((ANB_set <= 16 && !isILproduct) || (ilMainLifeANB <= 16 && isILproduct))
                {
                    console.log("ANB_set 22 :: "+ANB_set);
                    fnMsSolSelectElement("Occupation", "al_employee_details.mlife.occupation");
                    $(".occupationSearchMLifeText").val("");//Prashant 23.12.2016
                    fnMsSolSelectElement("Nature of Business", "al_employee_details.mlife.nature_of_business");
                    $(".natureSearchMLifeText").val("");//Prashant 23/12/2016
                    document.getElementById("al_employee_details.mlife.occupation_class").value = "";

                }
            }
            $("input[name='third_life'][value='Yes']").prop('checked',false);
            $("input[name='third_life'][value='No']").prop('checked',true);
        }
        else if ((ageYears < 16 && !isILproduct) || (ilMainLifeANB < 16 && isILproduct))
        {
            //Added by Paromita on 14 Aug 2017 for new Occupation list
            fnMsSolSelectElement("Child", "al_employee_details.mlife.occupation");
            $(".occupationSearchMLifeText").val("Child");
            fnMsSolSelectElement("Child","al_employee_details.mlife.nature_of_business");
            console.log("childee445");

            $(".natureSearchMLifeText").val("Child");
            
            $(".occupationSearchMLifeText").attr("disabled",true);//Added by Sachin for defect 5691
            $(".natureSearchMLifeText").attr("disabled",true);//Added by Sachin for defect 5691.
            fngetOccupationClassFromMatrix("al_employee_details.mlife.occupation","al_employee_details.mlife.nature_of_business","al_employee_details.mlife.occupation_class")
//            var res_occ_class = document.getElementById("al_employee_details.mlife.occupation").value.split("-");
//            document.getElementById("al_employee_details.mlife.occupation_class").value = res_occ_class[1];
            
            ANB_set =  document.getElementById("al_person_details.mlife.anb").value;
            console.log("ANB_set 25 :: "+ANB_set);
            document.getElementById("al_sqs_details.sec_parti_flag_yes").checked = true;
            document.getElementById("al_sqs_details.sec_parti_flag_no").checked = false;
            document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = true;
            $(".collapseTwo").attr("id", "collapseTwo");
            $(".second_life").addClass("normal_panel");
            $(".second_life").removeClass("disabled_panel");
 
            if(obj_chk == "obj_slife")
            {
            if(!(obj_res == "undefined" || obj_res == "" || obj_res == "{}" || obj_res == "null"))
               {
                   
                   if(document.getElementById("al_person_details.slife.gender_male").checked == true && document.getElementById("al_person_details.slife.gender_female").checked == false && document.getElementById("al_person_details.pre_natal_child_flg").checked == true)
                   {
                       document.getElementById("third_life_party_flag").style.display = 'block';
                       document.getElementById("al_sqs_details.third_parti_flg_yes").disabled = true;
                       document.getElementById("al_sqs_details.third_parti_flg_no").disabled = true;
                       
                       $("input[name='third_life'][value='Yes']").prop('checked',true);
                       $("input[name='third_life'][value='No']").prop('checked',false);
                       $(".collapseThree").attr("id", "collapseThree");
                       $(".third_life").addClass("normal_panel");
                       $(".third_life").removeClass("disabled_panel");
                   }
                   else if(document.getElementById("al_person_details.slife.gender_female").checked == true && document.getElementById("al_person_details.slife.gender_male").checked == false && document.getElementById("al_person_details.pre_natal_child_flg").checked == true)
                   {
                       document.getElementById("third_life_party_flag").style.display = 'block';
                       document.getElementById("al_sqs_details.third_parti_flg_yes").disabled = false;
                       document.getElementById("al_sqs_details.third_parti_flg_no").disabled = false;
                       $("input[name='third_life'][value='Yes']").prop('checked',false);
                       $("input[name='third_life'][value='No']").prop('checked',true);
                       $(".collapseThree").attr("id", "");
                       $(".third_life").addClass("disabled_panel");
                       $(".third_life").removeClass("normal_panel");
                       
                       SetValuesnull();
                   }
                   
            if(obj_res["al_person_details.slife.gender"] == "Male" && obj_res["al_person_details.pre_natal_child_flg"] == "Yes")
            {
                document.getElementById("third_life_party_flag").style.display = 'block';
                document.getElementById("al_sqs_details.third_parti_flg_yes").disabled = true;
                document.getElementById("al_sqs_details.third_parti_flg_no").disabled = true;
                
                $("input[name='third_life'][value='Yes']").prop('checked',true);
                $("input[name='third_life'][value='No']").prop('checked',false);
                $(".collapseThree").attr("id", "collapseThree");
                $(".third_life").addClass("normal_panel");
                $(".third_life").removeClass("disabled_panel");
            }
            else if(obj_res["al_person_details.slife.gender"] == "Female" && obj_res["al_person_details.pre_natal_child_flg"] == "Yes")
            {
                document.getElementById("third_life_party_flag").style.display = 'block';
                document.getElementById("al_sqs_details.third_parti_flg_yes").disabled = false;
                document.getElementById("al_sqs_details.third_parti_flg_no").disabled = false;
                $("input[name='third_life'][value='Yes']").prop('checked',false);
                $("input[name='third_life'][value='No']").prop('checked',true);
                $(".collapseThree").attr("id", "");
                $(".third_life").addClass("disabled_panel");
                $(".third_life").removeClass("normal_panel");
                
                SetValuesnull();
            }
               }
            }

        }
        else if(((ageYears < 16 && !isILproduct) || (ilMainLifeANB < 16 &&  isILproduct)) && (Channel == "Agency" || Channel == "FA"))  // Piyush(03/12/2018) : Added this changes for new channel FA
        {
            //Added by Paromita on 14 Aug 2017 for new Occupation list
            fnMsSolSelectElement("Child", "al_employee_details.mlife.occupation");
            $(".occupationSearchMLifeText").val("Child");
            fnMsSolSelectElement("Child","al_employee_details.mlife.nature_of_business");
            console.log("childee55");

            $(".natureSearchMLifeText").val("Child");
        fngetOccupationClassFromMatrix("al_employee_details.mlife.occupation","al_employee_details.mlife.nature_of_business","al_employee_details.mlife.occupation_class")
            
//            var res_occ_class = document.getElementById("al_employee_details.mlife.occupation").value.split("-");
//            document.getElementById("al_employee_details.mlife.occupation_class").value = res_occ_class[1];

        }
        else if(((ageYears == 17 || ageYears == 18) && !isILproduct) || ((ilMainLifeANB == 17 || ilMainLifeANB == 18) && isILproduct))
        {
            
            if(Channel == "Agency" || Channel == "FA")// Piyush (03/12/2018): Changes has been done for New channel
            {
            }else if(Channel == "Banca" || Channel == "UOB")//changed by Purva / Pramod C on 07th Aug 2017 for UOB
            {
                if((ANB_set <= 16 && !isILproduct) || (ilMainLifeANB <= 16 && isILproduct))
                {
                    console.log("ANB_set 28 :: "+ANB_set);
                    fnMsSolSelectElement("Occupation", "al_employee_details.mlife.occupation");
                    $(".occupationSearchMLifeText").val("");//Prashant 23.12.2016
                    fnMsSolSelectElement("Nature of Business", "al_employee_details.mlife.nature_of_business");
                    $(".natureSearchMLifeText").val("");//Prashant 23/12/2016
                    document.getElementById("al_employee_details.mlife.occupation_class").value = "";
                }
            }

            
            ANB_set =  document.getElementById("al_person_details.mlife.anb").value;
            
            console.log("ANB_set 26 :: "+ANB_set);
            if((document.getElementById("al_person_details.mlife.anb").value >16 && !isILproduct) || (ilMainLifeANB >16 && isILproduct))
            {
                console.log("ANB_set 27 :: "+ANB_set);
                if((ANB_set <= 16 && !isILproduct) || (ilMainLifeANB <= 16 && isILproduct))
                {
                    console.log("ANB_set 28 :: "+ANB_set);
                    fnMsSolSelectElement("Occupation", "al_employee_details.mlife.occupation");
                    $(".occupationSearchMLifeText").val("");//Prashant 23.12.2016
                    fnMsSolSelectElement("Nature of Business", "al_employee_details.mlife.nature_of_business");
                    $(".natureSearchMLifeText").val("");//Prashant 23/12/2016
                    document.getElementById("al_employee_details.mlife.occupation_class").value = "";

                }
            }
            if(document.getElementById(DateValueId).value == "")
            {
                document.getElementById("al_sqs_details.sec_parti_flag_yes").checked = false;
                document.getElementById("al_sqs_details.sec_parti_flag_no").checked = true;
                document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = false;
                document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = false;
                $(".collapseTwo").attr("id", "");
                $(".collapseThree").attr("id", "");
                $(".second_life,.third_life").addClass("disabled_panel");
                $(".second_life,.third_life").removeClass("normal_panel").removeClass("active_panel");
            }
            
            if(((document.getElementById("al_person_details.mlife.anb").value > 16 && document.getElementById("al_person_details.mlife.anb").value < 19 && !isILproduct) || (ilMainLifeANB > 16 && ilMainLifeANB < 19 && isILproduct)) && (Channel != "Banca" && Channel != "UOB"))//changed by Purva / Pramod C on 07th Aug 2017 for UOB
            {
                $("input[name='third_life'][value='Yes']").prop('checked',false);
                $("input[name='third_life'][value='No']").prop('checked',true);
            }
            //else if((document.getElementById("al_person_details.mlife.anb").value > 16 && document.getElementById("al_person_details.mlife.anb").value < 19) && Channel == "Banca")
            else if(Channel == "Banca" || Channel == "UOB")//changed by Purva / Pramod C on 07th Aug 2017 for UOB
            {
                //Do nothing
            }else
            {
                $("input[name='third_life'][value='Yes']").prop('checked',false);
                $("input[name='third_life'][value='No']").prop('checked',true);
            }
        }
        else if ((ageYears > 70 &&  !isILproduct) || (ilMainLifeANB > 70 && isILproduct))
        {
            console.log("@main1")
            document.getElementById("al_sqs_details.sec_parti_flag_yes").checked = false;
            document.getElementById("al_sqs_details.sec_parti_flag_no").checked = true;
            document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = false;
            document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = false;
            $(".collapseTwo").attr("id", "");
            $(".collapseThree").attr("id", "");
            $(".second_life,.third_life").addClass("disabled_panel");
            $(".second_life,.third_life").removeClass("normal_panel").removeClass("active_panel");
            $("input[name='third_life'][value='Yes']").prop('checked',false);
            $("input[name='third_life'][value='No']").prop('checked',true);
            alert("216","70");
            document.getElementById("al_person_details.mlife.anb").value = "";
            document.getElementById("al_person_details.mlife.dob").value = "";
            
            return false;
        }
        
        if ((ageYears <= 16 &&  !isILproduct) || (ilMainLifeANB <= 16 &&  isILproduct))
        {
            if (Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)" && (replicate_res == "" || replicate_res == null || replicate_res == "null" || replicate_res == "(null)"))
            {
                js_get_var("proposal_required_info", function(response_pro_req)
                {
                    js_get_var("ylp_id_for_sqs", function(res_ylp)
                    {
                        if((document.getElementById("al_person_details.mlife.anb").value <= 16 &&  !isILproduct) || (ilMainLifeANB <= 16 &&  isILproduct))
                        {
                               if((document.getElementById("al_person_details.mlife.anb").value >= 11 && document.getElementById("al_person_details.mlife.anb").value <= 16 &&  !isILproduct) || ((ilMainLifeANB >= 11 && ilMainLifeANB <= 16) || (ilMainLifeANB >= 11 && ilMainLifeANB <= 16) &&  isILproduct)) //26-06-2018
                               {
                               if(!(document.getElementById("al_person_details.mlife.parent_consent") == null && document.getElementById("al_person_details.mlife.parent_consent") == "null"))
                               {
                               if(document.getElementById("al_person_details.mlife.parent_consent_no").checked)
                               {
                               console.log("---->4");
                               //fnMsPersonalPopulateValues("al_person_details.slife.first_name_dropdown","slife")                      //def 1367
                               
                               if(res_ylp != "" && res_ylp != null && res_ylp != "null" && res_ylp != "(null)")
                               {
                               document.getElementById("al_person_details.slife.first_name_dropdown").disabled=true;
                               }else
                               {
                               document.getElementById("al_person_details.slife.first_name_dropdown").disabled=false;
                               }
                               }else if(document.getElementById("al_person_details.mlife.parent_consent_yes").checked)
                               {
                               fnMsDisableLives("al_person_details.mlife.parent_consent_yes");
                               }
                               }
                               }else if((document.getElementById("al_person_details.mlife.anb").value <= 11 && document.getElementById("al_person_details.mlife.anb").value != "" &&  !isILproduct) || (ilMainLifeANB <= 11 && ilMainLifeANB != "" &&  isILproduct))
                               {
                               console.log("---->5");
                               //fnMsPersonalPopulateValues("al_person_details.slife.first_name_dropdown","slife")                          //def 1367
                               
//                               if(res_ylp != "" && res_ylp != null && res_ylp != "null" && res_ylp != "(null)")
//                               {
//                               document.getElementById("al_person_details.slife.first_name_dropdown").disabled=true;//code commented for DEF- 5802 changes made by pramod chavan 04.07.2018
//                               }else
//                               {
                               document.getElementById("al_person_details.slife.first_name_dropdown").disabled=false;
//                               }
                               }
                        }
                    });
                });
            }

                if((Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)") || (replicate_res != "" && replicate_res != null && replicate_res != "null" && replicate_res != "(null)"))
                {
                    if(typeof pre_natal_handle == "undefined" || pre_natal_handle=="")
                    {
                        pre_natal_handle = "No";
                         console.log("client_ylp_type_mlife12--->"+client_ylp_type_mlife)
                        if((document.getElementById("al_person_details.mlife.anb").value <=16 && !isILproduct) || (ilMainLifeANB <=16 && isILproduct))
                        {
                            client_ylp_type_mlife = "lo";
                        }
                    }
                    
                if(((document.getElementById("al_person_details.mlife.anb").value > 16 && !isILproduct) || (ilMainLifeANB > 16 && isILproduct)) && (typeof relationship_mlife == 'undefined' || relationship_mlife == "" || relationship_mlife == "H" || relationship_mlife == "W" || relationship_mlife == "F" || relationship_mlife == "M"))
                {
                    if(((document.getElementById("al_person_details.mlife.anb").value==17 || document.getElementById("al_person_details.mlife.anb").value==18) && !isILproduct) || ((ilMainLifeANB==17 || ilMainLifeANB==18) && isILproduct))
                    {
                        if(client_ylp_type_mlife=="lo" && (Client_id!="" && Client_id!=null && Client_id!="null"))
                        {
                            document.getElementById("al_person_details.slife.relationship").value = "Parent";
                            document.getElementById("al_person_details.slife.relationship").disabled = false; // changes made by pramod chavan "True" to "False" for prodcution defect---PRUW00037533
                            console.log("23 disable");
                        }
                    }
                    else
                    {
                        //document.getElementById("al_person_details.slife.relationship").value = "Spouse";
                        //document.getElementById("al_person_details.slife.relationship").disabled = true;
                        console.log("24 disable");
                    }
                }else if(((document.getElementById("al_person_details.mlife.anb").value == 16 && !isILproduct) || (ilMainLifeANB == 16 && isILproduct)) && (client_ylp_type_mlife == "you"  || client_ylp_type_mlife == "spouse") && (typeof relationship_mlife == 'undefined' || relationship_mlife == "" || relationship_mlife == "H" || relationship_mlife == "W" || relationship_mlife == "F" || relationship_mlife == "M"))
                {
                    document.getElementById("al_person_details.slife.relationship").value = "Parent";
                    document.getElementById("al_person_details.slife.relationship").disabled = false; // changes made by pramod chavan "True" to "False" for prodcution defect---PRUW00037533
                    console.log("25 disable");
                }else if(((pre_natal_handle == "No" && ((document.getElementById("al_person_details.mlife.anb").value <=16 && !isILproduct) || (ilMainLifeANB <=16 && isILproduct)) ) || pre_natal_handle == "Yes") && (relationship_mlife == "C") && client_ylp_type_mlife == "lo"){

                if(relationship_slife == "F" || relationship_slife == "M" || relationship_slife == "" || typeof relationship_slife == "undefined")
                {
                document.getElementById("al_person_details.slife.relationship").value = "Parent";
                document.getElementById("al_person_details.slife.relationship").disabled = false;

                if(document.getElementById("al_sqs_details.third_parti_flg_yes").checked)
                {
                    document.getElementById("al_person_details.tlife.relationship").value = "Parent";
                    document.getElementById("al_person_details.tlife.relationship").disabled = false;
                }

                }else
                {
                    console.log("relationship_mlife in validations 6:: "+relationship_mlife+" --- "+relationship_slife);
                document.getElementById("al_person_details.slife.relationship").value = "Select Relationship";
                                           //commented by ankita on 8 april 2022
                //document.getElementById("al_person_details.slife.relationship").disabled = true;
                    console.log("26 disable");
                }
                }else
                {
                    console.log("relationship_mlife in validations 7:: "+relationship_mlife+" --- "+relationship_slife);
                document.getElementById("al_person_details.slife.relationship").value = "Select Relationship";
                                           //commented by ankita on 8 april 2022
                //document.getElementById("al_person_details.slife.relationship").disabled = true;
                    console.log("27 disable");
                }
                }
            if(((document.getElementById("al_person_details.mlife.anb").value > 16 && document.getElementById("al_person_details.mlife.anb").value < 19 && !isILproduct) || (ilMainLifeANB > 16 && ilMainLifeANB < 19 && isILproduct))  && (Channel != "Banca" && Channel != "UOB"))//changed by Purva / Pramod C on 07th Aug 2017 for UOB
            {
                document.getElementById("third_life_party_flag").style.display = 'block';
            }
            //else  if((document.getElementById("al_person_details.mlife.anb").value > 16 && document.getElementById("al_person_details.mlife.anb").value < 19) && Channel == "Banca" )
            else if(Channel == "Banca" || Channel == "UOB")//changed by Purva / Pramod C on 07th Aug 2017 for UOB
            {
                document.getElementById("third_life_party_flag").style.display = 'block';
            }else
            {
                document.getElementById("third_life_party_flag").style.display = 'block';
            }
            
                if (ageYears <= 16 && document.getElementById("al_person_details.pre_natal_child_flg").checked == true)
                {
                    $("input[name='third_life'][value='Yes']").prop('checked',true);
                    $("input[name='third_life'][value='No']").prop('checked',false);
                    
                    $( "select[name='al_person_details.slife.relationship']" ).find('option[value="Spouse"]').remove();
                     document.getElementById("al_person_details.slife.relationship").value="Parent";
                    document.getElementById("al_person_details.slife.relationship").disabled = false;
                }else if (ageYears <= 16 && document.getElementById("al_person_details.pre_natal_child_flg").checked == false)
                {
                    $( "select[name='al_person_details.slife.relationship']" ).find('option[value="Spouse"]').remove();
                     document.getElementById("al_person_details.slife.relationship").value="Parent";
                    document.getElementById("al_person_details.slife.relationship").disabled = false;
                }
                else
                {
                                           console.log("cheked modern family3 5108 ddlArray");
                    var ddloption = document.getElementById("al_person_details.slife.relationship");
                    //console.log("options ddloption "+ddloption);
                    ddloption.options.length=0;
                    for(var i = 0; i < ddlArray.length; i++)
                    {
                        var optn=document.createElement("option");
                        optn.value=ddlArray[i];
                        optn.text=ddlArray[i];
                        ddloption.appendChild(optn);
                    }
                    document.getElementById("al_person_details.slife.relationship").disabled = false;
                }
            } else
            {
                document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = false;
                document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = false;
                $(".collapseThree").attr("id", "");
                $(".third_life").addClass("disabled_panel");
                $(".third_life").removeClass("normal_panel").removeClass("active_panel");
                
                $("input[name='third_life'][value='Yes']").prop('checked',false);
                $("input[name='third_life'][value='No']").prop('checked',true);
                
                $("input[name='tlife_gender'][value='Male']").prop('checked',true);
                $("input[name='tlife_gender'][value='Female']").prop('checked',false);
                console.log("cheked modern family4 5108 ddlArray");
                                           
                                           //commented by ankita case starts from my solution select any modern family list then after front and back swipe all relationship was showing
                                           //to check 16 may 2022
                /*var ddloption = document.getElementById("al_person_details.slife.relationship");
                //console.log("options ddloption "+ddloption);
                ddloption.options.length=0;
                for(var i = 0; i < ddlArray.length; i++)
                {
                    var optn=document.createElement("option");
                    optn.value=ddlArray[i];
                    optn.text=ddlArray[i];
                    ddloption.appendChild(optn);
                }*/
                
                if((Client_id == "" || Client_id == null || Client_id == "null" || Client_id == "(null)") && (replicate_res == "" || replicate_res == null || replicate_res == "null" || replicate_res == "(null)"))
                {
                    if((document.getElementById("al_person_details.mlife.anb").value > 16 && !isILproduct) || (ilMainLifeANB > 16 && isILproduct))
                    {
                        if(((document.getElementById("al_person_details.mlife.anb").value==17 || document.getElementById("al_person_details.mlife.anb").value==18) && !isILproduct) || ((ilMainLifeANB==17 || ilMainLifeANB==18) && isILproduct))
                        {
                            if(client_ylp_type_mlife=="lo" && (Client_id!="" && Client_id!=null && Client_id!="null"))
                            {
                                document.getElementById("al_person_details.slife.relationship").value = "Parent";
                                document.getElementById("al_person_details.slife.relationship").disabled = false; // changes made by pramod chavan "True" to "False" for prodcution defect---PRUW00037533
                                console.log("28 disable");
                            }
                        }
                        else
                        {
                                           console.log("value 12345:"+document.getElementById("al_person_details.slife.relationship").value);
                            //document.getElementById("al_person_details.slife.relationship").value="Spouse";
                            //document.getElementById("al_person_details.slife.relationship").disabled = true;
                            console.log("29 disable");
                        }
                    }
                }else if((Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)") || (replicate_res != "" && replicate_res != null && replicate_res != "null" && replicate_res != "(null)"))
                {
                    if(typeof pre_natal_handle == "undefined" || pre_natal_handle=="")
                    {
                        pre_natal_handle = "No";
                        if((document.getElementById("al_person_details.mlife.anb").value <=16 && !isILproduct) || (ilMainLifeANB <=16 && isILproduct))
                        {
                            client_ylp_type_mlife = "lo";
                        }
                    }
                    
                    if(((document.getElementById("al_person_details.mlife.anb").value > 16 && !isILproduct) ||  (ilMainLifeANB > 16 && isILproduct)) && (typeof relationship_mlife == 'undefined' || relationship_mlife == "" || relationship_mlife == "H" || relationship_mlife == "W" || relationship_mlife == "F" || relationship_mlife == "M"))
                    {
                        if(((document.getElementById("al_person_details.mlife.anb").value==17 || document.getElementById("al_person_details.mlife.anb").value==18) && !isILproduct) || ((ilMainLifeANB==17 || ilMainLifeANB==18) && isILproduct))
                        {
                            if(client_ylp_type_mlife=="lo" && (Client_id!="" && Client_id!=null && Client_id!="null"))
                            {
                                document.getElementById("al_person_details.slife.relationship").value = "Parent";
                                document.getElementById("al_person_details.slife.relationship").disabled = false; // changes made by pramod chavan "True" to "False" for prodcution defect---PRUW00037533
                                console.log("30 disable");
                            }
                        }
                        else
                        {
                                           console.log("value 1234:"+document.getElementById("al_person_details.slife.relationship").value);
                                           
                            document.getElementById("al_person_details.slife.relationship").value = "Spouse";
                            document.getElementById("al_person_details.slife.relationship").disabled = true;
                            console.log("31 disable");
                        }
                    }else if(((document.getElementById("al_person_details.mlife.anb").value == 16 && !isILproduct) || (ilMainLifeANB == 16 && isILproduct)) && (client_ylp_type_mlife == "you"  || client_ylp_type_mlife == "spouse") && (typeof relationship_mlife == 'undefined' || relationship_mlife == "" || relationship_mlife == "H" || relationship_mlife == "W" || relationship_mlife == "F" || relationship_mlife == "M"))
                    {
                        document.getElementById("al_person_details.slife.relationship").value = "Parent";
                        document.getElementById("al_person_details.slife.relationship").disabled = false; // changes made by pramod chavan "True" to "False" for prodcution defect---PRUW00037533
                        console.log("32 disable");
                    }else if(((pre_natal_handle == "No" && ((document.getElementById("al_person_details.mlife.anb").value <=16 && !isILproduct) || (ilMainLifeANB <=16 && isILproduct))) || pre_natal_handle == "Yes") && (relationship_mlife == "C") && client_ylp_type_mlife == "lo")
                    {
                        if(relationship_slife == "F" || relationship_slife == "M" || relationship_slife == "" || typeof relationship_slife == "undefined")
                        {
                            document.getElementById("al_person_details.slife.relationship").value = "Parent";
                            document.getElementById("al_person_details.slife.relationship").disabled = false;
                            
                            if(document.getElementById("al_sqs_details.third_parti_flg_yes").checked)
                            {
                                document.getElementById("al_person_details.tlife.relationship").value = "Parent";
                                document.getElementById("al_person_details.tlife.relationship").disabled = false;
                            }
                            
                        }else
                        {
                            console.log("relationship_mlife in validations 8:: "+relationship_mlife+" --- "+relationship_slife);
                            document.getElementById("al_person_details.slife.relationship").value = "Select Relationship";
                           //commented by ankita on 8 april 2022
                                           //document.getElementById("al_person_details.slife.relationship").disabled = true;
                            console.log("33 disable");
                        }
                    }else
                    {
                        console.log("relationship_mlife in validations 9:: "+relationship_mlife+" --- "+relationship_slife);
                        //document.getElementById("al_person_details.slife.relationship").value = "Select Relationship";
                                           //commented by ankita on 8 april 2022
                                           //case starts from my needs go to solution it is disable list but when front swipe and backswipe it is getting enabled.
                        document.getElementById("al_person_details.slife.relationship").disabled = true;
                        console.log("34 disable");
                    }
                }
                
            }
        }
    
        if (DateValueId == "al_person_details.slife.dob")
        {
            if((document.getElementById("al_person_details.slife.relationship").value == "Spouse" ||  document.getElementById("al_person_details.slife.relationship").value == "Select Relationship" ))//Added By Rahul on 05-11-2015 and modified by Praveen on 01.04.2016
            {
                console.log("1.in display none");
                document.getElementById("third_life_party_flag").style.display = 'none';
            }
            else
            {
                document.getElementById("third_life_party_flag").style.display = 'block';
            }
            var Mlanb = document.getElementById("al_person_details.mlife.anb").value;
            var Slanb = document.getElementById("al_person_details.slife.anb").value;
            
            var MlanbIL = document.getElementById("al_person_details.mlife.anb_il_product").value;
            var SlanbIL = document.getElementById("al_person_details.slife.anb_il_product").value;
            
            //Commented by Paromita for defect 5431 on 3 July 2018
            /********@
             FOLLOWING CODE COMMENTED BY SACHIN TUPE FOR REMOVE SPOUSE VALIDATION FOR AGENCY CHANNEL ON 30 JULY 2018.
             
             ******@/
            if((Channel != "Banca" && Channel != "UOB") && (checkPRUwithyou!="PRUwith you" && checkPRUwithyou!="PRUcancer X"))//changed by Purva / Pramod C on 07th Aug 2017 for UOB 2..//Added checkPRUwithyou varible by Sachin Tupe for defect 5589 on 21-06-2018.

            {

                if (((Slanb < 20 && !isILproduct) || (SlanbIL < 20 && isILproduct)) && (document.getElementById("al_person_details.slife.relationship").value == "Spouse"))
                    {
                        alert("392");
                        fnMsDisableDropdownChange("spouse");
                        document.getElementById("al_person_details.slife.anb").value = "";
                        document.getElementById("al_person_details.slife.dob").value = "";
                        return false;
                    }

            }*******/
            //below if condition is removed for def-5949 and 6288 20 60 alert by sourabh and sachin on 28-sept-2018
            //if(Channel == "Banca" /*|| Channel == "UOB"* checked for defect 5084 by sachin T.*/)//changed by Purva / Pramod C on 07th Aug 2017 for UOB
           // {
              /**** Following code commented for 5431  if ((Mlanb > 16 && Mlanb <= 30 && !isILproduct) || (MlanbIL > 16 && MlanbIL <= 30 && isILproduct))
                {
                    if (((Slanb < 20 || Slanb > 40)) && !isILproduct && (document.getElementById("al_person_details.slife.relationship").value == "Spouse"))
                    {
                        alert("286");
                        document.getElementById("al_person_details.slife.anb").value = "";
                        document.getElementById("al_person_details.slife.dob").value = "";
                        return false;
                    }else if ((SlanbIL < 20 || SlanbIL > 40) && isILproduct && (document.getElementById("al_person_details.slife.relationship").value == "Spouse"))
                    {
                        alert("286");
                        document.getElementById("al_person_details.slife.anb").value = "";
                        document.getElementById("al_person_details.slife.dob").value = "";
                        return false;
                    }
                }************/
               
           
                /*if ((Mlanb >= 31 && Mlanb <= 70 && !isILproduct) || (MlanbIL >= 31 && MlanbIL <= 70 && isILproduct))
                {
                    if((Slanb < 20 || Slanb > 60) && !isILproduct) {
                        alert("287");
                        document.getElementById("al_person_details.slife.anb").value = "";
                        document.getElementById("al_person_details.slife.dob").value = "";
                        return false;
                    }else if((SlanbIL < 20 || SlanbIL > 60) && isILproduct) {
                        alert("287");
                        document.getElementById("al_person_details.slife.anb").value = "";
                        document.getElementById("al_person_details.slife.dob").value = "";
                        return false;
                    }*/
                    /***************Following code commented by Sachin Tupe for defect 5431 on date 06-08-2018
                    else
                    {
                        if ((Slanb >= 31 || Slanb <= 50 ) && !isILproduct)
                        {
                            if((Slanb - Mlanb) > 10)
                            {
                                alert("221");
                                document.getElementById("al_person_details.slife.anb").value = "";
                                document.getElementById("al_person_details.slife.dob").value = "";
                                return false;
                            }
                        }else if ((SlanbIL >= 31 || SlanbIL <= 50 ) && isILproduct)
                        {
                            if((SlanbIL - MlanbIL) > 10)
                            {
                                alert("221");
                                document.getElementById("al_person_details.slife.anb").value = "";
                                document.getElementById("al_person_details.slife.dob").value = "";
                                return false;
                            }
                        }
                    }//
                     ******************/
             //   }
           // }

            //Following 70 value to changes to 100 for "PAMBNEWP-4410 Allowed Assured above age 70 v0.3_Half" by sachin on 5-4-2022
            if ((Slanb > 100 && !isILproduct) || (SlanbIL > 100 && isILproduct))
            {
               // alert("216","70");
                alert("216","100");
                
                document.getElementById("al_person_details.slife.anb").value = "";
                document.getElementById("al_person_details.slife.dob").value = "";
                return false;
            }
            
            else if ((Slanb < 17 && !isILproduct) || (SlanbIL < 17 && isILproduct))//change anb 19 to 17 for modern family CR by ankita on 3 may 2022
            {
                alert("224","17");
                document.getElementById("al_person_details.slife.anb").value = "";
                document.getElementById("al_person_details.slife.dob").value = "";
                return false;
            }
            else if (((Slanb < 17 && !isILproduct) || (SlanbIL < 17 && isILproduct)) && document.getElementById("al_person_details.pre_natal_child_flg").checked == true)
            { //chenged by Rahul 18 to 19//change anb 19 to 17 for modern family CR by ankita on 3 may 2022
                //alert("224");
                document.getElementById("al_person_details.slife.anb").value = "";
                document.getElementById("al_person_details.slife.dob").value = "";
                alert("710");
                return false;
            }
            else if ((Slanb < 17 && !isILproduct) || (SlanbIL < 17 && isILproduct))//change anb 19 to 17 for modern family CR by ankita on 3 may 2022
            {
                //chenged by Rahul 18 to 19
                //alert("224");
                alert("710");
                document.getElementById("al_person_details.slife.anb").value = "";
                document.getElementById("al_person_details.slife.dob").value = "";
                
                return false;
            }
        }
        
        if (DateValueId == "al_person_details.tlife.dob")
        {
            var Tlanb = document.getElementById("al_person_details.tlife.anb").value
            var TlanbIL = document.getElementById("al_person_details.tlife.anb_il_product").value;// added for IL ANB changes.
            if ((Tlanb < 18 && !isILproduct) || (TlanbIL < 18 && isILproduct)) {
                alert("224","18");
                document.getElementById("al_person_details.tlife.anb").value = "";
                document.getElementById("al_person_details.tlife.dob").value = "";
                return false;
            }
            else if ((Tlanb > 70 && !isILproduct) || (TlanbIL > 70 && isILproduct)) {
                alert("216","70");
                document.getElementById("al_person_details.tlife.anb").value = "";
                document.getElementById("al_person_details.tlife.dob").value = "";
                return false;
            }
            // changed ANB 19 to 18 for DEF-4451
            else if (((Tlanb < 18 && !isILproduct) || (TlanbIL < 18 && isILproduct)) && document.getElementById("al_person_details.tlife.gender_female").checked && document.getElementById("al_person_details.pre_natal_child_flg").checked == true) {
               // alert("224");
                 alert("712");
                document.getElementById("al_person_details.tlife.anb").value = "";
                document.getElementById("al_person_details.tlife.dob").value = "";
                return false;
            }
            else if ((Tlanb < 18 && !isILproduct) || (TlanbIL < 18 && isILproduct)) {
                 alert("224");
                
                document.getElementById("al_person_details.tlife.anb").value = "";
                document.getElementById("al_person_details.tlife.dob").value = "";
                return false;
            }
        }
    }

function ClearData()
{
    tempExecute =0;
    var prod_choice_data = null;
    var ben_select_data = null;
    var ben_select_bundle=null;
    var prod_choice_res = null;
    var hideshow = null;
    var hideshow_bundle=null;
    var minmax = null;
    var loading_res = null;
    var hideshowloading = null;
    var loadin_data = null;
    prod_choice_response="";
    isILproduct=false;
    var referral_data=null;
    var solutionsPlanClearData=null;
    var bundleFundRes=null;
    var bundleProdRes=null;
    var calbundleRes=null;
    var bundleRiderRes=null;
    var clearFalg=null;
    var clearFalgBundle=null;
    var bundlePrevFileNameEmail=null;
    var language_option=null;
    var clearCancerFund=null;
     arrayBundleProduct=[];
    js_set_var("language_option",JSON.stringify(language_option),function()
               {
    js_set_var("bunldle_product_flag",JSON.stringify(clearFalgBundle),function()
               {

    js_set_var("bunldle_output_response",JSON.stringify(clearFalg),function()
               {
    js_set_var("bundle_product_response",JSON.stringify(bundleFundRes),function()
               {
               
               js_set_var("bundle_product_detail_response",JSON.stringify(bundleProdRes),function()
                          {
                          js_set_var("bundlePrevFileNameEmail",JSON.stringify(bundlePrevFileNameEmail),function()
                                     {
                          js_set_var("cal_bundle_product_details_response",JSON.stringify(calbundleRes),function()
                                     {
                                     js_set_var("bundle_rider_string",JSON.stringify(bundleRiderRes),function()
                                                {
js_set_var("cancer_loading_clear",JSON.stringify(clearCancerFund),function()
{
js_set_var("referral_details_response", JSON.stringify(referral_data), function()
{
  js_set_var("buttons_plans_response", JSON.stringify(solutionsPlanClearData), function()
    {
    js_set_var("prod_choice_response",JSON.stringify(prod_choice),function()
    {
        js_set_var("prod_choice_res",JSON.stringify(prod_choice_res),function()
        {
            js_set_var("MinMaxBudget",JSON.stringify(minmax),function()
            {
                js_set_var("hideshowrider",JSON.stringify(hideshow),function()
                {
                    js_set_var("hideshowrider_bundle",JSON.stringify(hideshow_bundle),function()
                                   {
                               js_set_var("beneft_selection_response",JSON.stringify(ben_select_data),function()
                    {
                                          js_set_var("beneft_selection_response_bundle",JSON.stringify(ben_select_bundle),function()
                                          {
                        js_set_var("loading_details_response",JSON.stringify(loading_res),function()
                        {
                            js_set_var("hideshowloadingrider",JSON.stringify(hideshowloading),function()
                            {
                                js_set_var("engineloadingstring",JSON.stringify(loadin_data),function()
                                {
                                });
                            });
                        });
                    });
                                          });
                });
                           });
            });
        });
    });
             });//
                                                });
                                                });
                                                });
                                     });
                          });
                          });
               });
});
});
               });
}

function ResetFieldsonAnbChange(Reset_data)
{
    console.log("---------2>=======>"+document.getElementById("al_person_details.pre_natal_child_flg").checked);
    if(document.getElementById("al_person_details.pre_natal_child_flg").checked)
    {
        document.getElementById("al_person_details.pre_natal_child_flg").checked = false;
        document.getElementById("gestational_week").style.display = 'none';
        
        document.getElementById("al_person_details.mlife.expected_delivery").style.display = 'none';
        document.getElementById("al_person_details.gestational_week").style.display = 'none';
        
        if((Client_id == "" || Client_id == null || Client_id == "null" || Client_id == "(null)") && (replicate_res == "" || replicate_res == null || replicate_res == "null" || replicate_res == "(null)"))
        {
        document.getElementById("al_person_details.mlife.expected_delivery_dt").value = "";
            document.getElementById("al_person_details.gestational_week").value = "Gestational Week";
        }
        
        
        
        document.getElementById("al_person_details.mlife.first_name").disabled = false;
        
        document.getElementById("al_person_details.mlife.dtofbirth").style.display = 'block';
        document.getElementById("al_person_details.mlife.anb_block").style.display = 'block';
        document.getElementById("al_person_details.mlife.anb").value = "";
    }
    
    if(Reset_data != "Checkdata" && Reset_data != "slife" && Reset_data != "tlife")
    {
    document.getElementById("al_employee_details.mlife.occupation").value = "Select";
    $(".occupationSearchMLifeText").val("");//Prashant 23.12.2016
    document.getElementById("al_employee_details.mlife.occupation_class").value = "";
    document.getElementById("al_employee_details.mlife.nature_of_business").value = "Select";
    $(".natureSearchMLifeText").val("");//Prashant 23/12/2016
    }
    
    if(!(Reset_data == "slife" || Reset_data == "tlife"))
    {
        document.getElementById("al_sqs_details.sec_parti_flag_yes").checked = false;
        document.getElementById("al_sqs_details.sec_parti_flag_no").checked = true;
        document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = false;
        document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = false;
        document.getElementById("parent_consent_block").style.display="none";
        document.getElementById("al_person_details.mlife.parent_consent_yes").checked=false;
        document.getElementById("al_person_details.mlife.parent_consent_no").checked=true;
        $(".collapseTwo").attr("id", "");
        $(".collapseThree").attr("id", "");
        $(".second_life,.third_life").addClass("disabled_panel");
        $(".second_life,.third_life").removeClass("normal_panel").removeClass("active_panel");
    
        document.getElementById("al_person_details.slife.first_name").value = "";
    }
    
    if((Client_id == "" || Client_id == null || Client_id == "null" || Client_id == "(null)") && (replicate_res == "" || replicate_res == null || replicate_res == "null" || replicate_res == "(null)"))
    {
        if((document.getElementById("al_person_details.mlife.anb").value > 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value > 16 && isILproduct))
        {
            if(((document.getElementById("al_person_details.mlife.anb").value==17 || document.getElementById("al_person_details.mlife.anb").value==18) && !isILproduct) || ((document.getElementById("al_person_details.mlife.anb_il_product").value==17 || document.getElementById("al_person_details.mlife.anb_il_product").value==18) && isILproduct))
            {
                if(client_ylp_type_mlife=="lo" && (Client_id!="" && Client_id!=null && Client_id!="null"))
                {
                    document.getElementById("al_person_details.slife.relationship").value = "Parent";
                    document.getElementById("al_person_details.slife.relationship").disabled = false; // changes made by pramod chavan "True" to "False" for prodcution defect---PRUW00037533
                    console.log("37 disable");
                }
            }
            else
            {
                document.getElementById("al_person_details.slife.relationship").value="Spouse";
                                           //commented by ankita for modern family as relationship was getting disable for you spouse scenario
                //document.getElementById("al_person_details.slife.relationship").disabled = true;
                console.log("38 disable");
            }
        }
    }else if((Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)") || (replicate_res != "" && replicate_res != null && replicate_res != "null" && replicate_res != "(null)"))
    {
        console.log("---------3>=======>"+document.getElementById("al_person_details.mlife.anb").value);
        if(typeof pre_natal_handle == "undefined" || pre_natal_handle=="")
        {
            pre_natal_handle = "No";
            if((document.getElementById("al_person_details.mlife.anb").value <=16  && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <=16  && isILproduct))
            {
                client_ylp_type_mlife = "lo";
            }
        }
        console.log("---------4>=======>"+document.getElementById("al_person_details.mlife.anb").value+"----->"+relationship_mlife);
        
        if(((document.getElementById("al_person_details.mlife.anb").value > 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value > 16 && isILproduct)) && (typeof relationship_mlife == "undefined" || relationship_mlife == "" || relationship_mlife == "H" || relationship_mlife == "W" || relationship_mlife == "F" || relationship_mlife == "M"))
        {
            console.log("---------5>=======>"+document.getElementById("al_person_details.mlife.anb").value+"----->"+relationship_mlife);
            if(((document.getElementById("al_person_details.mlife.anb").value==17 || document.getElementById("al_person_details.mlife.anb").value==18) && !isILproduct) || ((document.getElementById("al_person_details.mlife.anb_il_product").value==17 || document.getElementById("al_person_details.mlife.anb_il_product").value==18) && isILproduct))
            {
                if(client_ylp_type_mlife=="lo" && (Client_id!="" && Client_id!=null && Client_id!="null"))
                {
                    document.getElementById("al_person_details.slife.relationship").value = "Parent";
                    document.getElementById("al_person_details.slife.relationship").disabled = false; // changes made by pramod chavan "True" to "False" for prodcution defect---PRUW00037533
                    console.log("39 disable");
                }
            }
            else
            {
                document.getElementById("al_person_details.slife.relationship").value = "Spouse";
                document.getElementById("al_person_details.slife.relationship").disabled = true;
                console.log("40 disable");
            }
        }else if(((pre_natal_handle == "No" && ((document.getElementById("al_person_details.mlife.anb").value <=16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <=16 && isILproduct))) || pre_natal_handle == "Yes") && (relationship_mlife == "C") && client_ylp_type_mlife == "lo"){
            console.log("---------6>=======>"+document.getElementById("al_person_details.mlife.anb").value+"----->"+relationship_mlife);
            if(relationship_slife == "F" || relationship_slife == "M" || relationship_slife == "" || typeof relationship_slife == "undefined")
            {
                document.getElementById("al_person_details.slife.relationship").value = "Parent";
                document.getElementById("al_person_details.slife.relationship").disabled = false;
                
                if(document.getElementById("al_sqs_details.third_parti_flg_yes").checked)
                {
                    document.getElementById("al_person_details.tlife.relationship").value = "Parent";
                    document.getElementById("al_person_details.tlife.relationship").disabled = false;
                }
            }else
            {
                console.log("relationship_mlife in validations 11:: "+relationship_mlife+" --- "+relationship_slife);
                document.getElementById("al_person_details.slife.relationship").value = "Select Relationship";
                                           //commented by ankita on 8 april 2022
                //document.getElementById("al_person_details.slife.relationship").disabled = true;
                console.log("41 disable");
            }
        }else
        {
            if(Reset_data!="tlife")
            {
                console.log("relationship_mlife in validations :12:: "+relationship_mlife+" --- "+relationship_slife);
                document.getElementById("al_person_details.slife.relationship").value = "Select Relationship";
                                           //commented by ankita for modern family CR on 11 april 2022
                //document.getElementById("al_person_details.slife.relationship").disabled = true;
                console.log("42 disable");
            }
        }
    }

    if(!(Reset_data == "tlife"))
    {
        console.log("in reset");
    document.getElementById("al_person_details.slife.first_name_dropdown").value = "Select";
        document.getElementById("al_person_details.slife.dob").value = "";
        document.getElementById("al_person_details.slife.anb").value = "";
        document.getElementById("al_person_details.slife.gender_male").checked = true;
        document.getElementById("al_person_details.slife.gender_female").checked = false;
        document.getElementById("al_person_details.slife.smoke_status_yes").checked = false;
        document.getElementById("al_person_details.slife.smoke_status_no").checked = true;
        document.getElementById("al_employee_details.slife.occupation").value = "Select";
        $(".occupationSearchSLifeText").val("");//Prashant 23.12.2016
        document.getElementById("al_employee_details.slife.occupation_class").value = "";
        document.getElementById("al_employee_details.slife.nature_of_business").value = "Select";
        $(".natureSearchSLifeText").val("");//Prashant 23/12/2016
        document.getElementById("parent_consent_block").style.display="none";
        document.getElementById("al_person_details.mlife.parent_consent_yes").checked=false;
        document.getElementById("al_person_details.mlife.parent_consent_no").checked=true;
       
        if((document.getElementById("al_person_details.mlife.anb").value > 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value > 16 && isILproduct))
        {
                var isChecked = jQuery("input[name=third_life]:checked").val();
                if(!isChecked)
                {
                    //do nothing
                }else
                {
                    if(isChecked == "Yes")
                    {
                        $("input[name='third_life'][value='Yes']").prop('checked',false);
                        $("input[name='third_life'][value='No']").prop('checked',true);
                        
                    }
                }
        }
        
    }
            document.getElementById("al_person_details.tlife.first_name").value = "";
    document.getElementById("al_person_details.tlife.first_name_dropdown").value = "Select";
            document.getElementById("al_person_details.tlife.relationship").value = "Parent";
            document.getElementById("al_person_details.tlife.dob").value = "";
            document.getElementById("al_person_details.tlife.anb").value = "";
            document.getElementById("al_person_details.tlife.gender_male").checked = true;
            document.getElementById("al_person_details.tlife.gender_female").checked = false;
            document.getElementById("al_person_details.tlife.smoke_status_yes").checked = false;
            document.getElementById("al_person_details.tlife.smoke_status_no").checked = true;
            document.getElementById("al_employee_details.tlife.occupation").value = "Select";
            $(".occupationSearchTLifeText").val("");//Prashant 23.12.2016
            document.getElementById("parent_consent_block").style.display="none";
            document.getElementById("al_person_details.mlife.parent_consent_yes").checked=false;
            document.getElementById("al_person_details.mlife.parent_consent_no").checked=true;
            document.getElementById("al_employee_details.tlife.occupation_class").value = "";
            document.getElementById("al_employee_details.tlife.nature_of_business").value = "Select";
            $(".natureSearchTLifeText").val("");//Prashant 23/12/2016
            if((document.getElementById("al_person_details.mlife.anb").value < 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value < 16 && isILproduct))
           {
                               $("input[name='third_life'][value='Yes']").prop('checked',true);
                               $("input[name='third_life'][value='No']").prop('checked',false);
            }

}

//validate for third life in prenatal case
function validatePreNatalforThrirdLife()
{
    //if(document.getElementById("al_person_details.pre_natal_child_flg").checked || document.getElementById("al_person_details.mlife.anb").value<=16)
    if(document.getElementById("al_person_details.pre_natal_child_flg").checked)
    {
        if(document.getElementById("al_person_details.slife.gender_male").checked == true && document.getElementById("al_person_details.slife.gender_female").checked == false)
        {
            document.getElementById("third_life_party_flag").style.display = 'block';
            document.getElementById("al_sqs_details.third_parti_flg_yes").disabled = true;
            document.getElementById("al_sqs_details.third_parti_flg_no").disabled = true;
            $("input[name='third_life'][value='Yes']").prop('checked',true);
            $("input[name='third_life'][value='No']").prop('checked',false);
            $(".collapseThree").attr("id", "collapseThree");
            $(".third_life").addClass("normal_panel");
            $(".third_life").removeClass("disabled_panel");
        }
        else if(document.getElementById("al_person_details.slife.gender_female").checked == true && document.getElementById("al_person_details.slife.gender_male").checked == false)
        {
            document.getElementById("third_life_party_flag").style.display = 'block';
            document.getElementById("al_sqs_details.third_parti_flg_yes").disabled = false;
            document.getElementById("al_sqs_details.third_parti_flg_no").disabled = false;
            $("input[name='third_life'][value='Yes']").prop('checked',false);
            $("input[name='third_life'][value='No']").prop('checked',true);
            $(".collapseThree").attr("id", "");
            $(".third_life").addClass("disabled_panel");
            $(".third_life").removeClass("normal_panel");
            
            SetValuesnull();

        }
    }else
    {
        console.log("in purva 2.....");
        document.getElementById("al_sqs_details.third_parti_flg_yes").disabled = false;
        document.getElementById("al_sqs_details.third_parti_flg_no").disabled = false;
    }
}

/*******************************************************
 Function Name: fnMsValidateDuplicateClient()
 Function Description: validate if client already exist in db
 Parameters:Client_id, replicate_res, responseMlife, responseSlife, responseTlife
 Created By: Pramod Chavan
 Created On: 25 Oct 2017
 Modified By:
 Modified On:
 Modification Reason:
 *******************************************************/
function fnMsValidateDuplicateClient(Client_id, replicate_res, responseMlife, responseSlife, responseTlife){
    if ((Client_id == "" || Client_id == null || Client_id == "null" || Client_id == "(null)") && (replicate_res == "" || replicate_res == null || replicate_res == "null" || replicate_res == "(null)"))
    {
        if (!(document.getElementById("al_person_details.pre_natal_child_flg").checked))
        {
            if(responseMlife != null && responseMlife !="{}" && responseMlife !="(null)")
            {
                canSwipe=0;
                bootbox.alert("<h5>Client Record already exists. Please start from My Career Kit.</h5>",function(){
                              canSwipe=1;
                              menuController.loadPage("top_my_careerkit_summary",0);
                              
                              });
            }else if(getMlifePartiFlag() == "Yes" && responseSlife != null && responseSlife !="{}" && responseSlife !="(null)")
            {
                canSwipe=0;
                bootbox.alert("<h5>Client Record already exists. Please start from My Career Kit.</h5>",function(){
                              canSwipe=1;
                              menuController.loadPage("top_my_careerkit_summary",0);
                              
                              });
            }else if(getSlifePartiFlag() == "Yes" && responseTlife != null && responseTlife !="{}" && responseTlife !="(null)")
            {
                canSwipe=0;
                bootbox.alert("<h5>Client Record already exists. Please start from My Career Kit.</h5>",function(){
                              canSwipe=1;
                              menuController.loadPage("top_my_careerkit_summary",0);
                              
                              });
            }else{
                return true;
            }
        }else{
            if(getMlifePartiFlag() == "Yes" && responseSlife != null && responseSlife !="{}" && responseSlife !="(null)")
            {
                canSwipe=0;
                bootbox.alert("<h5>Client Record already exists. Please start from My Career Kit.</h5>",function(){
                              canSwipe=1;
                              menuController.loadPage("top_my_careerkit_summary",0);
                              
                              });
            }else if(getSlifePartiFlag() == "Yes" && responseTlife != null && responseTlife !="{}" && responseTlife !="(null)")
            {
                canSwipe=0;
                bootbox.alert("<h5>Client Record already exists. Please start from My Career Kit.</h5>",function(){
                              canSwipe=1;
                              menuController.loadPage("top_my_careerkit_summary",0);
                              
                              });
            }else{
            return true;
            }
            
        }
    }else{
        return true;
    }

}
/*******************************************************
 Function Name: fnMsPersonalCheckforFieldsUpdate()
 Function Description: Check for after once set any updates done on page
 Parameters:
 Created By: Pooja Dubey
 Created On: 06 Oct 2014
 Modified By:
 Modified On:
 Modification Reason:
 *******************************************************/
function fnMsPersonalCheckforFieldsUpdate(flag)
{
    var mlifeName="";
    var mlifeDob="";
    var mlifeOcc="";
    var mlifeGender="";
    var mlifeSmokeStatus="";
    
    var slifeName="";
    var slifeDob="";
    var slifeOcc="";
    var slifeGender="";
    var slifeSmokeStatus="";
    
    var tlifeName="";
    var tlifeDob="";
    var tlifeOcc="";
    var tlifeGender="";
    var tlifeSmokeStatus="";
    
    // Main life details
    
    mlifeName=document.getElementById("al_person_details.mlife.first_name").value;
    mlifeDob=document.getElementById("al_person_details.mlife.dob").value;
    mlifeOcc=document.getElementById("al_employee_details.mlife.occupation").value;
    
    
    if(document.getElementById("al_person_details.mlife.gender_male").checked)
    {
        mlifeGender="M";
    }
    else if(document.getElementById("al_person_details.mlife.gender_female").checked)
    {
        mlifeGender="F";
    }
    
    if(document.getElementById("al_person_details.mlife.smoke_status_yes").checked)
    {
        mlifeSmokeStatus="Yes";
    }else if(document.getElementById("al_person_details.mlife.smoke_status_no").checked)
    {
        mlifeSmokeStatus="No";
    }
    
    
    // Second life details
    if(getMlifePartiFlag() == "Yes")
    {
        slifeName=document.getElementById("al_person_details.slife.first_name").value;
        slifeDob=document.getElementById("al_person_details.slife.dob").value;
        slifeOcc=document.getElementById("al_employee_details.slife.occupation").value;
        
        if(document.getElementById("al_person_details.slife.gender_male").checked)
        {
            slifeGender="M";
        }else if(document.getElementById("al_person_details.slife.gender_female").checked)
        {
            slifeGender="F";
        }
        
        if(document.getElementById("al_person_details.slife.smoke_status_yes").checked)
        {
            slifeSmokeStatus="Yes";
        }
        else if(document.getElementById("al_person_details.slife.smoke_status_no").checked)
        {
            slifeSmokeStatus="No";
        }
    }
    // Third life details
    if(getSlifePartiFlag() == "Yes")
    {
        tlifeName=document.getElementById("al_person_details.tlife.first_name").value;
        tlifeDob=document.getElementById("al_person_details.tlife.dob").value;
        tlifeOcc=document.getElementById("al_employee_details.tlife.occupation").value;
        
        if(document.getElementById("al_person_details.tlife.gender_male").checked)
        {
            tlifeGender="M";
        }
        else if(document.getElementById("al_person_details.tlife.gender_female").checked)
        {
            tlifeGender="F";
        }
        
        if(document.getElementById("al_person_details.tlife.smoke_status_yes").checked)
        {
            tlifeSmokeStatus="Yes";
        }
        else if(document.getElementById("al_person_details.tlife.smoke_status_no").checked)
        {
            tlifeSmokeStatus="No";
        }
    }
    
    
    var loadQueryMlife = fnMsCheckExistingClient(mlifeName, mlifeDob, mlifeGender, mlifeSmokeStatus, mlifeOcc);
    loadQueryMlife.execute(function(responseMlife)
                      {
                      var loadQuerySlife = fnMsCheckExistingClient(slifeName, slifeDob, slifeGender, slifeSmokeStatus, slifeOcc);
                      loadQuerySlife.execute(function(responseSlife)
                                        {
                                        var loadQueryTlife = fnMsCheckExistingClient(tlifeName, tlifeDob, tlifeGender, tlifeSmokeStatus, tlifeOcc);
                                        loadQueryTlife.execute(function(responseTlife)
                                                          {
    if(ValidatePersonalScreen(flag))
    {
    js_get_var("proposal_required_info", function(replicate_res)
               {
    js_get_var("main_life_response", function(mlife_res)
    {
               if(fnMsValidateDuplicateClient(Client_id, replicate_res, responseMlife, responseSlife, responseTlife)){
        if(mlife_res != "" && mlife_res != null && mlife_res != "null"  && mlife_res != "(null)")
        {
            result_mlife = $.parseJSON(mlife_res);
            $.each(result_mlife, function(k, v)
            {
                if(k == "al_person_details.pre_natal_child_flg")
                {
                    if(!(v == getNatalStats()))
                    {
                        mlife_flag_update = "1";

                    }else
                    {
                        mlife_flag_noupdate = "0";
                    }
                }else  if(k == "al_person_details.mlife.parent_consent")
                   {
                   if(!(v == getParentConsent()))
                   {
                   mlife_flag_update = "1";
                   
                   }else
                   {
                   mlife_flag_noupdate = "0";
                   }
                }else if(k == "al_person_details.mlife.gender")
                {
                    if(!(v == getGender("mlife")))
                    {
                        mlife_flag_update = "1";

                    }else
                    {
                        mlife_flag_noupdate = "0";
                    }
                }
                else if(k == "al_person_details.mlife.smoke_status")
                {
                    if(!(v == getSmokeStats("mlife")))
                    {
                        mlife_flag_update = "1";

                    }else
                    {
                        mlife_flag_noupdate = "0";
                    }
                }
                else if(k == "al_sqs_details.sec_parti_flag")
                {
                    if(!(v == getMlifePartiFlag()))
                    {
                        mlife_flag_update = "1";

                    }else
                    {
                        mlife_flag_noupdate = "0";
                    }
                }
                else if(k == "al_employee_details.mlife.value_nature_of_business")
                {
                    if(!(v == val_nob_mlife))
                    {
                        mlife_flag_update = "1";
                   console.log("val_nob_mlife" +val_nob_mlife);

                    }else
                    {
                        mlife_flag_noupdate = "0";
                    }
                }
                else if(k == "al_employee_details.mlife.value_nature_of_business")
                {
                    if(!(v == val_nob_mlife))
                    {
                        mlife_flag_update = "1";
                      console.log("val_nob_mlife" +val_nob_mlife);

                    }else
                    {
                        mlife_flag_noupdate = "0";
                    }
                }
                else if(k == "al_person_details.mlife.first_name")
                {
                    if((Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)") || (replicate_res != "" && replicate_res != null && replicate_res != "null" && replicate_res != "(null)"))
                    {
                        if(!(v == document.getElementById(k+"_dropdown").value))
                        {
                            mlife_flag_update = "1";

                        }else
                        {
                            mlife_flag_noupdate = "0";
                        }
                    }else
                    {
                   console.log("----->"+k);
                   console.log("---->"+document.getElementById(k).value);
                        if(!(v == document.getElementById(k).value))
                        {
                            mlife_flag_update = "1";

                        }else
                        {
                            mlife_flag_noupdate = "0";
                        }
                    }
                   }
                //Added condition of rider_certified_check for rider certified check by ankita on 2 July 2018
                else if(!(k == "pvm_qualification_check" || k == "pamb_channel" || k == "client_ylp_type_mlife" || k == "client_ylp_sype_slife" || k == "client_ylp_type_tlife" || k == "anb_changed_by" || k == "pamb_sub_channel" || k=="al_person_details.mlife.anb_temp" || k=="al_person_details.mlife.anb_il_product_temp" || k=="al_person_details.mlife.anb_il_monthly_product_temp" || k == "rider_certified_check")) // Added temp condition for il monthly product by Sachin Tupe.
                {
                    console.log("alert system v"+k+"v"+v);
                   if(!(k == "client_ylp_type_mlife" || k == "client_ylp_sype_slife" || k == "client_ylp_type_tlife" || k == "anb_changed_by"))
                   {
                       if(!(v == document.getElementById(k).value))
                       {
                            mlife_flag_update = "1";

                       }else
                       {
                            mlife_flag_noupdate = "0";
                       }
                   }
                }
            });
               console.log("alert system");
            if (getMlifePartiFlag() == "Yes")
            {
                console.log("alert system1");
                js_get_var("sec_life_response", function(slife_res)
                {
                    if(slife_res != "" && slife_res != null && slife_res != "null"  && slife_res != "(null)")
                    {
                        var result = $.parseJSON(slife_res);
                        $.each(result, function(k, v)
                        {
                            if(k == "al_sqs_details.third_parti_flag")
                            {
                                if((document.getElementById("al_person_details.mlife.anb").value <= 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <= 16 && isILproduct))
                                {
                                    if(!(v == getSlifePartiFlag()))
                                    {
                                        slife_flag_update = "1";
                                    }else
                                    {
                                        slife_flag_noupdate = "0";
                                    }
                                }
                            }else if(k == "al_person_details.slife.gender")
                            {
                                if(!(v == getGender("slife")))
                                {
                                    slife_flag_update = "1";
                                }else
                                {
                                    slife_flag_noupdate = "0";
                                }
                            }
                            else if(k == "al_person_details.slife.smoke_status")
                            {
                                if(!(v == getSmokeStats("slife")))
                                {
                                    slife_flag_update = "1";
                                }else
                                {
                                    slife_flag_noupdate = "0";
                                }
                            }

                            else if(k == "al_employee_details.slife.value_nature_of_business")
                            {
                                if(!(v == val_nob_slife))
                                {
                                    slife_flag_update = "1";
                                }else
                                {
                                    slife_flag_noupdate = "0";
                                }
                            }else if(k == "al_person_details.slife.first_name")
                            {
                                if((Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)") || (replicate_res != "" && replicate_res != null && replicate_res != "null" && replicate_res != "(null)"))
                                {
                                    if(!(v == document.getElementById(k+"_dropdown").value))
                                    {
                                        slife_flag_update = "1";
                                    }else
                                    {
                                        slife_flag_noupdate = "0";
                                    }
                                }else
                                {
                                    if(!(v == document.getElementById(k).value))
                                    {
                                        slife_flag_update = "1";
                                    }else
                                    {
                                        slife_flag_noupdate = "0";
                                    }
                                }
                            }
                            else if(k == "al_person_details.slife.relationship")
                            {
                                if(!(v == document.getElementById(k).value))
                                {
                                slife_flag_update = "1";
                                }else
                                {
                                slife_flag_noupdate = "0";
                                }
                            }else if(k == "al_person_details.slife.dob")
                            {
                                if(!(v == document.getElementById(k).value))
                                {
                                slife_flag_update = "1";
                                }else
                                {
                                slife_flag_noupdate = "0";
                                }
                            }else if(k == "al_person_details.slife.anb")
                            {
                                if(!(v == document.getElementById(k).value))
                                {
                                slife_flag_update = "1";
                                }else
                                {
                                slife_flag_noupdate = "0";
                                }
                            }else if(k == "al_employee_details.slife.occupation")
                            {
                                if(!(v == document.getElementById(k).value))
                                {
                                slife_flag_update = "1";
                                }else
                                {
                                slife_flag_noupdate = "0";
                                }
                            }else if(k == "al_employee_details.slife.occupation_class")
                            {
                                if(!(v == document.getElementById(k).value))
                                {
                                slife_flag_update = "1";
                                }
                                else
                                {
                                slife_flag_noupdate = "0";
                                }
                            }else if(k == "al_employee_details.slife.nature_of_business")
                            {
                                if(!(v == document.getElementById(k).value))
                                {
                                slife_flag_update = "1";
                                }else
                                {
                                slife_flag_noupdate = "0";
                                }
                            }
                        });
                        
                        if (getSlifePartiFlag() == "Yes")
                        {
                            js_get_var("third_life_response", function(tlife_res)
                            {
                                       
                                if(tlife_res != "" && tlife_res != null && tlife_res != "null"  && tlife_res != "(null)")
                                {
                                    var result = $.parseJSON(tlife_res);
                                    $.each(result, function(k, v)
                                    {
                                        if(k == "al_person_details.tlife.gender")
                                        {
                                            if(!(v == getGender("tlife")))
                                            {
                                                tlife_flag_update = "1";
                                            }else
                                            {
                                                tlife_flag_noupdate = "0";
                                            }
                                        }
                                        else if(k == "al_person_details.tlife.smoke_status")
                                        {
                                            if(!(v == getSmokeStats("tlife")))
                                            {
                                                tlife_flag_update = "1";
                                            }else
                                            {
                                                tlife_flag_noupdate = "0";
                                            }
                                        }
                                           else if(k == "al_employee_details.tlife.value_nature_of_business")
                                           {
                                           if(!(v == val_nob_tlife))
                                           {
                                           tlife_flag_update = "1";
                                           
                                           }else
                                           {
                                           tlife_flag_noupdate = "0";
                                           }
                                           }

                                        else if(k == "al_employee_details.tlife.value_nature_of_business")
                                        {
                                            if(!(v == val_nob_tlife))
                                            {
                                                tlife_flag_update = "1";
                                            }else
                                            {
                                                tlife_flag_noupdate = "0";
                                            }
                                        }
                                        else if(!(k == "client_ylp_type_mlife" || k == "client_ylp_sype_slife" || k == "client_ylp_type_tlife" || k=="al_person_details.tlife.anb_temp" || k=="al_person_details.tlife.anb_il_product_temp" || k=="al_person_details.tlife.anb_il_monthly_product_temp")) //Added temp condition for il monthly by Sachin Tupe.
                                        {
                                           
                                           //console.log("tlife key"+k);
                                            if(!(v == document.getElementById(k).value))
                                            {
                                                tlife_flag_update = "1";
                                            }else
                                            {
                                                tlife_flag_noupdate = "0";
                                            }
                                        }
                                    });

                                    personal_life_details(flag);
                                }else
                                       {
                                            personal_life_details(flag);
                                       }
                                
                            });
                        }else
                        {
                           personal_life_details(flag);
                        }
                    }else
                           {
                                personal_life_details(flag);
                           }
                });
            }else
            {
               personal_life_details(flag);
            }
        }else
        {
               personal_life_details(flag);
        }
               }
    });
               });
    }
                      });
                      });
                       });
}

function fnMsPopulateClientData(mfname,Client_id,set_person_id,ds_agentId)
{
    var querySelect = new DbUtil();
// pramod chavan 29112016 below condition for production defect ylp type error in proposal ylp preview.
    //if(Client_id!="" && set_person_id!=""){
    if(replaceQuoteResponse != "" && replaceQuoteResponse != null && replaceQuoteResponse != "null" && replaceQuoteResponse != "(null)")
    {
        //This condition added by pramod chavan to fixed production defect
        var obj_person_id = "";
        var obj = JSON.parse(replaceQuoteResponse);
        e_reference_id=obj['e_reference_id'];
        sqs_id=obj['sqs_id'];
        ylp_id=obj['ylp_id'];
        agent_id=obj['agent_id'];
        proposal_mode=obj['proposal_mode'];
        
        querySelect.query()
        querySelect.select()
        querySelect.column('*')
        querySelect.from()
        querySelect.table('ylp_person_details AS t1,ylp_employee_details AS t3')
        querySelect.where()
        querySelect.clause('t1.person_id','==','t3.person_id')
        querySelect.and()
        querySelect.clause('t1.first_name','=',mfname)
        querySelect.and()
        querySelect.clause('t1.person_id','=',set_person_id)
        querySelect.and()
        querySelect.clause('t1.client_id','=',Client_id)
        querySelect.and()
        querySelect.clause('t1.ylp_id','=',ylp_id)
        querySelect.and()
        querySelect.clause('t1.is_deleted','=','No')
        querySelect.and()
        querySelect.clause('t1.agent_id','=',ds_agentId)
        querySelect.and()
        querySelect.clause('t3.agent_id','=',ds_agentId)//Added by Pallavi for device sharing
    }else{
    querySelect.query()
    querySelect.select()
    querySelect.column('*')
    querySelect.from()
    querySelect.table('careerkit_person_details AS t1,careerkit_employee_details AS t3')
    querySelect.where()
    querySelect.clause('t1.person_id','==','t3.person_id')
    querySelect.and()
    querySelect.clause('t1.first_name','=',mfname)
    querySelect.and()
    querySelect.clause('t1.person_id','=',set_person_id)
    querySelect.and()
    querySelect.clause('t1.client_id','=',Client_id)
    querySelect.and()
    querySelect.clause('t1.is_deleted','=','No')
    querySelect.and()
    querySelect.clause('t1.agent_id','=',ds_agentId)
    querySelect.and()
    querySelect.clause('t3.agent_id','=',ds_agentId)//Added by Pallavi for device sharing
    }
    return querySelect;
}

function fnMsPopulateClientDataPersn(ylp_id_resp,Client_id,ds_agentId)
{
    var querySelect = new DbUtil();
    
    querySelect.query()
    .select()
    .column('pro_person_id')
    .column('ypfr_creation_dt')
    .column('insurence_type')
    .from()
    .table('al_ylp_details')
    .where()
    .clause('client_id','=',Client_id)
    .and()
    .clause('ylp_id','=',ylp_id_resp)
    .and()
    .clause('is_deleted','=','No')
    .and()
    .clause('agent_id','=',ds_agentId)//Added by Pallavi for device sharing
    
    return querySelect;
    
}

function fnMsPopulateClientDataProposer(mfname,Client_id,pro_personid,agent_id)
{
    var querySelect = new DbUtil();
    
    querySelect.query()
    .select()
    .column('*')
    .from()
    .table('careerkit_person_details AS t1,careerkit_employee_details AS t3')
    .where()
    .clause('t1.person_id','==','t3.person_id')
    .and()
    .clause('t1.client_id','=',Client_id)
    .and()
    .clause('t1.person_id','=',pro_personid)
    .and()
    .clause('t1.is_deleted','=','No')
    .and()
    .clause('t1.agent_id','=',ds_agentId)
    .and()
    .clause('t3.agent_id','=',ds_agentId)//Added by Pallavi for device sharing
    return querySelect;
    
}
var campaign_code_benefit_screen = ""//Added by sachin t.for jan 2024 release on date 22 nov.
/*******************************************************
 Function Name: fnMsPersonalPopulateValues()
 Function Description: Populate Values from database on selection of the name from dropdown
 Parameters:
 Created By: Pooja Dubey
 Created On: 14 Oct 2014
 Modified By:
 Modified On:
 Modification Reason:
 *******************************************************/
function fnMsPersonalPopulateValues(id,persontype)
{
     easeCampaignCode="";
    campaign_code_benefit_screen = ""//Added by sachin t.for jan 2024 release  Campaign CR. on date 22 nov.
   if(persontype == "mlife"){
    startFromCareerkit = false;
   }
    
    var nobObj= MsGetNob(load_tsv_data["Nob_text"],load_tsv_data["Nob_value"]);     // changes by sayali for remove the dropdown
    var nobObjTwo=nobObj[2];
    var CompanyNobMS="";
    var ANB_set1="";
    js_get_var("LoginAgentId",function(agent_id)
               {
             //  ds_agentId=agent_id;
        js_get_var("proposal_required_info", function(response_pro_req)
        {
                   js_get_var("ylp_id_for_sqs", function(res_ylps)
                              {

        if(document.getElementById("al_person_details."+persontype+".first_name_dropdown").value == "Select")
        {
            document.getElementById("al_person_details."+persontype+".first_name_dropdown").value == "Select";
            
            
            if(persontype == "mlife")
            {
                var length_res = $('.mlifefnamedrop').children('option').length;
                $('.mlifefnamedrop').children().each(function(){
                $(this).prop('disabled',false);
            });
                
                              
            ClearData();
            document.getElementById("al_person_details.mlife.dob").value = "";
            document.getElementById("al_person_details.mlife.dob").style.display="block";
            document.getElementById("al_person_details.mlife.anb").value = "";
            document.getElementById("al_person_details.mlife.anb_il_product").value="";
            document.getElementById("al_person_details.mlife.insu_type_header").value = "select";
            document.getElementById("al_person_details.mlife.insu_type").value = "select";
            $(escape_jq("al_person_details.mlife.insu_type_header")).addClass("selectRedMandatory");
            $(escape_jq("al_person_details.mlife.insu_type")).addClass("selectRedMandatory");
            document.getElementById("al_person_details.slife.first_name_dropdown").value = "Select";
            document.getElementById("parent_consent_block").style.display="none";
            document.getElementById("al_person_details.mlife.parent_consent_yes").checked=false;
            document.getElementById("al_person_details.mlife.parent_consent_no").checked=true;
        }
                              // TODO
        if(!(persontype == "slife" && (document.getElementById("al_person_details.mlife.anb").value <= 16 || document.getElementById("al_person_details.mlife.anb_il_product").value <= 16)))
        {
            ResetFieldsonAnbChange(persontype);
        }
    }
    
    if ((Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)") || (response_pro_req != "" && response_pro_req != null &&  response_pro_req != "null" &&  response_pro_req != "(null)"))
    {
                              
        isFromMyneed=true;
        var queryCheck;
        var querySelect;
                              var obj_version="";
                              obj_priority=[];
                              
        var productRecommendation=fnfetchFNPPriority(Client_id,ds_agentId,res_ylps);//Added for solution button.
        var easeCampaignCheck=fnmsfindEaseCampaign(Client_id,ds_agentId);//Added for Ease campaign
        var fnMSGetCompDetails=fnMnpopulateYourCompanyDetails(Client_id,ds_agentId)
        var selectProgramVersion=fnRetriveProgramVersion(mck_client_id,mck_ylp_id,ds_agentId);
         selectProgramVersion.execute(function(response){
             if(response != "" && response != undefined && response != null && response !="{}")
             {
               obj_version = JSON.parse(response);
             }
        productRecommendation.execute(function(response_recommend)//Added for solution button.
            {
                          
                    //added by ankita on 15 jan 2023 for bundle product changes
                   //fetchPriorityResponse="";
                     
                if(response_recommend != "" && response_recommend != null &&  response_recommend != "null" &&  response_recommend != "(null)" && response_recommend != "{}")
                    {
                               
                                       var obj_recommend = JSON.parse(response_recommend);
                                      //added by ankita on 15 jan 2023 for bundle product changes
                                      fetchPriorityResponse=obj_recommend;
                                      var ftfctimeHorizon=obj_recommend[0]["time_horizon"];
                                      var ftfcPremiumTerm=obj_recommend[0]["premium_payment_term"];
                                      var selectedRecommendationProduct = obj_recommend[0]["recommendation_product_list"];
                                      var recommendedProd = "";
                                      if(selectedRecommendationProduct!=""){
                                      recommendedProd =selectedRecommendationProduct.split(",");
                                      }
                                     
                                      console.log("obj_recommend",obj_recommend);
                                      var isSavingTop3_is = "";
                                      var isIncomeTop3_is = "";
                                      var isRirementTop3_is="";
                                      var isHospitalTop3_is= "";
                                      var isChildEducation_is = "";
                                      var isDeathDisTop3_is = "";
                                      var isLegacy_is="";
                                      var prodConition = [];
                                      var recommendatedMysolution = [];
                                      
                                      var isFirstSaving="";
                                      var isFirstIncome="";
                                      var isFirstRirement="";
                                      var isFirstHospital="";
                                      var isFirstEducation="";
                                      var isFirstDeathDis="";
                                      var isFirstLegacy="";
                                      var priorityCondition= [];
                                      obj_priority=[];
                                      
                                      
                                      
                                      
                                      
                                 //////////////////////////
                                      
                                      if(obj_recommend[0]["saving_ranking"]=="1" || obj_recommend[0]["saving_ranking"]=="2" || obj_recommend[0]["saving_ranking"]=="3"){
                                                                                                    isSavingTop3_is = "Yes";
                                      if(obj_recommend[0]["saving_ranking"]=="1"){
                                      isFirstSaving="Yes";
                                      }
                                      
                                                                                                }
                                                        
                                                                                                
                                    if(obj_recommend[0]["security_ranking"]=="1" || obj_recommend[0]["security_ranking"]=="2" || obj_recommend[0]["security_ranking"]=="3"){
                                                                                                    
                                                                                                    isIncomeTop3_is = "Yes";
                                      if(obj_recommend[0]["security_ranking"]=="1"){
                                      isFirstIncome="Yes";
                                      }
                                    }
                                                                                              
                                                                                                
                                if(obj_recommend[0]["investment_ranking"]=="1" || obj_recommend[0]["investment_ranking"]=="2" || obj_recommend[0]["investment_ranking"]=="3"){
                                                                                                    
                                                                                                    isRirementTop3_is = "Yes";
                                      if(obj_recommend[0]["investment_ranking"]=="1"){
                                      isFirstRirement="Yes";
                                      
                                      }
                                      
                                            }
                                                                                                          
                                                                                                
                            if(obj_recommend[0]["others_ranking"]=="1" || obj_recommend[0]["others_ranking"]=="2" || obj_recommend[0]["others_ranking"]=="3"){
                                                                                                    
                                                                                                    isHospitalTop3_is = "Yes";
                                      
                                      if(obj_recommend[0]["others_ranking"]=="1"){
                                      isFirstHospital="Yes";
                                      
                                      }
                                      
                                                                                                }
                                                                                                          
                                                                                               
                                                                                                 if(obj_recommend[0]["education_ranking"]=="1" || obj_recommend[0]["education_ranking"]=="2" || obj_recommend[0]["education_ranking"]=="3"){
                                                                                                    
                                                                                                    isChildEducation_is = "Yes";
                                      
                                      if(obj_recommend[0]["education_ranking"]=="1"){
                                      isFirstEducation="Yes";
                                      
                                      }
                                      
                                                                                                }

                                                                                                          
                                                                                                 if(obj_recommend[0]["protection_ranking"]=="1" || obj_recommend[0]["protection_ranking"]=="2" || obj_recommend[0]["protection_ranking"]=="3"){
                                                                                                    
                                                                                                    isDeathDisTop3_is = "Yes";
                                      
                                      if(obj_recommend[0]["protection_ranking"]=="1"){
                                      isFirstDeathDis="Yes";
                                      }
                                      
                                      
                                                                                                }
                                                                                                  
                                                                                                          if(obj_recommend[0]["legacy_estate_planning_ranking"]=="1" || obj_recommend[0]["legacy_estate_planning_ranking"]=="2" || obj_recommend[0]["legacy_estate_planning_ranking"]=="3"){
                                                                                                                                                                         
                                                                                                                                                                         isLegacy_is = "Yes";
                                      
                                      
                                      
                                      if(obj_recommend[0]["legacy_estate_planning_ranking"]=="1"){
                                      isFirstLegacy="Yes";
                                      
                                      }
                                                                                                                                                                     }
                                                                                        
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                    if (changedProductMatrix != "" && changedProductMatrix != "{}") {
                                      
                                    for(var data in changedProductMatrix){
                                          var prodData = _.where(changedProductMatrix,{"product_name":changedProductMatrix[data]["product_name"]});
                                      if(isSavingTop3_is=="Yes"){
                                           prodConition.push("saving");
                                      if(isFirstSaving=="Yes"){
                                      priorityCondition.push("saving");
                                      }
                                          
                                       }
                                       if(isChildEducation_is=="Yes"){
                                           
                                           prodConition.push("education");
                                      
                                      if(isFirstEducation=="Yes"){
                                      priorityCondition.push("education");
                                      }
                                       }
                                       
                                       if(isIncomeTop3_is=="Yes"){
                                           
                                            prodConition.push("protection_critical_illness");
                                      
                                      if(isFirstIncome=="Yes"){
                                      priorityCondition.push("protection_critical_illness");
                                      }
                                       }
                                       
                                       if(isRirementTop3_is=="Yes"){
                                                             
                                                 prodConition.push("retirement");
                                      
                                      
                                      if(isFirstRirement=="Yes"){
                                      priorityCondition.push("retirement");
                                      }
                                      
                                      
                                                         }
                                       
                                      if(isDeathDisTop3_is=="Yes"){
                                            
                                                prodConition.push("protection");
                                      if(isFirstDeathDis=="Yes"){
                                      priorityCondition.push("protection");
                                      }
                                      
                                       }
                                       
                                       if(isHospitalTop3_is=="Yes"){
                                                                               
                                                 prodConition.push("hospital_cost");
                                      
                                      if(isFirstHospital=="Yes"){
                                      priorityCondition.push("hospital_cost");
                                      }
                                      
                                       }
                                       if(isLegacy_is=="Yes"){
                                                                                                  
                                                         prodConition.push("legacyPlanning");
                                      if(isFirstLegacy=="Yes"){
                                                priorityCondition.push("legacyPlanning");
                                                                }
                                                          }
                                      
                                      
                                         var uniqElement=_.uniq(prodConition);
                                         var uniqPriority=_.uniq(priorityCondition);
                                      
                                      
                                      if((prodConition.length!=0)){
                                                                                  var isAllTrue = [];
                                                                                   var TftfcH = "";
                                                                                   var ftfcprem = "";
                                                                                   if(ftfctimeHorizon=="20_100"){
                                                                                       TftfcH="20_"
                                                                                   }
                                                                                   else if(ftfctimeHorizon=="21_100"){
                                                                                       TftfcH="20_"
                                                                                   }else{
                                                                                      TftfcH=ftfctimeHorizon;
                                                                                   }
                                                                                   if(ftfcPremiumTerm=="20_100"){
                                                                                                              ftfcprem="20_"
                                                                                                          }else if(ftfcPremiumTerm=="21_100"){
                                                                                                              ftfcprem="20_"
                                                                                                          }
                                                                                                          else{
                                                                                                             ftfcprem=ftfcPremiumTerm;
                                                                                                          }
                                                            
                                                                               for(var iCounter=0; iCounter<=uniqElement.length-1;iCounter++)
                                                                               {
                                                                                   var valueData =uniqElement[iCounter];
                                                                                   
                                                                                   
                                                                                      
                                                                                   if(valueData=="saving"){
                                                                                          var  isDataPresent = _.where(prodData,{"saving":"Yes"});
                                                                                   }else if(valueData=="education"){
                                                                                        var  isDataPresent = _.where(prodData,{"education":"Yes"});
                                                                                   }
                                                                                   else if(valueData=="protection_critical_illness"){
                                                                                        var  isDataPresent = _.where(prodData,{"protection_critical_illness":"Yes"});
                                                                                   } else if(valueData=="retirement"){
                                                                                            var  isDataPresent = _.where(prodData,{"retirement":"Yes"});
                                                                                                                                 }
                                                                                   else if(valueData=="protection"){
                                                                                               var  isDataPresent = _.where(prodData,{"protection":"Yes"});
                                                                                                                                    }
                                                                                   else if(valueData=="hospital_cost"){
                                                                                    var  isDataPresent = _.where(prodData,{"hospital_cost":"Yes"});
                                                                                            }
                                                                                   else if(valueData=="legacyPlanning"){
                                                                                            var  isDataPresent = _.where(prodData,{"legacyPlanning":"Yes"});
                                                                                        }
                                                                                   
                                                                                
                                                                                  
                                                                                   
                                                                                   
                                                                                   if(isDataPresent!="" && isDataPresent!="undefined" && isDataPresent!=undefined){
                                                                                     // isAllTrue.push("Yes");
                                                                                       
                                                                                       var  isProductApplicable = _.where(prodData,{"time_horizon":TftfcH});
                                                                                       console.log("@time_horizon",isProductApplicable);
                                                                                       var isPremiumTermApplicable = _.where(isProductApplicable,{"ftfc_premium_payment_term":ftfcprem});
                                                                                         console.log("@ftfc_premium_payment_term",isPremiumTermApplicable);
                                                                                                                  
                                                                                                                  if((isProductApplicable!="" && isProductApplicable!=undefined && isProductApplicable!='undefined') && (isPremiumTermApplicable!="" && isPremiumTermApplicable!=undefined && isPremiumTermApplicable!='undefined'))
                                                                                                                  {
                                                                                                                      var ProdName = changedProductMatrix[data]["product_name"];
                                                                                                                    
                                                                                                                      recommendatedMysolution.push(ProdName)
                                                                                                                      
                                                                                                                  }
                                                                                       
                                                                                       
                                                                                       
                                                                                   }else{
                                                                                     // isAllTrue.push("No");
                                                                                       
                                                                                   }
                                                                                 
                                                                                   
                                                                                   
                                        
                                                            
                                                        }
                                   
                                      
                                      }
                                      
                                     //////////////
                                      if((priorityCondition.length!=0)){
                                      var filterData= ""
                                      var  isDataPriority="";
                                      for(var iCounter=0; iCounter<=uniqPriority.length-1;iCounter++)
                                        {
                                            var valueDataPriority =uniqPriority[iCounter];
                                                                                                                       
                                                                                                                       
                                                                                                                          
                                            if(valueDataPriority=="saving"){
                                              filterData= _.where(prodData,{"saving":"Yes"});
                                              //isDataPriority=_.where(filterData,{"Non_PWP_Product":"No"});
                                            }else if(valueDataPriority=="education"){
                                             filterData = _.where(prodData,{"education":"Yes"});
                                              //isDataPriority = _.where(filterData,{"Non_PWP_Product":"No"});
                                            }
                                            else if(valueDataPriority=="protection_critical_illness"){
                                              filterData = _.where(prodData,{"protection_critical_illness":"Yes"});
                                             // isDataPriority = _.where(filterData,{"Non_PWP_Product":"No"});
                                            } else if(valueDataPriority=="retirement"){
                                                 filterData = _.where(prodData,{"retirement":"Yes"});
                                                 //isDataPriority = _.where(filterData,{"Non_PWP_Product":"No"});
                                            }
                                            else if(valueDataPriority=="protection"){
                                                    filterData = _.where(prodData,{"protection":"Yes"});
                                                   // isDataPriority = _.where(filterData,{"Non_PWP_Product":"No"});
                                            }
                                                else if(valueDataPriority=="hospital_cost"){
                                                  filterData = _.where(prodData,{"hospital_cost":"Yes"});
                                                  //isDataPriority = _.where(filterData,{"Non_PWP_Product":"No"});
                                            }
                                            else if(valueDataPriority=="legacyPlanning"){
                                                  filterData = _.where(prodData,{"legacyPlanning":"Yes"});
                                                  //isDataPriority = _.where(filterData,{"Non_PWP_Product":"No"});
                                            }
                                                                                                                       
                                                               if(filterData!="" && filterData!="undefined" && filterData!=undefined)
                                                                  {
                                                                   console.log("@@filterData",filterData);
                                                                   isDataPriority = _.where(filterData,{"Non_PWP_Product":"No"});
                                      
                                                                  }
                                      
                                            
                                                                                                                      
                                                                                                                       
                                                                                                                       
                                                                                                                       if(isDataPriority!="" && isDataPriority!="undefined" && isDataPriority!=undefined){
                                                                                                                         
                                                                                                                            var ProdName = changedProductMatrix[data]["product_name"];
                                                                                                                                           
                                                                                                                          console.log("@obj_version",obj_version);
                                                                                                                          if(channelTypeForAgencyBancaRepls=="banca" && (!fnMPCompareTwoVersions(Jan2023Version,obj_version[0]['program_version']))){
                                                                                                                           obj_priority.push(ProdName);
                                                                                                                          }
                                      
                                                                                                                         
                                                                                                                       }else{
                                                                                                                         // isAllTrue.push("No");
                                                                                                                           
                                                                                                                       }
                                                                         
                                                                                                
                                                                                            }
                                      
                                      
                                      
                                      }
                                      
                                      
                                      
                                      
                                      } //
                                      
                                      console.log("@recommendatedMysolution",recommendatedMysolution)
                                      }
                                      
                                      
                                      
                                      
                                      
                                      ///////////////////////////
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                   
                                      
                                      
                                      if(obj_recommend[0]['protection_ranking']=="1")
                                      {
                                      riskProfile_ranking="0";
                                      }
                                      if(obj_recommend[0]['security_ranking']=="1")
                                      {
                                      riskProfile_ranking="1";
                                      }
                                      if(obj_recommend[0]['saving_ranking']=="1")
                                      {
                                      riskProfile_ranking="4";
                                      }
                                      if(obj_recommend[0]['education_ranking']=="1")
                                      {
                                      riskProfile_ranking="5";
                                      }
                                      if(obj_recommend[0]['others_ranking']=="1")
                                      {
                                      riskProfile_ranking="2";
                                      }
                                      if(obj_recommend[0]['investment_ranking']=="1")
                                      {
                                      riskProfile_ranking="3";
                                      }
                                      
                                      risk_profile_level=obj_recommend[0]["risk_profile_level"];
                                      console.log("RISK PROFILE"+risk_profile_level);
                                      
                                   //  obj_recommend[0]['risk_profile_score']
                                      
                        /////////////////////
                                      
                                      if(riskProfile_ranking == "0"){
                                      solnmyRiskProfileRanking = "Death_Disability";
                                      }else if(riskProfile_ranking == "1"){
                                      solnmyRiskProfileRanking = "Critical_Illness";
                                      }else if(riskProfile_ranking == "2"){
                                      solnmyRiskProfileRanking = "Medical_Hospital";
                                      }else if(riskProfile_ranking == "3"){
                                      solnmyRiskProfileRanking = "Retirement";
                                      }else if(riskProfile_ranking == "4"){
                                      solnmyRiskProfileRanking = "Savings";
                                      }else if(riskProfile_ranking == "5"){
                                      solnmyRiskProfileRanking = "Education";
                                      }
        
                                      
                                      
                                      
                                      ////////////
                                
                                      
                                      
                                      
                                      
                                      
                    }

         /**********************************************************************************************************************************************************************/
        var productRecommendationSoln=fnProductRecommendationSoln();
                                      
            productRecommendationSoln.execute(function(recommedResponse)
            {                                   var sequencePlanProduct= {};
                                                var arrSolution=[];
                                                var ribbenProductTemp=[];
             
                                              if(recommedResponse != "" && recommedResponse != null &&  recommedResponse != "null" &&  recommedResponse != "(null)" &&  recommedResponse != "{}")
                                              {
                                              
                                                 var recommendedSolution = JSON.parse(recommedResponse);
                                              
                                              testData=recommendedSolution;
                                              
                                              for (var i = 0; i < solutionPlanCsv.length; ++i)
                                              if (solutionPlanCsv[i] !== undefined) sequencePlanProduct[i] = solutionPlanCsv[i];
                                              
                                              for(var keys_solution in sequencePlanProduct)
                                              {
                                              
                                              arrSolution.push(sequencePlanProduct[keys_solution]["Basic_plan"])
                                              
                                              
                                              }
                                              
                                              var uniqElement=_.uniq(arrSolution)
                                              console.log("uniqElement",uniqElement)
                                              
                                              for( var key_rec in  recommendedSolution)
                                              {
                                              for(var i_counter=0;i_counter<=uniqElement.length-1;i_counter++)
                                              {
                                                    if(recommendedSolution[key_rec]["product_name"].indexOf(uniqElement[i_counter])>=0)
                                                    {
                                              console.log("uniqElement Data"+uniqElement[i_counter]);
                                             var filterSolution =_.where(sequencePlanProduct,{Basic_plan:uniqElement[i_counter]})
                                              
                                              var solnprodArray=[];
                                              for (var i = 0; i < filterSolution.length; i++)
                                              {
                                              if (filterSolution[i] !== undefined) solnprodArray[i] = filterSolution[i];
                                              
                                                    for(var keys in solnprodArray)
                                                    {
                                              
                                              
                                              //  ribbenProductTemp.push(solnprodArray[keys]["Solution"]);
                                              
                                                    }
                                              
                                              }
                                              
                                                    }
                                              
                                              
                                              }
                                              
                                              
                                              }
                                              
                                             // ribbenProduct=_.uniq(ribbenProductTemp);
                                              console.log("@@ribbenProduct"+ribbenProduct);
                                              
                                              }
                                              
                                              //Added for defect 1001 by sachin tupe on 3-07-2023 july 2023 release.
                                              sequencePlanProduct= {};
                                              for (var i = 0; i < solutionPlanCsv.length; ++i){
                                              if (solutionPlanCsv[i] !== undefined){
                                              sequencePlanProduct[i] = solutionPlanCsv[i];
                                              }
                                              }
                                              
                                              
                                              
                                              
                                              ribbenProduct=_.uniq(recommendatedMysolution);
                                              
                                              /********************************************************************************************************************************************/
                                              
                                              if(channelTypeForAgencyBancaRepls=="banca")
                                              {
                                                uniqElement=_.uniq(recommendedProd);
                                              //  obj_priority=uniqElement;
                                              }else{
                                              
                                              console.log("@@@recommendatedMysolution"+recommendatedMysolution);
                                              uniqElement=_.uniq(recommendatedMysolution);
                                              }
                                              
                                               for(var i_counter=0;i_counter<=uniqElement.length-1;i_counter++)
                                               {
                                                    
                                               console.log("uniqElement Data"+uniqElement[i_counter]);
                                              var filterSolution =_.where(sequencePlanProduct,{Basic_plan:uniqElement[i_counter]})
                                               
                                               var solnprodArray=[];
                                               for (var i = 0; i < filterSolution.length; i++)
                                               {
                                               if (filterSolution[i] !== undefined) solnprodArray[i] = filterSolution[i];
                                               
                                                     for(var keys in solnprodArray)
                                                     {
                                               
                                               
                                                 ribbenProductTemp.push(solnprodArray[keys]["Solution"]);
                                               
                                                     }
                                               
                                               }
                                               
                                                    
                                               
                                               
                                               }

                                                ribbenProduct=_.uniq(ribbenProductTemp);
                                               
                                              
                                              
                                              
                                              /************************************************************/
                                              
                                              
                                              
                                              
                                              
                                             
                                              
                                              
                                              
                                              
        var queryCheckYLP ="";
        var obj_YlpMs = "";
        var ylpInsuType ="";

        if(response_pro_req != "" && response_pro_req != null &&  response_pro_req != "null" &&  response_pro_req != "(null)")
        {
        var obj_replace = JSON.parse(response_pro_req);
        var res_ylp_replace=obj_replace['ylp_id'];
                              console.log("res_ylp_replace n Client_id"+res_ylp_replace+" ---- "+Client_id);
            queryCheck = fnMsPopulateClientDataPersn(res_ylp_replace,Client_id,ds_agentId);
            queryCheckYLP = fnMsPopulateClientDataPersn(res_ylp_replace,Client_id,ds_agentId);
        }else
        {
              console.log("res_ylps n Client_id--"+res_ylps+" ---- "+Client_id);
              if((res_ylps == "" || res_ylps == null || res_ylps == undefined) && (Client_id != "" && Client_id != undefined && Client_id != null)){
                  if(persontype == "mlife"){
                  startFromCareerkit = true;
                  }
                
              }
            queryCheck = fnMsPopulateClientDataPersn(res_ylps,Client_id,ds_agentId);
          queryCheckYLP =fnMsPopulateClientDataPersn(res_ylps,Client_id,ds_agentId);
        }
        
        queryCheckYLP.execute(function(responseYlpData)
      {
      if(responseYlpData != "" && responseYlpData != null &&  responseYlpData != "null" &&  responseYlpData != "(null)" &&  responseYlpData !="{}"){
            obj_YlpMs = JSON.parse(responseYlpData);
            ylpInsuType =obj_YlpMs[0]['insurence_type'];
      
      }
        easeCampaignCheck.execute(function(response_camp)
        {
         fnMSGetCompDetails.execute(function(responseMSComp)
        {
            if(responseMSComp != "" && responseMSComp != null &&  responseMSComp != "null" &&  responseMSComp != "(null)" &&  responseMSComp !="{}")
            {
              var obj_CompMs = JSON.parse(responseMSComp);
               CompanyNobMS=obj_CompMs[0]['comp_nob'];
                                    
            }
          
                                  
                console.log("###easeCampaignCheck");
        if(response_camp != "" && response_camp != null &&  response_camp != "null" &&  response_camp != "(null)" &&  response_camp !="{}")
            {
                 var obj_campaign = JSON.parse(response_camp);
                 var easeCamCode=obj_campaign[0]['campaign_code'];
                campaign_code_benefit_screen = obj_campaign[0]['campaign_code'];
                 femaleGender=obj_campaign[0]['gender'];
                 femaleAge=obj_campaign[0]['anb'];
                 female_smoke_status=obj_campaign[0]['smoke_status'];

                 console.log("FEMALE gender"+femaleGender);
                 console.log("FEMALE AGE"+femaleAge);
                 console.log("female_smoke_status"+female_smoke_status);
                                  
                console.log("###easeCamCode"+easeCamCode);
                /****if(easeCamCode!="" && (easeCamCode=="EASE1" || easeCamCode=="EASE2"))
                    {
                            easeCampaignCode=easeCamCode;
                                     
                    }******/
                                  
                    if(easeCamCode!="")
                    {
                        if(easeCamCode.indexOf("EASE1")>-1 && easeCamCode.indexOf("EASE2")>-1)
                        {
                              easeCampaignCode="EASE1";
                                  
                        }else if(easeCamCode.indexOf("EASE1")>-1)
                        {
                            easeCampaignCode="EASE1";
                                  
                        }else if(easeCamCode.indexOf("EASE2")>-1)
                        {
                               easeCampaignCode="EASE2";
                                  
                        }
                                  
                    }
                                     
            }
                       
        queryCheck.execute(function (response_persn)
        {
        var anb_client;
        var mfname = document.getElementById(id).value;
        var persin_id;
        var get_pid;
         
        if(persontype == "mlife")
        {
            persin_id= $("select[name='al_person_details.mlife.first_name_dropdown'] option:selected").index();
        }else if(persontype == "slife")
        {
            persin_id= $("select[name='al_person_details.slife.first_name_dropdown'] option:selected").index();
        } else if(persontype == "tlife")
        {
            persin_id= $("select[name='al_person_details.tlife.first_name_dropdown'] option:selected").index();
        }
                                                 
        if(typeof persin_id != "undefined" && persin_id != -1)
        {
            get_pid = person_id_ck[persin_id - 1];
           
        }
         
           if(response_persn != "" && response_persn != null &&  response_persn != "null" &&  response_persn != "(null)" && response_persn != "{}" )
           {
             var obj_resp =JSON.parse(response_persn);
              insurence_type_gb=obj_resp[0]["insurence_type"];
             ypfr_creation_dt = obj_resp[0]["ypfr_creation_dt"];
             console.log("insurence_type_gb---12---",insurence_type_gb)
             console.log("ypfr_creation_dt",ypfr_creation_dt)
           }
                           
       if((Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)") || (response_pro_req != "" && response_pro_req != null &&  response_pro_req != "null" &&  response_pro_req != "(null)"))
       {
                           
//                           if(Channel == "Banca")
//                           {
           
                           
                           
           if(persontype == "slife" && persontype != "mlife" && ((document.getElementById("al_person_details.mlife.anb").value <= 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <= 16 && isILproduct)))
           {
                           if((document.getElementById("al_person_details.mlife.anb").value >= 11 && document.getElementById("al_person_details.mlife.anb").value <= 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value >= 11 && document.getElementById("al_person_details.mlife.anb_il_product").value <= 16 && isILproduct))
                           {
                               if(document.getElementById("al_person_details.mlife.parent_consent_no").checked)
                               {
                           if(response_persn != "" && response_persn != null &&  response_persn != "null" &&  response_persn != "(null)" && response_persn != "{}" )
                            {
                   var obj_resp =JSON.parse(response_persn);
                   var person_id_resp = obj_resp[0]["pro_person_id"];
                  
                         
                   
                           console.log("mfname n Client_id n person_id_resp :: "+mfname+" --- "+Client_id+" --- "+person_id_resp);
                           
                   querySelect = fnMsPopulateClientDataProposer(mfname,Client_id,person_id_resp,ds_agentId);
                               document.getElementById("al_person_details.slife.first_name_dropdown").disabled=true;
                              // document.getElementById("al_person_details.slife.relationship").disabled=true;//Commented By Rahul on 06.11.2015 as relationship dropdown disabled from myneeds
                           }
                           else
                           {
                           if(persontype=="slife")
                           {
                           document.getElementById("al_person_details.slife.relationship").disabled=false;
                           }
                           querySelect = fnMsPopulateClientData(mfname,Client_id,get_pid,ds_agentId);
                           }
                               }else if(document.getElementById("al_person_details.mlife.parent_consent_yes").checked)
                               {
                               //do nothing
                                fnMsDisableLives("al_person_details.mlife.parent_consent_yes");
                               }
                           }
                           else if((document.getElementById("al_person_details.mlife.anb").value <= 11 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <= 11 && isILproduct))
                           {
                           if(response_persn != "" && response_persn != null &&  response_persn != "null" &&  response_persn != "(null)" && response_persn != "{}" )
                           {
                               var obj_resp =JSON.parse(response_persn);
                               var person_id_resp = obj_resp[0]["pro_person_id"];
                           
                           
                           console.log("mfname n Client_id n person_id_resp 2 :: "+mfname+" --- "+Client_id+" --- "+person_id_resp);
                               querySelect = fnMsPopulateClientDataProposer(mfname,Client_id,person_id_resp,ds_agentId);
                               document.getElementById("al_person_details.slife.first_name_dropdown").disabled=true;
                              // document.getElementById("al_person_details.slife.relationship").disabled=true;
                           }else
                           {
                          // alert("295");
                           if(persontype=="slife")
                           {
                               document.getElementById("al_person_details.slife.first_name_dropdown").disabled=false;
                               document.getElementById("al_person_details.slife.relationship").disabled=false;
                           }
                           querySelect = fnMsPopulateClientData(mfname,Client_id,get_pid,ds_agentId);
                           }
                           }
                           }else if((persontype == "slife" || persontype == "tlife") && persontype != "mlife" && ((document.getElementById("al_person_details.mlife.anb").value > 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value > 16 && isILproduct)))
                           {
                           console.log("mfname n Client_id n get_pid 1 :: "+mfname+" ---- "+Client_id+" ---- "+get_pid+"--------"+client_ylp_type_mlife+"----------"+response_persn);
                           if((((document.getElementById("al_person_details.mlife.anb").value==17 || document.getElementById("al_person_details.mlife.anb").value==18) && !isILproduct) || ((document.getElementById("al_person_details.mlife.anb_il_product").value==17 || document.getElementById("al_person_details.mlife.anb_il_product").value==18) && isILproduct)) && client_ylp_type_mlife=="lo")
                           {
                               if(response_persn != "" && response_persn != null &&  response_persn != "null" &&  response_persn != "(null)" && response_persn != "{}" )
                               {
                                   var obj_resp =JSON.parse(response_persn);
                                   var person_id_resp = obj_resp[0]["pro_person_id"];
                           
                                   
                                   console.log("mfname n Client_id n person_id_resp 2 :: "+mfname+" --- "+Client_id+" --- "+person_id_resp);
                                   querySelect = fnMsPopulateClientDataProposer(mfname,Client_id,person_id_resp);
                                    document.getElementById("al_person_details.slife.first_name_dropdown").disabled=true;
                                   if(persontype=="slife")
                                   {
                                        document.getElementById("al_person_details.slife.relationship").disabled=false;
                                   }
                               }
                               else
                               {
                                   if(persontype=="slife")
                                   {
                                        document.getElementById("al_person_details.slife.first_name_dropdown").disabled=false;
                                        document.getElementById("al_person_details.slife.relationship").disabled=false;
                                   }
                                    querySelect = fnMsPopulateClientData(mfname,Client_id,get_pid,ds_agentId);
                               }
                           }
                           else
                           {
                                querySelect = fnMsPopulateClientData(mfname,Client_id,get_pid,ds_agentId);
                               if(persontype == "tlife" && ((document.getElementById("al_person_details.mlife.anb").value <= 18 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <= 18 && isILproduct)))
                               {
                                    document.getElementById("al_person_details.slife.first_name_dropdown").disabled=true;
                               }else
                               {
                                    document.getElementById("al_person_details.slife.first_name_dropdown").disabled=false;
                               }
                           }
                           
                           }else if(persontype=="tlife"){
                           // Changes made by pramod chavan for def 3650
                           if(response_pro_req!=""&&response_pro_req!=null&&response_pro_req!="null"&&response_pro_req!="(null)")
                           {
                           if(client_ylp_type_mlife=="lo"){
                           querySelect=fnMsPopulateClientData(mfname,Client_id,get_pid,ds_agentId);
                           }
                           }
                          
                           }
                           //}
       }
                  // TODO
       if(!(persontype == "slife" && document.getElementById("al_person_details.mlife.anb").value <= 18))
       {
                           if(response_pro_req == "" || response_pro_req == null ||  response_pro_req == "null" ||  response_pro_req == "(null)")
                           {
                           console.log("mfname n Client_id n get_pid 2 :: "+mfname+" ---- "+Client_id+" ---- "+get_pid);
           querySelect = fnMsPopulateClientData(mfname,Client_id,get_pid,ds_agentId);
           
           if((persontype == "tlife") && ((document.getElementById("al_person_details.mlife.anb").value <= 18 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <= 18 && isILproduct)))
           {
           document.getElementById("al_person_details.slife.first_name_dropdown").disabled=true;
           }else
           {
           document.getElementById("al_person_details.slife.first_name_dropdown").disabled=false;
           }
           }
                           }
       
        if(!(persontype == "slife" && ((document.getElementById("al_person_details.mlife.anb").value <= 18 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <= 18 && isILproduct))))
        {
                           if(response_pro_req != "" && response_pro_req != null &&  response_pro_req != "null" &&  response_pro_req != "(null)")
                           {
                           if(Channel != "Banca" && Channel != "UOB")//changed by Purva / Pramod C on 07th Aug 2017 for UOB
                           {
                                console.log("mfname n Client_id n get_pid 3:: "+mfname+" ---- "+Client_id+" ---- "+get_pid);
                                querySelect = fnMsPopulateClientData(mfname,Client_id,get_pid,ds_agentId);
                               
                                if(persontype == "tlife" && ((document.getElementById("al_person_details.mlife.anb").value <= 18 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <= 18 && isILproduct)))
                                {
                                    document.getElementById("al_person_details.slife.first_name_dropdown").disabled=true;
                                }else
                                {
                                    document.getElementById("al_person_details.slife.first_name_dropdown").disabled=false;
                                }
                           }
                           }
        }else if((persontype == "slife" ||  persontype == "tlife" ) && persontype != "mlife" && ((document.getElementById("al_person_details.mlife.anb").value <= 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <= 16 && isILproduct)) && (res_ylps != "" && res_ylps != null && res_ylps != "null" && res_ylps != "(null)"))
        {
            if(persontype == "slife")
            {
                if(response_persn != "" && response_persn !=null && response_persn !="{}")
                {
                    var obj_resp =JSON.parse(response_persn);
                    var person_id_resp = obj_resp[0]["pro_person_id"];
                    
                           
                           console.log("mfname n Client_id n person_id_resp 3 :: "+mfname+" --- "+Client_id+" --- "+person_id_resp);
                    querySelect = fnMsPopulateClientDataProposer(mfname,Client_id,person_id_resp,ds_agentId);
                }else
                           {
                               if(persontype=="slife")
                               {
                                    document.getElementById("al_person_details.slife.first_name_dropdown").disabled=false;
                                    document.getElementById("al_person_details.slife.relationship").disabled=false;
                               }
                               querySelect = fnMsPopulateClientData(mfname,Client_id,get_pid,ds_agentId);
                           }
                
               
            }
                   if(res_ylps != "" && res_ylps != null && res_ylps != "null" && res_ylps != "(null)")
                   {
                   document.getElementById("al_person_details.slife.first_name_dropdown").disabled=true;
                   }else
                   {
                   document.getElementById("al_person_details.slife.first_name_dropdown").disabled=false;
                   }
          }else if((persontype == "slife" ||  persontype == "tlife" )  && persontype != "mlife" && ((document.getElementById("al_person_details.mlife.anb").value <= 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <= 16 && isILproduct)) && (res_ylps == "" || res_ylps == null || res_ylps == "null" || res_ylps == "(null)"))
          {
                           if(response_pro_req == "" || response_pro_req == null ||  response_pro_req == "null" || response_pro_req == "(null)")
                           {
                           
                           console.log("mfname n Client_id n get_pid 4 :: "+mfname+" ---- "+Client_id+" ---- "+get_pid);
              querySelect = fnMsPopulateClientData(mfname,Client_id,get_pid,ds_agentId);
              
              if(persontype == "tlife" && ((document.getElementById("al_person_details.mlife.anb").value <= 18 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <= 18 && isILproduct)))
              {
              document.getElementById("al_person_details.slife.first_name_dropdown").disabled=true;
              }else
              {
              document.getElementById("al_person_details.slife.first_name_dropdown").disabled=false;
              }
                           }
        }

            querySelect.execute(function (response)
                                {
                if(response != "" && response !=null && response !="{}")
                {
                    var obj=JSON.parse(response);
                    for (sub in obj)
                    {
                               // ANB_set = "0";
                        var elementsArray="";
                        var objSub="";
                        objSub = obj[sub];
                        elementsArray = Object.keys(objSub);
                        
                                if(persontype == "mlife")
                                {
                                client_ylp_type_mlife = "";
                                
                                }else if(persontype == "slife")
                                {
                                client_ylp_type_slife = "";
                                
                                }else if(persontype == "tlife")
                                
                                {
                                client_ylp_type_tlife = "";
                                }
                                
                        for(var i=0 ;i< elementsArray.length; i++)
                        {
                                console.log("persontype 8263:"+persontype+"--relationship:"+elementsArray[i]);
                            if(persontype == "mlife")
                            {
                                if(elementsArray[i] == "ylp_type")
                                {
                                
                                    client_ylp_type_mlife = obj[sub]["ylp_type"];
                                }
                                if(client_ylp_type_mlife=="you")//Added condition by Sachin Tupe for pwy Ease gio/sio on date 02-08-2018.
                                {
                                console.log("EASE Mlife");
                                 var  easeCampaignCodeMlife=obj[sub]["campaign_code"];//Added by Sachin Tupe for Ease Campaign for pruwith you on date 02-08-2018.
                                 console.log("EASE Mlife Campaign"+easeCampaignCodeMlife);
                                
                                if(easeCampaignCodeMlife!="")
                                {
                                if(easeCampaignCodeMlife.indexOf("EASE1")>-1 && easeCampaignCodeMlife.indexOf("EASE2")>-1)
                                {
                                easeCampaignCode="EASE1";
                                
                                }else if(easeCampaignCodeMlife.indexOf("EASE1")>-1)
                                {
                                easeCampaignCode="EASE1";
                                
                                }else if(easeCampaignCodeMlife.indexOf("EASE2")>-1)
                                {
                                easeCampaignCode="EASE2";
                                
                                }
                                
                                }
                                
                                
                               
                                
                                }
                            }else if(persontype == "slife")//Added condition by Sachin Tupe for pwy Ease gio/sio on date 02-08-2018.
                            {
                                if(elementsArray[i] == "ylp_type")
                                {
                                    client_ylp_type_slife = obj[sub]["ylp_type"];
                                }
                                
                                if(client_ylp_type_slife=="you")//Added condition by Sachin Tupe for pwy Ease gio/sio on date 02-08-2018.
                                {
                                 console.log("EASE Slife--->");
                              var  easeCampaignCodeSlife=obj[sub]["campaign_code"];//Added by Sachin Tupe for Ease Campaign for pruwith you on date 02-08-2018.
                                console.log("EASE Slife Campaign"+easeCampaignCodeSlife);
                                
                                
                                if(easeCampaignCodeSlife!="")
                                {
                                if(easeCampaignCodeSlife.indexOf("EASE1")>-1 && easeCampaignCodeSlife.indexOf("EASE2")>-1)
                                {
                                easeCampaignCode="EASE1";
                                SecondLifeEaseCampaignCode=true;
                                console.log("@@SecondLifeEaseCampaignCode"+SecondLifeEaseCampaignCode);
                                
                                }else if(easeCampaignCodeSlife.indexOf("EASE1")>-1)
                                {
                                easeCampaignCode="EASE1";
                                SecondLifeEaseCampaignCode=true;
                                console.log("@@SecondLifeEaseCampaignCode"+SecondLifeEaseCampaignCode);
                                
                                }else if(easeCampaignCodeSlife.indexOf("EASE2")>-1)
                                {
                                easeCampaignCode="EASE2";
                                SecondLifeEaseCampaignCode=true;
                                console.log("@@SecondLifeEaseCampaignCode"+SecondLifeEaseCampaignCode);
                                
                                }
                                
                                }

                                
                                
                                //
                                
                                }

                                
                            }else if(persontype == "tlife")//Added condition by Sachin Tupe for pwy Ease gio/sio on date 02-08-2018.
                            {
                                if(elementsArray[i] == "ylp_type")
                                {
                                    client_ylp_type_tlife = obj[sub]["ylp_type"];
                                }
                                
                                if(client_ylp_type_tlife=="you")
                                {
                                console.log("EASE tlife");
                               var  easeCampaignCodeTlife=obj[sub]["campaign_code"];//Added by Sachin Tupe for Ease Campaign for pruwith you on date 02-08-2018.
                                 console.log("EASE tlife Campaign"+easeCampaignCode);
                                
                                
                                if(easeCampaignCodeTlife!="")
                                {
                                if(easeCampaignCodeTlife.indexOf("EASE1")>-1 && easeCampaignCodeTlife.indexOf("EASE2")>-1)
                                {
                                easeCampaignCode="EASE1";
                                ThirdLifeEaseCampaignCode=true;
                                console.log("@@ThirdLifeEaseCampaignCode"+ThirdLifeEaseCampaignCode);
                                
                                }else if(easeCampaignCodeTlife.indexOf("EASE1")>-1)
                                {
                                easeCampaignCode="EASE1";
                                ThirdLifeEaseCampaignCode=true;
                                console.log("@@ThirdLifeEaseCampaignCode"+ThirdLifeEaseCampaignCode);
                                
                                }else if(easeCampaignCodeTlife.indexOf("EASE2")>-1)
                                {
                                easeCampaignCode="EASE2";
                                ThirdLifeEaseCampaignCode=true;
                                console.log("@@ThirdLifeEaseCampaignCode"+ThirdLifeEaseCampaignCode);
                                
                                }
                                
                                }

                                
                                
                                //
                                
                                }
                            }
                                
                            if(elementsArray[i] == "first_name")
                            {
                                if(persontype == "slife" && mfname!="" && mfname!="Select")
                                {
                                if(mfname!=obj[sub][elementsArray[i]])
                                alert("749",mfname);
                                }
                                
                                
                                document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_dropdown").value = obj[sub][elementsArray[i]];
                                
                                if(persontype == "slife" && ((document.getElementById("al_person_details.mlife.anb").value <= 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <= 16 && isILproduct)))
                                {
                                    fnMsSolSelectElement(obj[sub][elementsArray[i]],"al_person_details."+persontype+".first_name_dropdown");
                                }
                            }else if(elementsArray[i] == "insurence_type" && persontype == "mlife")
                            {
                            if((obj[sub][elementsArray[i]] !== "" || ylpInsuType !== "") && obj[sub][elementsArray[i]] !== null)
                            {
                                if(obj[sub][elementsArray[i]] == "individual" || ylpInsuType == "individual"){
                                document.getElementById("al_person_details.mlife.insu_type_header").value = "non_business_purpose";
                                }else{
                                    document.getElementById("al_person_details.mlife.insu_type_header").value = "business_purpose";
                                    document.getElementById("al_person_details.mlife.insu_type").value = obj[sub][elementsArray[i]];
                                if(ylpInsuType !== ""){
                                 document.getElementById("al_person_details.mlife.insu_type").value = ylpInsuType;
                                }
                                }
                            
                            $(escape_jq("al_person_details.mlife.insu_type")).removeClass('mandatory');
                            $(escape_jq("al_person_details.mlife.insu_type")).removeClass('selectRedMandatory');
                            $(escape_jq("al_person_details.mlife.insu_type")).attr("disabled","true");
                            }
                            
                            }
                            else if(elementsArray[i] == "smoke_status")
                            {
                                if(obj[sub][elementsArray[i]] == "No")
                                {
                                    document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_yes").checked=false;
                                    document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_no").checked=true;
                                }
                                else if(obj[sub][elementsArray[i]] == "Yes")
                                {
                                    document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_yes").checked=true;
                                    document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_no").checked=false;
                                }else
                                {
                                    document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_yes").checked=false;
                                    document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_no").checked=true;
                                }
                            }else if(elementsArray[i] == "gender")
                            {
                                console.log("gender populate:"+obj[sub][elementsArray[i]]);
                                if(obj[sub][elementsArray[i]] == "F")
                                {
                                    document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_male").checked=false;
                                    document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_female").checked=true;
                                console.log("persontype:"+persontype);
                                //document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_female").disabled=true;
                                    if(persontype == "slife")
                                    {
                                   //added by ankita 7 april 2022
                                   //document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_female").disabled=true;
                                        validatePreNatalforThrirdLife();
                                        ClearDataonChange('slife',"");
                                document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_male").disabled=true;
                                
                                    }
                                }
                                else if(obj[sub][elementsArray[i]] == "M")
                                {
                                    document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_male").checked=true;
                                    document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_female").checked=false;
                                //document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_male").disabled=true;
                                
                                    if(persontype == "slife")
                                    {
                                //added by ankita 7 april 2022
                                
                                
                                        validatePreNatalforThrirdLife();
                                        ClearDataonChange('slife',"");
                                document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_female").disabled=true;
                                
                                    }
                                }
                                
                            }
                           else if(elementsArray[i] == "dob" || elementsArray[i] == "anb")
                            {
                                // TODO
                                if((persontype=="slife" || persontype=="tlife") && elementsArray[i] == "anb")
                                {
                                if(calculatedAge!="")
                                {
                                ANB_set1 = calculatedAge;
                                }
                                else{
                                ANB_set1 = obj[sub][elementsArray[i]];
                                }
                                    if (obj[sub][elementsArray[i]] < 19) {
                                      document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value ="";
                                    }
                                    else
                                    {
                                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = ANB_set1;
                                    }
                                    if(persontype=="tlife")
                                    {
                                        if(document.getElementById("al_person_details.pre_natal_child_flg").checked)
                                        {
                                            if(getGender("tlife")=="Male")
                                            {
                                                if (obj[sub][elementsArray[i]] < 18) {
                                                    document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value ="";
                                                }
                                                else
                                                {
                                                    document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = ANB_set1;
                                                }
                                            }
                                            else if(getGender("tlife")=="Female")
                                            {
                                                            //if (obj[sub][elementsArray[i]] < 19)//Old condition Changed for defect 6470 by sachi on date 10-10-2018.
                                                if (obj[sub][elementsArray[i]] <= 17)//Added by Sachin Tupe for defect 6470.
                                                {
                                                    document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value ="";
                                
                                                }
                                                else
                                                {
                                                    document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = obj[sub][elementsArray[i]];
                                                }
                                            }
                                
                                        }
                                        else
                                        {
                                            if (obj[sub][elementsArray[i]] < 18) {
                                                document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value ="";
                                            }
                                            else
                                            {
                                                document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = ANB_set1;
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    if(calculatedAge!="")
                                    {
                                        ANB_set1 = calculatedAge;
                                    }
                                    else{
                                        ANB_set1 = obj[sub][elementsArray[i]];
                                    }
                                    document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = ANB_set1;
                                }
                                if(persontype == "mlife")
                                {
                                relationship_mlife = obj[sub]["relationship"];
                                }else if(persontype == "slife")
                                {
                                relationship_slife = obj[sub]["relationship"];
                                }else if(persontype == "tlife")
                                {
                                relationship_tlife = obj[sub]["relationship"];
                                }
                                
                                console.log("relationship :: "+ relationship_mlife+" === "+relationship_slife+" --- "+relationship_tlife)
                                
                                if(elementsArray[i] == "anb" && persontype == "mlife")
                                {
                                if(calculatedAge!="")
                                {
                                 ANB_set = calculatedAge;
                                }
                                else{
                                 ANB_set = obj[sub][elementsArray[i]];
                                }
                                    anb_client = obj[sub][elementsArray[i]]
                                ANB_set = obj[sub][elementsArray[i]];
                                console.log("ANB_set 31 :: "+ANB_set);
                                }
                                
                                    if(elementsArray[i] == "dob")
                                    {
                                        elementName_populate = "al_person_details."+persontype+"."+elementsArray[i];
                                        var day_res = obj[sub][elementsArray[i]].split("/");
                                        if(persontype=="mlife")
                                        {
                                                ANB_set=obj[sub]["anb"];
                                        }
                                
                                        if(ANB_json[0]["anb_type"]=="IL_Daily" && (ANB_json[0]["anb_type"]!="" && ANB_json[0]["anb_type"]!='undefined' && ANB_json[0]["anb_type"]!=undefined && ANB_json[0]["anb_type"]!="{}"))
                                        {
                                        fnMsCalculateANBforILproducts(persontype, obj[sub][elementsArray[i]]);// calculate IL product ANB. changes made by pramod chavan: 09122017
                                        }else if(ANB_json[0]["anb_type"]=="IL_Monthly" && (ANB_json[0]["anb_type"]!="" && ANB_json[0]["anb_type"]!='undefined' && ANB_json[0]["anb_type"]!=undefined && ANB_json[0]["anb_type"]!="{}"))
                                            {
                                         fnMsCalculateANBforIL_monthlyproducts(persontype, obj[sub][elementsArray[i]]);//TODO 1-06-2018;
                                            }
                                        CheckDate(elementName_populate, obj[sub][elementsArray[i]], day_res[0], day_res[1], day_res[2]);
                                    }
                            }else if(elementsArray[i] == "occupation_class")
                                {
                                     console.log("values"+document.getElementById("al_employee_details."+persontype+".occupation").value+"===="+document.getElementById("al_employee_details."+persontype+".nature_of_business").value)
                                if(obj[sub][elementsArray[i]] != "" && obj[sub][elementsArray[i]] != null && obj[sub][elementsArray[i]] != "null"  && obj[sub][elementsArray[i]] != "(null)")
                                {
                                document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value = obj[sub][elementsArray[i]];
                                }
                                else
                                {
                                    if(document.getElementById("al_employee_details."+persontype+".occupation_class").value != "Select")
                                    {
                                    //var res_occ_class = document.getElementById("al_employee_details."+persontype+".occupation").value.split("-"); //change
                                    //document.getElementById("al_employee_details."+persontype+".occupation_class").value = res_occ_class[1];
                                    fngetOccupationClassFromMatrix("al_employee_details."+persontype+".occupation","al_employee_details."+persontype+".nature_of_business","al_employee_details."+persontype+".occupation_class")
                                
                                    }else
                                    {
                                    document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value = "";
                                    }
                                }
                            }else if(elementsArray[i] == "occupation")
                                {
                                    if(obj[sub][elementsArray[i]] != "" && obj[sub][elementsArray[i]] != null && obj[sub][elementsArray[i]] != "null"  && obj[sub][elementsArray[i]] != "(null)")
                                    {
                                        var occupation_class;
                                        if(persontype == "mlife")
                                        {
                                            occupation_class = "occupationSearchMLifeText";
                                            nob_class = "natureSearchMLife";
                                            nob_class_txt = "natureSearchMLifeText";
                                        }else if(persontype == "slife")
                                        {
                                            occupation_class = "occupationSearchSLifeText";
                                            nob_class = "natureSearchSLife";
                                            nob_class_txt = "natureSearchSLifeText";
                                        }else if(persontype == "tlife")
                                        {
                                            occupation_class = "occupationSearchTLifeText";
                                            nob_class = "natureSearchTLife";
                                            nob_class_txt = "natureSearchTLifeText";
                                        }
                                
                                        if(obj[sub][elementsArray[i]] == "Occupation")
                                        {
                                            document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value = "Select";
                                             $("."+occupation_class).val("");
                                        }else
                                        {
                                        var occu_data_res = $('#al_employee_details\\.'+persontype+'\\.occupation option:contains("'+obj[sub][elementsArray[i]]+'")').val();
                                
//                                        document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value = occu_data_res;
                    
//                                            $("."+occupation_class).val(occu_data_res);
                                //Added by Paromita on 16 Aug 2017 for new Occupation list
                                
            document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value = obj[sub][elementsArray[i]]//+"-"+obj[sub]["occupation_class"];
                                                                                                             
                                $("."+occupation_class).val(obj[sub][elementsArray[i]])//+"-"+obj[sub]["occupation_class"]);
                                
                                //Added by Paromita on 14 Aug 2017 for new Occupation list
                                getNatureOfBusinessList("al_employee_details."+persontype+".occupation","al_employee_details."+persontype+".nature_of_business","al_employee_details."+persontype+".occupation_class","natureSearchMLifeText",persontype);//Added by Paromita on 14 Aug 2017
                                fngetOccupationClassFromMatrix("al_employee_details."+persontype+".occupation","al_employee_details."+persontype+".nature_of_business","al_employee_details."+persontype+".occupation_class")

                                
//                                var res_occ_class = document.getElementById("al_employee_details."+persontype+".occupation").value.split("-");
//                                console.log("pramod 22022017 res_occ_class"+res_occ_class+"-------"+res_occ_class[1]+"------->"+persontype);
                                
//                                document.getElementById("al_employee_details."+persontype+".occupation_class").value = res_occ_class[1];
                                if(document.getElementById("al_employee_details."+persontype+".occupation").value  == "Child" && ((document.getElementById("al_person_details.mlife.anb").value <= 18 && !isILproduct) ||(ilMainLifeANB <= 18 && isILproduct)))
                                {
                                    if((document.getElementById("al_person_details.mlife.anb").value<=16 && !isILproduct) || (ilMainLifeANB<=16 && isILproduct))
                                    {
                                        $(".occupationSearchMLifeText").attr("disabled","true");
                                        $(".natureSearchMLifeText").attr("disabled","true");
                                    }
                               
                                    document.getElementById("al_employee_details."+persontype+".nature_of_business").value  == "Child";
                               

                                    fnMsSolSelectElement("Child","al_employee_details."+persontype+".nature_of_business");
                                    $("."+nob_class_txt).val("Child");
                                }
                                
                                
                                        }
                                    }else
                                    {
                                document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value = "Select";
                                        $("."+occupation_class).val("");
                                    }
                                if(obj[sub][elementsArray[i]]  == "Student" || obj[sub][elementsArray[i]]=="Student Pilot-2" ||obj[sub][elementsArray[i]]=="Pilot (Student)-2")
                                {
                                document.getElementById("al_employee_details."+persontype+".nature_of_business").value="Student";
                                
                                document.getElementById("al_employee_details."+persontype+".nature_of_business").disabled=true;
                                
                                }
                                else if(obj[sub][elementsArray[i]]  == "Housewife")
                                {
                                  document.getElementById("al_employee_details."+persontype+".nature_of_business").value="Housewife";
                                
                                  document.getElementById("al_employee_details."+persontype+".nature_of_business").disabled=true;
                                }
                                else if(obj[sub][elementsArray[i]]  == "Child")
                                {
                                document.getElementById("al_employee_details."+persontype+".nature_of_business").value="Child";
                                
                                document.getElementById("al_employee_details."+persontype+".nature_of_business").disabled=true;
                                }

                                else if(obj[sub][elementsArray[i]]  == "Retiree" || obj[sub][elementsArray[i]]=="Pensioner-2")
                                {
                                document.getElementById("al_employee_details."+persontype+".nature_of_business").value="Retiree";
                                
                                document.getElementById("al_employee_details."+persontype+".nature_of_business").disabled=true;
                                }
                                console.log("occupation value=="+document.getElementById("al_employee_details."+persontype+".occupation").value+"=="+document.getElementById("al_employee_details."+persontype+".nature_of_business").value)
                                
                                if(document.getElementById("al_employee_details."+persontype+".occupation_class").value =="")
                                   {
                                     fngetOccupationClassFromMatrix("al_employee_details."+persontype+".occupation","al_employee_details."+persontype+".nature_of_business","al_employee_details."+persontype+".occupation_class");
                                   }
                                
                              
                                }
                                else if(elementsArray[i] == "nature_of_business")
                                {
                                if(persontype=="mlife")
                                {
                                    ANB_set=obj[sub]["anb"];
                                }
                                
                                console.log("pramod nob--obj[sub][elementsArray[i]"+obj[sub][elementsArray[i]]+"--"+persontype);
                                var nob_class;
                                var nob_class_txt;
                                if(persontype == "mlife")
                                {
                                nob_class = "natureSearchMLife";
                                nob_class_txt = "natureSearchMLifeText";
                                }else if(persontype == "slife")
                                {
                                nob_class = "natureSearchSLife";
                                nob_class_txt = "natureSearchSLifeText";
                                
                                }else if(persontype == "tlife")
                                {
                                nob_class = "natureSearchTLife";
                                nob_class_txt = "natureSearchTLifeText";
                                
                                }
                                if(obj[sub][elementsArray[i]] != "" && obj[sub][elementsArray[i]] != null && obj[sub][elementsArray[i]] != "null"  && obj[sub][elementsArray[i]] != "(null)")
                                {
                                
                                console.log("Check nob :: "+obj[sub][elementsArray[i]]);
                                
                                
                                    if(obj[sub][elementsArray[i]] == "Nature of Business" || obj[sub][elementsArray[i]] == "Select" || obj[sub][elementsArray[i]]=="select" ||obj[sub][elementsArray[i]]=="" )       // sayalip
                                    {
                                
                                        document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value = "Select";
                                        $("."+nob_class_txt).prop("disabled",false);
                                        fnMsSolSelectElement("Nature of Business","al_employee_details."+persontype+".nature_of_business");
                                        $("."+nob_class_txt).val("");
                                            console.log("Check nob1 :: "+obj[sub][elementsArray[i]]+" --- "+document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value);
                                
                                    }else
                                    {
                                
                                // #Prashant
                                         //Date 22 July 2015
                                           // fnDisableNOBForNonIncomeOnLoad("",nob_class_txt);
                                         //#Code End
                                //added
                                console.log("---------------->"+obj[sub]["occupation"]+"------"+persontype)
                                if(obj[sub]["occupation"]!="" && obj[sub]["occupation"]!="Select" && obj[sub]["occupation"]!="select" && obj[sub]["occupation"]!="Occupation" && obj[sub]["occupation"]!="null"&& obj[sub]["occupation"]!=null &&obj[sub]["occupation"]!="(null)" )
                                {
                                  document.getElementById("al_employee_details."+persontype+".occupation").value=obj[sub]["occupation"];
                                }
                                console.log("Occupation : :"+document.getElementById("al_employee_details."+persontype+".occupation").value);
                                        if(document.getElementById("al_employee_details."+persontype+".occupation").value  == "Student" || document.getElementById("al_employee_details."+persontype+".occupation").value  == "Housewife" || document.getElementById("al_employee_details."+persontype+".occupation").value  == "Child" || document.getElementById("al_employee_details."+persontype+".occupation").value  == "Retiree"
                                           || document.getElementById("al_employee_details."+persontype+".occupation").value  == "Pensioner"
                                           || document.getElementById("al_employee_details."+persontype+".occupation").value  == "Unemployed")
                                        {
                                               // document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value = obj[sub][elementsArray[i]];
                                                //var nob_set_data = $("."+nob_class).find("option:selected").text();
//                                document.getElementById("al_person_details.mlife.anb").value<=16
                                var nobMlifeStudent = ""; // below if condition added to resolved production defect "undefined occ class" changes made by pramod chavan 05122017
                                if(document.getElementById("al_employee_details."+persontype+".occupation").value=="Student"){
                                nobMlifeStudent="Student";
                                
                                }else if(document.getElementById("al_employee_details."+persontype+".occupation").value=="Housewife"){
                                nobMlifeStudent="Housewife";
                                }else if(document.getElementById("al_employee_details."+persontype+".occupation").value=="Child"){
                                nobMlifeStudent="Child";
                                }else if(document.getElementById("al_employee_details."+persontype+".occupation").value=="Retiree"){
                                nobMlifeStudent="Retiree";
                                }
                                else if(document.getElementById("al_employee_details."+persontype+".occupation").value=="Pensioner")
                                {
                                nobMlifeStudent="Pensioner";
                                }
                                else if(document.getElementById("al_employee_details."+persontype+".occupation").value=="Unemployed")
                                {
                                nobMlifeStudent="Unemployed";
                                }
                                else{
                                 nobMlifeStudent = nobObjTwo[obj[sub][elementsArray[i]]];
                                }
                                
                                document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value = nobMlifeStudent;
                                                var nob_set_data=nobMlifeStudent;
                                console.log("nob_set_data" +nob_set_data);
                                                $("."+nob_class_txt).val(nob_set_data);
                                                 fnMsSolSelectElement(nobMlifeStudent,"al_employee_details."+persontype+".nature_of_business");
                                                 fnDisableNOBForNonIncomeOnLoad("",nob_class_txt);
                               document.getElementById("al_employee_details."+persontype+".nature_of_business").disabled=true;
                                console.log("12-->"+document.getElementById("al_employee_details."+persontype+".nature_of_business").disabled);
                                        }
                                        else
                                        {
                                // pramod chavan 14042017 need to be change logic. TODO
                                if(persontype=="slife"){
                                if(obj[sub][elementsArray[i]]=="Select" || obj[sub][elementsArray[i]]==""){
                                console.log("pramod nob value"+obj_slife["al_employee_details.slife.nature_of_business"]);
                                if(obj_slife["al_employee_details.slife.nature_of_business"]=="" || obj_slife["al_employee_details.slife.nature_of_business"]=="Select"
                                   || obj_slife["al_employee_details.slife.nature_of_business"]=="undefined"){
                                obj[sub][elementsArray[i]]="Select";
                                }
//                                else{
                                //obj[sub][elementsArray[i]]=obj_slife["al_employee_details.slife.nature_of_business"];
                                // pramod chavan 14042017 need to be change logic. TODO This condition comented for DEF-3259
//                                }
                                }
                                }
                                
//                                                var nobObj= MsGetNob(load_tsv_data["Nob_text"],load_tsv_data["Nob_value"]);
//                                                var nobObjTwo=nobObj[2];
                                console.log("nobObjTwo" +JSON.stringify(nobObjTwo));
                                console.log("obj[sub][elementsArray[i]]" +obj[sub][elementsArray[i]]);
                                                var nobMlife = nobObjTwo[obj[sub][elementsArray[i]]];
                                console.log("nobMlife"+nobMlife);
                                                document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value = nobMlife;
                                
                                                //var nob_set_data = $("."+nob_class).find("option:selected").text();
                                                  //chnged by sayali on 1-06-2017 for nobdropdown
                                                  var nob_set_data=nobMlife;
                        
                                
                                                // Anjali: Def 2674 (mandatory color issue)
                                                //console.log("Anjali: Nature of Business--->>>"+nob_set_data);
                            
                                                if(nob_set_data == "Nature of Business" || nob_set_data == undefined){
                                                    $("."+nob_class_txt).val('');
                                                }else{
                                                    $("."+nob_class_txt).val(nob_set_data);
                                                }
                                                

                                                fnMsSolSelectElement(nobMlife,"al_employee_details."+persontype+".nature_of_business");
console.log("123-->"+document.getElementById("al_employee_details."+persontype+".nature_of_business").disabled);
console.log("Check nob2 :: "+obj[sub][elementsArray[i]]+" --- "+document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value);
                                // TODO 22042017 // below logic for enabled nob in replace quote case if it is blank DEF-3193.
                          
                               
            if(elementsArray[i]=="nature_of_business" && (document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value=="Select" || document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value == " ")){
                               
                               
                               // $("."+nob_class).prop("disabled",false);
                                 $("."+nob_class_txt).prop("disabled",false);
                                }
                                
                                        }
                                    }
                                }else
                                {
                                
                                
                                
                                     console.log("Check nob3 :: "+obj[sub][elementsArray[i]]+" --- "+document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value+" ----> "+persontype);
                                document.getElementById("al_employee_details."+persontype+".occupation").value
                                //changed by Paromita on 14 Aug 2017 for Occupation List
                                    if(document.getElementById("al_employee_details."+persontype+".occupation").value=="Child" )
                                    {
                               
                                    document.getElementById("al_employee_details."+persontype+".nature_of_business").value  == "Child";
                                

                                fnMsSolSelectElement("Child","al_employee_details."+persontype+".nature_of_business");
                              $("."+nob_class_txt).val("Child");
                              

                                    }else if(document.getElementById("al_employee_details."+persontype+".occupation").value =="Housewife")
                                    {
                                      document.getElementById("al_employee_details."+persontype+".nature_of_business").value  == "Housewife";
                                     fnMsSolSelectElement("Housewife","al_employee_details."+persontype+".nature_of_business");
                                   $("."+nob_class_txt).val("Housewife");
                                }else if(document.getElementById("al_employee_details."+persontype+".occupation").value  == "Student" || document.getElementById("al_employee_details."+persontype+".occupation").value  == "Student Pilot-2" || document.getElementById("al_employee_details."+persontype+".occupation").value  == "Pilot (Student)-2")
                                    {
                                    document.getElementById("al_employee_details."+persontype+".nature_of_business").value  == "Student";
                                fnMsSolSelectElement("Student","al_employee_details."+persontype+".nature_of_business");
                               $("."+nob_class_txt).val("Student");
                               

                                    }else if(document.getElementById("al_employee_details."+persontype+".occupation").value  == "Retiree" || document.getElementById("al_employee_details."+persontype+".occupation").value  == "Pensioner-2")
                                    {
                                    document.getElementById("al_employee_details."+persontype+".nature_of_business").value  == "Retiree";
                                fnMsSolSelectElement("Retiree","al_employee_details."+persontype+".nature_of_business");
                                $("."+nob_class_txt).val("Retiree");
                                

                                    }
                                else if(document.getElementById("al_employee_details."+persontype+".occupation").value  == "Pensioner")
                                {
                                document.getElementById("al_employee_details."+persontype+".nature_of_business").value  == "Pensioner";
                                fnMsSolSelectElement("Pensioner","al_employee_details."+persontype+".nature_of_business");
                                $("."+nob_class_txt).val("Pensioner");
                                
                                
                                }
                                
                                
                                else if(document.getElementById("al_employee_details."+persontype+".occupation").value  == "Unemployed")
                                    {
                                    document.getElementById("al_employee_details."+persontype+".nature_of_business").value  == "Unemployed";
                                fnMsSolSelectElement("Unemployed","al_employee_details."+persontype+".nature_of_business");
                               $("."+nob_class_txt).val("Unemployed");
                               

                                    }
                                    else if(document.getElementById("al_employee_details."+persontype+".occupation").value  == "Student Pilot-2")
                                    {
                                    	fnMsSolSelectElement("Student","al_employee_details."+persontype+".nature_of_business");
                               $("."+nob_class_txt).val("Student");
                               
                                    }
                                    else if(document.getElementById("al_employee_details."+persontype+".occupation").value  == "Pilot (Student)-2")
                                    {
                                    	fnMsSolSelectElement("Student","al_employee_details."+persontype+".nature_of_business");
                               $("."+nob_class_txt).val("Student");
                               
                                    }
                                    else
                                    {
					console.log("screen anb value"+document.getElementById("al_person_details.mlife.anb").value);    
          //below the blank condition is added because if the value is not set on that field and we are trying to get the value than it will consider as 0 and the condition become true-Piyushßßßß                             

                                        if(((document.getElementById("al_person_details.mlife.anb").value <= 16 && document.getElementById("al_person_details.mlife.anb").value!="" && !isILproduct) || (ilMainLifeANB <= 16 && isILproduct)) && Channel != "Agency" && Channel != "FA" && Channel !== "UOB")  // Piyush(03/12/2018) : Added this changes for new channel FA
                                {


                                                                       //  console.log("childee888 ---PrasonType-------> "+persontype+"----NOB SLIFE "+document.getElementById("al_employee_details."+persontype+".nature_of_business").value);
                                //Pramod /Sayali: solve set NOB as Child for Slife and Tlife when mlife < 16 on 15/06/2017
                                 /*document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value = "Child";
                                 console.log("childee888 ---PrasonType-------> "+persontype+"----NOB SLIFE "+document.getElementById("al_employee_details."+persontype+".nature_of_business").value);
                                 fnMsSolSelectElement("Child","al_employee_details."+persontype+".nature_of_business");
                                 $("."+nob_class_txt).val("Child");*/
                                 //Pramod / Sayali : Add new code to overcome above issue
                                 if(persontype =="mlife" )
                                  {
                                     fnMsSolSelectElement("Child","al_employee_details."+persontype+".nature_of_business");
                                     $("."+nob_class_txt).val("Child");
                                  }
                                }
                                
                                else  if(((document.getElementById("al_person_details.mlife.anb").value <= 15 && document.getElementById("al_person_details.mlife.anb").value!="" && !isILproduct) || (ilMainLifeANB <= 15 && isILproduct)) && (Channel=="Agency" || Channel=="FA") && persontype =="mlife")  // Piyush(03/12/2018) : Added this changes for new channel FA
                                {

                                    fnMsSolSelectElement("Child","al_employee_details."+persontype+".nature_of_business");
                                    $("."+nob_class_txt).val("Child");
                                }

                                
                                else
                                {

                                    document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value = "Select";
                                    fnMsSolSelectElement("Nature of Business","al_employee_details."+persontype+".nature_of_business");

                                    $("."+nob_class_txt).val("");
                                
                                console.log("Check nob4 :: "+obj[sub][elementsArray[i]]+" --- "+document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value+"  --->  "+persontype);
                                }
                                    
                                    }
                                
                                console.log("Check nob5 :: "+obj[sub][elementsArray[i]]+" --- "+document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value+"  --->  "+persontype);
//                                
//                                
//                                    document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value = "Select";
//                                    $("."+nob_class_txt).val("Nature of Business");
                                }
                                
                                console.log("Check nob6 :: "+obj[sub][elementsArray[i]]+" --- "+document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value+"  --->  "+persontype);
                                
                                 fngetOccupationClassFromMatrix("al_employee_details."+persontype+".occupation","al_employee_details."+persontype+".nature_of_business","al_employee_details."+persontype+".occupation_class")
                                }
                                
                                else if(elementsArray[i] == "person_id")
                                {
                                    if(persontype == "mlife")
                                    {
                                        ylp_type_mlife = obj[sub][elementsArray[i]];
                                    }else if(persontype == "slife")
                                    {
                                if(obj[sub][elementsArray[i]] != "" && obj[sub][elementsArray[i]] != "null")
                                {
                                        ylp_type_slife = obj[sub][elementsArray[i]];
                                }else
                                {
                                    ylp_type_slife = "";
                                }
                                    }else if(persontype == "tlife")
                                    {
                                if(obj[sub][elementsArray[i]] != "" && obj[sub][elementsArray[i]] != "null")
                                {
                                        ylp_type_tlife = obj[sub][elementsArray[i]];
                                }
                                else
                                {
                                    ylp_type_tlife = "";
                                }
                                    }


                                }else if(elementsArray[i] == "relationship")
                                {
                                console.log("Inside relationship:"+obj[sub][elementsArray[i]]+"--persontype:"+persontype);
                                
                                    if(obj[sub][elementsArray[i]] != "" && obj[sub][elementsArray[i]] != null && obj[sub][elementsArray[i]] != "null"  && obj[sub][elementsArray[i]] != "(null)")
                                    {
                                console.log("persontype relationship:"+persontype);
                                        if(persontype == "mlife")
                                        {
                                
                                            relationship_mlife = obj[sub][elementsArray[i]];
                                console.log("relationship mlife :: "+relationship_mlife)
                                //7 april 2022
                                if(relationship_mlife != "C" && relationship_mlife != "W" && relationship_mlife != "H" && relationship_mlife != "F" && relationship_mlife != "M")
                                {
                                    document.getElementById("al_person_details.slife."+elementsArray[i]).value = "Select Relationship";
                                document.getElementById("al_person_details.slife."+elementsArray[i]).disabled = false;
                                
                                }
                                
                                if(relationship_mlife == "C")
                                {
                                document.getElementById("al_person_details.slife."+elementsArray[i]).value = "Parent";                                
                                }
                                //added by ankita on 7 april 2022 for modern family
                               /* var gender="";
                                if(document.getElementById("al_person_details."+persontype+"."+"gender_male").checked)
                                {
                                gender="Male";
                                }
                                if(document.getElementById("al_person_details."+persontype+"."+"gender_female").checked)
                                {
                                gender="Female";
                                }
                                console.log("gender:"+gender);
                                var returnValueRelation=fnMsPopulateRelationship(relationship_mlife,gender);
                               console.log("returnValueRelation:"+returnValueRelation);
                                document.getElementById("al_person_details.slife."+elementsArray[i]).value=returnValueRelation;
                                var value=document.getElementById("al_person_details.slife."+elementsArray[i]).value;
                                document.getElementById("al_person_details.slife."+elementsArray[i]).disabled=true;
                                console.log("relation:"+value);*/
                                //end
                                
                                        }else if(persontype != "mlife")
                                        {
                                console.log("persontype:"+persontype);
                                        if(persontype == "slife")
                                        {
                                            if((obj[sub][elementsArray[i]] == "W" || obj[sub][elementsArray[i]] == "H" || obj[sub][elementsArray[i]] == "F" || obj[sub][elementsArray[i]] == "M") && ((document.getElementById("al_person_details.mlife.anb").value > 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value > 16 && isILproduct)))
                                            {
                                            if(obj[sub][elementsArray[i]] == "W")
                                            {
                                                console.log("Check 2:: ")
                                                document.getElementById("al_person_details."+persontype+"."+"gender_male").checked=false;
                                                document.getElementById("al_person_details."+persontype+"."+"gender_female").checked=true;
                                                document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = "Spouse";
                                                relationship_slife = obj[sub][elementsArray[i]];
                                            }
                                            else if(obj[sub][elementsArray[i]] == "H")
                                            {
                                 console.log("Check 3:: ")
                                                document.getElementById("al_person_details."+persontype+"."+"gender_male").checked=true;
                                                document.getElementById("al_person_details."+persontype+"."+"gender_female").checked=false;
                                                document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = "Spouse";
                                                 relationship_slife = obj[sub][elementsArray[i]];
                                
                                
                                            }
                                
                                console.log("second relation :: "+relationship_slife);
                                }else if(obj[sub][elementsArray[i]] != "W" && obj[sub][elementsArray[i]] != "H" && obj[sub][elementsArray[i]] == "F" && obj[sub][elementsArray[i]] == "M" && ((document.getElementById("al_person_details.mlife.anb").value > 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value > 16 && isILproduct)))
                                {
                                console.log("disable 1111");
                                    document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = "";
                                document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).disabled = true; // TODO need to check
                                }
                                //added by ankita on 7 april 2022 for modern family
                                 /*var gender="";
                                 if(document.getElementById("al_person_details."+persontype+"."+"gender_male").checked)
                                 {
                                 gender="Male";
                                 }
                                 if(document.getElementById("al_person_details."+persontype+"."+"gender_female").checked)
                                 {
                                 gender="Female";
                                 }
                                 console.log("gender:"+gender);
                                 var returnValueRelation=fnMsPopulateRelationship(relationship_mlife,gender);
                                console.log("returnValueRelation:"+returnValueRelation);
                                 document.getElementById("al_person_details.slife."+elementsArray[i]).value=returnValueRelation;
                                
                                 var value=document.getElementById("al_person_details.slife."+elementsArray[i]).value;
                                 document.getElementById("al_person_details.slife."+elementsArray[i]).disabled=true;
                                 console.log("relation:"+value);*/
                                 //end
                                        }
                                        if(relationship_mlife == "C" && (pre_natal_handle == "Yes" || (pre_natal_handle == "No" && ((document.getElementById("al_person_details.mlife.anb").value <=16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <=16 && isILproduct)))))
                                        {
                                        if(obj[sub][elementsArray[i]] == "M")
                                        {
                                            document.getElementById("al_person_details."+persontype+"."+"gender_male").checked=false;
                                            document.getElementById("al_person_details."+persontype+"."+"gender_female").checked=true;
                                            document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = "Parent";
                                        }
                                        else if(obj[sub][elementsArray[i]] == "F")
                                        {
                                            document.getElementById("al_person_details."+persontype+"."+"gender_male").checked=true;
                                            document.getElementById("al_person_details."+persontype+"."+"gender_female").checked=false;
                                            document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = "Parent";
                                        }else if(obj[sub][elementsArray[i]] == "G")
                                        {
                                            document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = "Legal Guardian";
                                        }else
                                {
                                 document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = "";
                                document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).disabled = true;// TODO need to check
                                }
                                
                                        if(relationship_mlife == "C" && ((pre_natal_handle == "No" && ((document.getElementById("al_person_details.mlife.anb").value <=16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <=16 && isILproduct))) || pre_natal_handle == "Yes"))
                                        {
                                            document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = "Parent";
                                        }else if((obj[sub][elementsArray[i]] == "" || obj[sub][elementsArray[i]] == "W" || obj[sub][elementsArray[i]] == "H" || relationship_mlife == "F" || relationship_mlife == "M") && ((document.getElementById("al_person_details.mlife.anb").value > 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value > 16 && isILproduct)))
                                        {
                                            document.getElementById("al_person_details.slife."+elementsArray[i]).value = "Spouse";
                                        }
                                }else if(relationship_mlife != "C" && ((document.getElementById("al_person_details.mlife.anb").value <= 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <= 16 && isILproduct)))
                                {
                                    document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = "";
                                document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).disabled = true; // TODO need to check
                                }
                                
                                if(persontype == "slife")
                                {
                                    relationship_slife = obj[sub][elementsArray[i]];
                                    console.log("AAAArelationship_slife"+relationship_slife);
                                    
                                }else if(persontype == "tlife")
                                {
                                relationship_tlife = obj[sub][elementsArray[i]];
                                }
                                
                                }
                                if(persontype=="mlife" && client_ylp_type_mlife=="lo" && relationship_mlife!="C" && ((document.getElementById("al_person_details.mlife.anb").value >18 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value >18 && isILproduct)))
                                {
                                    document.getElementById("al_person_details.slife.first_name_dropdown").disabled=false;
                                }
                                else if(persontype=="mlife" && client_ylp_type_mlife=="lo" && relationship_mlife!="C" && ((document.getElementById("al_person_details.mlife.anb").value <=18 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <=18 && isILproduct)))
                                {
                                    document.getElementById("al_person_details.slife.first_name_dropdown").disabled=true;
                                }
                                else if(persontype=="mlife" && client_ylp_type_mlife=="lo" && relationship_mlife=="C" && ((document.getElementById("al_person_details.mlife.anb").value >18 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value >18 && isILproduct)))
                                {
                                    document.getElementById("al_person_details.slife.first_name_dropdown").disabled=false;
                                }
                                //added by ankita on 7 april 2022 for modern family
                                 /*var gender="";
                                 if(document.getElementById("al_person_details.slife.gender_male").checked)
                                 {
                                 gender="Male";
                                 }
                                 if(document.getElementById("al_person_details.slife.gender_female").checked)
                                 {
                                 gender="Female";
                                 }
                                 console.log("gender:"+gender);
                                 var returnValueRelation=fnMsPopulateRelationship(relationship_mlife,gender);
                                console.log("returnValueRelation:"+returnValueRelation);
                                 document.getElementById("al_person_details.slife."+elementsArray[i]).value=returnValueRelation;
                                 var value=document.getElementById("al_person_details.slife."+elementsArray[i]).value;
                                 document.getElementById("al_person_details.slife."+elementsArray[i]).disabled=true;
                                 console.log("relation:"+value);*/
                                console.log("relationship_slife other :: "+relationship_slife+" == "+relationship_tlife);
                                
                                
                                
                                    }
                                else
                                {
                                    if(relationship_mlife=="C" && client_ylp_type_mlife=="lo" && (((document.getElementById("al_person_details.mlife.anb").value < 19 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value < 19 && isILproduct)))&& persontype=="slife")    // persontype condition added by sayali.
                                    {
                                        document.getElementById("al_person_details.slife.relationship").value="Parent";
                                        //document.getElementById("al_person_details.slife.relationship").disabled=true; // This line commented for DEF-3808 By pramod chavan on 23082017
                                    }
                                }
                                }
                                var value=document.getElementById("al_person_details.slife.relationship").disabled;
                                console.log("relation11111:"+value);
                                if(persontype == "mlife")
                                {
                                    if(elementsArray[i] == "pre_natal_child_flg" && persontype == "mlife")
                                    {
                                    if(obj[sub][elementsArray[i]] == "No")
                                    {
                                pre_natal_handle="No";
                                    document.getElementById("al_person_details."+elementsArray[i]).checked=false;
                                validate_pre_natal("");
                                    }
                                    else if(obj[sub][elementsArray[i]] == "Yes" && persontype == "mlife")
                                    {
                                    pre_natal_handle="Yes";
                                    document.getElementById("al_person_details."+elementsArray[i]).checked=true;
                                setTimeout(function(){validate_pre_natal("")},0);
                                    }else
                                    {
                                    document.getElementById("al_person_details."+elementsArray[i]).checked=false;
                                
                                
                                document.getElementById("gestational_week").style.display = 'none';
                                
                                document.getElementById("al_person_details.mlife.expected_delivery").style.display = 'none';
                                document.getElementById("al_person_details.mlife.expected_delivery_dt").value = "";
                                document.getElementById("al_person_details.gestational_week").style.display = 'none';
                                document.getElementById("al_person_details.gestational_week").value = "Gestational Week";
                                
                                document.getElementById("al_person_details.mlife.first_name").disabled = false;
                                
                                document.getElementById("al_person_details.mlife.dtofbirth").style.display = 'block';
                                document.getElementById("al_person_details.mlife.anb_block").style.display = 'block';
                                //document.getElementById("al_person_details.mlife.anb").value = ""; changes made by pramod chavan for DEF-3918 on 06092017
                                
                                
                                document.getElementById("al_person_details.mlife.gender_female").disabled = false;
                                document.getElementById("al_person_details.mlife.smoke_status_yes").disabled = false;
                                if(document.getElementById("al_employee_details.mlife.occupation").value  == "Child")
                                {
                                $(".occupationSearchMLifeText").attr("disabled",true);
                                }
                                else
                                {
                                $(".occupationSearchMLifeText").removeAttr("disabled");
                                document.getElementById("al_employee_details.mlife.occupation").disabled = false;
                                }
                                console.log("---------------->"+obj[sub]["occupation"]+"------"+persontype)
                                if(obj[sub]["occupation"]!="" && obj[sub]["occupation"]!="Select" && obj[sub]["occupation"]!="select" && obj[sub]["occupation"]!="Occupation" && obj[sub]["occupation"]!="null"&& obj[sub]["occupation"]!=null &&obj[sub]["occupation"]!="(null)" )
                                {
                                document.getElementById("al_employee_details."+persontype+".occupation").value=obj[sub]["occupation"];
                                }
                                if(document.getElementById("al_employee_details.mlife.occupation").value  == "Student" || document.getElementById("al_employee_details.mlife.occupation").value  == "Student Pilot-2" || document.getElementById("al_employee_details.mlife.occupation").value  == "Pilot (Student)-2" || document.getElementById("al_employee_details.mlife.occupation").value  == "Housewife" || document.getElementById("al_employee_details.mlife.occupation").value  == "Child" || document.getElementById("al_employee_details.mlife.occupation").value  == "Retiree")
                                        {
                                         $(".natureSearchMLifeText").attr("disabled",true);
                                        }
                                        else
                                        {
                                        $(".natureSearchMLifeText").removeAttr("disabled");
                                        document.getElementById("al_employee_details.mlife.nature_of_business").disabled = false;
                                        }
                                console.log("1233-->"+document.getElementById("al_employee_details."+persontype+".nature_of_business").disabled);
                                    }
                                }else if(elementsArray[i] == "expected_delivery_dt" || elementsArray[i] == "gestational_week")
                                {
                                if(obj[sub][elementsArray[i]] != "" && obj[sub][elementsArray[i]] != null && obj[sub][elementsArray[i]] != "null"  && obj[sub][elementsArray[i]] != "(null)")
                                {
                                if(elementsArray[i] == "gestational_week")
                                {
                                document.getElementById("al_person_details."+elementsArray[i]).value = obj[sub][elementsArray[i]];
                                }else
                                if(elementsArray[i] == "expected_delivery_dt")
                                {
                                  document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = obj[sub][elementsArray[i]];
                                var day_res = obj[sub][elementsArray[i]].split("/");
                                // CheckDate(elementName_populate, obj[sub][elementsArray[i]], day_res[0], day_res[1], day_res[2]);
                                
                                CheckDate("al_person_details.mlife.expected_delivery_dt", obj[sub][elementsArray[i]], day_res[0], day_res[1], day_res[2]);
                               
                                                }
                                            }
                                        }
                                 console.log("123322-->"+document.getElementById("al_employee_details."+persontype+".nature_of_business").disabled);
                                }else if(persontype == "slife" || persontype == "tlife")
                                {
                                if(elementsArray[i] == "pre_natal_child_flg")
                                {
                                
                                if(obj[sub][elementsArray[i]] == "Yes")
                                {
                                document.getElementById("al_employee_details."+persontype+".nature_of_business").value = "Child";
                                

                                fnMsSolSelectElement("Child","al_employee_details."+persontype+".nature_of_business");
                                
                                if(persontype == "slife")
                                {
                                $(".natureSearchSLifeText").val("Child");
                               

                                $(".natureSearchSLifeText").attr("disabled",true);
                                }else if(persontype == "tlife")
                                {
                                $(".natureSearchTLifeText").val("Child");
                               

                                $(".natureSearchTLifeText").attr("disabled",true);
                                }
                                }
                                }
                                 //added by ankita on 7 april 2022 for modern family
                                //added condition of child by ankita on 21 april 2022 for srf 3 to extend child case for adult parent
                                //225
                                if(relationship_mlife!="" && client_ylp_type_mlife=="lo" && persontype=="slife")
                                {
                                //added for defect 225 as gender was not getting of you of myneeds in setvaluesnull function
                               if(parseInt(document.getElementById("al_person_details.mlife.anb_il_product").value)>=17)
                                {
                                fnGetRelationshipList('al_person_details.mlife.anb_il_product','al_person_details.slife.anb_il_product','','al_person_details.slife.relationship','al_person_details.slife.gender_male','al_person_details.slife.gender_female','mySolutions');
                                }
                               //added mySolutions17LessAnb by ankita for defect 425
                                if(parseInt(document.getElementById("al_person_details.mlife.anb_il_product").value)<17)
                                {
                                fnGetRelationshipList('al_person_details.mlife.anb_il_product','al_person_details.slife.anb_il_product','','al_person_details.slife.relationship','al_person_details.slife.gender_male','al_person_details.slife.gender_female','mySolutions17LessAnb');
                                }
                                 var gender="";
                                 if(document.getElementById("al_person_details."+persontype+"."+"gender_male").checked)
                                 {
                                document.getElementById("al_person_details."+persontype+"."+"gender_male").diasbled=true;
                                 gender="Male";
                                 }
                                 if(document.getElementById("al_person_details."+persontype+"."+"gender_female").checked)
                                 {
                                document.getElementById("al_person_details."+persontype+"."+"gender_female").diasbled=true;
                                 gender="Female";
                                 }
                                 console.log("gender 9319:"+gender);
                                    console.log("RRelationship1"+relationship_mlife)
                                    console.log("RRelationship2"+relationship_slife)
                                // var returnValueRelation=fnMsPopulateRelationship(relationship_mlife,gender);//This was original code commited for internal issues by Sachin T. on date 15  dec 2023.
                                    
                                    var relationShipData = "";
                                    if(relationship_mlife!=""){
                                        relationShipData = relationship_mlife
                                    }else if(relationship_slife!=""){
                                        relationShipData = relationship_slife;
                                    }
                                    var returnValueRelation=fnMsPopulateRelationship(relationShipData,gender)
                                console.log("returnValueRelation:"+returnValueRelation);
                                 document.getElementById("al_person_details.slife.relationship").value=returnValueRelation;
                                 console.log("disabled 4");
                                 document.getElementById("al_person_details.slife.relationship").disabled=true;
                                 console.log("relation:"+document.getElementById("al_person_details.slife.relationship").value);
                                }
                                if((client_ylp_type_slife==="spouse" || client_ylp_type_slife==="you") && client_ylp_type_mlife!=="lo")//added by ankita for spouse and not lo scenario for modern family CR
                                {
                                document.getElementById("al_person_details.slife.relationship").value="Spouse";
                                 
                                console.log("disabled 5");
                                document.getElementById("al_person_details.slife.relationship").disabled=true;
                                }
                                if(relationship_mlife=="" && client_ylp_type_mlife=="you" && client_ylp_type_slife=="lo" && persontype=="slife")
                                 {
                                 //added for defect 225 as gender was not getting of you of myneeds in setvaluesnull function
                                if(parseInt(document.getElementById("al_person_details.mlife.anb_il_product").value)>=17)
                                 {
                                 fnGetRelationshipList('al_person_details.mlife.anb_il_product','al_person_details.slife.anb_il_product','','al_person_details.slife.relationship','al_person_details.slife.gender_male','al_person_details.slife.gender_female','mySolutions');
                                 }
                                //added mySolutions17LessAnb by ankita for defect 425
                                 if(parseInt(document.getElementById("al_person_details.mlife.anb_il_product").value)<17)
                                 {
                                 fnGetRelationshipList('al_person_details.mlife.anb_il_product','al_person_details.slife.anb_il_product','','al_person_details.slife.relationship','al_person_details.slife.gender_male','al_person_details.slife.gender_female','mySolutions17LessAnb');
                                 }
                                  var gender="";
                                  if(document.getElementById("al_person_details."+persontype+"."+"gender_male").checked)
                                  {
                                 document.getElementById("al_person_details."+persontype+"."+"gender_male").diasbled=true;
                                  gender="Male";
                                  }
                                  if(document.getElementById("al_person_details."+persontype+"."+"gender_female").checked)
                                  {
                                 document.getElementById("al_person_details."+persontype+"."+"gender_female").diasbled=true;
                                  gender="Female";
                                  }
                                  console.log("gender 9319:"+gender);
                                     console.log("RRelationship3"+relationship_mlife)
                                     console.log("RRelationship4"+relationship_slife)
                                  //var returnValueRelation=fnMsPopulateRelationship(relationship_mlife,gender); //original code
                                     //This was original code commited for internal issues by Sachin T. on date 15  dec 2023.
                                     var relationShipData = "";
                                     if(relationship_mlife!=""){
                                         relationShipData = relationship_mlife
                                     }else if(relationship_slife!=""){
                                         relationShipData = relationship_slife;
                                     }
                                     var returnValueRelation=fnMsPopulateRelationship(relationShipData,gender);
                                 console.log("returnValueRelation:"+returnValueRelation);
                                  document.getElementById("al_person_details.slife.relationship").value=returnValueRelation;
                                  console.log("disabled 4");
                                  document.getElementById("al_person_details.slife.relationship").disabled=true;
                                  console.log("relation:"+document.getElementById("al_person_details.slife.relationship").value);
                                 }
                                //added by ankita on 25 april 2022 for modern family CR
                                //added for defect 305
                                /*if(client_ylp_type_slife==="spouse" && client_ylp_type_mlife==="lo" && document.getElementById("al_person_details.pre_natal_child_flg").checked===false)
                                {
                                  document.getElementById("al_person_details.slife.relationship").value="Spouse";
                                   
                                      console.log("disabled 53333333");
                                  document.getElementById("al_person_details.slife.relationship").disabled=true;
                                }*/
                                
                                
                                 //end

                                }
                                
                                
                           //changed by paromita because it was clearing NOB.
//                                if(client_ylp_type_mlife == "lo")
//                                {
//                                    if(/*Channel == "Banca" && */document.getElementById("al_person_details.mlife.anb").value > 18)
//                                    {
//                                    document.getElementById("al_employee_details.mlife.nature_of_business").value = "Select";
//                                    $(".natureSearchMLifeText").val("");
//                                    fnMsSolSelectElement("Nature of Business","al_employee_details.mlife.nature_of_business");
//                                    }
////                                    else if(Channel == "Agency" && document.getElementById("al_person_details.mlife.anb").value > 18)
////                                    {
////                                    document.getElementById("al_employee_details.mlife.nature_of_business").value = "Select";
////                                    $(".natureSearchMLifeText").val("Nature of Business");
////                                    fnMsSolSelectElement("Nature of Business","al_employee_details.mlife.nature_of_business");
////                                    }
//                                }else if(client_ylp_type_slife == "lo")
//                                {
//                                if(/*Channel == "Banca" && */document.getElementById("al_person_details.slife.anb").value > 18)
//                                {
//                                    document.getElementById("al_employee_details.slife.nature_of_business").value = "Select";
//                                    $(".natureSearchSLifeText").val("");//Prashant 23/12/2016
//                                    fnMsSolSelectElement("Nature of Business","al_employee_details.slife.nature_of_business");
//                                }
//                                }else if(client_ylp_type_tlife == "lo")
//                                {
//                                if(/*Channel == "Banca" && */document.getElementById("al_person_details.tlife.anb").value > 18)
//                                {
//                                document.getElementById("al_employee_details.tlife.nature_of_business").value = "Select";
//                                $(".natureSearchTLifeText").val("");//Prashant 23/12/2016
//                                fnMsSolSelectElement("Nature of Business","al_employee_details.tlife.nature_of_business");
//                                }
//                                }
                                var value=document.getElementById("al_person_details.slife.relationship").disabled;
                                console.log("relation11:"+value);
                                if(elementsArray[i]=="dob" && id=="al_person_details.mlife.first_name_dropdown")
                                {
                                        var day_res = obj[sub][elementsArray[i]].split("/");
                                        console.log("in Refresh DOB ANB-------->"+elementName_populate,day_res);
                                
                                if(ANB_json[0]["anb_type"]=="IL_Daily" && (ANB_json[0]["anb_type"]!="" && ANB_json[0]["anb_type"]!='undefined' && ANB_json[0]["anb_type"]!=undefined && ANB_json[0]["anb_type"]!="{}"))
                                {
                                       fnMsCalculateANBforILproducts(persontype, obj[sub][elementsArray[i]]);// calculate IL product ANB. changes made by pramod chavan: 09122017
                                }else if(ANB_json[0]["anb_type"]=="IL_Monthly" && (ANB_json[0]["anb_type"]!="" && ANB_json[0]["anb_type"]!='undefined' && ANB_json[0]["anb_type"]!=undefined && ANB_json[0]["anb_type"]!="{}"))
                                {
                                        fnMsCalculateANBforIL_monthlyproducts(persontype, obj[sub][elementsArray[i]]);
                                }
                                
                                var value=document.getElementById("al_person_details.slife.relationship").disabled;
                                console.log("relation12:"+value);
                                       CheckDate(elementName_populate, obj[sub][elementsArray[i]], day_res[0], day_res[1], day_res[2]);//commeted for il to os migration
                                var value=document.getElementById("al_person_details.slife.relationship").disabled;
                                console.log("relation13:"+value);
                                }
                                }
                            }
                                
                        }
                         
                
            var mlifenobChk=document.getElementById("al_employee_details.mlife.nature_of_business").value;
            var mlifeOccCheck=document.getElementById("al_employee_details.mlife.occupation").value;
                                
                                console.log("mlifenobChk----"+mlifenobChk+"---mlifeOccCheck-----"+mlifeOccCheck+"--relationship_mlife:"+relationship_mlife);
                                //added by ankita for modern family CR to blank nob if occupation selected is other than child for anb<16 for modern family other then child is selected
                                if(relationship_mlife!=="C" && persontype==="mlife" && mlifenobChk==="Child" && mlifeOccCheck!=="Child" && parseInt(document.getElementById("al_person_details.mlife.anb_il_product").value)<=16)
                                {
                                document.getElementById("al_employee_details.mlife.nature_of_business").value="";
                                }
                if((mlifenobChk!="Select" && mlifenobChk!="select" && mlifenobChk!="" && mlifenobChk!= "Child"&& mlifenobChk!= "Housewife"&& mlifenobChk!="Pensioner"&& mlifenobChk!="Retiree"&& mlifenobChk!="Student"&& mlifenobChk!="Student Pilot"&& mlifenobChk!="Unemployed" && mlifenobChk!= "Nature of Business") && (insurence_type_gb=="keyman"|| insurence_type_gb=="employee" || insurence_type_gb=="partnership" || insurence_type_gb == "Business Loan Insurance (for Company/LLP)" || insurence_type_gb == "Business Loan Insurance (for Sole Proprietorship/Partnership)") && persontype=="mlife")
                {
                document.getElementById("al_employee_details.mlife.nature_of_business").disabled=true;
                }
                   
              if((mlifenobChk=="Select" || mlifenobChk=="select" || mlifenobChk=="" || mlifenobChk=="Nature of Business")&& (insurence_type_gb=="keyman"|| insurence_type_gb=="employee" || insurence_type_gb == "Business Loan Insurance (for Company/LLP)" ) && (CompanyNobMS!="Nature of Business" && CompanyNobMS!="Select" && CompanyNobMS!="select" && CompanyNobMS!=""))
                {
                       document.getElementById("al_employee_details.mlife.nature_of_business").value=nobObjTwo[CompanyNobMS];
                       
            getOccuandclass('al_employee_details.mlife.occupation','al_employee_details.mlife.nature_of_business','al_employee_details.mlife.occupation_class','natureSearchMLifeText')
              document.getElementById("al_employee_details.mlife.nature_of_business").disabled=true;
                }
                
                                
        if((mlifeOccCheck!="Select" && mlifeOccCheck!="select" && mlifeOccCheck!="" && mlifeOccCheck!= "Child"&& mlifeOccCheck!= "Housewife"&& mlifeOccCheck!="Pensioner"&& mlifeOccCheck!="Retiree"&& mlifeOccCheck!="Student"&& mlifeOccCheck!="Student Pilot"&& mlifeOccCheck!="Unemployed") && (insurence_type_gb=="keyman"|| insurence_type_gb=="employee" || insurence_type_gb=="partnership" || insurence_type_gb == "Business Loan Insurance (for Company/LLP)" || insurence_type_gb == "Business Loan Insurance (for Sole Proprietorship/Partnership)") && persontype=="mlife")
        {
        document.getElementById("al_employee_details.mlife.occupation").disabled=true;
        }
             
        if($(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Keyman Insurance" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Employer Employee Insurance" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Partnership Insurance" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Business Loan Insurance (for Sole Proprietorship/Partnership)" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Business Loan Insurance (for Company/LLP)"){
                $(escape_jq("al_person_details.pre_natal_child_flg")).attr("disabled",true);
        }
                                
                                
                                var value=document.getElementById("al_person_details.slife.relationship").disabled;
                                console.log("relation14:"+value);
                                //Added by Paromita
                                if(id == "al_person_details.slife.first_name_dropdown")
                                {
                                    ClearData();
                                }
                    });
                });//End
                                  });
                                               });
                                      
                                      });//END of Risk data
                                              });
                              });//end risk profile
                                      });
                              
                              }else{
                              isFromMyneed=false;
                              
                              
                              }
        });
                   });
                     setTimeout(function(){fnMsDisableDropdownChange("change");},1000);
    });
}

function PopulateValuesForReplicate(person_id_repl,persontype,obj_res,client_id,data_repl_res)
{
    
    console.log("inside replicate");
 //Pramod chavan : change obj_res to response_pro_req_AL to resolve BUG-1602 fixed on 28 Sept 2017
    var replaceQuoteCAL = JSON.parse(response_pro_req_AL);
//    e_reference_id=obj['e_reference_id'];
    e_reference_id=replaceQuoteCAL['e_reference_id'];
    sqs_id=replaceQuoteCAL['sqs_id'];
    ylp_id=replaceQuoteCAL['ylp_id'];
    agent_id=replaceQuoteCAL['agent_id'];
    proposal_mode=replaceQuoteCAL['proposal_mode'];
    var ANB_set1="";
    Client_id = client_id;
    
    var querySelect = new DbUtil();
    
    querySelect.query()
    .select()
    .column('*')
    .from()
    .table('ylp_person_details AS t1,ylp_employee_details AS t3')
    .where()
    .clause('t1.person_id','==','t3.person_id')
    .and()
    .clause('t1.ylp_id','=',ylp_id)
    .and()
    .clause('t1.person_id','=',person_id_repl)
    .and()
    .clause('t1.is_deleted','=','No')
    .and()
    .clause('t1.agent_id','=',ds_agentId)
    .and()
    .clause('t3.agent_id','=',ds_agentId);//Added by Pallavi for device sharing
    
    querySelect.execute(function (response)
                        {
                        if(response != "" && response !=null && response !="{}")
                        {
                        var obj=JSON.parse(response);
                        console.log("nob response" +JSON.stringify(obj));
                        for (sub in obj)
                        {
                        var elementsArray="";
                        var objSub="";
                        objSub = obj[sub];
                        elementsArray = Object.keys(objSub);
                        
                        if(persontype == "slife")
                        {
                            document.getElementById("al_sqs_details.sec_parti_flag_yes").checked = true;
                            document.getElementById("al_sqs_details.sec_parti_flag_no").checked = false;
                        
                        if((document.getElementById("al_person_details.mlife.anb").value <= 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <= 16 && isILproduct))
                        {
                            if(Channel != "Banca" && Channel != "UOB")//changed by Purva / Pramod C on 07th Aug 2017 for UOB
                            {
                                document.getElementById("al_person_details.slife.first_name_dropdown").disabled = true;
                                fnMsDisableLives();
                            }
                           else if(Channel == "Banca" || Channel == "UOB")//changed by Purva / Pramod C on 07th Aug 2017 for UOB
                            {
                                document.getElementById("al_person_details.mlife.parent_consent_yes").disabled = false;
                                document.getElementById("al_person_details.mlife.parent_consent_no").disabled = false;
                        
                                if(document.getElementById("al_person_details.mlife.parent_consent_yes").checked)
                                {
                                    document.getElementById("al_person_details.slife.first_name_dropdown").disabled = true;
                                }else if(document.getElementById("al_person_details.mlife.parent_consent_no").checked)
                                {
                                    document.getElementById("al_person_details.slife.first_name_dropdown").disabled = true;
                                }
                        
                                fnMsDisableLives();
                            }
                        }else
                        {
                            document.getElementById("al_person_details.slife.first_name_dropdown").disabled = false;
                        }
                        
                        
                            $(".collapseTwo").attr("id", "collapseTwo");
                            $(".second_life").addClass("normal_panel");
                            $(".second_life").removeClass("disabled_panel");
                        }else if(persontype == "tlife")
                        {
                                $("input[name='third_life'][value='Yes']").prop('checked',true);
                                $("input[name='third_life'][value='No']").prop('checked',false);
                                $(".collapseThree").attr("id", "collapseThree");
                                $(".third_life").addClass("normal_panel");
                                $(".third_life").removeClass("disabled_panel");

                        }
                        
                        for(var i=0 ;i< elementsArray.length; i++)
                        {
                        
                        if(persontype == "mlife")
                        {
                            if(elementsArray[i] == "ylp_type")
                            {
                                client_ylp_type_mlife = obj[sub][elementsArray[i]];
                            }
                        }else if(persontype == "slife")
                        {
                            if(elementsArray[i] == "ylp_type")
                            {
                                client_ylp_type_slife = obj[sub][elementsArray[i]];
                            }
                        }else if(persontype == "tlife")
                        {
                            if(elementsArray[i] == "ylp_type")
                            {
                                client_ylp_type_tlife = obj[sub][elementsArray[i]];
                            }
                        }
                        
                        if(elementsArray[i] == "first_name")
                        {
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_dropdown").value = obj[sub][elementsArray[i]];
                        
                        
                        }
                        else if(elementsArray[i] == "insurence_type" && persontype == "mlife")
                        {
                        if(obj[sub][elementsArray[i]] !== "" && obj[sub][elementsArray[i]] !== null)
                        {
                        if(obj[sub][elementsArray[i]] == "individual"){
                        document.getElementById("al_person_details.mlife.insu_type_header").value = "non_business_purpose";
                        }else{
                            document.getElementById("al_person_details.mlife.insu_type_header").value = "business_purpose";
                            document.getElementById("al_person_details.mlife.insu_type").value = obj[sub][elementsArray[i]];
                        }
                        
                        $(escape_jq("al_person_details.mlife.insu_type")).removeClass('mandatory');
                        $(escape_jq("al_person_details.mlife.insu_type")).removeClass('selectRedMandatory');
                        $(escape_jq("al_person_details.mlife.insu_type")).attr("disabled","true");
                        }
                        
                        }
                        else if(elementsArray[i] == "smoke_status")
                        {
                        if(obj[sub][elementsArray[i]] == "No")
                        {
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_yes").checked=false;
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_no").checked=true;
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_yes").disabled=true;
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_no").disabled=true;
                        }
                        else if(obj[sub][elementsArray[i]] == "Yes")
                        {
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_yes").checked=true;
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_no").checked=false;
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_yes").disabled=true;
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_no").disabled=true;
                        
                        }else
                        {
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_yes").checked=false;
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_no").checked=true;
                        }
                        }else if(elementsArray[i] == "gender")
                        {
                        if(obj[sub][elementsArray[i]] == "F")
                        {
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_male").checked=false;
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_female").checked=true;
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_male").disabled=true;
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_female").disabled=true;
                        }
                        else if(obj[sub][elementsArray[i]] == "M")
                        {
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_male").checked=true;
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_female").checked=false;
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_male").disabled=true;
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]+"_female").disabled=true;
                        }
                        
                        }
                        else if(elementsArray[i] == "dob" || elementsArray[i] == "anb")
                        {
                        if(elementsArray[i]=="anb")
                        {
                            if(calculatedAge!="")
                            {
                                ANB_set1 = calculatedAge;
                            }
                            else{
                                ANB_set1 = obj[sub][elementsArray[i]];
                            }
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = ANB_set1;
                        }
                        else{
                            document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = obj[sub][elementsArray[i]];
                        }
                        
                        if(persontype == "mlife")
                        {
                        relationship_mlife = obj[sub]["relationship"];
                        }else if(persontype == "slife")
                        {
                        relationship_slife = obj[sub]["relationship"];
                        }else if(persontype == "tlife")
                        {
                        relationship_tlife = obj[sub]["relationship"];
                        }
                        
                        if(persontype == "mlife")
                        {
                            //if(Channel == "Banca")
                           // {
                                if((document.getElementById("al_person_details.mlife.anb").value >=11 && document.getElementById("al_person_details.mlife.anb").value <= 16) || (document.getElementById("al_person_details.mlife.anb_il_product").value >=11 && document.getElementById("al_person_details.mlife.anb_il_product").value <= 16 ))
                                {
                                    document.getElementById("al_person_details.mlife.parent_consent_yes").disabled = false;
                                    document.getElementById("al_person_details.mlife.parent_consent_no").disabled = false;
                                    fnMsDisableLives("al_person_details.mlife.parent_consent_yes");
                                }
                        
                                else if((document.getElementById("al_person_details.mlife.anb").value <= 11  && document.getElementById("al_person_details.mlife.anb").value != "" && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <= 11  && document.getElementById("al_person_details.mlife.anb_il_product").value != "" && isILproduct))
                                {
                                   console.log("---->6");
                                    fnMsPersonalPopulateValues("al_person_details.slife.first_name_dropdown","slife");
                                }
                           // }
                        }
                        
                        if(elementsArray[i] == "dob")
                        {
                        if(persontype=="mlife")
                        {
                            ANB_set=obj[sub]["anb"];
                        }
                        elementName_populate = "al_person_details."+persontype+"."+elementsArray[i];
                        var day_res = obj[sub][elementsArray[i]].split("/");
                        console.log("---3-->"+document.getElementById("al_person_details.slife.anb").value);
                        
                        
                        if(ANB_json[0]["anb_type"]=="IL_Daily" && (ANB_json[0]["anb_type"]!="" && ANB_json[0]["anb_type"]!='undefined' && ANB_json[0]["anb_type"]!=undefined && ANB_json[0]["anb_type"]!="{}"))
                        {
                        fnMsCalculateANBforILproducts(persontype, obj[sub][elementsArray[i]]);// calculate IL product ANB. changes made by pramod chavan: 09122017
                        }else if(ANB_json[0]["anb_type"]=="IL_Monthly" && (ANB_json[0]["anb_type"]!="" && ANB_json[0]["anb_type"]!='undefined' && ANB_json[0]["anb_type"]!=undefined && ANB_json[0]["anb_type"]!="{}"))
                        {
                        fnMsCalculateANBforIL_monthlyproducts(persontype, obj[sub][elementsArray[i]]);
                        }
                       CheckDate(elementName_populate, obj[sub][elementsArray[i]], day_res[0], day_res[1], day_res[2]);//Commeted for IL Product conversion on date 19-06-2019.
                        
                        console.log("---4-->"+document.getElementById("al_person_details.slife.anb").value);
                        // Disabled condition added by Pramod Chavan for disabled below field in replace quote case 04032017
                        $(".occupationSearchMLifeText").prop("disabled",true);
                        $(".natureSearchMLifeText").prop("disabled",true);
                        $(".occupationSearchSLifeText").prop("disabled",true);
                       $(".natureSearchSLifeText").prop("disabled",true);
                        $(".occupationSearchTLifeText").prop("disabled",true);
                        $(".natureSearchTLifeText").prop("disabled",true);
                        }
                        }else if(elementsArray[i] == "occupation_class")
                        {
                        if(obj[sub][elementsArray[i]] != "" && obj[sub][elementsArray[i]] != null && obj[sub][elementsArray[i]] != "null"  && obj[sub][elementsArray[i]] != "(null)")
                        {
                        document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value = obj[sub][elementsArray[i]];
                        }else
                        {
                            if(document.getElementById("al_employee_details."+persontype+".occupation_class").value != "Select")
                            {
//                                var res_occ_class = document.getElementById("al_employee_details."+persontype+".occupation").value.split("-"); //change
//                                document.getElementById("al_employee_details."+persontype+".occupation_class").value = res_occ_class[1];
                        
                        fngetOccupationClassFromMatrix("al_employee_details."+persontype+".occupation","al_employee_details."+persontype+".nature_of_business","al_employee_details."+persontype+".occupation_class")
                        
                        
                            }else
                            {
                                document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value = "";
                            }
                        }
                        }else if(elementsArray[i] == "occupation")
                        {
                        if(obj[sub][elementsArray[i]] != "" && obj[sub][elementsArray[i]] != null && obj[sub][elementsArray[i]] != "null"  && obj[sub][elementsArray[i]] != "(null)")
                        {
                        var occupation_class;
                        if(persontype == "mlife")
                        {
                        occupation_class = "occupationSearchMLifeText";
                        }else if(persontype == "slife")
                        {
                        occupation_class = "occupationSearchSLifeText";
                        nob_class = "natureSearchSLife";
                        nob_class_txt = "natureSearchSLifeText";
                        }else if(persontype == "tlife")
                        {
                        occupation_class = "occupationSearchTLifeText";
                        nob_class = "natureSearchTLife";
                        nob_class_txt = "natureSearchTLifeText";
                        }
                        
                        if(obj[sub][elementsArray[i]] == "Occupation")
                        {
                        document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value = "Select";
                        $("."+occupation_class).val("");
                        }else
                        {
                        var occu_data_res = $('#al_employee_details\\.'+persontype+'\\.occupation option:contains("'+obj[sub][elementsArray[i]]+'")').val();
                        
                        //                                        document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value = occu_data_res;
                        
                        //                                            $("."+occupation_class).val(occu_data_res);
                        
                        document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value = obj[sub][elementsArray[i]]//+"-"+obj[sub]["occupation_class"]; //change
                        
                        $("."+occupation_class).val(obj[sub][elementsArray[i]])//+"-"+obj[sub]["occupation_class"]); //change
                        
//                        var res_occ_class = document.getElementById("al_employee_details."+persontype+".occupation").value.split("-");
//                        document.getElementById("al_employee_details."+persontype+".occupation_class").value = res_occ_class[1];
                        
                        
                        
                        
                        
                        fngetOccupationClassFromMatrix("al_employee_details."+persontype+".occupation","al_employee_details."+persontype+".nature_of_business","al_employee_details."+persontype+".occupation_class")
                        
                        
                        }
                        }else
                        {
                        document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value = "Select";
                        $("."+occupation_class).val("");
                        }
                        }else if(elementsArray[i] == "nature_of_business")
                        {
                        if(obj[sub][elementsArray[i]] != "" && obj[sub][elementsArray[i]] != null && obj[sub][elementsArray[i]] != "null"  && obj[sub][elementsArray[i]] != "(null)")
                        {
                        var nob_class;
                        var nob_class_txt;
                        if(persontype == "mlife")
                        {
                        nob_class = "natureSearchMLife";
                        nob_class_txt = "natureSearchMLifeText";
                        }
                        else if(persontype == "slife")
                        {
                        nob_class = "natureSearchSLife";
                        nob_class_txt = "natureSearchSLifeText";
                        }
                        else if(persontype == "tlife")
                        {
                        nob_class = "natureSearchTLife";
                        nob_class_txt = "natureSearchTLifeText";
                        }
                        if(obj[sub][elementsArray[i]] == "Nature of Business")
                        {
                        document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value = "Select";
                        $("."+nob_class_txt).val("");
                        }
                        else
                        {
                        console.log("pramod nob"+obj[sub][elementsArray[i]]+"---"+persontype);
                       
                    // changed by sayali
                        
                        var nobObj= MsGetNob(load_tsv_data["Nob_text"],load_tsv_data["Nob_value"]);
                        var nobObjOne=nobObj[2];
                        var nobMlife = nobObjOne[obj[sub][elementsArray[i]]];
                        document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value = nobMlife;
                       // var nob_set_data =obj[sub][elementsArray[i]];
                        var nob_set_data= nobMlife;
                        console.log("nob_set_date" +nobMlife);
                        $("."+nob_class_txt).val(nob_set_data);
                        
                        
                        
                       
                        }
                        }else
                        {
                        document.getElementById("al_employee_details."+persontype+"."+elementsArray[i]).value = "Select";
                        $("."+nob_class_txt).val("");
                        }
                        }
                        
                        else if(elementsArray[i] == "relationship")
                        {
                        if(obj[sub][elementsArray[i]] != "" && obj[sub][elementsArray[i]] != null && obj[sub][elementsArray[i]] != "null"  && obj[sub][elementsArray[i]] != "(null)")
                        {
                        
                        if(persontype == "mlife")
                        {
                        
                        relationship_mlife = obj[sub][elementsArray[i]];
                        console.log("relationship mlife :: "+relationship_mlife)
                        
                        if(relationship_mlife != "C" && relationship_mlife != "W" && relationship_mlife != "H" && relationship_mlife != "F" && relationship_mlife != "M")
                        {
                        document.getElementById("al_person_details.slife."+elementsArray[i]).value = "";
                        document.getElementById("al_person_details.slife."+elementsArray[i]).disabled = true;
                        
                        }
                        
                        if(relationship_mlife == "C")
                        {
                        document.getElementById("al_person_details.slife."+elementsArray[i]).value = "Parent";
                        document.getElementById("al_person_details.slife."+elementsArray[i]).disabled = false; // TODO 13092017
                        }
                        
                        }else if(persontype != "mlife")
                        {
                        if(persontype == "slife")
                        {
                        if((obj[sub][elementsArray[i]] == "W" || obj[sub][elementsArray[i]] == "H" || obj[sub][elementsArray[i]] == "F" || obj[sub][elementsArray[i]] == "M") && ((document.getElementById("al_person_details.mlife.anb").value > 16 && !isILproduct ) || (document.getElementById("al_person_details.mlife.anb_il_product").value > 16 && isILproduct )))
                        {
                        if(obj[sub][elementsArray[i]] == "W")
                        {
                         console.log("Check 4:: ")
                        document.getElementById("al_person_details."+persontype+"."+"gender_male").checked=false;
                        document.getElementById("al_person_details."+persontype+"."+"gender_female").checked=true;
                        console.log("A -- check 4 -- "+persontype+" -- "+JSON.stringify(elementsArray[i]));
                        setTimeout(function(){document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = "Spouse";},10);
                        relationship_slife = obj[sub][elementsArray[i]];
                        }
                        else if(obj[sub][elementsArray[i]] == "H")
                        {
                         console.log("Check 5:: ")
                        document.getElementById("al_person_details."+persontype+"."+"gender_male").checked=true;
                        document.getElementById("al_person_details."+persontype+"."+"gender_female").checked=false;
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = "Spouse";
                        relationship_slife = obj[sub][elementsArray[i]];
                        
                        
                        }
                        
                        console.log("second relation :: "+relationship_slife+ "obj[sub][elementsArray[i]]");
                        
                        }else if(obj[sub][elementsArray[i]] != "W" && obj[sub][elementsArray[i]] != "H" && obj[sub][elementsArray[i]] == "F" && obj[sub][elementsArray[i]] == "M" && ((document.getElementById("al_person_details.mlife.anb").value > 16 && !isILproduct ) || (document.getElementById("al_person_details.mlife.anb_il_product").value > 16 && isILproduct )))
                        {
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = "";
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).disabled = true;
                        }
                        }
                        if(relationship_mlife == "C" && (pre_natal_handle == "Yes" || (pre_natal_handle == "No" && ((document.getElementById("al_person_details.mlife.anb").value <=16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <=16 && isILproduct)))))
                        {
                        if(obj[sub][elementsArray[i]] == "M")
                        {
                        document.getElementById("al_person_details."+persontype+"."+"gender_male").checked=false;
                        document.getElementById("al_person_details."+persontype+"."+"gender_female").checked=true;
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = "Parent";
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).disabled = false; // DEF-3444
                        }
                        else if(obj[sub][elementsArray[i]] == "F")
                        {
                        document.getElementById("al_person_details."+persontype+"."+"gender_male").checked=true;
                        document.getElementById("al_person_details."+persontype+"."+"gender_female").checked=false;
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = "Parent";
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).disabled = false; // DEF-3444
                        }else if(obj[sub][elementsArray[i]] == "G")
                        {
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = "Legal Guardian";
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).disabled = false; // DEF-3444
                        }else
                        {
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = "";
                       document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).disabled = true;
                        }
                        
                        if(relationship_mlife == "C" && ((pre_natal_handle == "No" && ((document.getElementById("al_person_details.mlife.anb").value <=16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <=16 && isILproduct))) || pre_natal_handle == "Yes"))
                        {
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = "Parent";
                        }else if((obj[sub][elementsArray[i]] == "" || obj[sub][elementsArray[i]] == "W" || obj[sub][elementsArray[i]] == "H" || relationship_mlife == "F" || relationship_mlife == "M") && ((document.getElementById("al_person_details.mlife.anb").value > 16  && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value > 16  && isILproduct)))
                        {
                        console.log("spouse *******");
                        document.getElementById("al_person_details.slife."+elementsArray[i]).value = "Spouse";
                        }
                        }else if(relationship_mlife != "C" && ((document.getElementById("al_person_details.mlife.anb").value <= 16 && !isILproduct) || (document.getElementById("al_person_details.mlife.anb_il_product").value <= 16 && isILproduct)))
                        {
                        console.log("spouse **&&&&7");
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = "";
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).disabled = false; // DEF-3444
                        }
                        
                        if(persontype == "slife")
                        {
                        relationship_slife = obj[sub][elementsArray[i]];
                        }else if(persontype == "tlife")
                        {
                        relationship_tlife = obj[sub][elementsArray[i]];
                        }
                        
                        }

                        if(persontype != "mlife")
                        {
                        if(persontype == "slife")
                        {
                        if(obj[sub][elementsArray[i]] == "W")
                        {
                         console.log("Check 6:: ")
                        document.getElementById("al_person_details."+persontype+"."+"gender_male").checked=false;
                        document.getElementById("al_person_details."+persontype+"."+"gender_female").checked=true;
                        if(!(document.getElementById("al_person_details."+persontype+"."+elementsArray[i]) == "null" || document.getElementById("al_person_details."+persontype+"."+elementsArray[i]) == ""))
                        {
                        console.log("A -- check 6 -- "+persontype+" -- "+JSON.stringify(elementsArray[i]));
                        setTimeout(function(){ document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = "Spouse";},0.1);
                        }
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).disabled=true;
                        }
                        else if(obj[sub][elementsArray[i]] == "H")
                        {
                         console.log("Check 7:: ")
                        document.getElementById("al_person_details."+persontype+"."+"gender_male").checked=true;
                        document.getElementById("al_person_details."+persontype+"."+"gender_female").checked=false;
                        if(!(document.getElementById("al_person_details."+persontype+"."+elementsArray[i]) == "null" || document.getElementById("al_person_details."+persontype+"."+elementsArray[i]) == ""))
                        {
                        document.getElementById("al_person_details."+persontype+".relationship").value = "Spouse";
                        }
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).disabled=true;
                        }
                        }
                        if(obj[sub][elementsArray[i]] == "M")
                        {
                        document.getElementById("al_person_details."+persontype+"."+"gender_male").checked=false;
                        document.getElementById("al_person_details."+persontype+"."+"gender_female").checked=true;
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = "Parent";
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).disabled=false; // DEF-3444
                        }
                        else if(obj[sub][elementsArray[i]] == "F")
                        {
                        document.getElementById("al_person_details."+persontype+"."+"gender_male").checked=true;
                        document.getElementById("al_person_details."+persontype+"."+"gender_female").checked=false;
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = "Parent";
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).disabled=false; // DEF-3444
                        }else if(obj[sub][elementsArray[i]] == "G")
                        {
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = "Legal Guardian";
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).disabled=false; //DEF-3444
                        }else if(obj[sub][elementsArray[i]] != "W")
                        {
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = "";
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).disabled=true;
                        }
                        }
                        
                        }
                        }
                        
                        if(persontype == "mlife")
                        {
                        if(elementsArray[i] == "pre_natal_child_flg")
                        {
                        if(obj[sub][elementsArray[i]] == "No")
                        {
                        document.getElementById("al_person_details."+elementsArray[i]).checked=false;
                        validate_pre_natal(data_repl_res);
                        
                        }
                        else if(obj[sub][elementsArray[i]] == "Yes")
                        {
                        document.getElementById("al_person_details."+elementsArray[i]).checked=true;
                        setTimeout(function(){validate_pre_natal(data_repl_res);},10)
                        }else
                        {
                        document.getElementById("al_person_details."+elementsArray[i]).checked=false;
                        document.getElementById("gestational_week").style.display = 'none';
                        
                        document.getElementById("al_person_details.mlife.expected_delivery").style.display = 'none';
                        document.getElementById("al_person_details.mlife.expected_delivery_dt").value = "";
                        document.getElementById("al_person_details.gestational_week").style.display = 'none';
                        document.getElementById("al_person_details.gestational_week").value = "Gestational Week";
                        
                        document.getElementById("al_person_details.mlife.first_name").disabled = true;
                        
                        document.getElementById("al_person_details.mlife.dtofbirth").style.display = 'block';
                        document.getElementById("al_person_details.mlife.anb_block").style.display = 'block';
                        // document.getElementById("al_person_details.mlife.anb").value = ""; changes made by pramod chavan for defect 3918 on 07092017
                        
                        
                        document.getElementById("al_person_details.mlife.gender_female").disabled = true;
                        document.getElementById("al_person_details.mlife.smoke_status_yes").disabled = true;
                       $(".occupationSearchMLifeText").attr("disabled","true");
                        document.getElementById("al_employee_details.mlife.occupation").disabled = true;
                        console.log("nob disabled");
                        $(".natureSearchMLifeText").attr("disabled","true");
                        document.getElementById("al_employee_details.mlife.nature_of_business").disabled = true;
                        
                        if(persontype != "mlife")
                        {
                        document.getElementById("al_person_details."+persontype+".nature_of_business").disabled = true;
                        }
                        }
                        }else if(elementsArray[i] == "expected_delivery_dt" || elementsArray[i] == "gestational_week")
                        {
                        if(obj[sub][elementsArray[i]] != "" && obj[sub][elementsArray[i]] != null && obj[sub][elementsArray[i]] != "null"  && obj[sub][elementsArray[i]] != "(null)")
                        {
                            if(elementsArray[i] == "gestational_week")
                            {
                        document.getElementById("al_person_details."+elementsArray[i]).value = obj[sub][elementsArray[i]];
                        }else
                        if(elementsArray[i] == "expected_delivery_dt")
                        {
                        document.getElementById("al_person_details."+persontype+"."+elementsArray[i]).value = obj[sub][elementsArray[i]];
                        var day_res = obj[sub][elementsArray[i]].split("/");
                           // CheckDate(elementName_populate, obj[sub][elementsArray[i]], day_res[0], day_res[1], day_res[2]);
                            }
                            }
                        }
                        }
                        }
                        fnMnROACheckMandatoryFields(); //Anjali: Def-3070
                    }
                        }
                        //onLoadSqsMlifePage();
                        
                       
                        //Following logic added for product choice product listing based on priority by sachin on 7-12-2022.
                         obj_priority=[];
                         var obj_version="";
                                                                           var selectProgramVersion=fnRetriveProgramVersion(mck_client_id,mck_ylp_id,ds_agentId);
                        
                                                                            var prioritylisting=fnfetchFNPPriority(Client_id,ds_agentId,mck_ylp_id);
                                                                            selectProgramVersion.execute(function(response_version){
                                                                                                         if(response_version != "" && response_version != undefined && response_version != null && response_version !="{}")
                                                                                                         {
                                                                                                                          obj_version = JSON.parse(response_version);
                                                                                                         }
                                                                                                         
                                                                            prioritylisting.execute(function(response_data)
                                                                                       {
                                                                                                   
                                                                                          if(response_data != "" && response_data != null &&  response_data != "null" &&  response_data != "(null)" && response_data != "{}")
                                                                                               {
                                                                                                          
                                                                                                                  var obj_recommend = JSON.parse(response_data);

                                                                                                                 var isFirstSaving="";
                                                                                                                 var isFirstIncome="";
                                                                                                                 var isFirstRirement="";
                                                                                                                 var isFirstHospital="";
                                                                                                                 var isFirstEducation="";
                                                                                                                 var isFirstDeathDis="";
                                                                                                                 var isFirstLegacy="";
                                                                                                   var isfirstPriority="";
                                                                                                                 var priorityCondition= [];
                                                                                                                 var uniqPriority = [];


                                                                                                               if(obj_recommend[0]["saving_ranking"]=="1"){
                                                                                                                 isFirstSaving="Yes";
                                                                                                                 isfirstPriority="saving";
                                                                                                                 }

                                                                                                               if(obj_recommend[0]["security_ranking"]=="1"){
                                                                                                                 isFirstIncome="Yes";
                                                                                                                 isfirstPriority="protection_critical_illness";
                                                                                                                 }

                                                                                                               if(obj_recommend[0]["investment_ranking"]=="1"){
                                                                                                                  isFirstRirement="Yes";
                                                                                                                  isfirstPriority="retirement"
                                                                                                                 
                                                                                                                 }
                                                                                                                  if(obj_recommend[0]["others_ranking"]=="1"){
                                                                                                                    isFirstHospital="Yes";
                                                                                                                    isfirstPriority="hospital_cost"
                                                                                                                 
                                                                                                                 }

                                                                                                                 if(obj_recommend[0]["education_ranking"]=="1"){
                                                                                                                 isFirstEducation="Yes";
                                                                                                                 isfirstPriority="education"
                                                                                                                 
                                                                                                                 }
                                                                                                                 if(obj_recommend[0]["protection_ranking"]=="1"){
                                                                                                                 isFirstDeathDis="Yes";
                                                                                                                 isfirstPriority="protection"
                                                                                                   
                                                                                                                 }

                                                                                                                  if(obj_recommend[0]["legacy_estate_planning_ranking"]=="1"){
                                                                                                                    isFirstLegacy="Yes";
                                                                                                                    isfirstPriority="legacyPlanning"
                                                                                                                 
                                                                                                                 }



                                                                                                if (changedProductMatrix != "" && changedProductMatrix != "{}") {
                                                                                                  for(var data in changedProductMatrix){
                                                                                                  var prodData = _.where(changedProductMatrix,{"product_name":changedProductMatrix[data]["product_name"]});
                                                                                                   console.log("prodData",prodData);

//                                                                                                       if(isFirstSaving=="Yes"){
//                                                                                                                 priorityCondition.push("saving");
//                                                                                                                 }
//
//                                                                                                              if(isFirstEducation=="Yes"){
//                                                                                                                 priorityCondition.push("education");
//                                                                                                                 }
//
//                                                                                                                 if(isFirstIncome=="Yes"){
//                                                                                                                 priorityCondition.push("protection_critical_illness");
//                                                                                                                 }
//                                                                                                                if(isFirstRirement=="Yes"){
//                                                                                                                 priorityCondition.push("retirement");
//                                                                                                                 }
//                                                                                                                if(isFirstDeathDis=="Yes"){
//                                                                                                                 priorityCondition.push("protection");
//                                                                                                                 }
//                                                                                                                if(isFirstHospital=="Yes"){
//                                                                                                                 priorityCondition.push("hospital_cost");
//                                                                                                                 }
//
//                                                                                                                 if(isFirstLegacy=="Yes"){
//                                                                                                                           priorityCondition.push("legacyPlaning");
//                                                                                                                                           }

                                                                                                   console.log("Sachin FN Recommendation priorityCondition"+isfirstPriority);
                                                                                                  
                                                                                                           // uniqPriority=uniqPriority.push(isfirstPriority);
                                                                                                          uniqPriority.push(isfirstPriority);

                                                                                                    console.log("uniqPriority",uniqPriority.length);

                                                                                                            //////////////
                                                                                                               //  if((priorityCondition.length!=0)){
                                                                                                                 
                                                                                                                 for(var iCounter=0; iCounter<=uniqPriority.length-1;iCounter++)
                                                                                                                   {
                                                                                                   console.log("Sachin FN Recommendation iCounter"+isfirstPriority);
                                                                                                                       var valueDataPriority =uniqPriority[iCounter];
                                                                                                                       console.log("valueDataPriority",valueDataPriority);
                                                                                                 
                                                                                                    //var filterData= _.where(prodData,{isfirstPriority:"Yes"});
                                                                                                   //console.log("filterData",filterData);
                                                                                                    //var  isDataPriority=_.where(filterData,{"Non_PWP_Product":"No"});
                                                                                                                        
                                                                                                                      var filterData=""
                                                                                                                      var  isDataPriority=""
                                                                                                   
                                                                                                                       if(valueDataPriority=="saving"){
                                                                                                                          filterData= _.where(prodData,{"saving":"Yes"});
                                                                                                                          // isDataPriority=_.where(filterData,{"Non_PWP_Product":"No"});
                                                                                                                       }else if(valueDataPriority=="education"){
                                                                                                                          filterData = _.where(prodData,{"education":"Yes"});
                                                                                                                         // isDataPriority = _.where(filterData,{"Non_PWP_Product":"No"});
                                                                                                                       }
                                                                                                                       else if(valueDataPriority=="protection_critical_illness"){
                                                                                                                        filterData = _.where(prodData,{"protection_critical_illness":"Yes"});
                                                                                                                       // isDataPriority = _.where(filterData,{"Non_PWP_Product":"No"});
                                                                                                                       } else if(valueDataPriority=="retirement"){
                                                                                                                        filterData = _.where(prodData,{"retirement":"Yes"});
                                                                                                                        //isDataPriority = _.where(filterData,{"Non_PWP_Product":"No"});
                                                                                                                       }
                                                                                                                       else if(valueDataPriority=="protection"){
                                                                                                                           filterData = _.where(prodData,{"protection":"Yes"});
                                                                                                                           //isDataPriority = _.where(filterData,{"Non_PWP_Product":"No"});
                                                                                                                       }
                                                                                                                           else if(valueDataPriority=="hospital_cost"){
                                                                                                                           filterData = _.where(prodData,{"hospital_cost":"Yes"});
                                                                                                                          // isDataPriority = _.where(filterData,{"Non_PWP_Product":"No"});
                                                                                                                       }
                                                                                                                       else if(valueDataPriority=="legacyPlanning"){
                                                                                                                        filterData = _.where(prodData,{"legacyPlanning":"Yes"});
                                                                                                                        //isDataPriority = _.where(filterData,{"Non_PWP_Product":"No"});
                                                                                                                       }
                                                                                                                                                                                                  
                                                                                                                  if(filterData!="" && filterData!="undefined" && filterData!=undefined){
                                                                                                   
                                                                                                                          isDataPriority = _.where(filterData,{"Non_PWP_Product":"No"});
                                                                                                                       }
                                                                                                                                                                                                  
                                                                                                                                            
                                                                                                   console.log("isDataPriority",isDataPriority);
                                                                                                                                                                                                  if(isDataPriority!="" && isDataPriority!="undefined" && isDataPriority!=undefined){
                                                                                                                                                                                                    
                                                                                                                                                                                                       var ProdName = changedProductMatrix[data]["product_name"];
                                                                                                                                                                                                                      
                                                                                                                                                console.log("obj_version",obj_version);
                                                                                                                                                                                                     if(channelTypeForAgencyBancaRepls=="banca" && (!fnMPCompareTwoVersions(Jan2023Version,obj_version[0]['program_version']))){
                                                                                                                                                                                                      obj_priority.push(ProdName);
                                                                                                                                                                                                     }
                                                                                                                 
                                                                                                                                                                                                    
                                                                                                                                                                                                  }else{
                                                                                                                                                                                                    // isAllTrue.push("No");
                                                                                                                                                                                                      
                                                                                                                                                                                                  }
                                                                                                   console.log("obj_priority",obj_priority);
                                                                                                                                                    
                                                                                                                                                                           
                                                                                                                                                                       }
                                                                                                                 
                                                                                                                 
                                                                                                                 
                                                                                                              //   }


                                                                                                  }


                                                                                                   }


                                                                                               }

                                                                                       });
                                                                                                         });
                                                                            
                                                                            
                                                                          
                                              ///////////////////////////////////////
                        
                        
                        
                        
                        
                        
                        });
}

//Anjali/Makarand: Populate sqs data when user come from AL module
function PopulateValuesForAlSqs(personType){
    var AlSelectQuery = fnMPAlSelectQuery('al_letter_details',Al_proposal_no);
    AlSelectQuery.execute(function (response){
          if(response != "" && response !=null && response !="{}"){
              var obj = JSON.parse(response);
              var LA_name = obj[0]['LIFE_ASSURED_NAME'];
              var LA_DOB = obj[0]['LIFE_ASSURED_DOB'];
              var LA_ANB = obj[0]['LIFE_ASSURED_ANB'];
              var LA_OCC = obj[0]['LIFE_ASSURED_OCCUPATION'];
              var LA_OCC_CL = obj[0]['la_occupation_class'];
              var LA_NOB = obj[0]['LIFE_ASSURED_NOB'];
              var PR_name = obj[0]['PROPOSER_NAME'];
              var PR_DOB = obj[0]['PROPOSER_DOB'];
              var PR_ANB = obj[0]['PROPOSER_ANB'];
              var PR_OCC = obj[0]['PORPOSER_OCCUPATION'];
              var PR_NOB = obj[0]['PROPOSER_NOB'];
              var TL_name = obj[0]['JOINT_PARENT_NAME'];
              var TL_DOB = obj[0]['JOINT_PARENT_DOB'];
              var TL_ANB = obj[0]['JOINT_PARENT_ANB'];
              var TL_OCC = obj[0]['JOINT_PARENT_OCCUPATION'];
              var TL_NOB = obj[0]['JOINT_PARENT_NOB'];
              var LA_relationship = obj[0]['la_relationship'];
              var LA_pre_natal_child_flg = obj[0]['la_pre_natal_child_flg'];
              var LA_gestational_week = obj[0]['la_gestational_week'];
              var LA_occupation_class = obj[0]['la_occupation_class'];
              var LA_gender = obj[0]['la_gender'];
              var LA_smoke_status = obj[0]['la_smoke_status'];
              var LA_expected_delivery_dt = obj[0]['la_expected_delivery_dt'];
              var PR_gestational_week = obj[0]['pr_gestational_week'];
              var PR_occupation_class = obj[0]['pr_occupation_class'];
              var PR_pre_natal_child_flg = obj[0]['pr_pre_natal_child_flg'];
              var PR_relationship = obj[0]['pr_relationship'];
              var PR_gender = obj[0]['pr_gender'];
              var PR_smoke_status = obj[0]['pr_smoke_status'];
              var TL_pre_natal_child_flg = obj[0]['jp_pre_natal_child_flg'];
              var TL_occupation_class = obj[0]['jp_occupation_class'];
              var TL_relationship = obj[0]['jp_relationship'];
              var TL_expected_delivery_dt = obj[0]['jp_expected_delivery_dt'];
              var TL_gender = obj[0]['jp_gender'];
              var TL_gestational_week = obj[0]['jp_gestational_week'];
              var TL_smoke_status = obj[0]['jp_smoke_status'];
              var SL_name = obj[0]['slife_name'];
              var SL_pre_natal_child_flg = obj[0]['slife_pre_natal_child_flg'];
              var SL_gender = obj[0]['slife_gender'];
              var SL_gestational_week = obj[0]['slife_gestational_week'];
              var SL_smoke_status = obj[0]['slife_smoke_status'];
              var SL_anb = obj[0]['slife_anb'];
              var SL_relationship = obj[0]['slife_relationship'];
              var SL_expected_delivery_dt = obj[0]['slife_expected_delivery_dt'];
              var SL_dob = obj[0]['slife_dob'];
              var SL_occupation_class = obj[0]['slife_occupation_class'];
              var SL_nob = obj[0]['slife_nob'];
              var SL_occupation = obj[0]['slife_occupation'];
              var e_ref_id = obj[0]['e_reference_id'];
                          
              
              console.log("plan LA_name is ---->>" + LA_name +"plan LA_DOB is ---->>" + LA_DOB +"plan LA_ANB is ---->>" + LA_ANB +"plan LA_OCC is ---->>" + LA_OCC +"plan LA_NOB is ---->>" + LA_NOB +"plan PR_name is ---->>" + PR_name +"plan PR_DOB is ---->>" + PR_DOB +"plan PR_ANB is ---->>" + PR_ANB +"plan PR_OCC is ---->>" + PR_OCC +"plan PR_NOB is ---->>" + PR_NOB +"plan TL_name is ---->>" + TL_name +"plan TL_DOB is ---->>" + TL_DOB +"plan TL_ANB is ---->>" + TL_ANB +"plan TL_OCC is ---->>" + TL_OCC +"plan TL_NOB is ---->>" + TL_NOB + "slife name is --->>" + SL_name);
          }
                          
          if(personType == "mlife"){
              document.getElementById("al_person_details.mlife.first_name_dropdown").value = LA_name;
              document.getElementById("al_person_details.mlife.dob").value = LA_DOB;
             
            document.getElementById("al_person_details.mlife.anb").value = LA_ANB;
            
             if(ANB_json[0]["anb_type"]=="IL_Daily" && (ANB_json[0]["anb_type"]!="" && ANB_json[0]["anb_type"]!='undefined' && ANB_json[0]["anb_type"]!=undefined && ANB_json[0]["anb_type"]!="{}"))
                {
                     fnMsCalculateANBforILproducts(personType); //Added by Anjali for Defect 4746 On 9Jan18
                }else if(ANB_json[0]["anb_type"]=="IL_Monthly" && (ANB_json[0]["anb_type"]!="" && ANB_json[0]["anb_type"]!='undefined' && ANB_json[0]["anb_type"]!=undefined && ANB_json[0]["anb_type"]!="{}"))
                {
                 fnMsCalculateANBforIL_monthlyproducts(personType);
                }
            
              document.getElementById("al_employee_details.mlife.occupation").value = LA_OCC;
              document.getElementById("al_employee_details.mlife.occupation_class").value = LA_OCC_CL;
                    if(LA_gender == "M"){
                          document.getElementById("al_person_details.mlife.gender_male").checked = true;
                          document.getElementById("al_person_details.mlife.gender_female").checked = false;
                      }else{
                          document.getElementById("al_person_details.mlife.gender_male").checked = false;
                          document.getElementById("al_person_details.mlife.gender_female").checked = true;
                      }
                      if(LA_smoke_status == "No"){
                          document.getElementById("al_person_details.mlife.smoke_status_yes").checked = false;
                          document.getElementById("al_person_details.mlife.smoke_status_no").checked = true;

                      }else{
                          document.getElementById("al_person_details.mlife.smoke_status_yes").checked = true;
                          document.getElementById("al_person_details.mlife.smoke_status_no").checked = false;
                      }

                      var nobObj= MsGetNob(load_tsv_data["Nob_text"],load_tsv_data["Nob_value"]);     // changes by sayali for remove the dropdown
                      var nobObjTwo=nobObj[2];
                      
                      var nobMlife = (nobObjTwo[LA_NOB] != undefined && nobObjTwo[LA_NOB] != "undefined")? nobObjTwo[LA_NOB] : "";
                      document.getElementById("al_employee_details.mlife.nature_of_business").value = nobMlife;

                      //Added by Anjali for Prenatal case 
                      if(LA_pre_natal_child_flg=="Yes"){
                        document.getElementById("gestational_week").style.display='block';
                        document.getElementById("al_person_details.mlife.expected_delivery").style.display='block';
                        document.getElementById("al_person_details.mlife.expected_delivery_dt").style.display='block';
                        document.getElementById("al_person_details.gestational_week").style.display='block';
                        document.getElementById("al_person_details.gestational_week").disabled=true;
                        document.getElementById("al_person_details.mlife.expected_delivery_dt").disabled=true;
                        document.getElementById("al_person_details.mlife.dtofbirth").style.display='none';
                        document.getElementById("al_person_details.mlife.dob").style.display='none';
                        document.getElementById("al_person_details.mlife.anb_block").style.display='none';
                        $(escape_jq('al_person_details.pre_natal_child_flg')).prop('checked',true);
                        document.getElementById("al_person_details.mlife.expected_delivery_dt").value=LA_expected_delivery_dt
                        $('#gestational_week select option[value="' + LA_gestational_week +'"]').prop("selected", true);
                      }
                          
                       if(((LA_name == PR_name && LA_DOB == PR_DOB && LA_ANB == PR_ANB)&&(SL_name != "" && SL_name != null && SL_name != "null" && SL_name != "(null)")) || ((LA_name != PR_name && LA_DOB != PR_DOB && LA_ANB != PR_ANB)&&(SL_name == "" || SL_name == null || SL_name == "null" || SL_name == "(null)")))
                          {
                          
                              document.getElementById("al_sqs_details.sec_parti_flag_yes").checked = true;
                              document.getElementById("al_sqs_details.sec_parti_flag_no").checked = false;
                              $(".collapseTwo").attr("id", "collapseTwo");
                              $(".second_life").addClass("normal_panel");
                              $(".second_life").removeClass("disabled_panel");
                          }
                          else{
                          document.getElementById("al_sqs_details.sec_parti_flag_yes").checked = false;
                          document.getElementById("al_sqs_details.sec_parti_flag_no").checked = true;

                          }
          }
          if(personType == "slife"){
                          
               if((LA_name == PR_name && LA_DOB == PR_DOB && LA_ANB == PR_ANB)&&(SL_name != "" && SL_name != null && SL_name != "null" && SL_name != "(null)")){
              
                          console.log("second life name is " + SL_name);
                          document.getElementById("al_person_details.slife.first_name_dropdown").value = SL_name;
                          document.getElementById("al_person_details.slife.dob").value = SL_dob;
                          document.getElementById("al_person_details.slife.anb").value = SL_anb;
                          if(ANB_json[0]["anb_type"]=="IL_Daily" && (ANB_json[0]["anb_type"]!="" && ANB_json[0]["anb_type"]!='undefined' && ANB_json[0]["anb_type"]!=undefined && ANB_json[0]["anb_type"]!="{}")) //Added condition for OS TO IL conversion.
                          {
                          fnMsCalculateANBforILproducts(personType); //Added by Anjali for Defect 4746 On 9Jan18
                          }else if(ANB_json[0]["anb_type"]=="IL_Monthly" && (ANB_json[0]["anb_type"]!="" && ANB_json[0]["anb_type"]!='undefined' && ANB_json[0]["anb_type"]!=undefined && ANB_json[0]["anb_type"]!="{}"))
                          {
                           fnMsCalculateANBforIL_monthlyproducts(personType);
                          }
                          document.getElementById("al_employee_details.slife.occupation").value = SL_occupation;
                          document.getElementById("al_employee_details.slife.occupation_class").value = SL_occupation_class;
                          
                          if(SL_gender == "M"){
                              document.getElementById("al_person_details.slife.gender_male").checked = true;
                              document.getElementById("al_person_details.slife.gender_female").checked = false;
                          }else{
                              document.getElementById("al_person_details.slife.gender_male").checked = false;
                              document.getElementById("al_person_details.slife.gender_female").checked = true;
                          }
                          if(SL_smoke_status == "No"){
                              document.getElementById("al_person_details.slife.smoke_status_yes").checked = false;
                              document.getElementById("al_person_details.slife.smoke_status_no").checked = true;
                          
                          }else{
                              document.getElementById("al_person_details.slife.smoke_status_yes").checked = true;
                              document.getElementById("al_person_details.slife.smoke_status_no").checked = false;
                          }
                          
                          
                          console.log("PR_relationship"+PR_relationship);
                           console.log("SL_relationship"+SL_relationship);
                          
                          if(PR_relationship == "H" || PR_relationship == "W" || SL_relationship == "H" ||SL_relationship == "W"){
                          
                            document.getElementById("al_person_details.slife.relationship").value = "Spouse";
                          
                          
                          }
                          else if(PR_relationship == "G" || SL_relationship == "G"){
                            document.getElementById("al_person_details.slife.relationship").value = "Legal Guardian";
                          }
                          else if(PR_relationship == "F" || PR_relationship == "M" || SL_relationship == "F" ||SL_relationship == "M"){
                          
                          console.log("PR_relationship"+PR_relationship);
                          console.log("SL_relationship"+SL_relationship);
                          
                            document.getElementById("al_person_details.slife.relationship").value = "Parent";
                          }
                          else{}
                          
                      var nobObj= MsGetNob(load_tsv_data["Nob_text"],load_tsv_data["Nob_value"]);     // changes by sayali for remove the dropdown
                      var nobObjTwo=nobObj[2];
                      
                      //var nobSlife = nobObjTwo[SL_nob];
                      var nobSlife = (nobObjTwo[SL_nob] != undefined && nobObjTwo[SL_nob] != "undefined")? nobObjTwo[SL_nob] : "";
                      document.getElementById("al_employee_details.slife.nature_of_business").value = nobSlife;
                          
                          if(TL_name != "" && TL_name != null && TL_name != "null" && TL_name != "(null)"){
                            //al_sqs_details.third_parti_flg_yes
                              document.getElementById("al_sqs_details.third_parti_flg_no").checked = false;
                              document.getElementById("al_sqs_details.third_parti_flg_yes").checked = true;
                              document.getElementById("third_life_party_flag").style.display="block";
//                              SetValuesnull();
                          $(".collapseThree").attr("id", "collapseThree");
                          $(".third_life").addClass("normal_panel");
                          $(".third_life").removeClass("disabled_panel");

                          }
                          else{
                              document.getElementById("al_sqs_details.third_parti_flg_no").checked = true;
                              document.getElementById("al_sqs_details.third_parti_flg_yes").checked = false;
                          }
              
              }
               else if((LA_name != PR_name && LA_DOB != PR_DOB && LA_ANB != PR_ANB)&&(SL_name == "" || SL_name == null || SL_name == "null" || SL_name == "(null)")){
                  
                          console.log("inside PR_name condition");
                  document.getElementById("al_person_details.slife.first_name_dropdown").value = PR_name;
                  document.getElementById("al_person_details.slife.dob").value = PR_DOB;
                  document.getElementById("al_person_details.slife.anb").value = PR_ANB;
                 
                  if(ANB_json[0]["anb_type"]=="IL_Daily" && (ANB_json[0]["anb_type"]!="" && ANB_json[0]["anb_type"]!='undefined' && ANB_json[0]["anb_type"]!=undefined && ANB_json[0]["anb_type"]!="{}"))
                    {
                      fnMsCalculateANBforILproducts(personType); //Added by Anjali for Defect 4746 On 9Jan18
                    }else if(ANB_json[0]["anb_type"]=="IL_Monthly" && (ANB_json[0]["anb_type"]!="" && ANB_json[0]["anb_type"]!='undefined' && ANB_json[0]["anb_type"]!=undefined && ANB_json[0]["anb_type"]!="{}"))
                        {
                     fnMsCalculateANBforIL_monthlyproducts(personType);
                        }
                  document.getElementById("al_employee_details.slife.occupation").value = PR_OCC;
                  document.getElementById("al_employee_details.slife.occupation_class").value = PR_occupation_class;
                  
                          
                  if(PR_gender == "M"){
                      document.getElementById("al_person_details.slife.gender_male").checked = true;
                      document.getElementById("al_person_details.slife.gender_female").checked = false;
                  }else{
                      document.getElementById("al_person_details.slife.gender_male").checked = false;
                      document.getElementById("al_person_details.slife.gender_female").checked = true;
                  }
                  if(PR_smoke_status == "No"){
                      document.getElementById("al_person_details.slife.smoke_status_yes").checked = false;
                      document.getElementById("al_person_details.slife.smoke_status_no").checked = true;
                  
                  }else{
                      document.getElementById("al_person_details.slife.smoke_status_yes").checked = true;
                      document.getElementById("al_person_details.slife.smoke_status_no").checked = false;
                  }
                        
                          
                          console.log("PR_relationship"+PR_relationship);
                          console.log("SL_relationship"+SL_relationship);
                          if(PR_relationship == "H" || PR_relationship == "W" || SL_relationship == "H" ||SL_relationship == "W"){
                          
                          document.getElementById("al_person_details.slife.relationship").value = "Spouse";
                          
                          
                          }
                          else if(PR_relationship == "G" || SL_relationship == "G" || TL_relationship == "G"){
                          document.getElementById("al_person_details.slife.relationship").value = "Legal Guardian";
                          }
                          else if(PR_relationship == "F" || PR_relationship == "M" || SL_relationship == "F" ||SL_relationship == "M"){
                          console.log("PR_relationship inside else PR_name"+PR_relationship);
                          console.log("SL_relationship"+SL_relationship);

                          document.getElementById("al_person_details.slife.relationship").value = "Parent";
                          }
                          
                  var nobObj= MsGetNob(load_tsv_data["Nob_text"],load_tsv_data["Nob_value"]);     // changes by sayali for remove the dropdown
                  var nobObjTwo=nobObj[2];
                  
                  //var nobSlife = nobObjTwo[PR_NOB];
                  var nobSlife = (nobObjTwo[PR_NOB] != undefined && nobObjTwo[PR_NOB] != "undefined")? nobObjTwo[PR_NOB] : "";
                  document.getElementById("al_employee_details.slife.nature_of_business").value = nobSlife;
                          
                  if(TL_name != "" && TL_name != null && TL_name != "null" && TL_name != "(null)"){
                      //al_sqs_details.third_parti_flg_yes
                      document.getElementById("al_sqs_details.third_parti_flg_no").checked = false;
                      document.getElementById("al_sqs_details.third_parti_flg_yes").checked = true;
                      document.getElementById("third_life_party_flag").style.display="block";
//                                                SetValuesnull();
                          $(".collapseThree").attr("id", "collapseThree");
                          $(".third_life").addClass("normal_panel");
                          $(".third_life").removeClass("disabled_panel");

                          
                  }
                  else{
                      document.getElementById("al_sqs_details.third_parti_flg_no").checked = true;
                      document.getElementById("al_sqs_details.third_parti_flg_yes").checked = false;
                  }

                  
                  }
                else{
                          document.getElementById("al_person_details.slife.first_name_dropdown").value = "";
                          document.getElementById("al_person_details.slife.dob").value = "";
                          document.getElementById("al_person_details.slife.anb").value = "";
                          document.getElementById("al_employee_details.slife.occupation").value = "";
                          
                          document.getElementById("al_employee_details.slife.nature_of_business").value = "";
                    }
             
          }

          if(personType == "tlife"){
              document.getElementById("al_person_details.tlife.first_name_dropdown").value = TL_name;
              document.getElementById("al_person_details.tlife.dob").value = TL_DOB;
              document.getElementById("al_person_details.tlife.anb").value = TL_ANB;
                          
                
                          //channel if scb //
            if(ANB_json[0]["anb_type"]=="IL_Daily" && (ANB_json[0]["anb_type"]!="" && ANB_json[0]["anb_type"]!='undefined' && ANB_json[0]["anb_type"]!=undefined && ANB_json[0]["anb_type"]!="{}"))
            {
            fnMsCalculateANBforILproducts(personType); //Added by Anjali for Defect 4746 On 9Jan18
            }else if(ANB_json[0]["anb_type"]=="IL_Monthly" && (ANB_json[0]["anb_type"]!="" && ANB_json[0]["anb_type"]!='undefined' && ANB_json[0]["anb_type"]!=undefined && ANB_json[0]["anb_type"]!="{}"))
                {
                        fnMsCalculateANBforIL_monthlyproducts(personType);
                          
               }
                          
             
              document.getElementById("al_employee_details.tlife.occupation").value = TL_OCC;
              document.getElementById("al_employee_details.tlife.occupation_class").value = TL_occupation_class;
                          
                  if(TL_gender == "M"){
                      document.getElementById("al_person_details.tlife.gender_male").checked = true;
                      document.getElementById("al_person_details.tlife.gender_female").checked = false;
                  }else{
                      document.getElementById("al_person_details.tlife.gender_male").checked = false;
                      document.getElementById("al_person_details.tlife.gender_female").checked = true;
                  }
                  if(TL_smoke_status == "No"){
                      document.getElementById("al_person_details.tlife.smoke_status_yes").checked = false;
                      document.getElementById("al_person_details.tlife.smoke_status_no").checked = true;
                  
                  }else{
                      document.getElementById("al_person_details.tlife.smoke_status_yes").checked = true;
                      document.getElementById("al_person_details.tlife.smoke_status_no").checked = false;
                  }
              
              var nobObj= MsGetNob(load_tsv_data["Nob_text"],load_tsv_data["Nob_value"]);     // changes by sayali for remove the dropdown
              var nobObjTwo=nobObj[2];
              
              //var nobTlife = nobObjTwo[TL_NOB];
              var nobTlife = (nobObjTwo[TL_NOB] != undefined && nobObjTwo[TL_NOB] != "undefined")? nobObjTwo[TL_NOB] : "";
              document.getElementById("al_employee_details.tlife.nature_of_business").value = nobTlife;
          }

                          
        fnMnROACheckMandatoryFields();
        
    });
}

function fnMsDisableDropdownChange(callfrom)
{
    console.log("In fnMsDisableDropdownChange-->"+callfrom);
    var dropdownindex="";
    if(callfrom=="")
    {
        if($(".second_life").hasClass("disabled_panel"))
        {
            $('.slifefnamedrop').val("Select");
        }
        if($(".third_life").hasClass("disabled_panel"))
        {
            $('.tlifefnamedrop').val("Select");
        }
    }
    var c1=$(".mlifefnamedrop option:selected").text();
    var c2=$(".slifefnamedrop option:selected").text();
    var c3=$(".tlifefnamedrop option:selected").text();
    $('.mlifefnamedrop,.slifefnamedrop,.tlifefnamedrop').children().removeAttr('disabled');
    // var selectVal = $(".child2 option:selected").text();
    
    
    $('.mlifefnamedrop,.slifefnamedrop,.tlifefnamedrop').children('option[value="'+c1+'"]').prop('disabled','disabled');
     $('.mlifefnamedrop,.slifefnamedrop,.tlifefnamedrop').children('option[value="'+c2+'"]').prop('disabled','disabled');
    $('.mlifefnamedrop,.slifefnamedrop,.tlifefnamedrop').children('option[value="'+c3+'"]').prop('disabled','disabled');
    console.log(".mlife.insu_type",fromMySolution,(!($(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Keyman Insurance" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Employer Employee Insurance" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Partnership Insurance" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Business Loan Insurance (for Sole Proprietorship/Partnership)" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Business Loan Insurance (for Company/LLP)")))
   
    enableIfChagned();
   
   
   /* dropdownindex=$(escape_jq("al_person_details.mlife.first_name_dropdown")).prop('selectedIndex'); //Added for defect 6228
    var secondIndex=$(escape_jq("al_person_details.slife.first_name_dropdown")).prop('selectedIndex');
    var thirdIndex=$(escape_jq("al_person_details.tlife.first_name_dropdown")).prop('selectedIndex');
    $('.mlifefnamedrop').children("option").eq(dropdownindex).prop("disabled","disabled");
    $('.slifefnamedrop').children("option").eq(dropdownindex).prop("disabled","disabled");
    $('.tlifefnamedrop').children("option").eq(dropdownindex).prop("disabled","disabled");
    
    $('.mlifefnamedrop').children("option").eq(secondIndex).prop("disabled","disabled");
    $('.slifefnamedrop').children("option").eq(secondIndex).prop("disabled","disabled");
    $('.tlifefnamedrop').children("option").eq(secondIndex).prop("disabled","disabled");
    
    $('.mlifefnamedrop').children("option").eq(thirdIndex).prop("disabled","disabled");
    $('.slifefnamedrop').children("option").eq(thirdIndex).prop("disabled","disabled");
    $('.tlifefnamedrop').children("option").eq(thirdIndex).prop("disabled","disabled");
    
    }
    var selectEnable="Select"
    
    $('.mlifefnamedrop,.slifefnamedrop,.tlifefnamedrop').children('option[value="'+selectEnable+'"]').removeAttr('disabled');
    */





    
}

function DisableDropdown(id1)
{
    var elementID;
    elementID = document.getElementById(id1);
    elementID.disabled = true;
}

function fnMsDisableForm()
{
                                           console.log("123fnMsDisableForm")
    var MySolNonReplicate=new Array("al_person_details.slife.first_name_dropdown","al_person_details.tlife.first_name_dropdown","al_sqs_details.third_parti_flg_yes","al_sqs_details.third_parti_flg_no","al_sqs_details.sec_parti_flag_yes","al_sqs_details.sec_parti_flag_no", "al_person_details.slife.relationship","al_person_details.tlife.relationship");
    
    var MySolNonReplicateBanca=new Array("al_person_details.slife.first_name_dropdown","al_person_details.tlife.first_name_dropdown","al_sqs_details.third_parti_flg_yes","al_sqs_details.third_parti_flg_no","al_sqs_details.sec_parti_flag_yes","al_sqs_details.sec_parti_flag_no","al_person_details.mlife.parent_consent_no","al_person_details.mlife.parent_consent_yes");
    
    var RiderIdDiv = "disb_ids";
    var inputs = document.getElementById(RiderIdDiv).getElementsByTagName("input");
    for (var i = 0; i <inputs.length; i++) {
        
        if(Channel != "Banca" && Channel != "UOB")//changed by Purva / Pramod C on 07th Aug 2017 for UOB
        {
            for(var j = 0; j <MySolNonReplicate.length; j++)
            {
                if(inputs[i].id != MySolNonReplicate[j])
                {
            inputs[i].readOnly = true;
            inputs[i].disabled  = true;
                }
            }
        }
        
        if(Channel == "Banca" || Channel == "UOB")//changed by Purva / Pramod C on 07th Aug 2017 for UOB
        {
            for(var j = 0; j <MySolNonReplicateBanca.length; j++)
            {
               
                if(inputs[i].id != MySolNonReplicateBanca[j])
                {
                    inputs[i].readOnly = true;
                    inputs[i].disabled  = true;
                }
            }
        }
                                           
    }
    
    var image = document.getElementById(RiderIdDiv).getElementsByTagName("img");
    for (var i = 0; i < image.length; i++)
    {
        image[i].onclick = false;
        image[i].readOnly = true;
    }

    var selects = document.getElementById(RiderIdDiv).getElementsByTagName("select");
    for (var i = 0; i < selects.length; i++)
    {
        for(var j = 0; j <MySolNonReplicate.length; j++)
        {
            if(selects[i].id != MySolNonReplicate[j])
            {
                console.log("relation id 1---->"+selects[i].id);
        selects[i].disabled = true;
        selects[i].readOnly = true;
            }
        }
    }

    var textareas = document.getElementById(RiderIdDiv).getElementsByTagName("textarea");
    for (var i = 0; i < textareas.length; i++)
    {
        textareas[i].disabled = true;
        textareas[i].readOnly = true;
    }

    var buttons = document.getElementById(RiderIdDiv).getElementsByTagName("button");
    for (var i = 0; i < buttons.length; i++)
    {
        buttons[i].disabled = true;
        buttons[i].readOnly = true;
    }

    var radios = document.getElementById(RiderIdDiv).getElementsByTagName("radio");
    for (var i = 0; i < radios.length; i++)
    {
        
        
        if(Channel != "Banca" && Channel != "UOB")//changed by Purva / Pramod C on 07th Aug 2017 for UOB
        {
            for(var j = 0; j <MySolNonReplicate.length; j++)
            {
                if(radios[i].id != MySolNonReplicate[j])
                {
                    radios[i].disabled = true;
                    //radios[i].readOnly = true;
                }
            }
        }
        
        if(Channel == "Banca" || Channel == "UOB")//changed by Purva / Pramod C on 07th Aug 2017 for UOB
        {
            for(var j = 0; j <MySolNonReplicateBanca.length; j++)
            {
                if(radios[i].id != MySolNonReplicateBanca[j])
                {
                    radios[i].disabled = true;
                    //radios[i].readOnly = true;
                }
            }
        }
    }

    var checkboxes = document.getElementById(RiderIdDiv).getElementsByTagName("checkbox");
    for (var i = 0; i < checkboxes.length; i++)
    {
        for(var j = 0; j <MySolNonReplicate.length; j++)
        {
            if(checkboxes[i].id != MySolNonReplicate[j])
            {
        checkboxes[i].disabled = true;
        checkboxes[i].readOnly = true;
            }
        }
    }
    
    var spans = document.getElementById(RiderIdDiv).getElementsByTagName("span");
    for (var i = 0; i < spans.length; i++)
    {
        spans[i].disabled = true;
        spans[i].readOnly = true;
    }
    
    var labels = document.getElementById(RiderIdDiv).getElementsByTagName("label");
    for (var i = 0; i < labels.length; i++)
    {
        for(var j = 0; j <MySolNonReplicate.length; j++)
        {
            if(labels[i].id != MySolNonReplicate[j])
            {
        labels[i].disabled = true;
        labels[i].readOnly = true;
            }
        }
    }
    
    if(Channel != "Banca" && Channel != "UOB")//changed by Purva / Pramod C on 07th Aug 2017 for UOB
    {
    for (var m=0 ; m<MySolNonReplicate.length; m++)
    {
        var idname =document.getElementById(MySolNonReplicate[m]);
        
        if(idname != null && idname != "" && idname != "undefined")
        {
            console.log("relation id ---->"+MySolNonReplicate[m]);
                document.getElementById(MySolNonReplicate[m]).disabled = false;
                document.getElementById(MySolNonReplicate[m]).readOnly = false;
        }
    }
    }
    
    if(Channel == "Banca" || Channel == "UOB")//changed by Purva / Pramod C on 07th Aug 2017 for UOB
    {
        for (var m=0 ; m<MySolNonReplicateBanca.length; m++)
        {
            var idname =document.getElementById(MySolNonReplicateBanca[m]);
            
            if(idname != null && idname != "" && idname != "undefined")
            {
                document.getElementById(MySolNonReplicateBanca[m]).disabled = false;
                document.getElementById(MySolNonReplicateBanca[m]).readOnly = false;
            }
        }
    }
    if( $(".natureSearchSLifeText").val()==""){
    $(".natureSearchSLifeText").removeAttr("readonly");
    }
    if( $(".natureSearchTLifeText").val()==""){
    $(".natureSearchTLifeText").removeAttr("readonly");
    }
                                           console.log("fnmsdisableform"+document.getElementById("al_person_details.slife.gender_female").checked);
                                           console.log("fnmsdisableform"+document.getElementById("al_person_details.slife.gender_male").checked);
                                           
                                           //added for defect 280 by ankita on 26 april 2022
                                           
                                              if(replicate_res != "" && replicate_res != null && replicate_res != "null" && replicate_res != "(null)")
                                              {
                                           console.log("Inside replicate");
                                                  fnGetRelationshipList('al_person_details.mlife.anb_il_product','al_person_details.slife.anb_il_product','','al_person_details.slife.relationship','al_person_details.slife.gender_male','al_person_details.slife.gender_female','mySolutions');
                                              
                                                var gender="";
                                                if(document.getElementById("al_person_details.slife.gender_male").checked)
                                                {
                                               
                                                gender="Male";
                                                }
                                                if(document.getElementById("al_person_details.slife.gender_female").checked)
                                                {
                                                gender="Female";
                                                }
                                                console.log("gender 9319 checkdate:"+gender+"--relationship_mlife:"+relationship_mlife);
                                                  console.log("RRelationship5"+relationship_mlife)
                                                  console.log("RRelationship6"+relationship_slife)
                                               // var returnValueRelation=fnMsPopulateRelationship(relationship_mlife,gender);
                                                  //This was original code commited for internal issues by Sachin T. on date 15  dec 2023.
                                                  
                                                  var relationShipData = "";
                                                  if(relationship_mlife!=""){
                                                      relationShipData = relationship_mlife
                                                  }else if(relationship_slife!=""){
                                                      relationShipData = relationship_slife;
                                                  }
                                                  var returnValueRelation=fnMsPopulateRelationship(relationShipData,gender);
                                               console.log("returnValueRelation:"+returnValueRelation);
                                               
                                           setTimeout(function(){document.getElementById("al_person_details.slife.relationship").value = returnValueRelation;},0.1);
                                           //document.getElementById("al_person_details.slife.relationship").value=returnValueRelation;
                                                console.log("disabled 4");
                                                document.getElementById("al_person_details.slife.relationship").disabled=true;
                                                console.log("relation:"+document.getElementById("al_person_details.slife.relationship").value);
                                              }
                                           
                                           
                
                                           
                                           
}

function fnMsReturnRelationshipValue(rel_val)
{
    var rel_string="";
    
    if(rel_val == "H")
    {
       rel_string = "Husband";
    }else if(rel_val == "W")
    {
        rel_string = "Wife";
    }else if(rel_val == "F")
    {
        rel_string = "Father";
    }else if(rel_val == "M")
    {
        rel_string = "Mother";
    }else if(rel_val == "G")
    {
        rel_string = "Legal Guardian";
    }else if(rel_val == "B")
    {
        rel_string = "Brother";
    }else if(rel_val == "S")
    {
        rel_string = "Sister";
    }else if(rel_val == "C")
    {
        rel_string = "Child";
    }else if(rel_val == "O")
    {
        rel_string = "Other";
    }else if(rel_val == "E")
    {
        rel_string = "Employer";
    }else if(rel_val == "T")
    {
        rel_string = "Partner";
    }else if(rel_val == "R")
    {
        rel_string = "Friend";
    }else if(rel_val == "N")
    {
        rel_string = "Nephew / Niece";
    }else if(rel_val == "U")
    {
        rel_string = "Uncle";
    }else if(rel_val == "A")
    {
        rel_string = "Aunty";
    }else if(rel_val == "P")
    {
        rel_string = "Grandparents";
    }else if(rel_val == "L")
    {
        rel_string = "Grandchild";
    }else
    {
        rel_string="";
    }
    return rel_string;
}

function fnMsDisableLives(id,callfrom)
{
    // 14122017 mlifeILANB added for IL product condition.
    var mlifeILANB=document.getElementById("al_person_details.mlife.anb_il_product").value;
    var mlifeILANB_monthly=document.getElementById("al_person_details.mlife.anb_il_monthly_product").value; //Added by Sachin Tupe for il_monthly product on 26-06-2018.
        if(document.getElementById("al_person_details.mlife.parent_consent_yes").checked)
        {
            if((Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)") || (replicate_res != "" && replicate_res != null && replicate_res != "null" && replicate_res != "(null)"))
            {
                document.getElementById("al_sqs_details.sec_parti_flag_no").checked = true;
                document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = true;
                document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = true;
                $(".collapseTwo").attr("id", "");
                $(".second_life").addClass("disabled_panel");
                $(".second_life").removeClass("normal_panel").removeClass("active_panel");
                
                SetValuesnull();
            }else
            {
                document.getElementById("al_sqs_details.sec_parti_flag_yes").checked = true;
                document.getElementById("al_sqs_details.sec_parti_flag_no").checked = false;
                document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = true;
                $(".collapseTwo").attr("id", "collapseTwo");
                $(".second_life").addClass("normal_panel");
                $(".second_life").removeClass("disabled_panel");
            }
            // TODO
           if((document.getElementById("al_person_details.mlife.anb").value >= 11 && document.getElementById("al_person_details.mlife.anb").value <= 16) || (((mlifeILANB >= 11) && (mlifeILANB <= 16)) || ((mlifeILANB_monthly >= 11) && (mlifeILANB_monthly <= 16)) ))
           {
              
               document.getElementById("al_sqs_details.third_parti_flg_no").checked = true;
               document.getElementById("al_sqs_details.third_parti_flg_yes").checked = false;
               console.log("2.in display none");
               document.getElementById("third_life_party_flag").style.display="none";
               SetValuesnull();
               $(".collapseThree").attr("id", "");
               $(".third_life").addClass("disabled_panel");
               $(".third_life").removeClass("normal_panel").removeClass("active_panel");
           }
            else
            {
                if(Channel!="Banca" && Channel != "UOB")//changed by Purva / Pramod C on 07th Aug 2017 for UOB
                {
                 document.getElementById("third_life_party_flag").style.display="block";
                }
                else
                {
                     document.getElementById("third_life_party_flag").style.display="block";
                }
            }
        }
        
        else if(document.getElementById("al_person_details.mlife.parent_consent_no").checked)
        {
            //if((((document.getElementById("al_person_details.mlife.anb").value >= 11) && (document.getElementById("al_person_details.mlife.anb").value <= 16)) && !isILproduct) || ((((mlifeILANB >= 11) && (mlifeILANB <= 16)) || ((mlifeILANB_monthly >= 11) && (mlifeILANB_monthly <= 16))) && isILproduct)) //Paromita on 05 July 2018
            if((((document.getElementById("al_person_details.mlife.anb").value >= 11) && (document.getElementById("al_person_details.mlife.anb").value <= 16))) || ((((mlifeILANB >= 11) && (mlifeILANB <= 16)) || ((mlifeILANB_monthly >= 11) && (mlifeILANB_monthly <= 16)))))
            {
               document.getElementById("al_sqs_details.sec_parti_flag_yes").checked = true;
               document.getElementById("al_sqs_details.sec_parti_flag_no").checked = false;
               document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = true;
                $(".collapseTwo").attr("id", "collapseTwo");
                $(".second_life").addClass("normal_panel");
                $(".second_life").removeClass("disabled_panel");
                
                if((Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)") || (replicate_res != "" && replicate_res != null && replicate_res != "null" && replicate_res != "(null)"))
                {
                    js_get_var("ylp_id_for_sqs", function(res_ylp)
                    {
                               console.log("---->7");
                          // fnMsPersonalPopulateValues("al_person_details.slife.first_name_dropdown","slife")                            //def1367
                           
                           if(res_ylp != "" && res_ylp != null && res_ylp != "null" && res_ylp != "(null)")
                           {
                               console.log("slife name for parent consent-->"+document.getElementById("al_person_details.slife.first_name_dropdown").value);
                               if(document.getElementById("al_person_details.slife.first_name_dropdown").value=="Select" || document.getElementById("al_person_details.slife.first_name_dropdown").value==""){
                           document.getElementById("al_person_details.slife.first_name_dropdown").disabled=false;// "True" changes as "False" changes made by pramod chavan for production defect 08032018
                               }else{
                               document.getElementById("al_person_details.slife.first_name_dropdown").disabled=true;
                               }
                           }else
                           {
                           document.getElementById("al_person_details.slife.first_name_dropdown").disabled=false;
                           }
                            document.getElementById("al_person_details.slife.relationship").disabled=false;
                            document.getElementById("al_person_details.slife.relationship").value="Parent";
                    });
                }
            }
            else
            {
                //if(Channel=="Agency")
                //{
                     document.getElementById("third_life_party_flag").style.display="block";
                //}
            }
            
           // if(((document.getElementById("al_person_details.mlife.anb").value >= 11 && document.getElementById("al_person_details.mlife.anb").value <= 16) && !isILproduct) || (((mlifeILANB >= 11 && mlifeILANB <= 16) || (mlifeILANB_monthly >= 11 && mlifeILANB_monthly <= 16)) && isILproduct)) //Paromita on 05 July 2018
            if(((document.getElementById("al_person_details.mlife.anb").value >= 11 && document.getElementById("al_person_details.mlife.anb").value <= 16)) || (((mlifeILANB >= 11 && mlifeILANB <= 16) || (mlifeILANB_monthly >= 11 && mlifeILANB_monthly <= 16))))
            {
                document.getElementById("third_life_party_flag").style.display="block";
            }
        }else
        {
//            if(Channel=="Banca")
//            {
                document.getElementById("third_life_party_flag").style.display="block";
           // }
            document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = false;
            document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = false;
        }
    if(document.getElementById("al_person_details.mlife.parent_consent_yes").checked)
    {
        console.log("Client_id parent consent :- "+Client_id);
        if((Client_id != "" && Client_id != null && Client_id != "null" && Client_id != "(null)") || (replicate_res != "" && replicate_res != null && replicate_res != "null" && replicate_res != "(null)"))
        {
            console.log("Client_id parent consent 1:- "+Client_id);
            document.getElementById("al_sqs_details.sec_parti_flag_no").checked = true;
            document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = true;
            document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = true;
            $("#al_sqs_details.sec_parti_flag_no").prop("disabled", true);
                        $("#al_sqs_details.sec_parti_flag_yes").prop("disabled", true);
            $(".collapseTwo").attr("id", "");
            $(".second_life").addClass("disabled_panel");
            $(".second_life").removeClass("normal_panel").removeClass("active_panel");
            
            //SetValuesnull();
        }
        else
        {
            document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = true;
            document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = true;
            
        }
    }
        if(callfrom=="change")
        {

                ClearData();
           
        }
    }

function getPVMQualification(agent_id)
{
    var querySelect = new DbUtil();
    
    querySelect.query()
    .select()
    .column('pvm_qualification')
    .column('invest_link_prod')
    .column('agent_channel')
    .column('appointment_date')
    .column('agent_sub_channel')//added by sourabh for new channel 31-jan-2017
    .column('product_certified')//added by sachin for PRUwith you product on 7-DEC-2017
    .column('rider_certified')//added by ankita for PRUwith you product on 2 July 2018
    .from()
    .table('al_agent_details')
    .where()
    .clause('agent_id','=',ds_agentId);//Pallavi added for device sharing
    return querySelect;
}

function CheckRelationStatus()
{
    console.log("al_person_details.slife.anb :- "+document.getElementById("al_person_details.slife.anb").value);
    console.log("al_person_details.slife.relationship :-"+document.getElementById("al_person_details.slife.relationship").value);
    var Mlanb = document.getElementById("al_person_details.mlife.anb").value;
    var Slanb = document.getElementById("al_person_details.slife.anb").value;
    
    var MlanbIL = document.getElementById("al_person_details.mlife.anb_il_product").value;
    var SlanbIL = document.getElementById("al_person_details.slife.anb_il_product").value;
    //code commented by Praveen for banca relationship change
    /**********************************@@@@@@@@@@commented for defect 5431*****************@@@@@@@@@@@@@@@@@/
   if(Channel == "Banca" || Channel == "UOB")//changed by Purva / Pramod C on 07th Aug 2017 for UOB
    {
        if ((Mlanb > 16 && Mlanb <= 30 && !isILproduct) || (MlanbIL > 16 && MlanbIL <= 30 && isILproduct))
        {
            if(Slanb!="" && Slanb!=null && SlanbIL!="" && SlanbIL!=null)
            {
                if ((((Slanb < 20 || Slanb > 40) && !isILproduct) || ((SlanbIL < 20 || SlanbIL > 40) && isILproduct)) && (document.getElementById("al_person_details.slife.relationship").value == "Spouse"))
                {
                    alert("219");
                    fnMsDisableDropdownChange("spouse");
                    document.getElementById("al_person_details.slife.anb").value = "";
                    document.getElementById("al_person_details.slife.dob").value = "";
                    return false;
                }
            }
        }
    }
    
    /******@@@@End@@@@@@@@@@@@@@@@@@@@@@@@@@/
    /*********FOLLOWING CODE COMMENTED BY SACHIN TUPE FOR REMOVE SPOUSE CONDITION FOR AGENCY CHANNEL ON DATE 30 JULY 2018.
   else{
           if((Slanb!="" && Slanb!=null) && (checkPRUwithyou!="PRUwith you" && checkPRUwithyou!="PRUcancer X"))//Added checkPRUwithyou varible by Sachin Tupe for defect 5589 on 21-06-2018.
           {// changed by aniket
               if (((Slanb < 20 && !isILproduct) || (SlanbIL < 20 && isILproduct)) && (document.getElementById("al_person_details.slife.relationship").value == "Spouse"))
               {
                   alert("392");
                   fnMsDisableDropdownChange("spouse");
                   document.getElementById("al_person_details.slife.anb").value = "";
                   document.getElementById("al_person_details.slife.dob").value = "";
                   return false;
               }
           }
       }//Commented by Paromita for defect 5431 on 3 July 2018
     **********/
    
    
        if(obj_slife["al_person_details.slife.relationship"] != undefined && obj_slife["al_person_details.slife.relationship"] != "undefined" && obj_slife["al_person_details.slife.relationship"] != "" && obj_slife["al_person_details.slife.relationship"] != "null" && obj_slife["al_person_details.slife.relationship"] != null )
        {
            if(document.getElementById("al_person_details.slife.relationship").value == "Spouse" || document.getElementById("al_person_details.mlife.parent_consent_yes").checked || MlanbIL>18)//added MlanbIL condition by ankita for production defect PRUW00190136//modified condition by ankita for PAMBNEWP-14733 on 27 march 2023 MlanbIL change from 16 to 18
            {
                console.log("3.in display none");
                console.log("al_person_details.slife.anb 4:- "+document.getElementById("al_person_details.slife.anb").value);
                console.log("al_person_details.slife.relationship 4:-"+document.getElementById("al_person_details.slife.relationship").value);
                document.getElementById("al_sqs_details.third_parti_flg_no").checked = true;
                document.getElementById("al_sqs_details.third_parti_flg_yes").checked = false;
                document.getElementById("third_life_party_flag").style.display="none";
                SetValuesnull();
                $(".collapseThree").attr("id", "");
                $(".third_life").addClass("disabled_panel");
                $(".third_life").removeClass("normal_panel").removeClass("active_panel");
            }
            else if(document.getElementById("al_person_details.slife.relationship").value == "" || document.getElementById("al_person_details.slife.relationship").value == "Select Relationship" || document.getElementById("al_person_details.slife.relationship").value == "select relationship" || document.getElementById("al_person_details.slife.relationship").value == "SELECT RELATIONSHIP")
            {
                console.log("4.in display none");
                console.log("al_person_details.slife.anb 55:- "+document.getElementById("al_person_details.slife.anb").value);
                console.log("al_person_details.slife.relationship 55:-"+document.getElementById("al_person_details.slife.relationship").value);
                document.getElementById("al_sqs_details.third_parti_flg_no").checked = true;
                document.getElementById("al_sqs_details.third_parti_flg_yes").checked = false;
                document.getElementById("third_life_party_flag").style.display="none";
                SetValuesnull();
                $(".collapseThree").attr("id", "");
                $(".third_life").addClass("disabled_panel");
                $(".third_life").removeClass("normal_panel").removeClass("active_panel");
            }
            else
            {
           //modified condition by ankita for PAMBNEWP-14733 on 27 march 2023
                                           if(document.getElementById("al_person_details.slife.relationship").value==="Parent")
                {
                document.getElementById("third_life_party_flag").style.display="block";
                }
                else
                {
                document.getElementById("al_sqs_details.third_parti_flg_no").checked = true;
                document.getElementById("al_sqs_details.third_parti_flg_yes").checked = false;
                document.getElementById("third_life_party_flag").style.display="none";
                SetValuesnull();
                $(".collapseThree").attr("id", "");
                $(".third_life").addClass("disabled_panel");
                $(".third_life").removeClass("normal_panel").removeClass("active_panel");
                }
            }
        }
        else if(document.getElementById("al_person_details.slife.relationship").value != undefined && document.getElementById("al_person_details.slife.relationship").value != "undefined" && document.getElementById("al_person_details.slife.relationship").value != "" && document.getElementById("al_person_details.slife.relationship").value != "null" && document.getElementById("al_person_details.slife.relationship").value != null )
        {
            if(document.getElementById("al_person_details.slife.relationship").value == "Spouse" || document.getElementById("al_person_details.mlife.parent_consent_yes").checked || MlanbIL>18)//added MlanbIL condition by ankita for production defect PRUW00190136//modified condition by ankita for PAMBNEWP-14733 on 27 march 2023 MlanbIL change from 16 to 18
            {
                console.log("5.in display none");
                console.log("al_person_details.slife.anb 56:- "+document.getElementById("al_person_details.slife.anb").value);
                console.log("al_person_details.slife.relationship 56:-"+document.getElementById("al_person_details.slife.relationship").value);
                document.getElementById("al_sqs_details.third_parti_flg_no").checked = true;
                document.getElementById("al_sqs_details.third_parti_flg_yes").checked = false;
                document.getElementById("third_life_party_flag").style.display="none";
                SetValuesnull();
                $(".collapseThree").attr("id", "");
                $(".third_life").addClass("disabled_panel");
                $(".third_life").removeClass("normal_panel").removeClass("active_panel");
            }
            else if(document.getElementById("al_person_details.slife.relationship").value == "" || document.getElementById("al_person_details.slife.relationship").value == "Select Relationship" || document.getElementById("al_person_details.slife.relationship").value == "select relationship" || document.getElementById("al_person_details.slife.relationship").value == "SELECT RELATIONSHIP")
            {
                console.log("6.in display none");
                console.log("al_person_details.slife.anb 57:- "+document.getElementById("al_person_details.slife.anb").value);
                console.log("al_person_details.slife.relationship 57:-"+document.getElementById("al_person_details.slife.relationship").value);
                document.getElementById("al_sqs_details.third_parti_flg_no").checked = true;
                document.getElementById("al_sqs_details.third_parti_flg_yes").checked = false;
                document.getElementById("third_life_party_flag").style.display="none";
                SetValuesnull();
                $(".collapseThree").attr("id", "");
                $(".third_life").addClass("disabled_panel");
                $(".third_life").removeClass("normal_panel").removeClass("active_panel");
            }
            else
            {
           //modified condition by ankita for PAMBNEWP-14733 on 27 march 2023
                                           if(document.getElementById("al_person_details.slife.relationship").value==="Parent")
                {
                document.getElementById("third_life_party_flag").style.display="block";
                }
                                           else
                                           {
                                           document.getElementById("al_sqs_details.third_parti_flg_no").checked = true;
                                           document.getElementById("al_sqs_details.third_parti_flg_yes").checked = false;
                                           document.getElementById("third_life_party_flag").style.display="none";
                                           SetValuesnull();
                                           $(".collapseThree").attr("id", "");
                                           $(".third_life").addClass("disabled_panel");
                                           $(".third_life").removeClass("normal_panel").removeClass("active_panel");
                                           }
                 //document.getElementById("third_life_party_flag").style.display="block";
            }
        }
/*******************************************@@@@@@@@@@@Following code commented for 5431@@@@@@@@@@@@@@@@@@@/
        if(obj_slife["al_person_details.slife.relationship"] != undefined && obj_slife["al_person_details.slife.relationship"] != "undefined" && obj_slife["al_person_details.slife.relationship"] != "" && obj_slife["al_person_details.slife.relationship"] != "null" && obj_slife["al_person_details.slife.relationship"] != null )
        {
            console.log("al_person_details.slife.anb 1:- "+document.getElementById("al_person_details.slife.anb").value);
            console.log("al_person_details.slife.relationship 1:-"+document.getElementById("al_person_details.slife.relationship").value);
            if ((((eval(document.getElementById("al_person_details.slife.anb").value) < 20 || eval(document.getElementById("al_person_details.slife.anb").value) > 40) && !isILproduct) || ((eval(document.getElementById("al_person_details.slife.anb_il_product").value) < 20 || eval(document.getElementById("al_person_details.slife.anb_il_product").value) > 40) && isILproduct)) && (document.getElementById("al_person_details.slife.relationship").value == "Spouse") && (Channel == "Banca" || Channel == "UOB"))//changed by Purva / Pramod C on 07th Aug 2017 for UOB
            {
                alert("219");
                fnMsDisableDropdownChange("spouse");
                document.getElementById("al_person_details.slife.anb").value = "";
                document.getElementById("al_person_details.slife.dob").value = "";
                //ClearData();
                return false;
            }
            else
            {
                ClearData();
            }

          /****@ FOLLOWING CODE COMMENTED FOR REMOVE SPOUSE VALIDATION FOR AGENCY CHANNEL BY SACHIN TUPE ON DATE 30 JULY 2018.
           
           else if((((eval(document.getElementById("al_person_details.slife.anb").value) < 20 && !isILproduct) || (eval(document.getElementById("al_person_details.slife.anb_il_product").value) < 20 && isILproduct))) && (document.getElementById("al_person_details.slife.relationship").value == "Spouse") && (checkPRUwithyou!="PRUwith you" && checkPRUwithyou!="PRUcancer X") && (Channel != "Banca" && Channel != "UOB"))//changed by Purva / Pramod C on 07th Aug 2017 for UOB, //Added checkPRUwithyou varible by Sachin Tupe for defect 5589 on 21-06-2018.
            {
                alert("392");
                fnMsDisableDropdownChange("spouse");
                document.getElementById("al_person_details.slife.anb").value = "";
                document.getElementById("al_person_details.slife.dob").value = "";
                //ClearData();
                return false;
            } //Commented by Paromita for defect 5431 on 3 July 2018
            
            //ClearData();
           *******/
        //}
      /******************  else
        {
            if(document.getElementById("al_person_details.slife.relationship").value != undefined && document.getElementById("al_person_details.slife.relationship").value != "undefined" && document.getElementById("al_person_details.slife.relationship").value != "" && document.getElementById("al_person_details.slife.relationship").value != "null" && document.getElementById("al_person_details.slife.relationship").value != null )
            {
                console.log("al_person_details.slife.anb 2:- "+document.getElementById("al_person_details.slife.anb").value);
                console.log("al_person_details.slife.relationship 2:-"+document.getElementById("al_person_details.slife.relationship").value);
                if(Channel == "Banca" || Channel == "UOB") //changed by Purva / Pramod C on 07th Aug 2017 for UOB
                {
                        if ((((eval(document.getElementById("al_person_details.slife.anb").value) < 20 || eval(document.getElementById("al_person_details.slife.anb").value) > 40) && !isILproduct) || ((eval(document.getElementById("al_person_details.slife.anb_il_product").value) < 20 || eval(document.getElementById("al_person_details.slife.anb_il_product").value) > 40) && isILproduct)) && (document.getElementById("al_person_details.slife.relationship").value == "Spouse"))
                        {
                            alert("219");
                            fnMsDisableDropdownChange("spouse");
                            document.getElementById("al_person_details.slife.anb").value = "";
                            document.getElementById("al_person_details.slife.dob").value = "";
                            //ClearData();
                            return false;
                        }
                }
            /*** COMMETED BY SACHIN ON 30 JULY 2018   else{
                    if(((eval(document.getElementById("al_person_details.slife.anb").value) < 20 && !isILproduct) || (eval(document.getElementById("al_person_details.slife.anb_il_product").value) < 20 && isILproduct)) && (document.getElementById("al_person_details.slife.relationship").value == "Spouse") && (checkPRUwithyou!="PRUwith you" && checkPRUwithyou!="PRUcancer X"))//Added checkPRUwithyou varible by Sachin Tupe for defect 5589 on 21-06-2018.
                    {
                        alert("392");
                        fnMsDisableDropdownChange("spouse");
                        document.getElementById("al_person_details.slife.anb").value = "";
                        document.getElementById("al_person_details.slife.dob").value = "";
                        //ClearData();
                        return false;
                    }
                } /***///Commented by Paromita for defect 5431 on 3 July 2018

           // }
        //}///////////
}
//function Added By Praveen on 1 Dec 2015
function fnMsSetProposerSeventeen()
{
    if((((document.getElementById("al_person_details.mlife.anb").value==17 || document.getElementById("al_person_details.mlife.anb").value==18)&& !isILproduct) || ((document.getElementById("al_person_details.mlife.anb_il_product").value==17 || document.getElementById("al_person_details.mlife.anb_il_product").value==18)&& !isILproduct)) && (Client_id!="" && Client_id!=null && Client_id!="null") && client_ylp_type_mlife=="lo")
    {
        console.log("---->08");
    fnMsPersonalPopulateValues('al_person_details.slife.first_name_dropdown','slife');
         document.getElementById("third_life_party_flag").style.display="block";
    }
}
function onchangeDeleteExistingQuotation(Client_id,person_type,changeflg)
{
    var genderChangeFlag="No"
    var persin_id="";
    var columnName="";
    if(person_type == "mlife")
    {
        if(document.getElementById("al_person_details.mlife.first_name_dropdown").style.display!="none")
        {
            persin_id= $("select[name='al_person_details.mlife.first_name_dropdown'] option:selected").index();
        }
        else
        {
            persin_id=mlife_person_id_fresh;
        }
    }else if(person_type == "slife")
    {
        if(document.getElementById("al_person_details.slife.first_name_dropdown").style.display!="none")
        {
            persin_id= $("select[name='al_person_details.slife.first_name_dropdown'] option:selected").index();
        }
        else
        {
            persin_id=slife_person_id_fresh;
        }
    } else if(person_type == "tlife")
    {
        if(document.getElementById("al_person_details.tlife.first_name_dropdown").style.display!="none")
        {
            persin_id= $("select[name='al_person_details.tlife.first_name_dropdown'] option:selected").index();
        }
        else
        {
            persin_id=tlife_person_id_fresh;
        }
    }
    if(typeof persin_id != "undefined" && persin_id != -1)
    {
        if(document.getElementById("al_person_details."+person_type+".first_name_dropdown").style.display!="none")
        {
            person_id_delete=person_id_ck[persin_id - 1];
        }
        else
        {
            person_id_delete=persin_id;
        }
    }
    if(person_type=="mlife")
    {
        columnName="mlife_person_id"
    }
    if(person_type=="slife")
    {
        columnName="slife_person_id"
    }
    if(person_type=="tlife")
    {
        columnName="tlife_person_id"
    }
    if(document.getElementById("al_person_details."+person_type+".first_name_dropdown").style.display!="none")
    {
        var mname=document.getElementById("al_person_details."+person_type+".first_name_dropdown").value;
    }
    else
    {
       var mname=document.getElementById("al_person_details."+person_type+".first_name").value;
    }
    var selectQuery=fnMsPopulateClientData(mname,Client_id,person_id_delete,ds_agentId);
    var selectQuerySQS=selectQuerySQSdata(Client_id,person_id_delete,columnName);
    selectQuery.execute(function(response)
    {
        if(response!="" && response!="{}")
        {
            
            var obj=JSON.parse(response);
                        console.log("promod obj "+JSON.stringify(obj));
            var occupation_del=obj[0]['occupation'];
// pramod chavan 29112016 old occupation & occupation class compare with new occupation & occupation class internal defect.
            var occupationClassDeletion=obj[0]['occupation_class'];
            var nob_del=obj[0]['nature_of_business'];
            var smoking_del=obj[0]['smoke_status'];
            var gender_del=obj[0]['gender'];
            var dob_del=obj[0]['dob'];
            console.log("occupation_del--->"+occupation_del+":::nob_del---->"+nob_del+"::::smoking_del--->"+smoking_del+"::::gender_del---->"+gender_del+"::::dob_del---->"+dob_del+"----->"+changeflg);
            if(changeflg=="gender")
            {
                if(!(gender_del=="M" && document.getElementById("al_person_details."+person_type+".gender_male").checked && !document.getElementById("al_person_details."+person_type+".gender_female").checked))
                    {
                    if(gender_del=="F" && document.getElementById("al_person_details."+person_type+".gender_female").checked)
                        {
                            js_set_var(person_type+"_gender_changed","No",function()
                                       {
                                       selectQuerySQS.execute(function(response)
                                          {
                                              if(response!="" && response!="{}")
                                              {
                                                  var obj=JSON.parse(response);
                                                  var rider_sqs_id=obj[0]['sqs_id'];
                                                  if(obj[0]['purchased']=="No" && obj[0]['is_deleted']=="No")
                                                  {
                                                        deleteAllSQSData(Client_id,person_id_delete,rider_sqs_id,person_type, changeflg);
                                                  }
                                              }
                                          });
                                       });
                        }
                        else
                        {
                        genderChangeFlag="Yes";
                        js_set_var(person_type+"_gender_changed",genderChangeFlag,function()
                            {
                             selectQuerySQS.execute(function(response)
                               {
                                   if(response!="" && response!="{}")
                                   {
                                        var obj=JSON.parse(response);
                                        var rider_sqs_id=obj[0]['sqs_id'];
                                        if(obj[0]['purchased']=="No" && obj[0]['is_deleted']=="No")
                                        {
                                            deleteAllSQSData(Client_id,person_id_delete,rider_sqs_id,person_type, changeflg);
                                        }
                                   }
                               });
                            });
                        }
                    }
                    else if(!(gender_del=="F" && document.getElementById("al_person_details."+person_type+".gender_female").checked && !document.getElementById("al_person_details."+person_type+".gender_male").checked))
                    {
                        if(gender_del=="M" && document.getElementById("al_person_details."+person_type+".gender_male").checked)
                        {
                        js_set_var(person_type+"_gender_changed","No",function()
                                   {
                                   selectQuerySQS.execute(function(response)
                                      {
                                          if(response!="" && response!="{}")
                                          {
                                              var obj=JSON.parse(response);
                                              var rider_sqs_id=obj[0]['sqs_id'];
                                              if(obj[0]['purchased']=="No" && obj[0]['is_deleted']=="No")
                                              {
                                                    deleteAllSQSData(Client_id,person_id_delete,rider_sqs_id,person_type, changeflg);
                                              }
                                          }
                                      });
                                   });
                        }
                        else
                        {
                            console.log("-f---123->in "+gender_del);
                            genderChangeFlag="Yes";
                            js_set_var(person_type+"_gender_changed",genderChangeFlag,function()
                                {
                                  selectQuerySQS.execute(function(response)
                                   {
                                       if(response!="" && response!="{}")
                                       {
                                          
                                             var obj=JSON.parse(response);
                                             var rider_sqs_id=obj[0]['sqs_id'];
                                             if(obj[0]['purchased']=="No" && obj[0]['is_deleted']=="No")
                                             {
                                                deleteAllSQSData(Client_id,person_id_delete,rider_sqs_id,person_type, changeflg);
                                             }

                                       }
                                   });
                                });
                            }
                    }
                }
                else if(changeflg=="smoker")
                {
                    if(!(smoking_del=="No" && document.getElementById("al_person_details."+person_type+".smoke_status_no").checked))
                    {
                           selectQuerySQS.execute(function(response)
                           {
                               if(response!="" && response!="{}")
                               {
                                      var obj=JSON.parse(response);
                                      var rider_sqs_id=obj[0]['sqs_id'];
                                      if(obj[0]['purchased']=="No" && obj[0]['is_deleted']=="No")
                                      {
                                        deleteAllSQSData(Client_id,person_id_delete,rider_sqs_id,person_type, changeflg);
                                      }
                                }
                           });

                    }
                    else if(!(smoking_del=="Yes" && document.getElementById("al_person_details."+person_type+".smoke_status_yes").checked))
                    {
                       selectQuerySQS.execute(function(response)
                       {
                           if(response!="" && response!="{}")
                           {
                                  var obj=JSON.parse(response);
                                  var rider_sqs_id=obj[0]['sqs_id'];
                                  if(obj[0]['purchased']=="No" && obj[0]['is_deleted']=="No")
                                  {
                                     deleteAllSQSData(Client_id,person_id_delete,rider_sqs_id,person_type, changeflg);
                                  }
                           }
                       });
                    }
                }
                else if(changeflg=="occupation")
                {
                        
                        occupation_del=occupation_del+"-"+occupationClassDeletion;
// pramod chavan 29112016 old occupation & occupation class compare with new occupation & occupation class internal defect.                        
                    if(occupation_del!=document.getElementById("al_employee_details."+person_type+".occupation").value)
                    {
                       selectQuerySQS.execute(function(response)
                       {
                           if(response!="" && response!="{}")
                           {
                              var obj=JSON.parse(response);
                              var rider_sqs_id=obj[0]['sqs_id'];
                              if(obj[0]['purchased']=="No" && obj[0]['is_deleted']=="No")
                              {
                                  deleteAllSQSData(Client_id,person_id_delete,rider_sqs_id,person_type, changeflg);
                              }
                           }
                       });
                    }
                }
                else if(changeflg=="nob")
                {
                    if(nob_del!=document.getElementById("al_employee_details."+person_type+".nature_of_business").value)
                    {
                       selectQuerySQS.execute(function(response)
                       {
                           if(response!="" && response!="{}")
                           {
                              var obj=JSON.parse(response);
                              var rider_sqs_id=obj[0]['sqs_id'];
                              if(obj[0]['purchased']=="No" && obj[0]['is_deleted']=="No")
                              {
                                  deleteAllSQSData(Client_id,person_id_delete,rider_sqs_id,person_type, changeflg);
                              }
                           }
                       });
                    }
                }
                else if(changeflg=="dob")
                {
                        console.log("poers--->"+person_type);
                    if(dob_del!=document.getElementById("al_person_details."+person_type+".dob").value)
                    {
                       selectQuerySQS.execute(function(response)
                       {
                           if(response!="" && response!="{}")
                           {
                              var obj=JSON.parse(response);
                              var rider_sqs_id=obj[0]['sqs_id'];
                              if(obj[0]['purchased']=="No" && obj[0]['is_deleted']=="No")
                              {
                                  deleteAllSQSData(Client_id,person_id_delete,rider_sqs_id,person_type, changeflg);
                              }
                                              }else{
                                              
                                              var updateCampCode=fnMsClientUpdateCampaignCodeBlank(person_id_delete);
                                              updateCampCode.execute(function(response)
                                                 {
                                                 
                                                 });
                                              
                                              }
                       });
                    }
                }
                else
                {
                   js_set_var(person_type+"_gender_changed","No",function()
                      {
                        
                      });
                }
                        
                        }
    });
}



/*******************************************************
 Function Name: fnMsClientUpdateCampaignCodeBlank()
 Function Description: Query to update the careerkit_person_details for blank campaign code.
 Parameters:
 Created By: Pramod Chavan
 Created On: 18 July 2017
 Modified By:
 Modified On:
 Modification Reason:
 *******************************************************/
function fnMsClientUpdateCampaignCodeBlank(RecvdPersonId)
{
    var queryUpdate = new DbUtil();
    queryUpdate.query()
    .update()
    .table('careerkit_person_details')
    .column('campaign_code').value("")
    .where()
    .clause('person_id','=',RecvdPersonId)
    .and()
    .clause('agent_id', '=', ds_agentId)//Added by Pallavi for device sharing;
    return queryUpdate;
}



function selectQuerySQSdata(Client_id,person_id_query,columnName)
{
        var querySelect = new DbUtil();
    
        querySelect.query()
        .select()
        .column('*')
        .from()
        .table('al_sqs_details')
        .where()
        .clause('client_id','=',Client_id)
        .and()
        .clause('mlife_person_id','=',person_id_query,"(","")
        .or()
        .clause('slife_person_id','=',person_id_query)
        .or()
        .clause('tlife_person_id','=',person_id_query,"",")")
        .and()
        .clause('is_deleted','=','No')
        .and()
        .clause('purchased','=','No')
        .and()
        .clause('agent_id','=',ds_agentId);//Added by Pallavi for device sharing
    
        return querySelect;
    
}
function deleteRiderData(sqs_id)
{
    var querySelect = new DbUtil();
    querySelect.query()
    .delete()
    .from()
    .table('al_rider_sqs')
    .where()
    .clause('sqs_id','=',sqs_id)
    .and()
    .clause('agent_id','=',ds_agentId);//Added by Pallavi for device sharing
    
    return querySelect;
}
function deleteSQSData(Client_id,person_id_query)
{
    var querySelect = new DbUtil();
    querySelect.query()
    .delete()
    .from()
    .table('al_sqs_details')
    .where()
    .clause('client_id','=',Client_id)
    .and()
    .clause('mlife_person_id','=',person_id_query,"(","")
    .or()
    .clause('slife_person_id','=',person_id_query)
    .or()
    .clause('tlife_person_id','=',person_id_query,"",")")
    .and()
    .clause('is_deleted','=','No')
    .and()
    .clause('purchased','=','No')
    .and()
    .clause('agent_id','=',ds_agentId);//Added by Pallavi for device sharing
    // .clause('purchased','=','No'); added by Pramod Chavan 06122016 for production defect.
    
    return querySelect;
}

function deleteAllSQSData(Client_id,person_id_del,sqs_id,person_type, changeflg)
{
    genderChangeFlag="No";
    var life_res="";
    var nobValue="";
    var occupationText="";
    var nobText="";
    canSwipe=0;
    if(person_type=="mlife")
    {
        life_res="main_life_response";
        occupationText=".occupationSearchMLifeText";
        nobText=".natureSearchMLifeText";
        nobValue=".natureSearchMLife";
    }
    else if(person_type=="slife")
    {
        life_res="sec_life_response";
        occupationText=".occupationSearchSLifeText";
        nobText=".natureSearchSLifeText";
        nobValue=".natureSearchSLife";
    }
    else if(person_type=="tlife")
    {
        life_res="third_life_response";
        occupationText=".occupationSearchTLifeText";
        nobText=".natureSearchTLifeText";
        nobValue=".natureSearchTLife";
    }
    bootbox.confirm("<h5>There is an existing quotation for this contact. Modifying the contact details will delete the quotation from the Record of Advice. Tap on OK to proceed.</h5>", function(result)
    {
        canSwipe=0;
        if(result==true)
        {
        var deleteRiderDataquery=deleteRiderData(sqs_id);
        var deleteSQSDataquery=deleteSQSData(Client_id,person_id_del);
        deleteSQSDataquery.execute(function()
           {
              deleteRiderDataquery.execute(function()
                {
                                    console.log("changeflg------>"+changeflg);
                                           if(changeflg=="dob"){
                                           var updateCampCode=fnMsClientUpdateCampaignCodeBlank(person_id_delete);
                                           updateCampCode.execute(function(response)
                                                                  {
                                                                 canSwipe=1;
                                                                  });
                                           
                                           
                                           }else{
                                           canSwipe=1;
                                           
                                           
                                           }
                                           
                                           
                                           
                    
                });
           });
        }
        else
        {
            js_get_var(life_res,function(responses_life)
               {
                    if(document.getElementById("al_person_details."+person_type+".first_name_dropdown").style.display!="none")
                    {
                        fnMsPersonalPopulateValues("al_person_details."+person_type+".first_name_dropdown",person_type);
                    }
                    else
                    {
                    if(responses_life!="" && responses_life!="null" && responses_life!="(null)" && responses_life!=null)
                       {
                       console.log("------>"+occupationText+"------>"+occupationText+"---->"+nobValue+"--->"+nobText);
                           var obj_life_res=JSON.parse(responses_life);
                           document.getElementById("al_person_details."+person_type+".first_name").value=obj_life_res["al_person_details."+person_type+".first_name"];
                           document.getElementById("al_person_details."+person_type+".dob").value=obj_life_res["al_person_details."+person_type+".dob"];
                           document.getElementById("al_person_details."+person_type+".anb").value=obj_life_res["al_person_details."+person_type+".anb"];
                           document.getElementById("al_employee_details."+person_type+".occupation").value = obj_life_res["al_employee_details."+person_type+".occupation"];
                           $(occupationText).val(obj_life_res["al_employee_details."+person_type+".occupation"]);
                       
                           document.getElementById("al_employee_details."+person_type+".occupation_class").value = obj_life_res["al_employee_details."+person_type+".occupation_class"];
                       
                           document.getElementById("al_employee_details."+person_type+".nature_of_business").value =getOccupationCodeAndNOB("", obj_life_res["al_employee_details."+person_type+".nature_of_business"],"nob") ;
                          // var nob_set_data = $(nobValue).find("option:selected").text();
                       // getOccupationCodeAndNOB this function convert nob code to nob value added by pramod chavan for DEF-1591 22092017
                       var nob_set_data = obj_life_res["al_employee_details."+person_type+".nature_of_business"];
                           $(nobText).val(getOccupationCodeAndNOB("", nob_set_data,"nob"));
                           if(obj_life_res["al_person_details."+person_type+".gender"]=="Male")
                           {
                                document.getElementById("al_person_details."+person_type+".gender_male").checked=true;
                           }
                           else
                           {
                                document.getElementById("al_person_details."+person_type+".gender_female").checked=true;
                           }
                           if(obj_life_res["al_person_details."+person_type+".smoke_status"]=="Non-Smoker")
                           {
                                document.getElementById("al_person_details."+person_type+".smoke_status_no").checked=true;
                           }
                           else
                           {
                                document.getElementById("al_person_details."+person_type+".smoke_status_yes").checked=true;
                           }
                       }
                    }
                     canSwipe=1;
               });
        }
    });

}
function getDetailsforDelete(persontype,changeflg)
{
    onchangeDeleteExistingQuotation(Client_id,persontype,changeflg);
}



/*******************************************************
 Function Name: fnMsCalculateANBforILproducts(persontype)
 Function Description:
 Parameters:
 Created By: Pramod Chavan
 Created On: 09 Dec 2017
 Modified By:
 Modified On:
 Modification Reason:
 *******************************************************/
function fnMsCalculateANBforILproducts(persontype, dobForIL) {
    try {
        //var dob='8/12/1998';
        var dob=$(escape_jq("al_person_details."+persontype+".dob")).val();
        if(dobForIL!=undefined && dobForIL!='undefined' && dobForIL!="" && dobForIL!='null' && dobForIL!=null)  //chaned by sayali.it was giving undefined in options
        {
            dob=dobForIL;
        }
        
        
        console.log("dob for IL ANB---->"+dob+"---------"+ persontype+"------"+dobForIL);
        var currentTime = new Date();
        if(sysdate!=""){
             currentTime = new Date(sysdate);
        }else{
             currentTime = new Date();
        }
        
        var incDay = parseInt(currentTime.getDate());
        var incMonth = parseInt(currentTime.getMonth()); //January is 0!
        var incYear = parseInt(currentTime.getFullYear());
        
        var mydd=dob.split("/");
        var dobDay=parseInt(mydd[0]);
        var dobMonth = parseInt(mydd[1]);
        var dobYear = parseInt(mydd[2]);
        dobMonth=dobMonth-1;
        
        var ANB=0;
        CreatedinceptiondateDate=incDay+"/"+dobMonth+"/"+dobYear;
        if(((incMonth*31)+incDay)==((dobMonth*31)+dobDay)){
            ANB  =incYear-dobYear;
        }else if(((incMonth*31)+incDay)>((dobMonth*31)+dobDay)){
            ANB  =(incYear-dobYear)+1;
        }else if(((incMonth*31)+incDay)<((dobMonth*31)+dobDay)){
            ANB  =incYear-dobYear;
        }
        
        $(escape_jq("al_person_details."+persontype+".anb_il_product")).val(ANB);
        $(escape_jq("al_person_details."+persontype+".anb")).val(ANB);//Added for product to IL Conversion
        $(escape_jq("al_person_details."+persontype+".anb_il_monthly_product")).val(ANB);//Added for product to IL Conversion
       
        console.log("IL ANB---->"+ANB);
    } catch (e) {
        console.log("Agent Check Error - - >" + e);
        return;
    }
}



/*******************************************************
 Function Name: fnMsCalculateANBforIL_monthlyproducts
 Function Description:il monthly product anb cal.
 Parameters:
 Created By: Sachin Tupe
 Created On:18-06-2018
 Reason for Addition :
 Modified By:
 Modified On:
 Modification Reason:
 **************************************************/


function fnMsCalculateANBforIL_monthlyproducts(persontype, dobForIL) {
    try {
        //var dob='8/12/1998';
        var dob=$(escape_jq("al_person_details."+persontype+".dob")).val();
        if(dobForIL!=undefined && dobForIL!='undefined' && dobForIL!="" && dobForIL!='null' && dobForIL!=null)
        {
            dob=dobForIL;
        }
        
        
        console.log("dob for IL ANB---->"+dob+"---------"+ persontype+"------"+dobForIL);
        var currentTime = new Date();
        if(sysdate!=""){
             currentTime = new Date(sysdate);
        }
        else{
             currentTime = new Date();
        }
        console.log("currentTime"+currentTime);
        var incDay = parseInt(currentTime.getDate());
      //  var incMonth = parseInt(currentTime.getMonth()); //January is 0! original code commented  for OS to IL product Conversion. by Sachin T. on date 24-06-2019
         var incMonth = parseInt(currentTime.getMonth())+1;
        var incYear = parseInt(currentTime.getFullYear());
        //
        
            if(incDay>=2)
            {
                incMonth = eval(incMonth)+1 ;
                incDay = 1 ;
            }
            else
            {
                incDay = 1 ;
            }
            
            
         /*   if(incDay<10)
            {
                incDay='0'+incDay ;
            }*/
           if(incMonth > 12)
            {
                incMonth= 1;
                incYear =incYear+1;
            }
          /*  if(incMonth<10)
            {
                incMonth='0'+incMonth;
            }
            */
        

        
        
        //////
        CreatedinceptiondateDate=incDay+"/"+incMonth+"/"+incYear;
        
        var mydd=dob.split("/");
        var dobDay=parseInt(mydd[0]);
        var dobMonth = parseInt(mydd[1]);
        var dobYear = parseInt(mydd[2]);
       // dobMonth=dobMonth-1;// commented for 8604
        
        var ANB=0;
        if(((incMonth*31)+incDay)==((dobMonth*31)+dobDay)){
            ANB  =incYear-dobYear;
        }else if(((incMonth*31)+incDay)>((dobMonth*31)+dobDay)){
            ANB  =(incYear-dobYear)+1;
        }else if(((incMonth*31)+incDay)<((dobMonth*31)+dobDay)){
            ANB  =incYear-dobYear;
        }
        
        $(escape_jq("al_person_details."+persontype+".anb_il_monthly_product")).val(ANB);
        $(escape_jq("al_person_details."+persontype+".anb_il_product")).val(ANB);//Added for IL Conversion on date 19-06-2019
        $(escape_jq("al_person_details."+persontype+".anb")).val(ANB);//Added for product to IL Conversion
        
        console.log("IL ANB monthly---->"+ANB);
    } catch (e) {
        console.log("Agent Check Error - - >" + e);
        return;
    }
}




/*******************************************************
 Function Name: inceptionRetrive
 Function Description:find il monthly product.
 Parameters:
 Created By: Sachin Tupe
 Created On:18-06-2018
 Reason for Addition :
 Modified By:
 Modified On:
 Modification Reason:
 **************************************************/


function inceptionRetrive()
{
    console.log("inceptionRetrive");
    var inception_load_Query = new DbUtil();
    inception_load_Query.query()
    .select()
    .column('*')
    .from()
    .table('inception_date')
    .where()
    .clause('inception_category','=','il_monthly');
    inception_load_Query.execute(function(retrival_data)
                                 {
                                    console.log("retrive ds"+retrival_data)
                                    if(retrival_data != "" && retrival_data != "{}")
                                    {
                                        console.log("retrival_data"+retrival_data);
                                        var obj_inception=JSON.parse(retrival_data);
                                    js_set_var("inception_load_data",JSON.stringify(obj_inception),function()
                                               {
                                                console.log("set retrival_data");
                                               
                                               });
                                 
                                 
                                 
                                    }
                                 else
                                 {
                                 
                                 js_set_var("inception_load_data","",function()
                                            {
                                            console.log("set retrival_data To null");
                                            
                                            });

                                 
                                 }
                                 
                                 
                                 });
    


}

/************Added function for retrive data of ease colun*****************/
function fnmsfindEaseCampaign(client_id,DSagent_id)
{

    var selectQuery = new DbUtil();
    selectQuery.query()
    .select()
    .column('*')
    .from()
    .table('careerkit_person_details')
    .where()
    .clause('client_id', '=', client_id)
    .and()
    /*   .clause('person_id', '=', person_id)
     .and()***/
    .clause('ylp_type', '=', 'you')
    .and()
    .clause('agent_id', '=', DSagent_id)
    .and()
    .clause('campaign_code', '<>', '')
    return selectQuery;
    


}

//added function  fnfetchFNPPriority by Sachin T..

function fnfetchFNPPriority(mck_client_id,ds_agentId,mck_ylp_id)
{
    console.log("Ylp_id"+mck_ylp_id);
    var querySelect = new DbUtil();
    querySelect.query()
    .select()
    .column('*')
    .from()
    .table('family_needs_risk_profile')
    .where()
    .clause('client_id','=',mck_client_id)
    .and()
    .clause('ylp_id','=',mck_ylp_id)
    .and()
    .clause('ylp_type','=',"you")
    .and()
    .clause('agent_id', '=', ds_agentId);
    
    return querySelect;
    
    
  
}



function fnProductRecommendationSoln()
{

    
    var selectQuery = new DbUtil();
    selectQuery.query()
    selectQuery.select()
    selectQuery.column('*')
    selectQuery.from()
    selectQuery.table('al_top_recommendation') //"needs" TEXT, "risk_profile" TEXT,
    selectQuery.where()
    selectQuery.clause('needs', '=', solnmyRiskProfileRanking);
    selectQuery.and()
    selectQuery.clause('risk_profile', '=', risk_profile_level)
    selectQuery.and()
    selectQuery.clause('product_channel','=',Channel);
    
    return selectQuery;
    



}
function fnMsdisableSlifeOnBusiProposeChange(){
  
   
//   var insurence_type = $(escape_jq(id)).val()
//   insurence_type_gb=$(escape_jq(id)).val();
//   if(insurence_type == "keyman" || insurence_type == "employee" || insurence_type == "partnership"){
   if(startFromCareerkit != true){
       if(document.getElementById("youAndspouseDetails").value !=""){
           console.log("value one")
           var tempStr = document.getElementById("youAndspouseDetails").value;
            console.log("value Piyush",tempStr)
           tempStr = tempStr.split("||");
           console.log("value Piyush1",tempStr,tempStr.indexOf("spouse"),tempStr.indexOf("lo"),tempStr[tempStr.indexOf("spouse")+1],tempStr[tempStr.indexOf("lo")+1])
           if(tempStr.indexOf("spouse") != -1){
              
               $(escape_jq("al_person_details.mlife.first_name_dropdown")+" option[value='"+tempStr[tempStr.indexOf("spouse")+1]+"']").remove();
           }
           if(tempStr.indexOf("lo") != -1){
               
               $(escape_jq("al_person_details.mlife.first_name_dropdown")+" option[value='"+tempStr[tempStr.indexOf("lo")+1]+"']").remove();
           }
       }
       $(".collapseTwo").attr("id", "");
       $(".collapseThree").attr("id", "");
       $(".second_life,.third_life").addClass("disabled_panel");
       document.getElementById("al_person_details.mlife.dob").value = "";
       $(".second_life,.third_life").removeClass("normal_panel").removeClass("active_panel");
       $(escape_jq("al_sqs_details.sec_parti_flag_yes")).prop('checked',false);
       $(escape_jq("al_sqs_details.sec_parti_flag_no")).prop('checked',true);
       $(escape_jq("al_person_details.mlife.gender_male")).attr('disabled',false);
       $(escape_jq("al_person_details.mlife.gender_female")).attr('disabled',false);
       $("input[name='third_life'][value='Yes']").prop('checked',false);
       $("input[name='third_life'][value='No']").prop('checked',true);
       $("input[name='second_life'][value='Yes']").attr("disabled", true)
       $("input[name='second_life'][value='No']").attr("disabled", true)
       $(escape_jq("al_person_details.pre_natal_child_flg")).attr("disabled", true)
       $(escape_jq("al_person_details.pre_natal_child_flg")).attr("checked", false)
       SetValuesnull();
       //validate_pre_natal();
       
//       if((insurence_type == "keyman" || insurence_type == "employee" ||insurence_type == "partnership")){
       //9400
          /* var arrOccupation = _.filter(ocArr,
                                function(occ){
                                return (occ!= "Child"&& occ!= "Housewife"&& occ!="Pensioner"&& occ!="Retiree"&& occ!="Student"&& occ!="Student Pilot"&& occ!="Unemployed");
                                });
           console.log("arrOccupation----"+arrOccupation)
           var occmlifechk=document.getElementById("al_employee_details.mlife.occupation").value;
           var nobmlifechk=document.getElementById("al_employee_details.mlife.nature_of_business").value;
           if(occmlifechk == "Child"&& occmlifechk == "Housewife"&& occmlifechk =="Pensioner"&& occmlifechk =="Retiree"&& occmlifechk =="Student"&& occmlifechk =="Student Pilot"&& occmlifechk =="Unemployed")
           {
               document.getElementById("al_employee_details.mlife.occupation").value="";
               document.getElementById("al_employee_details.mlife.nature_of_business").value="";
           }else if(occmlifechk!="select" && occmlifechk!="Select" && occmlifechk!="")
           {
               document.getElementById("al_employee_details.mlife.occupation").disabled=true;
           }
          
           
           if((nobmlifechk!="Select" && nobmlifechk!="select" && nobmlifechk!="" && nobmlifechk!= "Child"&& nobmlifechk!= "Housewife"&& nobmlifechk!="Pensioner"&& nobmlifechk!="Retiree"&& nobmlifechk!="Student"&& nobmlifechk!="Student Pilot"&& nobmlifechk!="Unemployed"))
           {
               document.getElementById("al_employee_details.mlife.nature_of_business").disabled=true;
           }
       
           seachableDropDownMLifeOccupation(arrOccupation,insurence_type);*/
//       }
       
//   }else{
//        console.log("partnership==non=="+ocArr)
//        seachableDropDownMLifeOccupation(ocArr);
//       $(escape_jq("al_person_details.pre_natal_child_flg")).attr('disabled',false);
//   }
}
}

function fnMsdisableSlife(id){
   
    
    var insurence_type = $(escape_jq(id)).val()
    insurence_type_gb=$(escape_jq(id)).val();
    if(insurence_type == "keyman" || insurence_type == "employee" || insurence_type == "partnership" || insurence_type == "Business Loan Insurance (for Company/LLP)" || insurence_type == "Business Loan Insurance (for Sole Proprietorship/Partnership)"){
        if(document.getElementById("youAndspouseDetails").value !=""){
            console.log("value one")
            var tempStr = document.getElementById("youAndspouseDetails").value;
             console.log("value Piyush",tempStr)
            tempStr = tempStr.split("||");
            console.log("value Piyush1",tempStr,tempStr.indexOf("spouse"),tempStr.indexOf("lo"),tempStr[tempStr.indexOf("spouse")+1],tempStr[tempStr.indexOf("lo")+1])
            if(tempStr.indexOf("spouse") != -1){
               
                $(escape_jq("al_person_details.mlife.first_name_dropdown")+" option[value='"+tempStr[tempStr.indexOf("spouse")+1]+"']").remove();
            }
            if(tempStr.indexOf("lo") != -1){
                
                $(escape_jq("al_person_details.mlife.first_name_dropdown")+" option[value='"+tempStr[tempStr.indexOf("lo")+1]+"']").remove();
            }
        }
        $(".collapseTwo").attr("id", "");
        $(".collapseThree").attr("id", "");
        $(".second_life,.third_life").addClass("disabled_panel");
        document.getElementById("al_person_details.mlife.dob").value = "";
        $(".second_life,.third_life").removeClass("normal_panel").removeClass("active_panel");
        $(escape_jq("al_sqs_details.sec_parti_flag_yes")).prop('checked',false);
        $(escape_jq("al_sqs_details.sec_parti_flag_no")).prop('checked',true);
        $("input[name='third_life'][value='Yes']").prop('checked',false);
        $("input[name='third_life'][value='No']").prop('checked',true);
        $("input[name='second_life'][value='Yes']").attr("disabled", true)
        $("input[name='second_life'][value='No']").attr("disabled", true)
        $(escape_jq("al_person_details.pre_natal_child_flg")).attr("disabled", true)
        $(escape_jq("al_person_details.pre_natal_child_flg")).attr("checked", false)
        SetValuesnull();
        //validate_pre_natal();
        
        if((insurence_type == "keyman" || insurence_type == "employee" ||insurence_type == "partnership" || insurence_type == "Business Loan Insurance (for Company/LLP)" || insurence_type == "Business Loan Insurance (for Sole Proprietorship/Partnership)")){
            var arrOccupation = _.filter(ocArr,
                                 function(occ){
                                 return (occ!= "Child"&& occ!= "Housewife"&& occ!="Pensioner"&& occ!="Retiree"&& occ!="Student"&& occ!="Student Pilot"&& occ!="Unemployed");
                                 });
            console.log("arrOccupation----"+arrOccupation)
            var occmlifechk=document.getElementById("al_employee_details.mlife.occupation").value;
            var nobmlifechk=document.getElementById("al_employee_details.mlife.nature_of_business").value;
            if(occmlifechk == "Child"&& occmlifechk == "Housewife"&& occmlifechk =="Pensioner"&& occmlifechk =="Retiree"&& occmlifechk =="Student"&& occmlifechk =="Student Pilot"&& occmlifechk =="Unemployed")
            {
                document.getElementById("al_employee_details.mlife.occupation").value="";
                document.getElementById("al_employee_details.mlife.nature_of_business").value="";
            }else if(occmlifechk!="select" && occmlifechk!="Select" && occmlifechk!="")
            {
                document.getElementById("al_employee_details.mlife.occupation").disabled=true;
            }
           
            
            if((nobmlifechk!="Select" && nobmlifechk!="select" && nobmlifechk!="" && nobmlifechk!= "Child"&& nobmlifechk!= "Housewife"&& nobmlifechk!="Pensioner"&& nobmlifechk!="Retiree"&& nobmlifechk!="Student"&& nobmlifechk!="Student Pilot"&& nobmlifechk!="Unemployed"))
            {
                document.getElementById("al_employee_details.mlife.nature_of_business").disabled=true;
            }
        
            seachableDropDownMLifeOccupation(arrOccupation,insurence_type);
        }
        
    }else{
         console.log("partnership==non=="+ocArr)
         seachableDropDownMLifeOccupation(ocArr);
        $(escape_jq("al_person_details.pre_natal_child_flg")).attr('disabled',false);
    }
}


function fngetBasicMsqgPlan() {
    
    
    console.log("fnMSGetMedicalRider---")
    var loadQuery = new DbUtil();
    loadQuery.query()
    .select()
    .column('*')
    .from()
    .table('al_msqg_rider')
    .where()
    .clause('medical_plan','=',"basic_plan")
    
    return loadQuery;
    
    
    
}


/**********Added Function for change ANB on change life change and backdate operation*************/
function fnLifeChangesAnb(anbtype){
    
    if(ANB_json[0]["anb_type"]=="IL_Daily")
    {
      fnMsCalculateANBforILproducts(anbtype);
    }else if(ANB_json[0]["anb_type"]=="IL_Monthly"){
        
         fnMsCalculateANBforIL_monthlyproducts(anbtype)
        
    }
}


function checkNameDDDisplayNoneOrNot(){
if(fromMySolution != true && SQS_From_AL !== "Yes"){
   console.log("inside checkNameDDDisplayNoneOrNot()")
   $(escape_jq("al_person_details.mlife.insu_type")+" option[value='individual']").remove();
   if(arrConfigData['0']["partnership"]!="Yes" && arrConfigData['0']["keyman"]!="Yes" && arrConfigData['0']["employee"]!="Yes" && arrConfigData['0']["businessloan_partnership"]!="Yes" && arrConfigData['0']["businessloan_company"]!="Yes"){
           $(escape_jq("al_person_details.mlife.insu_type")).addClass("mandatory");
           $(escape_jq("al_person_details.mlife.insu_type")).removeClass("selectMandatory");
             $(escape_jq("al_person_details.mlife.insu_type")).addClass("mandatory");
       }
   if(document.getElementById("al_person_details.mlife.first_name_dropdown").style.display!="none" && document.getElementById("al_person_details.mlife.first_name_dropdown").value =="Select"){
           $(escape_jq("al_person_details.mlife.insu_type")).attr("disabled","true");
           $(escape_jq("al_person_details.mlife.insu_type_header")).attr("disabled","true");
           $(escape_jq("al_employee_details.mlife.nature_of_business")).attr("disabled","true");
           $(escape_jq("al_employee_details.mlife.occupation")).attr("disabled","true");
           $(escape_jq("al_person_details.mlife.expected_delivery_dt")).attr("disabled","true");
           $(escape_jq("al_person_details.mlife.dob")).removeClass("mandatory");
           $(escape_jq("al_person_details.mlife.gender_male")).attr("disabled","true");
           $(escape_jq("al_person_details.mlife.gender_female")).attr("disabled","true");
           $(escape_jq("al_person_details.pre_natal_child_flg")).attr("disabled","true");
           $(escape_jq("al_person_details.mlife.smoke_status_yes")).attr("disabled","true");
           $(escape_jq("al_person_details.mlife.smoke_status_no")).attr("disabled","true");
           $(escape_jq("al_sqs_details.sec_parti_flag_yes")).attr("disabled","true");
           $(escape_jq("al_sqs_details.sec_parti_flag_no")).attr("disabled","true");
           $(escape_jq("al_person_details.mlife.expected_delivery_dt")).attr("disabled","true");
            //$(".mlifeAgeCelender").off("click");
       }
        if(document.getElementById("al_person_details.mlife.first_name_dropdown").style.display =="none"){
           $(escape_jq("al_person_details.mlife.first_name")).attr("disabled","true");
           $(escape_jq("al_employee_details.mlife.nature_of_business")).attr("disabled","true");
           $(escape_jq("al_employee_details.mlife.occupation")).attr("disabled","true");
           $(escape_jq("al_person_details.mlife.expected_delivery_dt")).attr("disabled","true");
           $(escape_jq("al_person_details.mlife.gender_male")).attr("disabled","true");
           $(escape_jq("al_person_details.mlife.dob")).removeClass("mandatory");
           $(escape_jq("al_person_details.mlife.gender_female")).attr("disabled","true");
           $(escape_jq("al_person_details.pre_natal_child_flg")).attr("disabled","true");
           $(escape_jq("al_person_details.mlife.smoke_status_yes")).attr("disabled","true");
           $(escape_jq("al_person_details.mlife.smoke_status_no")).attr("disabled","true");
           $(escape_jq("al_sqs_details.sec_parti_flag_yes")).attr("disabled","true");
           $(escape_jq("al_sqs_details.sec_parti_flag_no")).attr("disabled","true");
           $(escape_jq("al_person_details.mlife.insu_type")).attr("disabled",false);
           $(escape_jq("al_person_details.mlife.insu_type_header")).attr("disabled",false);
           $(escape_jq("al_person_details.mlife.expected_delivery_dt")).attr("disabled","true");
                                          // $(".mlifeAgeCelender").off("click");
                                           
        }
       }
       if(SQS_From_AL == "Yes"){
        $(escape_jq("al_person_details.mlife.insu_type_header")).attr("disabled",false);
       }
                                           
   if(fromMySolution == true && document.getElementById("al_person_details.mlife.first_name_dropdown").style.display =="none"){
       if($(escape_jq("al_person_details.pre_natal_child_flg")). prop("checked") !== true){
        $(escape_jq("al_person_details.mlife.gender_male")).attr("disabled",false);
        $(escape_jq("al_person_details.mlife.gender_female")).attr("disabled",false);
       }
       
   }
}

function enableIfChagned(){
   $(escape_jq("al_person_details.mlife.insu_type")+" option[value='individual']").remove();
   console.log("inside enableIfChagned()",(document.getElementById("al_person_details.mlife.first_name_dropdown").style.display !="none" && document.getElementById("al_person_details.mlife.first_name_dropdown").value =="Select"))
   if(document.getElementById("al_person_details.mlife.first_name_dropdown").style.display !="none" && document.getElementById("al_person_details.mlife.first_name_dropdown").value =="Select"){
           $(escape_jq("al_person_details.mlife.insu_type")).attr("disabled","true");
           $(escape_jq("al_person_details.mlife.insu_type_header")).attr("disabled","true");
           $(escape_jq("al_employee_details.mlife.nature_of_business")).attr("disabled","true");
           $(escape_jq("al_employee_details.mlife.occupation")).attr("disabled","true");
           $(escape_jq("al_person_details.mlife.expected_delivery_dt")).attr("disabled","true");
           $(escape_jq("al_person_details.mlife.gender_male")).attr("disabled","true");
           $(escape_jq("al_person_details.mlife.dob")).removeClass("mandatory");
           $(escape_jq("al_person_details.mlife.gender_female")).attr("disabled","true");
           $(escape_jq("al_person_details.pre_natal_child_flg")).attr("disabled","true");
           $(escape_jq("al_person_details.mlife.smoke_status_yes")).attr("disabled","true");
           $(escape_jq("al_person_details.mlife.smoke_status_no")).attr("disabled","true");
           $(escape_jq("al_sqs_details.sec_parti_flag_yes")).attr("disabled","true");
           $(escape_jq("al_sqs_details.sec_parti_flag_no")).attr("disabled","true");
          // $(".mlifeAgeCelender").off("click");
       }else if(fromMySolution == true && document.getElementById("al_person_details.mlife.first_name_dropdown").style.display =="none"){
           if(($(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Keyman Insurance" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Employer Employee Insurance" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Partnership Insurance" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Business Loan Insurance (for Sole Proprietorship/Partnership)" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Business Loan Insurance (for Company/LLP)")){
               $(escape_jq("al_person_details.mlife.insu_type")).attr("disabled",false);
           }
           if(!($(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Keyman Insurance" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Employer Employee Insurance" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Partnership Insurance" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Business Loan Insurance (for Sole Proprietorship/Partnership)" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Business Loan Insurance (for Company/LLP)")){
                   $(escape_jq("al_sqs_details.sec_parti_flag_yes")).attr("disabled",false);
                   $(escape_jq("al_sqs_details.sec_parti_flag_no")).attr("disabled",false);
                   $(escape_jq("al_person_details.pre_natal_child_flg")).attr("disabled",false);
           }
           $(escape_jq("al_person_details.mlife.insu_type_header")).attr("disabled",false);
           $(escape_jq("al_person_details.mlife.first_name")).attr("disabled",false);
           $(escape_jq("al_employee_details.mlife.nature_of_business")).attr("disabled",false);
           $(escape_jq("al_employee_details.mlife.occupation")).attr("disabled",false);
           $(escape_jq("al_person_details.mlife.expected_delivery_dt")).attr("disabled",false);
           $(escape_jq("al_person_details.mlife.dob")).addClass("mandatory");
           if($(escape_jq("al_person_details.pre_natal_child_flg")). prop("checked") !== true){
            $(escape_jq("al_employee_details.mlife.nature_of_business")).attr("disabled",false);
            $(escape_jq("al_employee_details.mlife.occupation")).attr("disabled",false);
            $(escape_jq("al_person_details.mlife.gender_male")).attr("disabled",false);
            $(escape_jq("al_person_details.mlife.gender_female")).attr("disabled",false);
           }
           
           $(escape_jq("al_person_details.mlife.smoke_status_yes")).attr("disabled",false);
           $(escape_jq("al_person_details.mlife.smoke_status_no")).attr("disabled",false);
           
           $(escape_jq("al_person_details.mlife.expected_delivery_dt")).attr("disabled",false);
       }
       else{
           if(!($(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Keyman Insurance" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Employer Employee Insurance" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Partnership Insurance" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Business Loan Insurance (for Sole Proprietorship/Partnership)" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Business Loan Insurance (for Company/LLP)")){
                if(startFromCareerkit == true){
                 $(escape_jq("al_person_details.mlife.insu_type")).attr("disabled",false);
                 $(escape_jq("al_person_details.mlife.insu_type_header")).attr("disabled",false);
                }
                
               if($(escape_jq("al_person_details.pre_natal_child_flg")). prop("checked") !== true){
                $(escape_jq("al_employee_details.mlife.nature_of_business")).attr("disabled",false);
                $(escape_jq("al_employee_details.mlife.occupation")).attr("disabled",false);
                $(escape_jq("al_person_details.mlife.gender_male")).attr("disabled",false);
                $(escape_jq("al_person_details.mlife.gender_female")).attr("disabled",false);
               }
                $(escape_jq("al_person_details.mlife.expected_delivery_dt")).attr("disabled",false);
                $(escape_jq("al_person_details.mlife.dob")).addClass("mandatory");
                $(escape_jq("al_person_details.pre_natal_child_flg")).attr("disabled",false);
                $(escape_jq("al_person_details.mlife.smoke_status_yes")).attr("disabled",false);
                $(escape_jq("al_person_details.mlife.smoke_status_no")).attr("disabled",false);
                $(escape_jq("al_sqs_details.sec_parti_flag_yes")).attr("disabled",false);
                $(escape_jq("al_sqs_details.sec_parti_flag_no")).attr("disabled",false);
               }
           
           //$(".mlifeAgeCelender").on("click");
       }
       console.log("prenital",$(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html());
       if($(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Keyman Insurance" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Employer Employee Insurance" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Partnership Insurance" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Business Loan Insurance (for Sole Proprietorship/Partnership)" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Business Loan Insurance (for Company/LLP)"){
               $(escape_jq("al_person_details.pre_natal_child_flg")).attr("disabled","true");
       }
       if($(escape_jq("al_person_details.mlife.insu_type_header")+" option:selected").html() == "Non-business Purpose"){
             $(escape_jq("al_person_details.mlife.insu_type")).val("select");
               $(escape_jq("al_person_details.mlife.insu_type")).addClass("colorGray")
               $(escape_jq("al_person_details.mlife.insu_type")).removeClass("mandatory");
       }else{
        $(escape_jq("al_person_details.mlife.insu_type")).removeClass("colorGray");
       $(escape_jq("al_person_details.mlife.insu_type")).addClass("mandatory");
       
        
       }
                                           console.log("relationship_mlife:"+relationship_mlife+"--client_ylp_type_mlife:"+client_ylp_type_mlife);
                                           //added by ankita on 18 may 2022 for defect 321 changes by Lai Har
                                           if(relationship_mlife!=="" && client_ylp_type_mlife==="lo" && document.getElementById("al_person_details.mlife.first_name_dropdown").value!=="Select" && relationship_mlife!="C")
                                           {
                                           console.log("Inside mandatory");
                                           if(parseInt(document.getElementById("al_person_details.mlife.anb_il_product").value)===17 || parseInt(document.getElementById("al_person_details.mlife.anb_il_product").value)===18)
                                           {
                                           document.getElementById("al_person_details.slife.first_name_dropdown").disabled=false;
                                           
                                           }
                                           document.getElementById("al_sqs_details.sec_parti_flag_no").disabled = true;
                                           document.getElementById("al_sqs_details.sec_parti_flag_yes").disabled = true;
                                           document.getElementById("al_sqs_details.sec_parti_flag_yes").checked = true;
                                           $(".collapseTwo").attr("id", "collapseTwo");
                                           $(".second_life").addClass("normal_panel");
                                           $(".second_life").removeClass("disabled_panel");
                                           
                                           }
                                           //added by ankita on 1 dec 2022 for production defect PRUW00190136
                                           //modified condition by ankita for PAMBNEWP-14733 on 27 march 2023
                                           if(client_ylp_type_tlife!=="")
                                           {
                                           console.log("Ankita client_ylp_type_tlife");
                                              //document.getElementById("third_life_party_flag").style.display="block";
                                           
                                           }
                                           else
                                           {
                                           
                                           if(!document.getElementById("al_person_details.pre_natal_child_flg").checked && relationship_mlife!=="C" && relationship_mlife!="")//added relationship_mlife!="" by ankita on 9 dec 2022 for internal issue of hiding third life if we clicked on yes button
                                           {
                                           document.getElementById("third_life_party_flag").style.display="none";
                                           }
                                           }
                                          //modified condition by ankita for PAMBNEWP-14733 on 27 march 2023 change from 16 to 18
                                           if(parseInt(document.getElementById("al_person_details.mlife.anb_il_product").value)>18)
                                           {
                                           console.log("Inside null");
                                           document.getElementById("third_life_party_flag").style.display="none";
                                           
                                           }
                                           //END HERE
                              
}


function enableIfChagneBusiPropose(){
   if(arrConfigData['0']["partnership"]!="Yes" && arrConfigData['0']["keyman"]!="Yes" && arrConfigData['0']["employee"]!="Yes" && arrConfigData['0']["businessloan_partnership"]!="Yes" && arrConfigData['0']["businessloan_company"]!="Yes" && $(escape_jq("al_person_details.mlife.insu_type_header")+" option:selected").html() == "Business Purpose" ){
       clearTimeout(clrTimeout);
       canSwipe = 0;
       bootbox.alert({
             className: "aletIDF",
           message: "<h5><div>For a life insurance purchased for business purpose, the law requires Service Tax to be imposed on the premium payable.</div><br/><div>Please proceed business proposal with manual submission.</div></h5>",
           buttons: {
             ok: {
               label: 'Close'
             }
           },
           callback: function (){
           canSwipe=1;
           $(escape_jq("al_person_details.mlife.insu_type_header")).val("select");
           $(escape_jq("al_person_details.mlife.insu_type_header")).removeClass("selectMandatory");
             $(escape_jq("al_person_details.mlife.insu_type_header")).addClass("mandatory");
             enableIfChagneBusiProposeNew()
         }
       });
   }
   else if($(escape_jq("al_person_details.mlife.insu_type_header")+" option:selected").html() == "Business Purpose" && $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() != "Insurance Type"){
   clearTimeout(clrTimeout);
   canSwipe = 0;
   bootbox.alert({
                 className: "aletIDF",
       message: "<h5>For a life insurance purchased for business purpose, the law requires Service Tax to be imposed on the premium payable.</h5>",
       buttons: {
         ok: {
           label: 'Close'
         }
       },
       callback: function (){
       canSwipe=1;
       enableIfChagneBusiProposeNew()
     }
   });
   }else{
       enableIfChagneBusiProposeNew()
   }

}

function enableIfChagneBusiProposeNew(){
   if(document.getElementById("al_person_details.mlife.first_name_dropdown").style.display !="none" && $(escape_jq("al_person_details.mlife.insu_type_header")+" option:selected").html() == "Non-business Purpose"){
           $(escape_jq("al_person_details.mlife.insu_type")).attr("disabled",true);
   }
   else if(document.getElementById("al_person_details.mlife.first_name_dropdown").style.display !="none" && $(escape_jq("al_person_details.mlife.insu_type_header")+" option:selected").html() != "Proposal Purpose"){
           $(escape_jq("al_person_details.mlife.insu_type")).attr("disabled",false);
   }
   else if(document.getElementById("al_person_details.mlife.first_name_dropdown").style.display =="none" && ($(escape_jq("al_person_details.mlife.insu_type_header")+" option:selected").html() == "Proposal Purpose" || ($(escape_jq("al_person_details.mlife.insu_type_header")+" option:selected").html() != "Non-business Purpose" && $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Insurance Type"))){
       if($(escape_jq("al_person_details.mlife.insu_type_header")+" option:selected").html() != "Non-business Purpose"){
           $(escape_jq("al_person_details.mlife.insu_type")).attr("disabled",false);
       }
      $(escape_jq("al_person_details.mlife.first_name")).attr("disabled","true");
      $(escape_jq("al_person_details.mlife.first_name")).val("");
      $(escape_jq("al_person_details.mlife.dob")).removeClass("mandatory");
      $(escape_jq("al_employee_details.mlife.occupation_class")).val("");
      $(escape_jq("al_employee_details.mlife.nature_of_business")).attr("disabled","true");
      $(escape_jq("al_employee_details.mlife.nature_of_business")).val("");
      $(escape_jq("al_employee_details.mlife.occupation")).attr("disabled","true");
      $("#gestational_week").hide();
      $(escape_jq("al_employee_details.mlife.occupation")).val("");
      $(escape_jq("al_person_details.mlife.expected_delivery_dt")).attr("disabled","true");
      $(escape_jq("al_person_details.mlife.gender_male")).attr("disabled","true");
      $(escape_jq("al_person_details.mlife.gender_female")).attr("disabled","true");
      $(escape_jq("al_person_details.pre_natal_child_flg")).attr("disabled","true");
      $(escape_jq("al_person_details.mlife.smoke_status_yes")).attr("disabled","true");
      $(escape_jq("al_person_details.mlife.smoke_status_no")).attr("disabled","true");
      $(escape_jq("al_sqs_details.sec_parti_flag_yes")).attr("disabled","true");
      $(escape_jq("al_sqs_details.sec_parti_flag_no")).attr("disabled","true");
      $(escape_jq("al_person_details.mlife.expected_delivery_dt")).attr("disabled","true");
                                     // $(".mlifeAgeCelender").off("click");
                                      
   }else if(document.getElementById("al_person_details.mlife.first_name_dropdown").style.display =="none" && (($(escape_jq("al_person_details.mlife.insu_type_header")+" option:selected").html() != "Proposal Purpose" && $(escape_jq("al_person_details.mlife.insu_type_header")+" option:selected").html() != "Insurance Type") || ($(escape_jq("al_person_details.mlife.insu_type_header")+" option:selected").html() == "Non-business Purpose"))){
        if($(escape_jq("al_person_details.mlife.insu_type_header")+" option:selected").html() == "Non-business Purpose"){
            $(escape_jq("al_person_details.mlife.insu_type")).attr("disabled","true");
            $(escape_jq("al_person_details.mlife.insu_type")).val("select");
        }
      $(escape_jq("al_person_details.mlife.first_name")).attr("disabled",false);
      $(escape_jq("al_employee_details.mlife.nature_of_business")).attr("disabled",false);
      $(escape_jq("al_employee_details.mlife.occupation")).attr("disabled",false);
      $(escape_jq("al_person_details.mlife.expected_delivery_dt")).attr("disabled",false);
      $(escape_jq("al_person_details.mlife.dob")).addClass("mandatory");
       if($(escape_jq("al_person_details.pre_natal_child_flg")). prop("checked") !== true){
        $(escape_jq("al_person_details.mlife.gender_male")).attr("disabled",false);
        $(escape_jq("al_person_details.mlife.gender_female")).attr("disabled",false);
       }
      $(escape_jq("al_person_details.pre_natal_child_flg")).attr("disabled",false);
      $(escape_jq("al_person_details.mlife.smoke_status_yes")).attr("disabled",false);
      $(escape_jq("al_person_details.mlife.smoke_status_no")).attr("disabled",false);
      $(escape_jq("al_sqs_details.sec_parti_flag_yes")).attr("disabled",false);
      $(escape_jq("al_sqs_details.sec_parti_flag_no")).attr("disabled",false);
      $(escape_jq("al_person_details.mlife.expected_delivery_dt")).attr("disabled",false);
                                     // $(".mlifeAgeCelender").off("click");
                                      
   }
   if($(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Keyman Insurance" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Employer Employee Insurance" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Partnership Insurance" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Business Loan Insurance (for Sole Proprietorship/Partnership)" || $(escape_jq("al_person_details.mlife.insu_type")+" option:selected").html() == "Business Loan Insurance (for Company/LLP)"){
           $(escape_jq("al_person_details.pre_natal_child_flg")).attr("disabled",true);
   }
   if($(escape_jq("al_person_details.mlife.insu_type_header")+" option:selected").html() == "Non-business Purpose"){
         $(escape_jq("al_person_details.mlife.insu_type")).val("select");
           $(escape_jq("al_person_details.mlife.insu_type")).addClass("colorGray")
           $(escape_jq("al_person_details.mlife.insu_type")).removeClass("mandatory");
   }else{
    $(escape_jq("al_person_details.mlife.insu_type")).removeClass("colorGray");
   $(escape_jq("al_person_details.mlife.insu_type")).addClass("mandatory");
   
    
   }
}


                                           function fnMscheckYlpData(ylpid,agentid){
                                           
                                           }
                                          

                                           
                                           

