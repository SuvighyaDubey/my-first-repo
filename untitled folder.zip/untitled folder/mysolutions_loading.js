var obj_mlife={};
var obj_slife={};
var obj_prochoice={};
var exp_age;
var mlife_anb;
var basic_term;
var loading_flag_noupdate="1";
var loading_flag_update="0";
var obj_solution="";
var obj_solutions_loading={};
var disability_care_term; // Added by Shivani for DEF - 10775
//$(document).ready(function () {
//    fnMsLoadingonload();
//});

/*start
Common header to add comment if added new product condition and also specify that product is similar to which product

condition for product name PRUSignature Vanguard added by ankita and is similar to PRUWealth plus and PRUSignature Assure product for july release.
condition for product name PRUSignature Ace added by ankita and is similar to PRUSignature Invest product on 13 sept 2022 for october release.
 condition for PRUEnhanced Cover similar to PRUmillion Cover 2.0 added by Pradnya for Aug 2023 release
 *Pradnya: added condition for PRULady_PRL for jan24 release*
 Pradnya: added PRULink Supreme Plus product for march24 release.
 
end*/

function fnMsLoadingonload()
{
    disableCutCopyPaste();
    placeholderToSelect();
    document.getElementById("naviagtionBtnTable").style.display="block";
    js_get_var("main_life_response", function(mainlife_res)
    {
        if(mainlife_res != "" && mainlife_res != null && mainlife_res != "null"  && mainlife_res != "(null)")
        {
            obj_mlife = JSON.parse(mainlife_res);

            if(obj_mlife["al_sqs_details.sec_parti_flag"]=="Yes")
            {
                js_get_var("sec_life_response", function(seclife_res)
                {
                    if(seclife_res != "" && seclife_res != null && seclife_res != "null"  && seclife_res != "(null)")
                    {
                        obj_slife = JSON.parse(seclife_res);
                              
                        if(obj_slife["al_sqs_details.third_parti_flg"]=="Yes")
                        {
                            fnMsLoadingonloading();
                        }else
                        {
                            fnMsLoadingonloading();
                        }
                    }
                });
            }else
            {
               fnMsLoadingonloading();
            }
        }
    });
}

//On load of the page, will get the data from native and set the life's as per the personal details life taken
function fnMsLoadingonloading()
{
    //fnMsLoadingChangePanels();
    fnMsLoadingHideRiderElement();
    js_get_var("cancer_loading_clear", function(cancer_valid_res)
    {
               
               console.log("cancer_valid_res"+cancer_valid_res)
               
              
               
    js_get_var("hideshowloadingrider", function(per_valid_res)
    {
        if(per_valid_res != "" && per_valid_res != null && per_valid_res != "null"  && per_valid_res != "(null)")
        {
            var obj = JSON.parse(per_valid_res);
            var result = $.parseJSON(obj);
            $.each(result, function(k, v)
            {
                if(!(k=="rider_row_al_loading_details_sqs.pmed" || k=="rider_row_al_loading_details_sqs.hb"))
                {
                   ShowElement(k);
                }
            });
        }

        if(obj_mlife["al_sqs_details.sec_parti_flag"]=="Yes")
        {
            if(obj_prochoice["al_sqs_details.product_name"] != "PRUheritage")
            {

               $(".collapseTwo").attr("id","collapseTwo");
               $(".second_life").addClass("softGrey_panel");
               $(".second_life").removeClass("disabled_panel");
            }
           

            if(obj_slife["al_sqs_details.third_parti_flg"]=="Yes")
            {
               $(".collapseThree").attr("id","collapseThree");
               $(".third_life").addClass("softGrey_panel");
               $(".third_life").removeClass("disabled_panel");
            }else
            {
               $(".collapseThree").attr("id","");
               $(".third_life").addClass("disabled_panel");
               $(".third_life").removeClass("softGrey_panel").removeClass("active_panel");
            }
           if(obj_prochoice["al_sqs_details.product_name"]=="PRUlife partner" && parseInt(obj_slife["al_person_details.slife.anb"])>50)
           {
               $(".collapseTwo").attr("id","");
               $(".second_life,.third_life").addClass("disabled_panel");
               $(".second_life,.third_life").removeClass("softGrey_panel").removeClass("active_panel");
           }
        }else
        {
            $(".collapseTwo").attr("id","");
            $(".second_life,.third_life").addClass("disabled_panel");
            $(".second_life,.third_life").removeClass("softGrey_panel").removeClass("active_panel");
        }
               $(".first_life").click(function() {
                                      console.log("Its working")
                                     if ($(this).hasClass("softGrey_panel")) {
                                      if($(".second_life").hasClass("softGrey_panel") || $(".second_life").hasClass("active_panel")){
                                         $(".second_life").removeClass("active_panel").addClass("softGrey_panel");
                                      }
                                      if($(".third_life").hasClass("softGrey_panel") || $(".third_life").hasClass("active_panel")){
                                        $(".third_life").removeClass("active_panel").addClass("softGrey_panel");
                                      }
                                      $(this).addClass("active_panel").removeClass("softGrey_panel");
                                      }
                                      });
              $(".second_life").click(function() {
                                       console.log("Its working")
                                     if ($(this).hasClass("softGrey_panel")) {
                                     if($(".first_life").hasClass("softGrey_panel") || $(".first_life").hasClass("active_panel")){
                                     $(".first_life").removeClass("active_panel").addClass("softGrey_panel");
                                     }
                                     if($(".third_life").hasClass("softGrey_panel") || $(".third_life").hasClass("active_panel")){
                                     $(".third_life").removeClass("active_panel").addClass("softGrey_panel");
                                     }
                                         $(this).addClass("active_panel").removeClass("softGrey_panel");
                                     }
                                      
                                      });
               $(".third_life").click(function() {
                                       console.log("Its working")
                                       if ($(this).hasClass("softGrey_panel")) {
                                       if($(".first_life").hasClass("softGrey_panel") || $(".first_life").hasClass("active_panel")){
                                       $(".first_life").removeClass("active_panel").addClass("softGrey_panel");
                                       }
                                       if($(".second_life").hasClass("softGrey_panel") || $(".second_life").hasClass("active_panel")){
                                       $(".second_life").removeClass("active_panel").addClass("softGrey_panel");
                                       }
                                         $(this).addClass("active_panel").removeClass("softGrey_panel");
                                       }
                                       });
                      mlife_anb = obj_mlife["al_person_details.mlife.anb"];

               
               

js_get_var("buttons_plans_response", function(solutionsPlan)
{
       
           if(solutionsPlan != "" && solutionsPlan != null && solutionsPlan != "null"  && solutionsPlan != "(null)")
           {
     
           obj_solution=JSON.parse(solutionsPlan);
           
           }
           
           
           
           
js_get_var("beneft_selection_response",function(benefit_selection_response)
{
    console.log("loading benfeft response"+clone_benefet_selection)
           
           if(benefit_selection_response=="" || benefit_selection_response==null || benefit_selection_response=="null" || benefit_selection_response=="(null)") {
           
           if(clone_benefet_selection!="" && clone_benefet_selection!=null && clone_benefet_selection!=null) {
           
           benefit_selection_response=clone_benefet_selection;
           
           }
           
           
           
           }
           
if(benefit_selection_response!=""&&benefit_selection_response!=null&&benefit_selection_response!="null"&&benefit_selection_response!="(null)")
{
obj_benefit_selection=JSON.parse(benefit_selection_response);
        js_get_var("prod_choice_response", function(prod_choice_res)
        {
            js_get_var("bundle_product_response", function(prod_choice_res_bundle)
            {
                       
            if(prod_choice_res != "" && prod_choice_res != null && prod_choice_res != "null"  && prod_choice_res != "(null)")
            {
                obj_prochoice= JSON.parse(prod_choice_res);
                       //added by ankita for bundle product
                //22 feb
                if(arrayBundleProduct.indexOf("PRUCritical Protect") !=-1)
                {
                       if(prod_choice_res_bundle != "" && prod_choice_res_bundle != null && prod_choice_res_bundle != "null"  && prod_choice_res_bundle != "(null)")
                       {
                             obj_prochoice=JSON.parse(prod_choice_res_bundle);
                             //currentPlan=obj_prochoice["al_sqs_details.product_name"];
                       }
                }
                   //code commented by praveen
                if(obj_prochoice["al_sqs_details.product_name"] == "PRUlife ready")
                {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>Life Ready";
                }else if(obj_prochoice["al_sqs_details.product_name"] == "PRUlink one")
                {
                    document.getElementById("product_title").innerHTML="<b>PRU</b>Link One";

               }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUwith you")
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>With You";
                   
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRULink Cover")//Added condition by ankita on 10 April 2019
                   {
                        document.getElementById("product_title").innerHTML="<b>PRU</b>Link Cover";
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUSignature Assure")//Added condition by ankita on 10 April 2019
                                     {
                                          document.getElementById("product_title").innerHTML="<b>PRU</b>Signature Assure";
                                     }
                
                   
                   
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUmillion cover")
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>Million Cover";
                   
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUMillion Cover 2.0")
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>Million Cover 2.0";
                   
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUEnhanced Cover")
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>Enhanced Cover";
                   
                   }
                
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUMy Gift")
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>My Gift";
                   
                   }
                   // added by Shivani for PRUMulti Crisis Guard
                   else if(obj_prochoice["al_sqs_details.product_name"] === "PRUMulti Crisis Guard")
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>Multi Crisis Guard";
                   
                   }
                   
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUsmart gain")//Added condition for PRUsmart gain product on 21 June 2018

                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>Smart Gain";
                   
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUValue Gain")
                   
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>Value Gain";
                   
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUFlexi Gain")
                   
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>Flexi Gain";
                   
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUEnrich Gain")
                   
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>Enrich Gain";
                   
                   }
                   
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUGain Plus")
                   
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>Gain Plus";
                   
                   }

                   else if(obj_prochoice["al_sqs_details.product_name"] === "PRUCash Enrich")
                   
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>Cash Enrich";
                   
                   }
                   
                   else if(obj_prochoice["al_sqs_details.product_name"] === "PRUTerm Premier")
                                     
                     {
                     document.getElementById("product_title").innerHTML="<b>PRU</b>Term Premier";
                     
                     }
                   else if(obj_prochoice["al_sqs_details.product_name"] === "PRUAll Care")
                                                      
                                      {
                                      document.getElementById("product_title").innerHTML="<b>PRU</b>All Care";
                                      
                                      }
                                    
                   
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUsignature income")//Added condition for PRUsignature income product on 9 July 2018 by ankita
                   
                   {
                   document.getElementById("product_title").innerHTML="<b>PRUSignature Income</b>";
                   
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "EssentialLife (SP)")
                   
                   {
                   document.getElementById("product_title").innerHTML="EssentialLife (SP)";
                   
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUSignature Protect")//Abhilash: EssentialLife (SP)_SCB name changed to PRUSignature Protect on 3rd July
                   
                   {
                   document.getElementById("product_title").innerHTML="PRUSignature Protect";//Abhilash: EssentialLife (SP)_SCB name changed to PRUSignature Protect on 3rd July
                   
                   }
                   
               else if(obj_prochoice["al_sqs_details.product_name"] == "PRUlife partner")
               {
               document.getElementById("product_title").innerHTML="<b>PRU</b>Life Partner";
               
               }else if(obj_prochoice["al_sqs_details.product_name"] == "PRUmy child")
               {
               document.getElementById("product_title").innerHTML="<b>PRU</b>My Child";
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUmy kid")
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>My Kid";
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUlink million")
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>Link million";
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUmy legacy")// Added By Rahul for Product name display
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>My Legacy";
                   }else if(obj_prochoice["al_sqs_details.product_name"] == "PRUmy gift")// Added By Rahul for Product name display
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>My Gift";
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "LifeLink")
                   {
                   document.getElementById("product_title").innerHTML="<b>LifeLink</b>";
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUcancer plan")
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>Cancer Plan";
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUcancer X")//Added by ankita for PRUcancer X product on 5 June 2018
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>Cancer X";
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUlady")
                   {
                   document.getElementById("product_title").innerHTML="<b>PRULady</b>";
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUMan")
                   {
                   document.getElementById("product_title").innerHTML="<b>PRUMan</b>";
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRULady_PRL")
                   {
                   document.getElementById("product_title").innerHTML="<b>PRULady</b>";
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUheritage")
                   {
                   document.getElementById("product_title").innerHTML="<b>PRUHeritage</b>";
                   }else if(obj_prochoice["al_sqs_details.product_name"] == "PRUsignature")
                   {
                   document.getElementById("product_title").innerHTML="<b>PRUSignature</b>";
                   }else if(obj_prochoice["al_sqs_details.product_name"] == "PRUsignature USD")
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>Signature USD";
                   }else if(obj_prochoice["al_sqs_details.product_name"] === "PRULink Supreme")
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>Link Supreme";
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] === "PRULink Supreme Plus")
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>Link Supreme Plus";
                    document.getElementById("change_elite").innerHTML="Details of Benefit";
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] === "PRUElite Invest")
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>Elite Invest";
                   document.getElementById("change_elite").innerHTML="Details of Benefit";
                   }
                    else if(obj_prochoice["al_sqs_details.product_name"] === "PRUSignature GrowthPlus")
                    {
                       document.getElementById("product_title").innerHTML="<b>PRU</b>Signature GrowthPlus";
                       document.getElementById("change_elite").innerHTML="Details of Benefit";
                    }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUsignature infinite")
                   {
                   document.getElementById("product_title").innerHTML="<b>PRUSignature Infinite</b>";
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUSignature Ace")
                   {
                   document.getElementById("product_title").innerHTML="<b>PRUSignature Ace</b>";
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUMax Cover")
                   {
                   document.getElementById("product_title").innerHTML="<b>PRUMax Cover</b>";
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUwealth")// Change made By Pramod Chavan for Product name display on 15032017
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>Wealth";
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUwealth")// Change made By Pramod Chavan for Product name display on 15032017
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>Wealth";
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUmy treasure")
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>My Treasure";
                   
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUWealth Plus")
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>Wealth Plus";
                   
                   }
                  else if(obj_prochoice["al_sqs_details.product_name"] == "PRUWealth Enrich")
                  {
                  document.getElementById("product_title").innerHTML="<b>PRU</b>Wealth Enrich";
                  
                  }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUWealth Max")
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>Wealth Max";
                   
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] === "PRUSignature Vanguard")
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>Signature Vanguard";
                   
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] === "PRUCritical Protect")
                   {
                   document.getElementById("product_title").innerHTML="<b>PRU</b>Critical Protect";
                   
                   }
                   
                   document.getElementById("loading_cancer").style.display="none";
                   document.getElementById("forOther").style.display="block";
                   
                   if(obj_prochoice["al_sqs_details.product_name"] != "PRUwith you" && obj_prochoice["al_sqs_details.product_name"] != "PRULink Cover")//added prulink cover for def1147 by Pradnya
                   {
                    document.getElementById("med_boosterCheck").style.display="none";
                    document.getElementById("value_booster").style.display="none";
                   
                   }
                

               if(obj_prochoice["al_sqs_details.product_name"] == "PRUlife ready" || obj_prochoice["al_sqs_details.product_name"] == "PRUlink one" ||  obj_prochoice["al_sqs_details.product_name"] == "LifeLink" || obj_prochoice["al_sqs_details.product_name"] == "PRUlife partner")
               {
                   //For Mainlife
                   document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="E";
                   document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="M";
                   document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="P";
                   document.getElementById("al_loading_details_sqs.mlife.tpd.value_val").innerHTML="PE";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value_val").innerHTML="PM (%)";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value_val").innerHTML="PP (%)";
                   document.getElementById("al_loading_details_sqs.mlife.ah_add.value_val").innerHTML="AH";
                   document.getElementById("al_loading_details_sqs.mlife.critical_illness.value_val").innerHTML="C";
                   document.getElementById("al_loading_details_sqs.mlife.ah_ecp.value_val").innerHTML="CEW";
                   document.getElementById("al_loading_details_sqs.mlife.ah_dp.value_val").innerHTML="X";
                   document.getElementById("al_loading_details_sqs.mlife.ah_amr.value_val").innerHTML="AH";
                   document.getElementById("al_loading_details_sqs.mlife.ah_adi.value_val").innerHTML="AH";
                   document.getElementById("al_loading_details_sqs.mlife.ah_pmed.value_val").innerHTML="AH";
                   document.getElementById("al_loading_details_sqs.mlife.ah_hb.value_val").innerHTML="AH";
                   document.getElementById("al_loading_details_sqs.mlife.ah_phl.value_val").innerHTML="AH";
                   document.getElementById("rider_row_al_loading_details_sqs.add_on").style.display="table-row";
                   
                   //For Second Life
                   document.getElementById("al_loading_details_sqs.slife.em.value_val").innerHTML="SE";
                   document.getElementById("al_loading_details_sqs.slife.death_per_mille.value_val").innerHTML="SM";
                   document.getElementById("al_loading_details_sqs.slife.death_pursuit_term.value_val").innerHTML="SP";
                   document.getElementById("al_loading_details_sqs.slife.tpd.value_val").innerHTML="SPE";
                   document.getElementById("al_loading_details_sqs.slife.tpd_per_mille.value_val").innerHTML="SPM (%)";
                   document.getElementById("al_loading_details_sqs.slife.tpd_pursuit_term.value_val").innerHTML="SPP (%)";
                   document.getElementById("al_loading_details_sqs.slife.critical_illness.value_val").innerHTML="SC";
                   
                   //Third Life
                   document.getElementById("al_loading_details_sqs.tlife.em.value_val").innerHTML="XE";
                   document.getElementById("al_loading_details_sqs.tlife.death_per_mille.value_val").innerHTML="XM";
                   document.getElementById("al_loading_details_sqs.tlife.death_pursuit_term.value_val").innerHTML="XP";
                   document.getElementById("al_loading_details_sqs.tlife.tpd.value_val").innerHTML="XPE";
                   document.getElementById("al_loading_details_sqs.tlife.tpd_per_mille.value_val").innerHTML="XPM (%)";
                   document.getElementById("al_loading_details_sqs.tlife.tpd_pursuit_term.value_val").innerHTML="XPP (%)";
                   document.getElementById("al_loading_details_sqs.tlife.critical_illness.value").innerHTML="XC";
                   
                   document.getElementById("al_loading_details_sqs.mlife.ah_pec.value").value="";
                   if(obj_prochoice["al_sqs_details.product_name"] == "PRUlife partner")
                   {
                   // TODO 12072017
                   $("#headerForPruLifePartner").css("display","block");
                   $("#headerOtherThanPruLifePartner").css("display","none");
                   document.getElementById("row_al_loading_details_sqs.mlife.ah_add_double.block").style.display="table-row";
                       document.getElementById("row_al_loading_details_sqs.slife.ah_add_double.block").style.display="table-row";
                       document.getElementById("row_al_loading_details_sqs.mlife.di.block").style.display="table-row";
                       document.getElementById("row_al_loading_details_sqs.slife.di.block").style.display="table-row";
					   document.getElementById("al_loading_details_sqs.mlife.ah_add_double_i_button_block").style.display="table-row";// for i button changes made by pramod chavan on 20062017
                       document.getElementById("al_loading_details_sqs.mlife.di_i_button_block").style.display="table-row";// for i button changes made by pramod chavan on 20062017
                       
                       
                       document.getElementById("al_loading_details_sqs.mlife.disability_income_rider_value_i_button_block").style.display="table-cell";// for i button changes made by pramod chavan on 20062017
                       document.getElementById("al_loading_details_sqs.mlife.ah_cash_rider_value_i_button_block").style.display="table-cell";// for i button changes made by pramod chavan on 20062017
                       document.getElementById("al_loading_details_sqs.slife.disability_income_rider_value_i_button_block").style.display="table-cell";// for i button changes made by pramod chavan on 20062017
                       document.getElementById("al_loading_details_sqs.slife.ah_cash_rider_value_i_button_block").style.display="table-cell";// for i button changes made by pramod chavan on 20062017
                   //Life 1
                   
                   //css added for i button CR on 29Jun17
                   $('.prulifePartnerCol').show();
                   $(escape_jq("al_loading_details_sqs.mlife.addClassForPLPartner")).addClass('prulifePartnerTable');
                   $(escape_jq("al_loading_details_sqs.slife.addClassForPLPartner")).addClass('prulifePartnerTable');
                   $(escape_jq("al_loading_details_sqs.mlife.addClassForPLPartner_opt_bene")).addClass('prulifePartnerTable_opt_bene');
                   $(escape_jq("al_loading_details_sqs.slife.addClassForPLPartner_opt_bene")).addClass('prulifePartnerTable_opt_bene');

                   
                   document.getElementById("al_loading_details_sqs.slife.ah_add_double_i_button_block").style.display="table-row";// for i button changes made by pramod chavan on 20062017
                   document.getElementById("al_loading_details_sqs.slife.di_i_button_block").style.display="table-row";// for i button changes made by pramod chavan on 20062017
                   //Life 1
                       document.getElementById("al_loading_details_sqs.mlife.di.value_val").innerHTML="PE";
                       document.getElementById("al_loading_details_sqs.mlife.di_per_mille.value_val").innerHTML="PM (%)";
                       document.getElementById("al_loading_details_sqs.mlife.di_pursuit_term.value_val").innerHTML="PP (%)";
                       document.getElementById("al_loading_details_sqs.mlife.ah_add_double.value_val").innerHTML="AH";
                   //Life 2
                       document.getElementById("al_loading_details_sqs.slife.di.value_val").innerHTML="SPE";
                       document.getElementById("al_loading_details_sqs.slife.di_per_mille.value_val").innerHTML="SPM (%)";
                       document.getElementById("al_loading_details_sqs.slife.di_pursuit_term.value_val").innerHTML="SPP (%)";
                       document.getElementById("al_loading_details_sqs.slife.ah_add_double.value_val").innerHTML="AH";
                   
            
             /*      var disabledId=["al_loading_details_sqs.slife.di.value","al_loading_details_sqs.slife.di_per_mille.value","al_loading_details_sqs.slife.di_per_mille_term.value","al_loading_details_sqs.slife.di_pursuit.value","al_loading_details_sqs.slife.di_pursuit_term.value","al_loading_details_sqs.mlife.di.value","al_loading_details_sqs.mlife.di_per_mille.value","al_loading_details_sqs.mlife.di_per_mille_term.value","al_loading_details_sqs.mlife.di_pursuit.value","al_loading_details_sqs.mlife.di_pursuit_term.value"];
                   console.log("array is"+disabledId);
                   for(var i=0;i<=disabledId.length-1;i++)
                   {
                   var id=disabledId[i];
                   console.log("id"+id)
                   document.getElementById(id).disabled=true; //todo 09-04-2018
                   }*/
                   
                  
                   }
                   
                   
                   }
                   
                   /* bellow added for PRUwith you*/
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUwith you" || obj_prochoice["al_sqs_details.product_name"] == "PRULink Cover" || obj_prochoice["al_sqs_details.product_name"] == "PRUSignature Assure")//Added condition by ankita on 10 April 2019
                   {
                   console.log("in millennium loading..");
                   console.log("spouse value is"+obj_slife["al_person_details.slife.relationship"]);
                   console.log("Mainlife obj -->"+obj_mlife["pvm_qualification_check"]);
                   
                   // for main life
                  
                   document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="E";
                   document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="M";
                   document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="P";
                   document.getElementById("al_loading_details_sqs.mlife.tpd.value_val").innerHTML="PE";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value_val").innerHTML="PM (%)";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value_val").innerHTML="PP (%)";
                   document.getElementById("row_optional_benefits").style.display='none';
                   document.getElementById("rider_row_al_loading_details_sqs.add_on").style.display='none';
                   document.getElementById("al_loading_details_sqs.mlife.critical_illness.value_val").innerHTML="C";
                   document.getElementById("pru_acc_med").innerHTML="Acci Med Plus";
                document.getElementById("rider_row_al_loading_details_sqs.amr").style.display='table-row';
                
                  
                   document.getElementById("al_loading_details_sqs.mlife.ah_pmed.value_val").innerHTML="AH";
                 
                  
                 document.getElementById("acc_guard_plus").innerHTML="Acci Guard Plus";
               document.getElementById("rider_row_al_loading_details_sqs.add_millennium").style.display='table-row';
                
                 
                document.getElementById("al_loading_details_sqs.mlife.millennium_ah_add.value_val").innerHTML="AH";
                    document.getElementById("pru_acci_income").innerHTML="Acci Income Plus";
                   document.getElementById("rider_row_al_loading_details_sqs.adi").style.display='table-row';
                   document.getElementById("al_loading_details_sqs.mlife.ah_adi.value").innerHTML="AH";
                    document.getElementById("al_loading_details_sqs.mlife.ah_adi.value_val").innerHTML="AH";
                   document.getElementById("rider_row_al_loading_details_sqs.phl_millennium").style.display='table-row';
                   document.getElementById("al_loading_details_sqs.mlife.ah_phl.value_val_millennium").innerHTML="AH";
                document.getElementById("al_loading_details_sqs.mlife.millennium_ah_add.value_val").innerHTML="AH";
                   document.getElementById("al_loading_details_sqs.mlife.ah_amr.value_val").innerHTML="AH";
                   
             document.getElementById("al_loading_details_sqs.mlife.ah_amr.value").innerHTML="AH";
                    document.getElementById("al_loading_details_sqs.mlife.ah_pmed.value").innerHTML="AH";
                    document.getElementById("al_loading_details_sqs.mlife.ah_add.value").innerHTML="AH";
                    document.getElementById("al_loading_details_sqs.mlife.ah_pec.value").innerHTML="AH";
                   document.getElementById("rider_row_al_loading_details_sqs.phl").style.display='none';
               
                    document.getElementById("al_loading_details_sqs.mlife.ah_phl.value_val").innerHTML="AH";
                   //Sourabh changed for two rider of pruwith you
                   if(obj_mlife["pvm_qualification_check"] !="Yes" && obj_prochoice["al_sqs_details.product_name"] != "PRUSignature Assure")
                   {
                    document.getElementById("pvmFlagNotInDB").style.display='none';
                   }
                   
                   //Added by ankita on 3 July 2018 for rider PRUmillion med of PRUwith you product
//                   if(obj_mlife["rider_certified_check"] != "PruMillionMed_Yes" && obj_prochoice["al_sqs_details.product_name"] != "PRUSignature Assure")
//                   {
//                      document.getElementById("pmmFlagCheck").style.display='none';
//                   }
                    if(obj_prochoice["al_sqs_details.product_name"] != "PRUwith you" && obj_prochoice["al_sqs_details.product_name"] != "PRULink Cover"  && obj_prochoice["al_sqs_details.product_name"] != "PRUSignature Assure")//Pradnya: added for may24 release
                       {
                        document.getElementById("med_active").style.display="none";
                        document.getElementById("med_plus").style.display="none";
                           document.getElementById("active_booster").style.display="none";
                           document.getElementById("plus_booster").style.display="none";
                       
                       }
                   
                   
              
                  if(obj_prochoice["al_sqs_details.product_name"] == "PRUwith you")
                   {
                    var current_date = fnGetDateTimeStamp();
                   console.log("@Current Date",current_date);
                    var blocking_date="2099-06-11 00:00:00";
                     
                   
                     if(current_date >= blocking_date)
                     {
                            
                         document.getElementById("pmmFlaghealth").style.display='none';
                         
                          
                     }
                   }
                                          
                   
                   
                   
                 if(obj_prochoice["al_sqs_details.mlife.il_anb"]<=18)
                   {
                   console.log("millennium age check condition--->");
                   
                   document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="JE";
                   document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="JM";
                   document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="P";
                   document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="JP";
                  //
                   
                   document.getElementById("al_loading_details_sqs.mlife.tpd.value_val").innerHTML="JPE";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value_val").innerHTML="JPM (%)";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value_val").innerHTML="JPP (%)";
                   document.getElementById("al_loading_details_sqs.mlife.critical_illness.value_val").innerHTML="JC";
                   
                   
                   
                   }
                    if(obj_prochoice["al_sqs_details.mlife.il_anb"]<=15)
                   {
                    console.log("essentail child condition");
                    document.getElementById("rider_row_al_loading_details_sqs.pec").style.display='table-row';
                    document.getElementById("pru_essential_child").innerHTML="Essential Child Plus";
                    document.getElementById("al_loading_details_sqs.mlife.ah_pec.value_val").innerHTML="JCE";
                   
                   }
                  $('#tpd_id').html('Total & Permanent Disability (TPD)');
                   document.getElementById("tpd_id_italic").innerHTML="";
                    $("#tpd_id").removeClass("red");
                  // document.getElementById("al_loading_details_sqs.mlife.millennium_ah_add.value_val").style.display="AH";
                  
             

                  //for second life
             
                   console.log("in spouse Checking"+obj_slife["al_person_details.slife.relationship"]);
                   document.getElementById("al_loading_details_sqs.slife.em.value_val").innerHTML="SE";
                   document.getElementById("al_loading_details_sqs.slife.death_per_mille.value_val").innerHTML="SM";
                   document.getElementById("al_loading_details_sqs.slife.death_pursuit_term.value_val").innerHTML="SP";
                 

                   document.getElementById("al_loading_details_sqs.slife.tpd.value_val").innerHTML="SPE";
                   document.getElementById("al_loading_details_sqs.slife.tpd_per_mille.value_val").innerHTML="SPM (%)";
                   document.getElementById("al_loading_details_sqs.slife.tpd_pursuit_term.value_val").innerHTML="SPP (%)";
                   document.getElementById("al_loading_details_sqs.slife.critical_illness.value_val").innerHTML="SC";
                   document.getElementById("optional_benefits.id").style.display='none';
                   
                   if(obj_slife["al_person_details.slife.relationship"] =="Parent" || obj_slife["al_person_details.slife.relationship"] == "Legal Guardian")
                   {
                    console.log("in Parent Checking"+obj_slife["al_person_details.slife.relationship"] == "Parent");
                   document.getElementById("al_loading_details_sqs.slife.em.value_val").innerHTML="PE";
                   document.getElementById("al_loading_details_sqs.slife.death_per_mille.value_val").innerHTML="PM";
                   document.getElementById("al_loading_details_sqs.slife.death_pursuit_term.value_val").innerHTML="PP";
                   document.getElementById("al_loading_details_sqs.slife.tpd.value_val").innerHTML="PPE";
                   document.getElementById("al_loading_details_sqs.slife.tpd_per_mille.value_val").innerHTML="PPM (%)";
                   document.getElementById("al_loading_details_sqs.slife.tpd_pursuit_term.value_val").innerHTML="PPP (%)";
                   document.getElementById("al_loading_details_sqs.slife.critical_illness.value_val").innerHTML="PC";
                   }
                   
                   $('#pdp_id').html('Total & Permanent Disability (TPD)');
                   document.getElementById("pdp_id_italic").innerHTML="";
                   $("#pdp_id").removeClass("red");
                   $(escape_jq("al_loading_details_sqs.mlife.ml_disability_income.rider_value")).removeAttr('readonly');

                                      //Third Life
                   document.getElementById("al_loading_details_sqs.tlife.em.value_val").innerHTML="XE";
                   document.getElementById("al_loading_details_sqs.tlife.death_per_mille.value_val").innerHTML="XM";
                   document.getElementById("al_loading_details_sqs.tlife.death_pursuit_term.value_val").innerHTML="XP";
                   document.getElementById("al_loading_details_sqs.tlife.tpd.value_val").innerHTML="XPE";
                   document.getElementById("al_loading_details_sqs.tlife.tpd_per_mille.value_val").innerHTML="XPM (%)";
                   document.getElementById("al_loading_details_sqs.tlife.tpd_pursuit_term.value_val").innerHTML="XPP (%)";
                   document.getElementById("al_loading_details_sqs.tlife.critical_illness.value_val").innerHTML="XC";
                
                    document.getElementById("t_optional_benefits").style.display='none';
                   
                   $('#third_tpd_id').html('Total & Permanent Disability (TPD)');
                   document.getElementById("third_tpd_id__italic").innerHTML="";
                   $("#third_tpd_id").removeClass("red");
                   $(escape_jq("al_loading_details_sqs.mlife.ml_disability_income.rider_value")).removeAttr('readonly');
                   //added by ankita on 26 july 2019
                   if(obj_prochoice["al_sqs_details.product_name"] == "PRUwith you" || obj_prochoice["al_sqs_details.product_name"] == "PRUSignature Assure")
                   {
                       document.getElementById("rider_row_al_loading_details_sqs.multi_crisis_care").style.display='table-row';
                       document.getElementById("rider_row_al_loading_details_sqs.early_crisis_care").style.display='table-row';
                       document.getElementById("rider_row_al_loading_details_sqs.total_multi_crisis_care").style.display='table-row';
                       document.getElementById("al_loading_details_sqs.mlife.multi_crisis_care.value_val").innerHTML="CIM";
                       document.getElementById("al_loading_details_sqs.mlife.early_crisis_care.value_val").innerHTML="CIE";
                       document.getElementById("al_loading_details_sqs.mlife.total_multi_crisis_care.value_val").innerHTML="CIT";
                   }
                  
                   
                   }
                   
                   /*end of PRUwith you */
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUMax Cover")//Added condition by ankita on 10 April 2019
                   {
                   console.log("in millennium loading..");
                   console.log("spouse value is"+obj_slife["al_person_details.slife.relationship"]);
                   console.log("Mainlife obj -->"+obj_mlife["pvm_qualification_check"]);
                   
                   // for main life
                   
                   document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="E";
                   document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="M";
                   document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="P";
                   document.getElementById("al_loading_details_sqs.mlife.tpd.value_val").innerHTML="PE";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value_val").innerHTML="PM (%)";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value_val").innerHTML="PP (%)";
                   document.getElementById("row_optional_benefits").style.display='none';
                   document.getElementById("rider_row_al_loading_details_sqs.add_on").style.display='none';
                   document.getElementById("al_loading_details_sqs.mlife.critical_illness.value_val").innerHTML="C";
                   document.getElementById("row_al_loading_details_sqs.mlife.ah_load.block").style.display="table-row";
                   document.getElementById("al_loading_details_sqs.mlife.ah_load.value_val").innerHTML="AH";
                   
                   
                 
                   
                 
                   
                   if(obj_prochoice["al_sqs_details.mlife.il_anb"]<=18)
                   {
                   console.log("millennium age check condition--->");
                   
                   document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="JE";
                   document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="JM";
                   document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="P";
                   document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="JP";
                   //
                   
                   document.getElementById("al_loading_details_sqs.mlife.tpd.value_val").innerHTML="JPE";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value_val").innerHTML="JPM (%)";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value_val").innerHTML="JPP (%)";
                   document.getElementById("al_loading_details_sqs.mlife.critical_illness.value_val").innerHTML="JC";
                   
                   
                   
                   }
                  
                   $('#tpd_id').html('Total & Permanent Disability');
                   document.getElementById("tpd_id_italic").innerHTML="";
                   $("#tpd_id").removeClass("red");
               /*****************************************************/
                   //For Second Life
                   document.getElementById("al_loading_details_sqs.slife.em.value_val").innerHTML="SE";
                   document.getElementById("al_loading_details_sqs.slife.death_per_mille.value_val").innerHTML="SM";
                   document.getElementById("al_loading_details_sqs.slife.death_pursuit_term.value_val").innerHTML="SP";
                   
                   
                   document.getElementById("al_loading_details_sqs.slife.tpd.value_val").innerHTML="SPE";
                   document.getElementById("al_loading_details_sqs.slife.tpd_per_mille.value_val").innerHTML="SPM (%)";
                   document.getElementById("al_loading_details_sqs.slife.tpd_pursuit_term.value_val").innerHTML="SPP (%)";
                   document.getElementById("al_loading_details_sqs.slife.critical_illness.value_val").innerHTML="SC";
                   document.getElementById("optional_benefits.id").style.display='none';
                   
                   if(obj_slife["al_person_details.slife.relationship"] =="Parent" || obj_slife["al_person_details.slife.relationship"] == "Legal Guardian")
                   {
                   console.log("in Parent Checking"+obj_slife["al_person_details.slife.relationship"] == "Parent");
                   document.getElementById("al_loading_details_sqs.slife.em.value_val").innerHTML="PE";
                   document.getElementById("al_loading_details_sqs.slife.death_per_mille.value_val").innerHTML="PM";
                   document.getElementById("al_loading_details_sqs.slife.death_pursuit_term.value_val").innerHTML="PP";
                   document.getElementById("al_loading_details_sqs.slife.tpd.value_val").innerHTML="PPE";
                   document.getElementById("al_loading_details_sqs.slife.tpd_per_mille.value_val").innerHTML="PPM (%)";
                   document.getElementById("al_loading_details_sqs.slife.tpd_pursuit_term.value_val").innerHTML="PPP (%)";
                   document.getElementById("al_loading_details_sqs.slife.critical_illness.value_val").innerHTML="PC";
                   }
                   
                   
                   
                   
              /*******************************************************/
                 
                   //For Second Life
                  /* document.getElementById("al_loading_details_sqs.slife.em.value_val").innerHTML="PE";
                   document.getElementById("al_loading_details_sqs.slife.death_per_mille.value_val").innerHTML="PM";
                   document.getElementById("al_loading_details_sqs.slife.death_pursuit_term.value_val").innerHTML="PP";
                   document.getElementById("al_loading_details_sqs.slife.tpd.value_val").innerHTML="PPE";
                   document.getElementById("al_loading_details_sqs.slife.tpd_per_mille.value_val").innerHTML="PPM (%)";
                   document.getElementById("al_loading_details_sqs.slife.tpd_pursuit_term.value_val").innerHTML="PPP (%)";
                   document.getElementById("al_loading_details_sqs.slife.critical_illness.value_val").innerHTML="PC";
                    document.getElementById("optional_benefits.id").style.display='none';***/
                   
                   $('#pdp_id').html('Total & Permanent Disability');
                   document.getElementById("pdp_id_italic").innerHTML="";
                   $("#pdp_id").removeClass("red");
                   $(escape_jq("al_loading_details_sqs.mlife.ml_disability_income.rider_value")).removeAttr('readonly');
                   
                  
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "EssentialLife (SP)" || obj_prochoice["al_sqs_details.product_name"] == "PRUSignature Protect")//Added condition by ankita on 10 April 2019 //Abhilash: EssentialLife (SP)_SCB name changed to PRUSignature Protect on 3rd July
                   {
                  
                   // for main life
                   
                   document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="E";
                   document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="M";
                   document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="P";
                   document.getElementById("al_loading_details_sqs.mlife.tpd.value_val").innerHTML="PE";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value_val").innerHTML="PM (%)";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value_val").innerHTML="PP (%)";
                   document.getElementById("row_optional_benefits").style.display='none';
                   document.getElementById("rider_row_al_loading_details_sqs.add_on").style.display='none';
                   document.getElementById("al_loading_details_sqs.mlife.critical_illness.value_val").innerHTML="C";
                   document.getElementById("row_critical_illness_benefits").style.display='none';
                    document.getElementById("row_al_loading_details_sqs.mlife.disability.block").style.display='table-row';
                    $('#tpd_id').html('Total & Permanent Disability (TPD)');
                   document.getElementById("tpd_id_italic").innerHTML="";
                   $("#tpd_id").removeClass("red");
                   $(".second_life,.third_life").hide();
                   
                   }
                   
                   
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUmy treasure")
                   {
                   console.log("in millennium loading..");
                   console.log("spouse value is"+obj_slife["al_person_details.slife.relationship"]);
                   
                   // for main life
                   
                   //CSS
                   
                   $(escape_jq("death_loading_prumy_treasure")).addClass("paddingTop5");
                   $(escape_jq("death_loading_prumy_treasure")).addClass("paddingLeft15");
                   $(escape_jq("death_loading_prumy_treasure")).css("width","25%");
                   
                   $(escape_jq("al_loading_details_sqs.mlife.em.value_val")).css("width","7%");
                   

                   
                   
                   
                   document.getElementById("death_loading_prumy_treasure").innerHTML="<b>"+"Death/ Total and Permanent"+"<br>"+"Disability (TPD)"+"</b>";
                   
                   document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="E";
                                     document.getElementById("row_optional_benefits").style.display='none';
                   document.getElementById("rider_row_al_loading_details_sqs.add_on").style.display='none';
                   document.getElementById("row_critical_illness_benefits").style.display='none';
                   document.getElementById("row_al_loading_details_sqs.mlife.disability.block").style.display='none';
                   document.getElementById("al_loading_details_sqs.mlife.death_per_mille_term.value").style.display='none';
                   document.getElementById("al_loading_details_sqs.mlife.death_pursuit.value").style.display='none';
                   document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value").style.display='none';
                   document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value").style.display='none';
                   document.getElementById("rider_row_al_loading_details_sqs.amr").style.display='none';
                   
                   document.getElementById("rider_row_al_loading_details_sqs.add_millennium").style.display='none';
                   
                   document.getElementById("rider_row_al_loading_details_sqs.adi").style.display='none';
                   document.getElementById("rider_row_al_loading_details_sqs.phl_millennium").style.display='none';
                   document.getElementById("rider_row_al_loading_details_sqs.phl").style.display='none';
                   $(".second_life,.third_life").hide();
                   
                   }
				   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUmillion cover" || obj_prochoice["al_sqs_details.product_name"] == "PRUsmart gain" ||  obj_prochoice["al_sqs_details.product_name"] == "PRUMy Gift" || obj_prochoice["al_sqs_details.product_name"] == "PRUValue Gain" || obj_prochoice["al_sqs_details.product_name"] == "PRUMillion Cover 2.0" || obj_prochoice["al_sqs_details.product_name"] === "PRUMulti Crisis Guard" || obj_prochoice["al_sqs_details.product_name"] === "PRUCash Enrich" || obj_prochoice["al_sqs_details.product_name"] === "PRUFlexi Gain" || obj_prochoice["al_sqs_details.product_name"] === "PRUGain Plus" || obj_prochoice["al_sqs_details.product_name"] === "PRUEnrich Gain" || obj_prochoice["al_sqs_details.product_name"] === "PRUEnhanced Cover")//Added condition for PRUsmart gain product on 21 June 2018 // Added condition by Shivani for PRUMulti Crisis Guard
                   {
				   // for main life
                  
                   document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="E";
                   document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="M";
                   document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="P";
                   document.getElementById("al_loading_details_sqs.mlife.tpd.value_val").innerHTML="PE";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value_val").innerHTML="PM (%)";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value_val").innerHTML="PP (%)";
                   document.getElementById("row_optional_benefits").style.display='none';
                   document.getElementById("rider_row_al_loading_details_sqs.add_on").style.display='none';
                   
                   //document.getElementById("row_al_loading_details_sqs.mlife.ah_load.block").style.display='none';//Commented for defect 6260 by Sachin on date 28-09-018
                //   document.getElementById("row_al_loading_details_sqs.mlife.ah_load.block").style.display='table-row';//Addded for defect 6260
               /*****************************************************************************************************/
                   //document.getElementById("row_al_loading_details_sqs.mlife.ah_load.block").style.display="table-row";
                   //document.getElementById("al_loading_details_sqs.mlife.ah_load.value_val").innerHTML="AH";
                   
                   
                   if(obj_prochoice["al_sqs_details.product_name"] == "PRUsmart gain" || obj_prochoice["al_sqs_details.product_name"] == "PRUMy Gift" || obj_prochoice["al_sqs_details.product_name"] === "PRUMulti Crisis Guard")//Missing code added by Sachin Tupe for defect 6260 on date 2018. // condition added by Shivani for PRUMulti Crisis Guard
                   {
                                // Added by shivani for critical illness benefit.
                           if(obj_prochoice["al_sqs_details.product_name"] === "PRUMulti Crisis Guard")
                           {
                           
                            document.getElementById("row_al_loading_details_sqs.mlife.ah_load.block").style.display='none';
                   
                            document.getElementById("row_critical_illness_multicrisisguard").style.display='table-row';
                   
                            document.getElementById("al_loading_details_sqs.mlife.critical_illness_multicrisisguard.value_val").innerHTML="ZC";
                            
                            $('#cib_id').html('Critical Illness (Payor)');
                   
                            $('#cib_sl_id').html('Critical Illness (Spouse Payor)');
                   
                            $('#tpd_pmcg_id').html('Total and Permanent Disability (TPD)');
                   
                            $('#pdp_pmcg_slife').html('Total and Permanent Disability (TPD)');
                   
                           
                           }
                           
                           else
                           {
                           document.getElementById("row_al_loading_details_sqs.mlife.ah_load.block").style.display='none';
                           }
                   }
                   
                   // Added by Shivani for PRUGain plus on 24th Nov 2021
                  else if(obj_prochoice["al_sqs_details.product_name"] === "PRUGain Plus")
                   {
                   
                   console.log("Gain plus check 11111");
                   
                   document.getElementById("row_al_loading_details_sqs.mlife.ah_load.block").style.display="none";
                   }
                   else
                   {
                   console.log("Gain plus check 22222");
                   
                   document.getElementById("row_al_loading_details_sqs.mlife.ah_load.block").style.display="table-row";
                   document.getElementById("al_loading_details_sqs.mlife.ah_load.value_val").innerHTML="AH";
                   }
                   
                /*****************************************************************************************************/
                  document.getElementById("al_loading_details_sqs.mlife.critical_illness.value_val").innerHTML="C";
                   
                   if(obj_prochoice["al_sqs_details.product_name"] !== "PRUMulti Crisis Guard")
                   {
                   $('#tpd_id').html('Total & Permanent Disability (TPD)');
                   document.getElementById("tpd_id_italic").innerHTML="";
                    $("#tpd_id").removeClass("red");
						   
                   }
                   
                   // second life
                   
                   document.getElementById("al_loading_details_sqs.slife.em.value_val").innerHTML="SE";
                   document.getElementById("al_loading_details_sqs.slife.death_per_mille.value_val").innerHTML="SM";
                   document.getElementById("al_loading_details_sqs.slife.death_pursuit_term.value_val").innerHTML="SP";
                   document.getElementById("al_loading_details_sqs.slife.tpd.value_val").innerHTML="SPE";
                   document.getElementById("al_loading_details_sqs.slife.tpd_per_mille.value_val").innerHTML="SPM (%)";
                   document.getElementById("al_loading_details_sqs.slife.tpd_pursuit_term.value_val").innerHTML="SPP (%)";
                   document.getElementById("al_loading_details_sqs.slife.critical_illness.value_val").innerHTML="SC";
                   
                   document.getElementById("optional_benefits.id").style.display='none';
                 /*******************************************************************///added for defect 6260 by Sachin 28-09-2018.
                   
                   if(obj_prochoice["al_sqs_details.product_name"] !== "PRUMulti Crisis Guard")
                   {
                   
                   $('#pdp_id').html('Total & Permanent Disability (TPD)');
                   document.getElementById("pdp_id_italic").innerHTML="";
                   $("#pdp_id").removeClass("red");
                   
                   }
                   /****************************************************************/
                   if(obj_prochoice["al_sqs_details.product_name"] == "PRUsmart gain" || obj_prochoice["al_sqs_details.product_name"] == "PRUValue Gain" || obj_prochoice["al_sqs_details.product_name"] === "PRUCash Enrich"  || obj_prochoice["al_sqs_details.product_name"] === "PRUFlexi Gain" || obj_prochoice["al_sqs_details.product_name"] === "PRUGain Plus"  || obj_prochoice["al_sqs_details.product_name"] === "PRUEnrich Gain")//added condition for PRUsignature income by ankita on 9 July 2018
                   {
                   $('#pdp_id').html('Total & Permanent Disability (TPD)');
                   document.getElementById("pdp_id_italic").innerHTML="";
                   $("#pdp_id").removeClass("red");
                  
                   
                   if(obj_prochoice["al_sqs_details.product_name"] == "PRUValue Gain"){
                    document.getElementById("al_loading_details_sqs.mlife.prulady_cancer_income_loading.value_val").innerHTML="CA"
                   }
                   }
                   
                   
                   if(mlife_anb<=16 && (obj_prochoice["al_sqs_details.product_name"] == "PRUValue Gain" || obj_prochoice["al_sqs_details.product_name"] === "PRUCash Enrich" || obj_prochoice["al_sqs_details.product_name"] === "PRUFlexi Gain" || obj_prochoice["al_sqs_details.product_name"] === "PRUGain Plus" || obj_prochoice["al_sqs_details.product_name"] === "PRUEnrich Gain"))
                   {
                   
                   document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="JE";
                   document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="JM";
                   document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="JP";
                   
                   document.getElementById("al_loading_details_sqs.mlife.tpd.value_val").innerHTML="JPE";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value_val").innerHTML="JPM (%)";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value_val").innerHTML="JPP (%)";
                    document.getElementById("al_loading_details_sqs.mlife.critical_illness.value_val").innerHTML="JC";
                 
                   
                   }
                       //Added for defect 1040 by Sachin/Shreya.
                       if(obj_prochoice["al_sqs_details.product_name"] === "PRUEnhanced Cover"){
                       if(obj_prochoice["al_sqs_details.mlife.il_anb"]<=18)
                          {
                          console.log("millennium age check condition--->");
                          
                          document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="JE";
                          document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="JM";
                          document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="P";
                          document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="JP";
                       
                          document.getElementById("al_loading_details_sqs.mlife.tpd.value_val").innerHTML="JPE";
                          document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value_val").innerHTML="JPM (%)";
                          document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value_val").innerHTML="JPP (%)";
                          document.getElementById("al_loading_details_sqs.mlife.critical_illness.value_val").innerHTML="JC";
                          
                          
                          
                          }
                       }
                       
                       
                       
                       
                   if(obj_prochoice["al_sqs_details.product_name"] == "PRUFlexi Gain" || obj_prochoice["al_sqs_details.product_name"] == "PRUEnrich Gain"){
                   if(obj_prochoice["al_sqs_details.mlife.il_anb"] > 65)
                                                     {
                                     document.getElementById("row_al_loading_details_sqs.mlife.ah_load.block").style.display='none';
                                                        
                                    
                                                     }
                   }
                   
                   
                   if(obj_slife["al_person_details.slife.relationship"] =="Parent" || obj_slife["al_person_details.slife.relationship"] == "Legal Guardian")
                   {
                   console.log("in Parent Checking"+obj_slife["al_person_details.slife.relationship"] == "Parent");
                   document.getElementById("al_loading_details_sqs.slife.em.value_val").innerHTML="PE";
                   document.getElementById("al_loading_details_sqs.slife.death_per_mille.value_val").innerHTML="PM";
                   document.getElementById("al_loading_details_sqs.slife.death_pursuit_term.value_val").innerHTML="PP";
                   document.getElementById("al_loading_details_sqs.slife.tpd.value_val").innerHTML="PPE";
                   document.getElementById("al_loading_details_sqs.slife.tpd_per_mille.value_val").innerHTML="PPM (%)";
                   document.getElementById("al_loading_details_sqs.slife.tpd_pursuit_term.value_val").innerHTML="PPP (%)";
                   document.getElementById("al_loading_details_sqs.slife.critical_illness.value_val").innerHTML="PC";
                   }
                   
                   if(obj_prochoice["al_sqs_details.product_name"] === "PRUCash Enrich")
                   {
                        document.getElementById("row_al_loading_details_sqs.mlife.ah_load.block").style.display='none';
                            //added by ankita on 15 april 2021 for new loading code changes
                            
                            document.getElementById("al_loading_details_sqs.slife.em.value_val").innerHTML="BE";
                            document.getElementById("al_loading_details_sqs.slife.death_per_mille.value_val").innerHTML="BM";
                            document.getElementById("al_loading_details_sqs.slife.death_pursuit_term.value_val").innerHTML="BP";
                            document.getElementById("al_loading_details_sqs.slife.tpd.value_val").innerHTML="BPE";
                            document.getElementById("al_loading_details_sqs.slife.tpd_per_mille.value_val").innerHTML="BPM (%)";
                            document.getElementById("al_loading_details_sqs.slife.tpd_pursuit_term.value_val").innerHTML="BPP (%)";
                            document.getElementById("al_loading_details_sqs.slife.critical_illness.value_val").innerHTML="BC";
                            
                            
                   }
                   
                       //Added for August release 2023 by sachin.
                                          if(obj_prochoice["al_sqs_details.product_name"] == "PRUEnhanced Cover"){
                                         document.getElementById("al_loading_details_sqs.tlife.em.value_val").innerHTML="XE";
                                            document.getElementById("al_loading_details_sqs.tlife.death_per_mille.value_val").innerHTML="XM";
                                            document.getElementById("al_loading_details_sqs.tlife.death_pursuit_term.value_val").innerHTML="XP";
                                            document.getElementById("al_loading_details_sqs.tlife.tpd.value_val").innerHTML="XPE";
                                            document.getElementById("al_loading_details_sqs.tlife.tpd_per_mille.value_val").innerHTML="XPM (%)";
                                            document.getElementById("al_loading_details_sqs.tlife.tpd_pursuit_term.value_val").innerHTML="XPP (%)";
                                            document.getElementById("al_loading_details_sqs.tlife.critical_illness.value_val").innerHTML="XC";
                                         
                                             document.getElementById("t_optional_benefits").style.display='none';
                                            
                                            $('#third_tpd_id').html('Total & Permanent Disability (TPD)');
                                            document.getElementById("third_tpd_id__italic").innerHTML="";
                                            $("#third_tpd_id").removeClass("red");
                                          }
                   
                       
                   
				   }
                   
                   
                   
                   else if(obj_prochoice["al_sqs_details.product_name"] === "PRUTerm Premier")
                   
                   
                   {
                       // for main life
                      
                       document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="E";
                       document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="M";
                       document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="P";
                       document.getElementById("al_loading_details_sqs.mlife.tpd.value_val").innerHTML="PE";
                       document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value_val").innerHTML="PM (%)";
                       document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value_val").innerHTML="PP (%)";
                       document.getElementById("row_optional_benefits").style.display='none';
                       document.getElementById("rider_row_al_loading_details_sqs.add_on").style.display='none';
                   
                       document.getElementById("row_critical_illness_benefits").style.display='none';
                       document.getElementById("PTP_id").style.display='none';
                   
                        $('#tpd_id').html('Total & Permanent Disability (TPD)');
                        document.getElementById("tpd_id_italic").innerHTML="";
                        $("#tpd_id").removeClass("red");
                   $(".second_life,.third_life").hide();
                        
                 }
                   
                   else if(obj_prochoice["al_sqs_details.product_name"] === "PRUAll Care")
                                   
                                   
                                   {
                                       // for main life
                                      
                                       document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="E";
                                       document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="M";
                                       document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="P";
                                       document.getElementById("al_loading_details_sqs.mlife.tpd.value_val").innerHTML="PE";
                                       document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value_val").innerHTML="PM (%)";
                                       document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value_val").innerHTML="PP (%)";
                                       document.getElementById("row_optional_benefits").style.display='none';
                                       document.getElementById("rider_row_al_loading_details_sqs.add_on").style.display='none';
                                       document.getElementById("row_post_surgery_recovery_benefits").style.display='table-row';
                                       document.getElementById("row_intensive_care_support_benefits").style.display='table-row';
                   
                                          document.getElementById("rider_row_al_loading_details_sqs.total_multi_crisis_care").style.display='table-row';
                   document.getElementById("al_loading_details_sqs.mlife.total_multi_crisis_care.value_val").innerHTML="CIT";
                   document.getElementById("al_loading_details_sqs.mlife.post_surgery_recovery_benefits.value_val").innerHTML="SU";
                   document.getElementById("al_loading_details_sqs.mlife.intensive_care_support_benefits.value_val").innerHTML="IC";
                                     
                                     
                                     
                   
                                      // document.getElementById("row_critical_illness_benefits").style.display='none';
                                       document.getElementById("PTP_id").style.display='none';
                     document.getElementById("al_loading_details_sqs.mlife.critical_illness.value_val").innerHTML="C";
                                   
                                        $('#tpd_id').html('Total & Permanent Disability (TPD)');
                                        document.getElementById("tpd_id_italic").innerHTML="";
                                        $("#tpd_id").removeClass("red");
                                  // $(".second_life,.third_life").hide();
                   
                   
                   
                   
                   
                   if(mlife_anb<=16)
                   {
                   
                   document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="JE";
                   document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="JM";
                   document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="JP";
                   
                   document.getElementById("al_loading_details_sqs.mlife.tpd.value_val").innerHTML="JPE";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value_val").innerHTML="JPM (%)";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value_val").innerHTML="JPP (%)";
                    document.getElementById("al_loading_details_sqs.mlife.critical_illness.value_val").innerHTML="JC";
                   }
                   
                   
                   if(obj_slife["al_person_details.slife.relationship"] =="Parent" || obj_slife["al_person_details.slife.relationship"] == "Legal Guardian")
                   {
                   console.log("in Parent Checking"+obj_slife["al_person_details.slife.relationship"] == "Parent");
                   document.getElementById("al_loading_details_sqs.slife.em.value_val").innerHTML="PE";
                   document.getElementById("al_loading_details_sqs.slife.death_per_mille.value_val").innerHTML="PM";
                   document.getElementById("al_loading_details_sqs.slife.death_pursuit_term.value_val").innerHTML="PP";
                   document.getElementById("al_loading_details_sqs.slife.tpd.value_val").innerHTML="PPE";
                   document.getElementById("al_loading_details_sqs.slife.tpd_per_mille.value_val").innerHTML="PPM (%)";
                   document.getElementById("al_loading_details_sqs.slife.tpd_pursuit_term.value_val").innerHTML="PPP (%)";
                   document.getElementById("al_loading_details_sqs.slife.critical_illness.value_val").innerHTML="PC";
                   }
                   
                  
                        document.getElementById("row_al_loading_details_sqs.mlife.ah_load.block").style.display='none';
                            //added by ankita on 15 april 2021 for new loading code changes
                            
                            document.getElementById("al_loading_details_sqs.slife.em.value_val").innerHTML="BE";
                            document.getElementById("al_loading_details_sqs.slife.death_per_mille.value_val").innerHTML="BM";
                            document.getElementById("al_loading_details_sqs.slife.death_pursuit_term.value_val").innerHTML="BP";
                            document.getElementById("al_loading_details_sqs.slife.tpd.value_val").innerHTML="BPE";
                            document.getElementById("al_loading_details_sqs.slife.tpd_per_mille.value_val").innerHTML="BPM (%)";
                            document.getElementById("al_loading_details_sqs.slife.tpd_pursuit_term.value_val").innerHTML="BPP (%)";
                            document.getElementById("al_loading_details_sqs.slife.critical_illness.value_val").innerHTML="BC";
                            
                             $('#pdp_pmcg_slife').html('Total and Permanent Disability (TPD)');
                   document.getElementById("toHideForIncome").style.display='none';
                   document.getElementById("toHideForAllCare").style.display='table-row';
                   
                   
                   
                   document.getElementById("tmcc_2_label").innerHTML = "Total Multi Crisis Care 2"
                    document.getElementById("optional_benefits.id").style.display='none';
                  
                
                                        
                                 }
                                   
                   
                   
                   
                   
                   
                   
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUsignature income")//added condition for PRUsignature income by ankita on 9 July 2018
                   {
                   
                   //Added
                   
                   
                   var htmlDivDynamicElement= "<div class=\"table-responsive\" id=\"headerForIncome\" style=\"display:none;\"><table class=\"table rider_header marginBottom5 marginTop5\"><tr class=\"tableBorderBottom\"><td class=\"benefitsDetailsUSD paddingLeft15\" rowspan=\"3\" width=40% valign=\"bottom\" id=\"changeNameIncome1\" style=\"width: 30%\">Details of Benefit</td><td colspan=\"8\" class=\"benefitsDetailsUSD\" id=\"changeNameIncome2\">% Of The Total Premiums Paid (excluding any Top-up Premium)</td></tr></table></div><div class=\"table-rasponsive grey_gredient\" id=\"idForSignatureIncomeProductIndicator\" style=\"display:none\"><input id=\"al_loading_details_sqs.mlife.loading_value_indicator\" type=\"hidden\" value=\"\"><table class=\"table\" id=\"al_loading_details_sqs.mlife.prusignatureUSD\"><tr id=\"rider_row_al_loading_details_sqs.add\"><td width=44%  class=\"loadingNamePadding\" style=\"width: 80%\">Death / Total and Permanent Disability</td><td width=10% class=\"loadingNamePadding\"><input id=\"al_loading_details_sqs.mlife.loading_value_indicator_125\" name=\"USDloadingValue\"type=\"radio\" class=\"form-control\" /><label for=\"al_loading_details_sqs.mlife.loading_value_indicator_125\" value=\"125\" class=\"marginRight40  \"><change>125%</change></label></label></td><td width=10% class=\"loadingNamePadding\"><input id=\"al_loading_details_sqs.mlife.loading_value_indicator_105\" name=\"USDloadingValue\" type=\"radio\" class=\"form-control\"/><label for=\"al_loading_details_sqs.mlife.loading_value_indicator_105\" value=\"105\" class=\"marginRight40  \"><change>105%</change></label></label></td><td width=60% colspan=\"6\"></td></tr></table></div><div class=\"table-responsive\"  id=\"idForSignatureIncomeProductHeaders\" style=\"display:none\"><table class=\"table rider_header marginBottom5 marginTop5\"><tr class=\"tableBorderBottom\"><td class=\"benefitsDetails\" rowspan=\"3\" width=22% valign=\"bottom\">Details of Benefit</td><td colspan=\"8\" class=\"text_center paddingTop3Bottom2\">Special Terms</td></tr><tr class=\"tableBorderBottom\"><td colspan=\"8\" class=\"text_center paddingTop3Bottom2\">Extra Insurance Charges</td></tr><tr><td class=\"paddingTop5Bottom0 text_center\" width=10%>Loading Code</td><td class=\"paddingTop5Bottom0 text_center\" width=12%>%of <br/>normal rate</td><td class=\"paddingTop5Bottom0 text_center\" width=10%>Loading Code</td><td class=\"paddingTop5Bottom0 text_center\" width=10%>Rate per 1,000 SA</td><td class=\"paddingTop5Bottom0 \" width=10%>Term</td><td class=\"paddingTop5Bottom0 text_center\" width=10%>Loading Code</td><td class=\"paddingTop5Bottom0 text_center\" width=10%>Rate</td><td class=\"paddingTop5Bottom0 \" width=10%>Term</td></tr></table></div>";
                   
                   document.getElementById("idForSignatureIncomeProduct").innerHTML= htmlDivDynamicElement;
                   
                   var htmlElementSecondLifeHeaders ="<table class=\"table rider_header marginBottom5 marginTop5\"><tr class=\"tableBorderBottom\"><td class=\"benefitsDetails\" rowspan=\"3\" width=22% valign=\"bottom\">Details of Benefit</td><td colspan=\"8\" class=\"text_center paddingTop3Bottom2\">Special Terms</td></tr><tr class=\"tableBorderBottom\"><td colspan=\"8\" class=\"text_center paddingTop3Bottom2\">Extra Insurance Charges</td></tr><tr><td class=\"paddingTop5Bottom0 text_center\" width=10%>Loading Code</td><td class=\"paddingTop5Bottom0 text_center\" width=12%>%of <br/>normal rate</td><td class=\"paddingTop5Bottom0 text_center\" width=10%>Loading Code</td><td class=\"paddingTop5Bottom0 text_center\" width=10%>Rate per 1,000 SA</td><td class=\"paddingTop5Bottom0 \" width=10%>Term</td><td class=\"paddingTop5Bottom0 text_center\" width=10%>Loading Code</td><td class=\"paddingTop5Bottom0 text_center\" width=10%>Rate</td><td class=\"paddingTop5Bottom0 \" width=10%>Term</td></tr></table>";
                   
                   document.getElementById("idForSignatureIncomeProductSecondLife").innerHTML= htmlElementSecondLifeHeaders;
                   
                   $(escape_jq('al_loading_details_sqs.slife.tpd.value')).css("margin-top","5px");
                   $(escape_jq('al_loading_details_sqs.slife.tpd_per_mille.value')).css("margin-top","5px");
                   $(escape_jq('al_loading_details_sqs.slife.tpd_per_mille_term.value')).css("margin-top","5px");
                   $(escape_jq('al_loading_details_sqs.slife.tpd_pursuit.value')).css("margin-top","5px");
                   $(escape_jq('al_loading_details_sqs.slife.tpd_pursuit_term.value')).css("margin-top","5px");
                   
                   document.getElementById("usdLoading").innerHTML="";
                   document.getElementById("idForSignatureIncomeProduct").style.display='block';
                   document.getElementById("idForSignatureIncomeProductSecondLife").style.display='block';
                   document.getElementById("toHideForIncome").style.display='none';
                   // toHideForIncome
                   document.getElementById("headerForIncome").style.display='block';
                   document.getElementById("idForSignatureIncomeProductIndicator").style.display='block';
                   document.getElementById("idForSignatureIncomeProductHeaders").style.display='block';
                   document.getElementById("idToHideForIncome").style.display='none';
                   document.getElementById("al_loading_details_sqs.mlife.addClassForPLPartner").style.display='none';
                   
                   document.getElementById("rider_row_al_loading_details_sqs.add_on").style.display='none';
                   document.getElementById("row_al_loading_details_sqs.mlife.ah_load.block").style.display='none';
                   document.getElementById("row_critical_illness_benefits").style.display='block';
                   document.getElementById("row_al_loading_details_sqs.mlife.disability.block").style.display='none';
                   document.getElementById("al_loading_details_sqs.mlife.critical_illness.value_val").innerHTML="C";
                   document.getElementById("headerOtherThanPruLifePartner").style.display='none';
                   document.getElementById("rider_row_al_loading_details_sqs.add").style.display='block';
                   document.getElementById("changeNameIncome1").innerHTML="Details of Benefit";
                   document.getElementById("changeNameIncome2").innerHTML="% of The Total Insurance Premium Paid";
                   
                   
                   document.getElementById("row_optional_benefits").style.display='none';
                   document.getElementById("al_loading_details_sqs.mlife.prusignatureUSD").style.display='block';
                   
                   if(obj_prochoice["al_sqs_details.mlife.il_anb"]<=50)
                   {
                   console.log("ANB Mlife:"+obj_prochoice["al_sqs_details.mlife.il_anb"]);
                   document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator_125").checked=true;
                   document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator_105").checked=false;
                   }
                   else
                   {
                   document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator_105").checked=true;
                   document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator_125").checked=false;
                   document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator_125").disabled=true;
                   }
                   
                   /*document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="E";
                    document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="M";
                    document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="P";
                    document.getElementById("al_loading_details_sqs.mlife.tpd.value_val").innerHTML="PE";
                    document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value_val").innerHTML="PM (%)";
                    document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value_val").innerHTML="PP (%)";*/
                   
                   
                   
                   
                   
                   
                   $('#tpd_id').html('Total & Permanent Disability (TPD)');
                   document.getElementById("tpd_id_italic").innerHTML="";
                   $("#tpd_id").removeClass("red");
                   
                   
                   
                   // second life
                   
                   document.getElementById("al_loading_details_sqs.slife.em.value_val").innerHTML="SE";
                   document.getElementById("al_loading_details_sqs.slife.death_per_mille.value_val").innerHTML="SM";
                   document.getElementById("al_loading_details_sqs.slife.death_pursuit_term.value_val").innerHTML="SP";
                   document.getElementById("al_loading_details_sqs.slife.tpd.value_val").innerHTML="SPE";
                   document.getElementById("al_loading_details_sqs.slife.tpd_per_mille.value_val").innerHTML="SPM (%)";
                   document.getElementById("al_loading_details_sqs.slife.tpd_pursuit_term.value_val").innerHTML="SPP (%)";
                   document.getElementById("al_loading_details_sqs.slife.critical_illness.value_val").innerHTML="SC";
                   document.getElementById("optional_benefits.id").style.display='none';
                   $('#pdp_id').html('Total & Permanent Disability (TPD)');
                   document.getElementById("pdp_id_italic").innerHTML="";
                   $("#pdp_id").removeClass("red");
                   
                   
                   
                   }
                   else  if(obj_prochoice["al_sqs_details.product_name"] == "PRUmy child" || obj_prochoice["al_sqs_details.product_name"] == "PRUmy kid")
                   {
                   //For Mainlife
                   document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="JE";
                   document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="JM";
                   document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="JP";
                   document.getElementById("al_loading_details_sqs.mlife.tpd.value_val").innerHTML="JPE";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value_val").innerHTML="JPM (%)";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value_val").innerHTML="JPP (%)";
                   document.getElementById("al_loading_details_sqs.mlife.ah_add.value_val").innerHTML="AH";
                   document.getElementById("al_loading_details_sqs.mlife.critical_illness.value_val").innerHTML="JC";
                   document.getElementById("al_loading_details_sqs.mlife.ah_ecp.value_val").innerHTML="CEW";
                   document.getElementById("al_loading_details_sqs.mlife.ah_dp.value_val").innerHTML="X";
                   document.getElementById("al_loading_details_sqs.mlife.ah_amr.value_val").innerHTML="AH";
                   document.getElementById("al_loading_details_sqs.mlife.ah_adi.value_val").innerHTML="AH";
                   document.getElementById("al_loading_details_sqs.mlife.ah_pmed.value_val").innerHTML="AH";
                   document.getElementById("al_loading_details_sqs.mlife.ah_hb.value_val").innerHTML="AH";
                   document.getElementById("al_loading_details_sqs.mlife.ah_phl.value_val").innerHTML="AH";
                   document.getElementById("al_loading_details_sqs.mlife.ah_pec.value_val").innerHTML="JCE";
                    document.getElementById("rider_row_al_loading_details_sqs.add_on").style.display="table-row";
                   
                   //For Second Life
                   document.getElementById("al_loading_details_sqs.slife.em.value_val").innerHTML="PE";
                   document.getElementById("al_loading_details_sqs.slife.death_per_mille.value_val").innerHTML="PM";
                   document.getElementById("al_loading_details_sqs.slife.death_pursuit_term.value_val").innerHTML="PP";
                   document.getElementById("al_loading_details_sqs.slife.tpd.value_val").innerHTML="PPE";
                   document.getElementById("al_loading_details_sqs.slife.tpd_per_mille.value_val").innerHTML="PPM (%)";
                   document.getElementById("al_loading_details_sqs.slife.tpd_pursuit_term.value_val").innerHTML="PPP (%)";
                   document.getElementById("al_loading_details_sqs.slife.critical_illness.value_val").innerHTML="PC";
                   
                   //Third Life
                   document.getElementById("al_loading_details_sqs.tlife.em.value_val").innerHTML="XE";
                   document.getElementById("al_loading_details_sqs.tlife.death_per_mille.value_val").innerHTML="XM";
                   document.getElementById("al_loading_details_sqs.tlife.death_pursuit_term.value_val").innerHTML="XP";
                   document.getElementById("al_loading_details_sqs.tlife.tpd.value_val").innerHTML="XPE";
                   document.getElementById("al_loading_details_sqs.tlife.tpd_per_mille.value_val").innerHTML="XPM (%)";
                   document.getElementById("al_loading_details_sqs.tlife.tpd_pursuit_term.value_val").innerHTML="XPP (%)";
                   document.getElementById("al_loading_details_sqs.tlife.critical_illness.value_val").innerHTML="XC";
                   
                   }else if(obj_prochoice["al_sqs_details.product_name"] == "PRUlink million" || obj_prochoice["al_sqs_details.product_name"] == "PRUwealth" || obj_prochoice["al_sqs_details.product_name"] == "PRUWealth Plus" || obj_prochoice["al_sqs_details.product_name"] == "PRUWealth Max" || obj_prochoice["al_sqs_details.product_name"] === "PRUSignature Vanguard" || obj_prochoice["al_sqs_details.product_name"] === "PRUWealth Enrich")
                   {
                       //For Mainlife
                       document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="E";
                       document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="M";
                       document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="P";
                       document.getElementById("al_loading_details_sqs.mlife.tpd.value_val").innerHTML="PE";
                       document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value_val").innerHTML="PM (%)";
                       document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value_val").innerHTML="PP (%)";
                       document.getElementById("al_loading_details_sqs.mlife.critical_illness.value_val").innerHTML="C";
                       
                    document.getElementById("rider_row_al_loading_details_sqs.add_on").style.display="none";
                    
						if(obj_prochoice["al_sqs_details.product_name"] == "PRUwealth" || obj_prochoice["al_sqs_details.product_name"] == "PRUWealth Plus" || obj_prochoice["al_sqs_details.product_name"] == "PRUWealth Max" || obj_prochoice["al_sqs_details.product_name"] === "PRUSignature Vanguard" || obj_prochoice["al_sqs_details.product_name"] === "PRUWealth Enrich")
                        {
						   document.getElementById("row_al_loading_details_sqs.mlife.ah_load.block").style.display="table-row";
						   document.getElementById("al_loading_details_sqs.mlife.ah_load.value_val").innerHTML="AH";
						   }
                       
                       //For Second Life
                       document.getElementById("al_loading_details_sqs.slife.em.value_val").innerHTML="SE";
                       document.getElementById("al_loading_details_sqs.slife.death_per_mille.value_val").innerHTML="SM";
                       document.getElementById("al_loading_details_sqs.slife.death_pursuit_term.value_val").innerHTML="SP";
                       document.getElementById("al_loading_details_sqs.slife.tpd.value_val").innerHTML="SPE";
                       document.getElementById("al_loading_details_sqs.slife.tpd_per_mille.value_val").innerHTML="SPM (%)";
                       document.getElementById("al_loading_details_sqs.slife.tpd_pursuit_term.value_val").innerHTML="SPP (%)";
                       document.getElementById("al_loading_details_sqs.slife.critical_illness.value_val").innerHTML="SC";
                   
                   if(obj_prochoice["al_sqs_details.product_name"] == "PRUWealth Plus" || obj_prochoice["al_sqs_details.product_name"] == "PRUWealth Max" || obj_prochoice["al_sqs_details.product_name"] === "PRUSignature Vanguard" || obj_prochoice["al_sqs_details.product_name"] == "PRUWealth Enrich")
                   {
                   $('#tpd_id').html('Total & Permanent Disability (TPD)');
                   document.getElementById("tpd_id_italic").innerHTML="";
                   $("#tpd_id").removeClass("red");
                   
                   if(obj_slife["al_person_details.slife.relationship"] =="Parent")
                   {
                   console.log("in Parent Checking"+obj_slife["al_person_details.slife.relationship"] == "Parent");
                   document.getElementById("al_loading_details_sqs.slife.em.value_val").innerHTML="PE";
                   document.getElementById("al_loading_details_sqs.slife.death_per_mille.value_val").innerHTML="PM";
                   document.getElementById("al_loading_details_sqs.slife.death_pursuit_term.value_val").innerHTML="PP";
                   document.getElementById("al_loading_details_sqs.slife.tpd.value_val").innerHTML="PPE";
                   document.getElementById("al_loading_details_sqs.slife.tpd_per_mille.value_val").innerHTML="PPM (%)";
                   document.getElementById("al_loading_details_sqs.slife.tpd_pursuit_term.value_val").innerHTML="PPP (%)";
                   document.getElementById("al_loading_details_sqs.slife.critical_illness.value_val").innerHTML="PC";
                   }
                   
                   $('#pdp_id').html('Total & Permanent Disability (TPD)');
                   document.getElementById("pdp_id_italic").innerHTML="";
                   $("#pdp_id").removeClass("red");
                   
                   
                   if(obj_prochoice["al_sqs_details.mlife.il_anb"]<=18)
                   {
                   console.log("millennium age check condition--->");
                   
                   document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="JE";
                   document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="JM";
                   document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="P";
                   document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="JP";
                   //
                   
                   document.getElementById("al_loading_details_sqs.mlife.tpd.value_val").innerHTML="JPE";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value_val").innerHTML="JPM (%)";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value_val").innerHTML="JPP (%)";
                   document.getElementById("al_loading_details_sqs.mlife.critical_illness.value_val").innerHTML="JC";
                   
                   
                   
                   }
                       //Added for August release 2023 by sachin.
                    if(obj_prochoice["al_sqs_details.product_name"] == "PRUWealth Enrich"){
                   document.getElementById("al_loading_details_sqs.tlife.em.value_val").innerHTML="XE";
                   document.getElementById("al_loading_details_sqs.tlife.death_per_mille.value_val").innerHTML="XM";
                   document.getElementById("al_loading_details_sqs.tlife.death_pursuit_term.value_val").innerHTML="XP";
                   document.getElementById("al_loading_details_sqs.tlife.tpd.value_val").innerHTML="XPE";
                   document.getElementById("al_loading_details_sqs.tlife.tpd_per_mille.value_val").innerHTML="XPM (%)";
                   document.getElementById("al_loading_details_sqs.tlife.tpd_pursuit_term.value_val").innerHTML="XPP (%)";
                   document.getElementById("al_loading_details_sqs.tlife.critical_illness.value_val").innerHTML="XC";
                 //  $('#thirdtpd_label').html('Total & Permanent Disability (TPD)');
                        $('#third_tpd_id__italic').html('Total and Permanent Disability (TPD)');
                       // $('#tpd_id').html('Total and Permanent Disability (TPD)');
                        document.getElementById("third_tpd_id").style.display='none'
                    }
                   
                   
                   }
                   if(obj_prochoice["al_sqs_details.product_name"] === "PRUSignature Vanguard")
                   {
                      $('#tpd_id').html('Total and Permanent Disability (TPD)');
                   }
                   
                   
                  
                   
                   
                   
                   
                   
                   
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] === "PRUCritical Protect")
                   {
                        //For Mainlife
                       //commented by ankita as per policy limit file 1.0 for bundle product on 3 march 2023
                       /*document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="E";
                        document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="M";
                        document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="P";*/
                        document.getElementById("idToHideForSignatureIncome").style.display="none"; document.getElementById("al_loading_details_sqs.mlife.critical_illness.value_val").innerHTML="C";
                        
                     document.getElementById("rider_row_al_loading_details_sqs.add_on").style.display="none";
                    if(obj_prochoice["al_sqs_details.mlife.il_anb"]<=18)
                    {
                    console.log("millennium age check condition--->");
                    
                    //document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="JE";
                    //document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="JM";
                     //document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="JP";
                    document.getElementById("al_loading_details_sqs.mlife.critical_illness.value_val").innerHTML="JC";
                    
                    
                    
                    }
                   document.getElementById("row_al_loading_details_sqs.mlife.disability.block").style.display="none";
                   document.getElementById("row_al_loading_details_sqs.mlife.ah_load.block").style.display="none";
                   document.getElementById("row_optional_benefits").style.display="none";
                   
                   $(".second_life,.third_life").hide();
                    
                    }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUmy legacy" || obj_prochoice["al_sqs_details.product_name"] == "PRUmy gift")//Added By Rahul
                   {
                   //For Mainlife
                   document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="E";
                   document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="M";
                   document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="P";
                   document.getElementById("al_loading_details_sqs.mlife.tpd.value_val").innerHTML="PE";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value_val").innerHTML="PM (%)";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value_val").innerHTML="PP (%)";
                   document.getElementById("al_loading_details_sqs.mlife.critical_illness.value_val").innerHTML="C";
                   document.getElementById("rider_row_al_loading_details_sqs.add_on").style.display="none";
                   
                   //For Second Life
                   document.getElementById("al_loading_details_sqs.slife.em.value_val").innerHTML="SE";
                   document.getElementById("al_loading_details_sqs.slife.death_per_mille.value_val").innerHTML="SM";
                   document.getElementById("al_loading_details_sqs.slife.death_pursuit_term.value_val").innerHTML="SP";
                   document.getElementById("al_loading_details_sqs.slife.tpd.value_val").innerHTML="SPE";
                   document.getElementById("al_loading_details_sqs.slife.tpd_per_mille.value_val").innerHTML="SPM (%)";
                   document.getElementById("al_loading_details_sqs.slife.tpd_pursuit_term.value_val").innerHTML="SPP (%)";
                   document.getElementById("al_loading_details_sqs.slife.critical_illness.value_val").innerHTML="SC";
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUcancer plan" || obj_prochoice["al_sqs_details.product_name"] == "PRUcancer X")//Added condition for PRUcancer X product by ankita on 5 June 2018
                   {
                       document.getElementById("loading_cancer").style.display="block";
                       document.getElementById("forOther").style.display="none";
                       if(mlife_anb<=16)
                       {
                            document.getElementById("loading_code_cancer").innerHTML="JCA"
                       }
                       else
                       {
                            document.getElementById("loading_code_cancer").innerHTML="CA"
                       }
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUlady" || obj_prochoice["al_sqs_details.product_name"] == "PRUMan"
                           || obj_prochoice["al_sqs_details.product_name"] == "PRULady_PRL")
                   {
//                   document.getElementById("loading_cancer").style.display="block";
//                   document.getElementById("forOther").style.display="none";
                   
                       document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="E";
                       document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="M";
                       document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="P";
                       document.getElementById("al_loading_details_sqs.mlife.tpd.value_val").innerHTML="PE";
                       //document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value_val").innerHTML="PM (%)";
                       //document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value_val").innerHTML="PP (%)";
                       document.getElementById("al_loading_details_sqs.mlife.critical_illness.value_val").innerHTML="C";
                       document.getElementById("rider_row_al_loading_details_sqs.add_on").style.display="none";
                       document.getElementById("loading_cancer").style.display="none";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value").style.display="none";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille_term.value").style.display="none";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit.value").style.display="none";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value").style.display="none";
                   
                   $(".second_life,.third_life").hide();
                   document.getElementById("row_optional_benefits").style.display="none";
                       //Pradnya: added below if for (TPD) on loading page
                       if( obj_prochoice["al_sqs_details.product_name"] == "PRUMan"
                               || obj_prochoice["al_sqs_details.product_name"] == "PRULady_PRL")
                       {
                           
                           $('#tpd_id').html('Total & Permanent Disability (TPD)');
                           document.getElementById("tpd_id_italic").innerHTML="";
                           $("#tpd_id").removeClass("red");
                       }
                       else{
                   // Added by Shivani
                   $('#tpd_id').html('Total & Permanent Disability');
                   document.getElementById("tpd_id_italic").innerHTML="";
                   $("#tpd_id").removeClass("red");
                       }
                       
                       if(mlife_anb<=16 && (obj_prochoice["al_sqs_details.product_name"] == "PRUMan"
                          || obj_prochoice["al_sqs_details.product_name"] == "PRULady_PRL")) //Added by Paromita on 7th Dec
                       {
                       
                           document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="JE";
                           document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="JM";
                           document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="JP";
                           document.getElementById("al_loading_details_sqs.mlife.tpd.value_val").innerHTML="JPE";
                           document.getElementById("al_loading_details_sqs.mlife.critical_illness.value_val").innerHTML="JC";
                    
                       }
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUheritage")
                   {
                       //For Mainlife
                       document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="E";
                       document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="M";
                       document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="P";
                       document.getElementById("al_loading_details_sqs.mlife.tpd.value_val").innerHTML="PE";
                   
                       document.getElementById("al_loading_details_sqs.mlife.critical_illness.value_val").innerHTML="C";
                       document.getElementById("rider_row_al_loading_details_sqs.add_on").style.display="none";
                       document.getElementById("loading_cancer").style.display="none";
                       document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value").style.display="none";
                       document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille_term.value").style.display="none";
                       document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit.value").style.display="none";
                       document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value").style.display="none";
                   document.getElementById("al_loading_details_sqs.mlife.critical_illness.value_val").style.display="none";
                   document.getElementById("al_loading_details_sqs.mlife.critical_illness.value").style.display="none";
                    document.getElementById("tpd_id").innerHTML="Total and Permanent Disability";
                   document.getElementById("tpd_id_italic").innerHTML="";
                   
                   $("#tpd_id").removeClass("red");
                   
                  // document.getElementById("al_loading_details_sqs.mlife.death_per_mille_term.value").style.display="none";
                  // document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value").style.display="none";
                   document.getElementById("row_critical_illness_benefits").style.display="none";
                   
                       //$(".second_life,.third_life").hide();
                       document.getElementById("row_optional_benefits").style.display="none";
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUsignature" )
                   {
                   //For Mainlife
                   document.getElementById("row_optional_benefits").style.display="none";
                   document.getElementById("row_critical_illness_benefits").style.display="none";
                   document.getElementById("rider_row_al_loading_details_sqs.add_on").style.display="none";
                   
                   document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="E";
                   document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="M";
                   document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="P";
                   document.getElementById("al_loading_details_sqs.mlife.tpd.value_val").innerHTML="PE";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value_val").innerHTML="PM (%)";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value_val").innerHTML="PP (%)";
                   $(".second_life,.third_life").hide();
                   
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUsignature USD")
                   {
                   //For Mainlife
                   document.getElementById("row_optional_benefits").style.display="none";
                   document.getElementById("row_critical_illness_benefits").style.display="none";
                   document.getElementById("rider_row_al_loading_details_sqs.add_on").style.display="none";
                   
                  /* document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="E";
                   document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="M";
                   document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="P";
                   document.getElementById("al_loading_details_sqs.mlife.tpd.value_val").innerHTML="PE";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value_val").innerHTML="PM (%)";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value_val").innerHTML="PP (%)";*/
                   $(escape_jq("al_loading_details_sqs.mlife.addClassForPLPartner")).hide();
                   $("#usdLoading").css("display","block");
                   $("#headerOtherThanPruLifePartner").css("display","none");
                   $("#headerForUSD").css("display","block")
                   $(".first_life,.second_life,.third_life").hide();
                   
                   }
                   // Added by Shivani for MAr2022 release
                   else if(obj_prochoice["al_sqs_details.product_name"] === "PRULink Supreme" || obj_prochoice["al_sqs_details.product_name"] === "PRUElite Invest" || obj_prochoice["al_sqs_details.product_name"] === "PRUSignature GrowthPlus" || obj_prochoice["al_sqs_details.product_name"] === "PRULink Supreme Plus")
                    {
                    //For Mainlife
                    document.getElementById("row_optional_benefits").style.display="none";
                    document.getElementById("row_critical_illness_benefits").style.display="none";
                    document.getElementById("rider_row_al_loading_details_sqs.add_on").style.display="none";
                
                    $(escape_jq("al_loading_details_sqs.mlife.addClassForPLPartner")).hide();
                    $("#usdLoading").css("display","block");
                    $("#headerOtherThanPruLifePartner").css("display","none");
                    $("#headerForUSD").css("display","block");
                    $("#headerForUSD_1").html('% of the Total Insurance Premium Paid'); // added by Shivani for DEf- 120 for PRULink Supreme
                    document.getElementById("headerForUSD_2").innerHTML="Death / Total & Permanent Disability (TPD)"; // added by Shivani for DEf- 120 for PRULink Supreme
                    $(".second_life,.third_life").hide();
                    
                    }
                   
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUsignature infinite")//Added By Rahul
                   {
                   //For Mainlife
                   document.getElementById("row_optional_benefits").style.display="none";
                   document.getElementById("row_critical_illness_benefits").style.display="none";
                   document.getElementById("rider_row_al_loading_details_sqs.add_on").style.display="none";
                   
                   document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="E";
                   document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="M";
                   document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="P";
                   document.getElementById("al_loading_details_sqs.mlife.tpd.value_val").innerHTML="PE";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value_val").innerHTML="PM (%)";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value_val").innerHTML="PP (%)";
                   
                   $('#tpd_id').html('Total & Permanent Disability (TPD)');
                   document.getElementById("tpd_id_italic").innerHTML="";
                   $("#tpd_id").removeClass("red");
                   
                   $(".second_life,.third_life").hide();
                   
                   }
                   else if(obj_prochoice["al_sqs_details.product_name"] == "PRUSignature Ace")
                   {
                   //For Mainlife
                   document.getElementById("row_optional_benefits").style.display="none";
                   document.getElementById("row_critical_illness_benefits").style.display="none";
                   document.getElementById("rider_row_al_loading_details_sqs.add_on").style.display="none";
                   
                   document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="E";
                   document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="M";
                   document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="P";
                   document.getElementById("al_loading_details_sqs.mlife.tpd.value_val").innerHTML="PE";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value_val").innerHTML="PM (%)";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value_val").innerHTML="PP (%)";
                   
                   $('#tpd_id').html('Total & Permanent Disability (TPD)');
                   if(obj_prochoice["al_sqs_details.product_name"] == "PRUSignature Ace")
                   {
                        $('#tpd_id').html('Total and Permanent Disability (TPD)');
                        if(obj_prochoice["al_sqs_details.mlife.il_anb"]<=18)
                        {
                   document.getElementById("al_loading_details_sqs.mlife.em.value_val").innerHTML="JE";
                   document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value_val").innerHTML="JM";
                   document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value_val").innerHTML="JP";
                   document.getElementById("al_loading_details_sqs.mlife.tpd.value_val").innerHTML="JPE";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value_val").innerHTML="JPM (%)";
                   document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value_val").innerHTML="JPP (%)";
                   
                        }
                   }
                   document.getElementById("tpd_id_italic").innerHTML="";
                   $("#tpd_id").removeClass("red");
                   
                   $(".second_life,.third_life").hide();
                   
                   }

                       
                   exp_age=obj_prochoice["al_sqs_details.expiry_age"];
                   console.log("exp_age"+exp_age+"mlife_anb"+mlife_anb);
                   console.log("@EXP_AGE-->"+exp_age);
                   console.log("@Main_AGE-->"+mlife_anb);
                   
                   if((obj_prochoice["al_sqs_details.product_name"] == "PRUMillion Cover 2.0" || obj_prochoice["al_sqs_details.product_name"] == "PRUmillion cover" || obj_prochoice["al_sqs_details.product_name"] == "PRUEnhanced Cover") && (obj_prochoice["al_sqs_details.expiry_age"]=="" || obj_prochoice["al_sqs_details.expiry_age"]=="null" || obj_prochoice["al_sqs_details.expiry_age"]==null || obj_prochoice["al_sqs_details.expiry_age"]==undefined)){
                   
                   exp_age=100;
                       
                   }
               
                
                
                   
                basic_term = exp_age - mlife_anb;
    /**********Following code for PRUsignature infinite**********/
                if(obj_prochoice["al_sqs_details.product_name"] == "PRUMy Gift"){
                    
                    if(obj_benefit_selection["al_rider_sqs.basic_plan.rider_term"]!="" && obj_benefit_selection["al_rider_sqs.basic_plan.rider_term"]!="null" && obj_benefit_selection["al_rider_sqs.basic_plan.rider_term"]!=null){
                        
                    
                        basic_term=obj_benefit_selection["al_rider_sqs.basic_plan.rider_term"];
                    
                }
                }
                   
                   console.log("basic_term112:"+basic_term);
                   if(obj_prochoice["al_sqs_details.product_name"]=="PRUmy treasure")
                   {
                   //exp_age=88;//change from 100 to 88 by ankita on 23 June 18
                   basic_term=exp_age - obj_prochoice["al_sqs_details.mlife.il_anb"];
                  
                    }
                   if(obj_prochoice["al_sqs_details.product_name"]=="PRUsignature infinite")
                   {
                   exp_age=100;//expiry age=100 for prusignature infinite //for defect 7182
                   console.log("exp_age-->"+exp_age);
                   basic_term=exp_age - obj_prochoice["al_sqs_details.mlife.il_anb"];
                   console.log("basic_term-->"+basic_term);
                   
                   }
                   if(obj_prochoice["al_sqs_details.product_name"]==="PRUSignature Ace")
                   {
                   exp_age=100;
                   console.log("exp_age-->"+exp_age);
                   basic_term=exp_age - obj_prochoice["al_sqs_details.mlife.il_anb"];
                   console.log("basic_term-->"+basic_term);
                   
                   }
                 
                   if(obj_prochoice["al_sqs_details.product_name"]=="PRUcancer X")//Added by ankita for PRUcancer X product loading
                   {
                   
                   basic_term=10;
                   
                   }
                   if(obj_prochoice["al_sqs_details.product_name"]=="PRUsmart gain" || obj_prochoice["al_sqs_details.product_name"]=="PRULink Cover" || obj_prochoice["al_sqs_details.product_name"]=="PRUMax Cover" || obj_prochoice["al_sqs_details.product_name"]=="PRUSignature Assure" || obj_prochoice["al_sqs_details.product_name"]=="PRUSignature Vanguard" || obj_prochoice["al_sqs_details.product_name"]=="PRUCritical Protect")//added by ankita on 23 June 2018//PRUSignature Vanguard condition added by ankita for defect 616
                   {
                   
                   basic_term = obj_benefit_selection["al_rider_sqs.basic_plan.rider_term"];
                   console.log("basic_term1-->"+basic_term);
                   
                   }

                   
                   
if(obj_prochoice["al_sqs_details.product_name"]=="PRUlife partner")
{
exp_age=obj_benefit_selection["al_rider_sqs.ml_basic_plan.rider_expiry_age"];
if(exp_age==NaN || exp_age=="0") //update condition for Def-3227 - exp_age=="0" : Added by Anjali/Sourabh
{
basic_term=0;
}
else
{
basic_term=exp_age-mlife_anb;
}
}
}
                   if(obj_prochoice["al_sqs_details.product_name"]=="EssentialLife (SP)" || obj_prochoice["al_sqs_details.product_name"]=="PRUSignature Protect")//Abhilash: EssentialLife (SP)_SCB name changed to PRUSignature Protect on 3rd July
                   {
                  
                   basic_term=obj_benefit_selection["al_rider_sqs.basic_plan.rider_term"];
                  
                   
                   }
                   console.log("Term PMCG SSD "+basic_term);
                   if(obj_prochoice["al_sqs_details.product_name"]==="PRUMulti Crisis Guard")
                    {
                    console.log("Check going in if or not");
                    basic_term=obj_benefit_selection["al_rider_sqs.basic_plan.rider_term"];
                   
                    
                    }
                   if(obj_prochoice["al_sqs_details.product_name"]==="PRUCash Enrich" || obj_prochoice["al_sqs_details.product_name"]==="PRUAll Care")
                   {
                      obj_benefit_selection=JSON.parse(clone_benefet_selection);
                      obj_benefit_selection=JSON.parse(obj_benefit_selection);
                      basic_term=obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"];
                      console.log("basic_term PCE:"+basic_term);
                   }
                   
                  if(obj_prochoice["al_sqs_details.product_name"]==="PRUTerm Premier")
                   {
                      obj_benefit_selection=JSON.parse(clone_benefet_selection);
                      obj_benefit_selection=JSON.parse(obj_benefit_selection);
                      basic_term=obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"];
                     console.log("basic_term PCE 1111:"+basic_term);
                   // Added by Shivani for DEF - 10775
                   if(document.getElementById("al_rider_sqs.disability_care.id").checked)
                   {
                   var ptp_term = document.getElementById("al_rider_sqs.ptp.rider_term").value;
                   disability_care_term = Math.min(ptp_term,70-eval(obj_mlife["al_person_details.mlife.anb"]));
                   
                   }
                  /* else
                   {
                   obj_benefit_selection=JSON.parse(clone_benefet_selection);
                   obj_benefit_selection=JSON.parse(obj_benefit_selection);
                   basic_term=document.getElementById("al_rider_sqs.ptp.rider_term").value;
                   console.log("basic_term PCE:"+basic_term);
                   
                   }*/
                   
                   console.log("basic_term PTP :"+disability_care_term);
                   
                   }
//                   if(obj_prochoice["al_sqs_details.product_name"]==="PRUAll Care")
//                    {
//                       obj_benefit_selection=JSON.parse(clone_benefet_selection);
//                       obj_benefit_selection=JSON.parse(obj_benefit_selection);
//                       basic_term=obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"];
//
//                    }
                    

                   
                   if(obj_prochoice["al_sqs_details.product_name"]==="PRUFlexi Gain" || obj_prochoice["al_sqs_details.product_name"]==="PRUGain Plus" || obj_prochoice["al_sqs_details.product_name"]==="PRUEnrich Gain")
                                     {
                                        obj_benefit_selection=JSON.parse(clone_benefet_selection);
                                        obj_benefit_selection=JSON.parse(obj_benefit_selection);
                                        basic_term=obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"];
                                       console.log("basic_term PCE 1111:"+basic_term);
                                   
                                     
                                     }
                   
                   
                   
                                     
                   if(obj_prochoice["al_sqs_details.product_name"]=="PRUValue Gain")
                   {
                  
                   obj_benefit_selection=JSON.parse(clone_benefet_selection);
                   obj_benefit_selection=JSON.parse(obj_benefit_selection);
                   if(obj_prochoice["al_sqs_details.mlife.il_anb"]>=17){
                   document.getElementById("row_prulady_cancer_income_loading").style.display='table-row';
                   document.getElementById("idToHideForPRULadyCancerIncome").style.display='table-row';
                   
                   }
                   basic_term=obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"];
                   console.log("@@Basic Term"+basic_term)
                   console.log("Rider selected"+obj_benefit_selection["al_rider_sqs.prulady_cancer_income.id"]);
                   
                   if(obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"]!="" && obj_mlife["al_person_details.mlife.gender"]=="Female"){
                   
                 
                   if((parseInt(mlife_anb)+parseInt(basic_term)>80 && (obj_benefit_selection["al_rider_sqs.basic_plans.rider_premium"]!="0" && obj_benefit_selection["al_rider_sqs.basic_plans.rider_premium"]!="" && obj_benefit_selection["al_rider_sqs.basic_plans.rider_premium"]!=null && obj_benefit_selection["al_rider_sqs.basic_plans.rider_premium"]!=undefined)) || isriderVisible){
                   
                   document.getElementById("al_loading_details_sqs.mlife.prulady_cancer_income_loading.value").value="";
                   document.getElementById("row_prulady_cancer_income_loading").style.display='none'
                   document.getElementById("idToHideForPRULadyCancerIncome").style.display='none'
                   
                   
                   }
                   
                   
                   }
                  
                   if(obj_mlife["al_person_details.mlife.gender"]!="Female"){
                   
                   document.getElementById("al_loading_details_sqs.mlife.prulady_cancer_income_loading.value").value="";
                   document.getElementById("row_prulady_cancer_income_loading").style.display='none'
                   document.getElementById("idToHideForPRULadyCancerIncome").style.display='none'
                   
                   }
                   
                   
                  if(riderArray.length != 0)
                   {
                    if(riderArray.includes("prulady_cancer_income"))
                   {
                   document.getElementById("al_loading_details_sqs.mlife.prulady_cancer_income_loading.value").value="";
                   document.getElementById("row_prulady_cancer_income_loading").style.display='none'
                   document.getElementById("idToHideForPRULadyCancerIncome").style.display='none'
                   
                   }
                   
                   }
                
                   
                   if(productCertified != "undefined" && productCertified!="")
                   {
                   if(!(productCertified.includes("TR15_Yes")  || productCertified == ""))
                   {
                   document.getElementById("al_loading_details_sqs.mlife.prulady_cancer_income_loading.value").value="";
                   document.getElementById("row_prulady_cancer_income_loading").style.display='none'
                   document.getElementById("idToHideForPRULadyCancerIncome").style.display='none'
                   
                   }
                   
                   if((referral_PlC.indexOf("TR15")<0 && referral_Database.length!=0 && referral_Database.length!='0'))
                   {
                   document.getElementById("al_loading_details_sqs.mlife.prulady_cancer_income_loading.value").value="";
                   document.getElementById("row_prulady_cancer_income_loading").style.display='none'
                   document.getElementById("idToHideForPRULadyCancerIncome").style.display='none'
                   
                   }
                   
                   
                   }
                   
                   
                   }
                   
                   
                   
                   
                   
                   
                   
                //Get Loading data
                js_get_var("loading_details_response", function(loading_res)
                {
                    if(loading_res != "" && loading_res != null && loading_res != "null"  && loading_res != "(null)")
                    {
                        obj_loaddata = JSON.parse(loading_res);
                        document.getElementById("al_loading_details_sqs.mlife.em.value").value = obj_loaddata["al_loading_details_sqs.mlife.em.value"];
                            document.getElementById("al_loading_details_sqs.mlife.prulady_cancer_income_loading.value").value = obj_loaddata["al_loading_details_sqs.mlife.prulady_cancer_income_loading.value"];
                        document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value").value = obj_loaddata["al_loading_details_sqs.mlife.death_per_mille.value"];
                        document.getElementById("al_loading_details_sqs.mlife.death_per_mille_term.value").value = obj_loaddata["al_loading_details_sqs.mlife.death_per_mille_term.value"];
                        document.getElementById("al_loading_details_sqs.mlife.death_pursuit.value").value = obj_loaddata["al_loading_details_sqs.mlife.death_pursuit.value"];
                        document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value").value = obj_loaddata["al_loading_details_sqs.mlife.death_pursuit_term.value"];
                        document.getElementById("al_loading_details_sqs.mlife.tpd.value").value = obj_loaddata["al_loading_details_sqs.mlife.tpd.value"];
                        document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value").value = obj_loaddata["al_loading_details_sqs.mlife.tpd_per_mille.value"];
                        document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille_term.value").value = obj_loaddata["al_loading_details_sqs.mlife.tpd_per_mille_term.value"];
                        document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit.value").value = obj_loaddata["al_loading_details_sqs.mlife.tpd_pursuit.value"];
                        document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value").value = obj_loaddata["al_loading_details_sqs.mlife.tpd_pursuit_term.value"];
                        document.getElementById("al_loading_details_sqs.mlife.ah_add.value").value = obj_loaddata["al_loading_details_sqs.mlife.ah_add.value"];
                        document.getElementById("al_loading_details_sqs.mlife.critical_illness.value").value = obj_loaddata["al_loading_details_sqs.mlife.critical_illness.value"];
                        document.getElementById("al_loading_details_sqs.mlife.ah_ecp.value").value = obj_loaddata["al_loading_details_sqs.mlife.ah_ecp.value"];
                        document.getElementById("al_loading_details_sqs.mlife.ah_dp.value").value = obj_loaddata["al_loading_details_sqs.mlife.ah_dp.value"];
                        document.getElementById("al_loading_details_sqs.mlife.ah_amr.value").value = obj_loaddata["al_loading_details_sqs.mlife.ah_amr.value"];
                        document.getElementById("al_loading_details_sqs.mlife.ah_adi.value").value = obj_loaddata["al_loading_details_sqs.mlife.ah_adi.value"];
                        document.getElementById("al_loading_details_sqs.mlife.ah_pmed.value").value = obj_loaddata["al_loading_details_sqs.mlife.ah_pmed.value"];
                        document.getElementById("al_loading_details_sqs.mlife.ah_hb.value").value = obj_loaddata["al_loading_details_sqs.mlife.ah_hb.value"];
                        document.getElementById("al_loading_details_sqs.mlife.ah_phl.value").value = obj_loaddata["al_loading_details_sqs.mlife.ah_phl.value"];
                        document.getElementById("al_loading_details_sqs.mlife.ah_pec.value").value = obj_loaddata["al_loading_details_sqs.mlife.ah_pec.value"];
                        document.getElementById("al_loading_details_sqs.mlife.di.value").value = obj_loaddata["al_loading_details_sqs.mlife.di.value"];
                        document.getElementById("al_loading_details_sqs.mlife.di_per_mille.value").value = obj_loaddata["al_loading_details_sqs.mlife.di_per_mille.value"];
                        document.getElementById("al_loading_details_sqs.mlife.di_per_mille_term.value").value = obj_loaddata["al_loading_details_sqs.mlife.di_per_mille_term.value"];
                        document.getElementById("al_loading_details_sqs.mlife.di_pursuit.value").value = obj_loaddata["al_loading_details_sqs.mlife.di_pursuit.value"];
                        document.getElementById("al_loading_details_sqs.mlife.di_pursuit_term.value").value = obj_loaddata["al_loading_details_sqs.mlife.di_pursuit_term.value"];
                        document.getElementById("al_loading_details_sqs.mlife.ah_add_double.value").value=obj_loaddata["al_loading_details_sqs.mlife.ah_add_double.value"];
                           
                        document.getElementById("al_loading_details_sqs.slife.em.value").value = obj_loaddata["al_loading_details_sqs.slife.em.value"];
                        document.getElementById("al_loading_details_sqs.slife.death_per_mille.value").value = obj_loaddata["al_loading_details_sqs.slife.death_per_mille.value"];
                        document.getElementById("al_loading_details_sqs.slife.death_per_mille_term.value").value = obj_loaddata["al_loading_details_sqs.slife.death_per_mille_term.value"];
                        document.getElementById("al_loading_details_sqs.slife.death_pursuit.value").value = obj_loaddata["al_loading_details_sqs.slife.death_pursuit.value"];
                        document.getElementById("al_loading_details_sqs.slife.death_pursuit_term.value").value = obj_loaddata["al_loading_details_sqs.slife.death_pursuit_term.value"];
                        document.getElementById("al_loading_details_sqs.slife.tpd.value").value = obj_loaddata["al_loading_details_sqs.slife.tpd.value"];
                        document.getElementById("al_loading_details_sqs.slife.tpd_per_mille.value").value = obj_loaddata["al_loading_details_sqs.slife.tpd_per_mille.value"];
                        document.getElementById("al_loading_details_sqs.slife.tpd_per_mille_term.value").value = obj_loaddata["al_loading_details_sqs.slife.tpd_per_mille_term.value"];
                        document.getElementById("al_loading_details_sqs.slife.tpd_pursuit.value").value = obj_loaddata["al_loading_details_sqs.slife.tpd_pursuit.value"];
                        document.getElementById("al_loading_details_sqs.slife.tpd_pursuit_term.value").value = obj_loaddata["al_loading_details_sqs.slife.tpd_pursuit_term.value"];
                        document.getElementById("al_loading_details_sqs.slife.critical_illness.value").value = obj_loaddata["al_loading_details_sqs.slife.critical_illness.value"];
                        document.getElementById("al_loading_details_sqs.slife.di.value").value = obj_loaddata["al_loading_details_sqs.slife.di.value"];
                        document.getElementById("al_loading_details_sqs.slife.di_per_mille.value").value = obj_loaddata["al_loading_details_sqs.slife.di_per_mille.value"];
                        document.getElementById("al_loading_details_sqs.slife.di_per_mille_term.value").value = obj_loaddata["al_loading_details_sqs.slife.di_per_mille_term.value"];
                        document.getElementById("al_loading_details_sqs.slife.di_pursuit.value").value = obj_loaddata["al_loading_details_sqs.slife.di_pursuit.value"];
                        document.getElementById("al_loading_details_sqs.slife.di_pursuit_term.value").value = obj_loaddata["al_loading_details_sqs.slife.di_pursuit_term.value"];
                        document.getElementById("al_loading_details_sqs.slife.ah_add_double.value").value=obj_loaddata["al_loading_details_sqs.slife.ah_add_double.value"];

                        document.getElementById("al_loading_details_sqs.tlife.em.value").value = obj_loaddata["al_loading_details_sqs.tlife.em.value"];
                        document.getElementById("al_loading_details_sqs.tlife.death_per_mille.value").value = obj_loaddata["al_loading_details_sqs.tlife.death_per_mille.value"];
                        document.getElementById("al_loading_details_sqs.tlife.death_per_mille_term.value").value = obj_loaddata["al_loading_details_sqs.tlife.death_per_mille_term.value"];
                        document.getElementById("al_loading_details_sqs.tlife.death_pursuit.value").value = obj_loaddata["al_loading_details_sqs.tlife.death_pursuit.value"];
                        document.getElementById("al_loading_details_sqs.tlife.death_pursuit_term.value").value = obj_loaddata["al_loading_details_sqs.tlife.death_pursuit_term.value"];
                        document.getElementById("al_loading_details_sqs.tlife.tpd.value").value = obj_loaddata["al_loading_details_sqs.tlife.tpd.value"];
                        document.getElementById("al_loading_details_sqs.tlife.tpd_per_mille.value").value = obj_loaddata["al_loading_details_sqs.tlife.tpd_per_mille.value"];
                        document.getElementById("al_loading_details_sqs.tlife.tpd_per_mille_term.value").value = obj_loaddata["al_loading_details_sqs.tlife.tpd_per_mille_term.value"];
                        document.getElementById("al_loading_details_sqs.tlife.tpd_pursuit.value").value = obj_loaddata["al_loading_details_sqs.tlife.tpd_pursuit.value"];
                        document.getElementById("al_loading_details_sqs.tlife.tpd_pursuit_term.value").value = obj_loaddata["al_loading_details_sqs.tlife.tpd_pursuit_term.value"];
                        document.getElementById("al_loading_details_sqs.tlife.critical_illness.value").value = obj_loaddata["al_loading_details_sqs.tlife.critical_illness.value"];
                           console.log("---------->"+obj_loaddata["al_loading_details_sqs.mlife.ca.value"]);
                        document.getElementById("al_loading_details_sqs.mlife.ca.value").value=obj_loaddata["al_loading_details_sqs.mlife.ca.value"];
                        document.getElementById("al_loading_details_sqs.mlife.ah_load.value").value=obj_loaddata["al_loading_details_sqs.mlife.ah_load.value"];
                        
                           document.getElementById("al_loading_details_sqs.mlife.millennium_ah_add.value").value=obj_loaddata["al_loading_details_sqs.mlife.millennium_ah_add.value"];
                           document.getElementById("al_loading_details_sqs.mlife.ah_phl.value_millennium").value=obj_loaddata["al_loading_details_sqs.mlife.ah_phl.value_millennium"];
                           document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator").value=obj_loaddata["al_loading_details_sqs.mlife.loading_value_indicator"];
                           //added by ankita on 26 July 2019
                           document.getElementById("al_loading_details_sqs.mlife.multi_crisis_care.value").value=obj_loaddata["al_loading_details_sqs.mlife.multi_crisis_care.value"];
                           document.getElementById("al_loading_details_sqs.mlife.early_crisis_care.value").value=obj_loaddata["al_loading_details_sqs.mlife.early_crisis_care.value"];
                           document.getElementById("al_loading_details_sqs.mlife.total_multi_crisis_care.value").value=obj_loaddata["al_loading_details_sqs.mlife.total_multi_crisis_care.value"];
                            document.getElementById("al_loading_details_sqs.mlife.post_surgery_recovery_benefits.value").value=obj_loaddata["al_loading_details_sqs.mlife.post_surgery_recovery_benefits.value"];
                             document.getElementById("al_loading_details_sqs.mlife.intensive_care_support_benefits.value").value=obj_loaddata["al_loading_details_sqs.mlife.intensive_care_support_benefits.value"];
                           
                           
                           
                                // Added by Shivani for newly added loading Critical illness benefit for PRUMultic Crisis Guard
                           document.getElementById("al_loading_details_sqs.mlife.critical_illness_benefit_multicrisisguard.value").value=obj_loaddata["al_loading_details_sqs.mlife.critical_illness_benefit_multicrisisguard.value"];
                           
                           if(obj_prochoice["al_sqs_details.product_name"]=="PRUsignature income")
                           {
                                if(obj_loaddata["al_loading_details_sqs.mlife.em.value"]!="" && obj_loaddata["al_loading_details_sqs.mlife.em.value"]=="125")
                                {
                                    console.log("SR--->Income loading issue two");

                                    document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator_125").checked=true;
                                }
                                else
                                {
                           console.log("SR--->Income loading issue three");

                                    document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator_105").checked=true;
                                }
                           }
                           else
                           {
                           if(obj_loaddata["al_loading_details_sqs.mlife.loading_value_indicator"]=="N"){
                           
                           document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator_125").checked=true;
                           document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator_105").checked=false;
                           }else if(obj_loaddata["al_loading_details_sqs.mlife.loading_value_indicator"]=="Y"){
                           document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator_125").checked=false;
                           document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator_105").checked=true;
                           }else{
							  document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator_125").checked=true;
                              document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator_105").checked=false; 
                              document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator").value="N";
							   }
                           }
                           
                           
                        
                        // Below changes made by pramod chavan for i button CR. on 22062017
   var mlDisIncome="";
   mlDisIncome=obj_loaddata["al_loading_details_sqs.mlife.ml_disability_income.rider_value"];
   document.getElementById("al_loading_details_sqs.mlife.ml_disability_income.rider_value").value=mlDisIncome;
   if(mlDisIncome!="" && mlDisIncome!=null && mlDisIncome!=0)
   {
         console.log("remove readonly");
         $(escape_jq("al_loading_details_sqs.mlife.ml_disability_income.rider_value")).removeAttr('readonly');
   }
   var mlAcciDeathDis="";
   mlAcciDeathDis=obj_loaddata["al_loading_details_sqs.mlife.accidental_death_and_disablement_cash.rider_value"];
   document.getElementById("al_loading_details_sqs.mlife.accidental_death_and_disablement_cash.rider_value").value=mlAcciDeathDis;
   if(mlAcciDeathDis!="" && mlAcciDeathDis!=null && mlAcciDeathDis!=0){
   $(escape_jq("al_loading_details_sqs.mlife.accidental_death_and_disablement_cash.rider_value")).removeAttr('readonly');
   }
                           
   var slDisIncome="";
       slDisIncome=obj_loaddata["al_loading_details_sqs.slife.sl_disability_income.rider_value"];
   document.getElementById("al_loading_details_sqs.slife.sl_disability_income.rider_value").value=slDisIncome;
   if(slDisIncome!="" && slDisIncome!=null && slDisIncome!=0)
   {
     $(escape_jq("al_loading_details_sqs.slife.sl_disability_income.rider_value")).removeAttr('readonly');
   }
                           
   var slAcciDeathDis="";
   slAcciDeathDis=obj_loaddata["al_loading_details_sqs.slife.accidental_death_and_disablement_cash.rider_value"];
   document.getElementById("al_loading_details_sqs.slife.accidental_death_and_disablement_cash.rider_value").value=slAcciDeathDis;
   if(slAcciDeathDis!="" && slAcciDeathDis!=null && slAcciDeathDis!=0)
   {
       $(escape_jq("al_loading_details_sqs.slife.accidental_death_and_disablement_cash.rider_value")).removeAttr('readonly');
   }
                           
                           if(obj_loaddata["al_rider_sqs.ml_disab_income.id"]=="TRUE")
                           {
                           $(escape_jq("al_rider_sqs.ml_disab_income.id")).attr('checked', true);
                           }
                           if(obj_loaddata["al_rider_sqs.ml_acc_death.id"]=="TRUE")
                           {
                           $(escape_jq("al_rider_sqs.ml_acc_death.id")).attr('checked', true);
                           }

                           if(obj_loaddata["al_rider_sqs.sl_disab_income.id"]=="TRUE")
                           {
                           $(escape_jq("al_rider_sqs.sl_disab_income.id")).attr('checked', true);
                           }

                           if(obj_loaddata["al_rider_sqs.sl_acc_death.id"]=="TRUE")
                           {
                           $(escape_jq("al_rider_sqs.sl_acc_death.id")).attr('checked', true);
                           }

                           
                           
                        
                    }
                           if(obj_prochoice["al_sqs_details.product_name"]=="PRUValue Gain")
                           {
                           
                           if(cancer_valid_res!=null && cancer_valid_res!='null' && cancer_valid_res!='(null)'){
                           document.getElementById("al_loading_details_sqs.mlife.prulady_cancer_income_loading.value").value="";
                           
                           }
                           }
                           
                    //Removed else and added the code for def 6675 for disabling the loading for Diabetic care.

                    obj_solutions_loading=solutions_loading;
                    var loadingArrayId={"TPD":"al_loading_details_sqs.mlife.tpd.value","CI":"al_loading_details_sqs.mlife.critical_illness.value","Medical":"al_loading_details_sqs.mlife.ah_phl.value_millennium"};
                    for(i=0;i<obj_solutions_loading.length;i++)
                    {
                        console.log("obj_solutions_loading[i]:"+JSON.stringify(obj_solutions_loading[i]));
                        var getValuesToSet = obj_solutions_loading[i];
                        console.log("getValuesToSet:"+getValuesToSet["SolutionName"]);
                        if(getValuesToSet["SolutionName"] == "PRUmy diabetes care" && (getValuesToSet["ProductName"] == "PRUwith you" || getValuesToSet["ProductName"] == "PRULink Cover" || getValuesToSet["ProductName"] == "PRUSignature Assure"))
                        {
                            if(obj_solution["duration_with_diabets"]>getValuesToSet["DiabeticDurationMin"] && obj_solution["duration_with_diabets"]<=getValuesToSet["DiabeticDurationMax"])
                            {
                                if(obj_solution["hba1c_level"]>getValuesToSet["HbA1cMin"] && obj_solution["hba1c_level"]<=getValuesToSet["HbA1cMax"])
                                {

                                var loadingId=loadingArrayId[getValuesToSet["LoadingParameter"]];
                                console.log("loadingId:"+loadingId);
                                document.getElementById(loadingId).value=getValuesToSet["LoadingValue"];
                                document.getElementById(loadingId).disabled=true;


                                }
                            }
                        }
                    }
                           
                           
                    js_get_var("loading_update_flags", function(update_loading_res)
                    {
                        js_get_var("loading_update_flags_database", function(update_loading_res)
                        {
                            if (update_loading_res != "" && update_loading_res != null && update_loading_res != "null" && update_loading_res != "(null)")
                            {
                                var obj_update_loading = JSON.parse(update_loading_res);

                                if(obj_update_loading["loading_flag_update"] == "1")
                                {
                                    loading_flag_update = "1";
                                }
                            }
                        });
                    });
                });
            //});
              });
                   });//ankita bundle
          }
        });//
               });
    });
});
}

function fnMsLoadingChangePanels()
{
    $(".first_life").click(function(){
        $(this).addClass("active_panel").removeClass("normal_panel").removeClass("softGrey_panel");

        if(obj_mlife["al_sqs_details.sec_parti_flag"]=="Yes")
        {
            $(".second_life").removeClass("active_panel").addClass("softGrey_panel");
        }
        else if(obj_slife["al_sqs_details.third_parti_flg"]=="Yes" && obj_mlife["al_sqs_details.sec_parti_flag"]=="Yes")
        {
            $(".second_life,.third_life").removeClass("active_panel").addClass("softGrey_panel");
        }
    });

    if(obj_mlife["al_sqs_details.sec_parti_flag"]=="Yes")
    {
        $('.second_life').click(function()
        {
            if ($(this).hasClass("softGrey_panel"))
            {
                $(this).addClass("active_panel").removeClass("normal_panel").removeClass("softGrey_panel");
                $(".first_life").removeClass("active_panel").addClass("softGrey_panel");
                if(obj_slife["al_sqs_details.third_parti_flg"]=="Yes")
                {
                    $(".second_life").removeClass("active_panel").addClass("softGrey_panel");
                }
            }
        });

        if(obj_slife["al_sqs_details.third_parti_flg"]=="Yes")
        {
            $('.third_life').click(function()
            {
                if ($(this).hasClass("softGrey_panel"))
                {
                    $(".first_life,.second_life").removeClass("active_panel").addClass("softGrey_panel");
                    $(this).addClass("active_panel").removeClass("normal_panel").removeClass("softGrey_panel");
                }
            });
        }
    }
}

//Set Data in native on exit of page
function fnMsLoadingSetDataonExit()
{
    console.log("----->"+document.getElementById("al_loading_details_sqs.mlife.em.value").value);
    
    if(obj_prochoice["al_sqs_details.product_name"]=="PRUsignature USD" || obj_prochoice["al_sqs_details.product_name"]==="PRULink Supreme" || obj_prochoice["al_sqs_details.product_name"]==="PRUElite Invest" || obj_prochoice["al_sqs_details.product_name"]==="PRUSignature GrowthPlus" || obj_prochoice["al_sqs_details.product_name"] === "PRULink Supreme Plus"){
    if(document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator_125").checked){
       
        
        document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator").value="N";
        
    }else if(document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator_105").checked){
        
        
        document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator").value="Y";
    }
    }
    if(obj_prochoice["al_sqs_details.product_name"]=="PRUsignature income")
    {
        if((obj_prochoice["al_sqs_details.mlife.il_anb"]<=50 && document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator_125").checked) ||(obj_prochoice["al_sqs_details.mlife.il_anb"]>50 && document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator_105").checked))
        {
            console.log("Inside income");
            console.log("Inside income1:"+document.getElementById("al_loading_details_sqs.mlife.critical_illness.value").value);

            if(document.getElementById("al_loading_details_sqs.mlife.critical_illness.value").value=="" && document.getElementById("al_loading_details_sqs.slife.em.value").value=="" && document.getElementById("al_loading_details_sqs.slife.death_per_mille.value").value=="" && document.getElementById("al_loading_details_sqs.slife.death_per_mille_term.value").value=="" && document.getElementById("al_loading_details_sqs.slife.death_pursuit.value").value=="" && document.getElementById("al_loading_details_sqs.slife.death_pursuit_term.value").value=="" && document.getElementById("al_loading_details_sqs.slife.tpd.value").value=="" && document.getElementById("al_loading_details_sqs.slife.tpd_per_mille.value").value=="" && document.getElementById("al_loading_details_sqs.slife.tpd_per_mille_term.value").value=="" && document.getElementById("al_loading_details_sqs.slife.tpd_pursuit.value").value=="" && document.getElementById("al_loading_details_sqs.slife.tpd_pursuit_term.value").value=="" && document.getElementById("al_loading_details_sqs.slife.critical_illness.value").value=="")
            {
                document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator").value="N";
            }
            else
            {
                document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator").value="Y";
            }
            
        }
        else if(obj_prochoice["al_sqs_details.mlife.il_anb"]<=50 && document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator_105").checked)
        {
            document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator").value="Y";
        }
        else //Added by Paromita for defect 5984 on 09th August 2018
        {
            document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator").value="Y";
        }
        console.log("Inside income3:"+document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator").value);
        
    }
    
    var isCancerLoading="Yes";
    if(document.getElementById("al_loading_details_sqs.mlife.prulady_cancer_income_loading.value").value!=""){
        
        isCancerLoading=null;
    }
    
    
    
    var loading_mlife = {
        "al_loading_details_sqs.mlife.em.value": document.getElementById("al_loading_details_sqs.mlife.em.value").value,
        "al_loading_details_sqs.mlife.death_per_mille.value": document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value").value,
        "al_loading_details_sqs.mlife.death_per_mille_term.value": document.getElementById("al_loading_details_sqs.mlife.death_per_mille_term.value").value,
        "al_loading_details_sqs.mlife.death_pursuit.value": document.getElementById("al_loading_details_sqs.mlife.death_pursuit.value").value,
        "al_loading_details_sqs.mlife.death_pursuit_term.value": document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value").value,
        "al_loading_details_sqs.mlife.tpd.value": document.getElementById("al_loading_details_sqs.mlife.tpd.value").value,
        "al_loading_details_sqs.mlife.tpd_per_mille.value": document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value").value,
        "al_loading_details_sqs.mlife.tpd_per_mille_term.value": document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille_term.value").value,
        "al_loading_details_sqs.mlife.tpd_pursuit.value": document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit.value").value,
        "al_loading_details_sqs.mlife.tpd_pursuit_term.value": document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value").value,
        "al_loading_details_sqs.mlife.ah_add.value": document.getElementById("al_loading_details_sqs.mlife.ah_add.value").value,
        "al_loading_details_sqs.mlife.critical_illness.value": document.getElementById("al_loading_details_sqs.mlife.critical_illness.value").value,
        "al_loading_details_sqs.mlife.ah_ecp.value": document.getElementById("al_loading_details_sqs.mlife.ah_ecp.value").value,
        "al_loading_details_sqs.mlife.ah_dp.value": document.getElementById("al_loading_details_sqs.mlife.ah_dp.value").value,
        "al_loading_details_sqs.mlife.ah_amr.value": document.getElementById("al_loading_details_sqs.mlife.ah_amr.value").value,
        "al_loading_details_sqs.mlife.ah_adi.value": document.getElementById("al_loading_details_sqs.mlife.ah_adi.value").value,
        "al_loading_details_sqs.mlife.ah_pmed.value": document.getElementById("al_loading_details_sqs.mlife.ah_pmed.value").value,
        "al_loading_details_sqs.mlife.ah_hb.value": document.getElementById("al_loading_details_sqs.mlife.ah_hb.value").value,
        "al_loading_details_sqs.mlife.ah_phl.value": document.getElementById("al_loading_details_sqs.mlife.ah_phl.value").value,
        "al_loading_details_sqs.mlife.ah_pec.value": document.getElementById("al_loading_details_sqs.mlife.ah_pec.value").value,
        "al_loading_details_sqs.mlife.di.value": document.getElementById("al_loading_details_sqs.mlife.di.value").value,
        "al_loading_details_sqs.mlife.di_per_mille.value": document.getElementById("al_loading_details_sqs.mlife.di_per_mille.value").value,
        "al_loading_details_sqs.mlife.di_per_mille_term.value": document.getElementById("al_loading_details_sqs.mlife.di_per_mille_term.value").value,
        "al_loading_details_sqs.mlife.di_pursuit.value": document.getElementById("al_loading_details_sqs.mlife.di_pursuit.value").value,
        "al_loading_details_sqs.mlife.di_pursuit_term.value": document.getElementById("al_loading_details_sqs.mlife.di_pursuit_term.value").value,
        "al_loading_details_sqs.mlife.ah_add_double.value": document.getElementById("al_loading_details_sqs.mlife.ah_add_double.value").value,
        "al_loading_details_sqs.slife.em.value": document.getElementById("al_loading_details_sqs.slife.em.value").value,
        "al_loading_details_sqs.slife.death_per_mille.value": document.getElementById("al_loading_details_sqs.slife.death_per_mille.value").value,
        "al_loading_details_sqs.slife.death_per_mille_term.value": document.getElementById("al_loading_details_sqs.slife.death_per_mille_term.value").value,
        "al_loading_details_sqs.slife.death_pursuit.value": document.getElementById("al_loading_details_sqs.slife.death_pursuit.value").value,
        "al_loading_details_sqs.slife.death_pursuit_term.value": document.getElementById("al_loading_details_sqs.slife.death_pursuit_term.value").value,
        "al_loading_details_sqs.slife.tpd.value": document.getElementById("al_loading_details_sqs.slife.tpd.value").value,
        "al_loading_details_sqs.slife.tpd_per_mille.value": document.getElementById("al_loading_details_sqs.slife.tpd_per_mille.value").value,
        "al_loading_details_sqs.slife.tpd_per_mille_term.value": document.getElementById("al_loading_details_sqs.slife.tpd_per_mille_term.value").value,
        "al_loading_details_sqs.slife.tpd_pursuit.value": document.getElementById("al_loading_details_sqs.slife.tpd_pursuit.value").value,
        "al_loading_details_sqs.slife.tpd_pursuit_term.value": document.getElementById("al_loading_details_sqs.slife.tpd_pursuit_term.value").value,
        "al_loading_details_sqs.slife.critical_illness.value": document.getElementById("al_loading_details_sqs.slife.critical_illness.value").value,
        "al_loading_details_sqs.slife.di.value": document.getElementById("al_loading_details_sqs.slife.di.value").value,
        "al_loading_details_sqs.slife.di_per_mille.value": document.getElementById("al_loading_details_sqs.slife.di_per_mille.value").value,
        "al_loading_details_sqs.slife.di_per_mille_term.value": document.getElementById("al_loading_details_sqs.slife.di_per_mille_term.value").value,
        "al_loading_details_sqs.slife.di_pursuit.value": document.getElementById("al_loading_details_sqs.slife.di_pursuit.value").value,
        "al_loading_details_sqs.slife.di_pursuit_term.value": document.getElementById("al_loading_details_sqs.slife.di_pursuit_term.value").value,
        "al_loading_details_sqs.slife.ah_add_double.value": document.getElementById("al_loading_details_sqs.slife.ah_add_double.value").value,
        "al_loading_details_sqs.tlife.em.value": document.getElementById("al_loading_details_sqs.tlife.em.value").value,
        "al_loading_details_sqs.tlife.death_per_mille.value": document.getElementById("al_loading_details_sqs.tlife.death_per_mille.value").value,
        "al_loading_details_sqs.tlife.death_per_mille_term.value": document.getElementById("al_loading_details_sqs.tlife.death_per_mille_term.value").value,
        "al_loading_details_sqs.tlife.death_pursuit.value": document.getElementById("al_loading_details_sqs.tlife.death_pursuit.value").value,
        "al_loading_details_sqs.tlife.death_pursuit_term.value": document.getElementById("al_loading_details_sqs.tlife.death_pursuit_term.value").value,
        "al_loading_details_sqs.tlife.tpd.value": document.getElementById("al_loading_details_sqs.tlife.tpd.value").value,
        "al_loading_details_sqs.tlife.tpd_per_mille.value": document.getElementById("al_loading_details_sqs.tlife.tpd_per_mille.value").value,
        "al_loading_details_sqs.tlife.tpd_per_mille_term.value": document.getElementById("al_loading_details_sqs.tlife.tpd_per_mille_term.value").value,
        "al_loading_details_sqs.tlife.tpd_pursuit.value": document.getElementById("al_loading_details_sqs.tlife.tpd_pursuit.value").value,
        "al_loading_details_sqs.tlife.tpd_pursuit_term.value": document.getElementById("al_loading_details_sqs.tlife.tpd_pursuit_term.value").value,
        "al_loading_details_sqs.tlife.critical_illness.value": document.getElementById("al_loading_details_sqs.tlife.critical_illness.value").value,
        "al_loading_details_sqs.mlife.ca.value": document.getElementById("al_loading_details_sqs.mlife.ca.value").value,
        "al_loading_details_sqs.mlife.ah_load.value": document.getElementById("al_loading_details_sqs.mlife.ah_load.value").value,
        // Below changes made by pramod chavan for i button CR. on 22062017
                       
          "al_loading_details_sqs.mlife.millennium_ah_add.value": document.getElementById("al_loading_details_sqs.mlife.millennium_ah_add.value").value,
          "al_loading_details_sqs.mlife.ah_phl.value_millennium": document.getElementById("al_loading_details_sqs.mlife.ah_phl.value_millennium").value,
        
        
        "al_loading_details_sqs.mlife.ml_disability_income.rider_value": document.getElementById("al_loading_details_sqs.mlife.ml_disability_income.rider_value").value,
        "al_loading_details_sqs.mlife.accidental_death_and_disablement_cash.rider_value": document.getElementById("al_loading_details_sqs.mlife.accidental_death_and_disablement_cash.rider_value").value,
        "al_loading_details_sqs.slife.sl_disability_income.rider_value": document.getElementById("al_loading_details_sqs.slife.sl_disability_income.rider_value").value,
        "al_loading_details_sqs.slife.accidental_death_and_disablement_cash.rider_value": document.getElementById("al_loading_details_sqs.slife.accidental_death_and_disablement_cash.rider_value").value,
        "al_rider_sqs.ml_disab_income.id":getCheckBoxValue("ml_disab_income"),
        "al_rider_sqs.ml_acc_death.id":getCheckBoxValue("ml_acc_death"),
        "al_rider_sqs.sl_disab_income.id":getCheckBoxValue("sl_disab_income"),
        "al_rider_sqs.sl_acc_death.id":getCheckBoxValue("sl_acc_death"),
        "al_loading_details_sqs.mlife.loading_value_indicator":document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator").value,
        //added by ankita on 26 July 2019 for pruwith you new riders
        "al_loading_details_sqs.mlife.multi_crisis_care.value":document.getElementById("al_loading_details_sqs.mlife.multi_crisis_care.value").value,
        "al_loading_details_sqs.mlife.early_crisis_care.value":document.getElementById("al_loading_details_sqs.mlife.early_crisis_care.value").value,
        "al_loading_details_sqs.mlife.total_multi_crisis_care.value":document.getElementById("al_loading_details_sqs.mlife.total_multi_crisis_care.value").value,
  "al_loading_details_sqs.mlife.prulady_cancer_income_loading.value":document.getElementById("al_loading_details_sqs.mlife.prulady_cancer_income_loading.value").value,
        // Added by Shivani for newly added loading crisis cover benefit for PRUMulti Crisis Guard
        "al_loading_details_sqs.mlife.critical_illness_benefit_multicrisisguard.value":document.getElementById("al_loading_details_sqs.mlife.critical_illness_benefit_multicrisisguard.value").value,
        "al_loading_details_sqs.mlife.post_surgery_recovery_benefits.value":document.getElementById("al_loading_details_sqs.mlife.post_surgery_recovery_benefits.value").value,
        "al_loading_details_sqs.mlife.intensive_care_support_benefits.value":document.getElementById("al_loading_details_sqs.mlife.intensive_care_support_benefits.value").value
        
        
                       
    }

    
    if(obj_prochoice["al_sqs_details.product_name"]=="PRUsignature income")
    {
        console.log("SR--->Income loading issue one");
        if(document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator_125").checked)
        {
          loading_mlife["al_loading_details_sqs.mlife.em.value"]="125";
        }
        else
        {
          loading_mlife["al_loading_details_sqs.mlife.em.value"]="105";
        }
    }
    
    js_set_var("loading_details_response", JSON.stringify(loading_mlife), function()
    {
    js_set_var("cancer_loading_clear",JSON.stringify(isCancerLoading),function(){

            
        $("#laodingPage").hide();
        menuController.loadPage("top_mysolutions_benefit_selection",0);
    });
    });
}

//Validate data on exit of page
function fnMsLoadingvalidateData()
{
    console.log("basic_term -->"+basic_term);
    
    
    if(obj_prochoice["al_sqs_details.product_name"] == "EssentialLife (SP)" || obj_prochoice["al_sqs_details.product_name"] == "PRUSignature Protect")//Abhilash: EssentialLife (SP)_SCB name changed to PRUSignature Protect on 3rd July
    {
        
        if((document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille_term.value").value!="" && document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille_term.value").value<5) || (document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value").value!="" && document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value").value<5))
        {
            
            alert("805");
            return false;
            
        }
        
        
        
    }
    
    if(document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value").value.length > 0)
    {
        if(document.getElementById("al_loading_details_sqs.mlife.death_per_mille_term.value").value.length == 0)
        {
            if(obj_prochoice["al_sqs_details.product_name"] != "PRUheritage")
            {
                alert("252");
                return false;
            }
        }
    }
    
    if(document.getElementById("al_loading_details_sqs.mlife.death_per_mille_term.value").value.length > 0)
    {
        if(document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value").value.length == 0)
        {
            alert("253");
            return false;
        }
    }
    
    if(document.getElementById("al_loading_details_sqs.mlife.death_pursuit.value").value.length > 0)
    {
        if(document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value").value.length == 0)
        {
            if(obj_prochoice["al_sqs_details.product_name"] != "PRUheritage")
            {
                alert("252");
                return false;
            }
        }
    }
    
    if(document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value").value.length > 0)
    {
        if(document.getElementById("al_loading_details_sqs.mlife.death_pursuit.value").value.length == 0)
        {
            alert("253");
            return false;
        }
    }
    
    
    if(document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value").value.length > 0)
    {
        if(document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille_term.value").value.length == 0)
        {
            alert("252");
            return false;
        }
    }
    
    if(document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille_term.value").value.length > 0)
    {
        if(document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille.value").value.length == 0)
        {
            alert("253");
            return false;
        }
    }
    
    if(document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit.value").value.length > 0)
    {
        if(document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value").value.length == 0)
        {
            alert("252");
            return false;
        }
    }
    
    if(document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value").value.length > 0)
    {
        if(document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit.value").value.length == 0)
        {
            alert("253");
            return false;
        }
    }
    console.log("PTP TEST"+basic_term);
    if(parseInt(document.getElementById("al_loading_details_sqs.mlife.death_per_mille_term.value").value) > basic_term && (obj_prochoice["al_sqs_details.product_name"]!="EssentialLife (SP)" && obj_prochoice["al_sqs_details.product_name"]!="PRUSignature Protect" && obj_prochoice["al_sqs_details.product_name"]!="PRUValue Gain" && obj_prochoice["al_sqs_details.product_name"] !== "PRUCash Enrich" && obj_prochoice["al_sqs_details.product_name"] !== "PRUAll Care"  && obj_prochoice["al_sqs_details.product_name"] !== "PRUFlexi Gain" && obj_prochoice["al_sqs_details.product_name"] !== "PRUGain Plus" && obj_prochoice["al_sqs_details.product_name"] !== "PRUEnrich Gain" && obj_prochoice["al_sqs_details.product_name"] !== "PRUCritical Protect"))//Abhilash: EssentialLife (SP)_SCB name changed to PRUSignature Protect on 3rd July
    {console.log("ankita 1")
        
        var dataV1=document.getElementById("al_loading_details_sqs.mlife.death_per_mille_term.value").value;
        console.log("254-->1"+dataV1);
        alert("254");
        return false;
    }
    else
    {
        
        if(obj_prochoice["al_sqs_details.product_name"]=="PRUValue Gain" || obj_prochoice["al_sqs_details.product_name"] === "PRUCash Enrich" || obj_prochoice["al_sqs_details.product_name"] === "PRUAll Care" || obj_prochoice["al_sqs_details.product_name"] === "PRUFlexi Gain" || obj_prochoice["al_sqs_details.product_name"] === "PRUGain Plus" || obj_prochoice["al_sqs_details.product_name"] === "PRUEnrich Gain"){
           
            if((obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"]!="" && obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"]!="0") && (parseInt(document.getElementById("al_loading_details_sqs.mlife.death_per_mille_term.value").value) > basic_term)){
                
                var dataV1=document.getElementById("al_loading_details_sqs.mlife.death_per_mille_term.value").value;
                console.log("254-->1"+dataV1);
                alert("254");
                return false;
                
            }

            
        }else{
        if((obj_benefit_selection["al_rider_sqs.basic_plan.rider_term"]!="") && (parseInt(document.getElementById("al_loading_details_sqs.mlife.death_per_mille_term.value").value) > basic_term)){
            console.log("ankita 2")
            var dataV1=document.getElementById("al_loading_details_sqs.mlife.death_per_mille_term.value").value;
            console.log("254-->1"+dataV1);
            alert("254");
            return false;
            
        }
        }
    }
    
    if((parseInt(document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value").value) > basic_term) && (obj_prochoice["al_sqs_details.product_name"]!="EssentialLife (SP)" && obj_prochoice["al_sqs_details.product_name"]!="PRUSignature Protect" && obj_prochoice["al_sqs_details.product_name"]!="PRUValue Gain" && obj_prochoice["al_sqs_details.product_name"] !== "PRUCash Enrich"  && obj_prochoice["al_sqs_details.product_name"] !== "PRUAll Care" && obj_prochoice["al_sqs_details.product_name"] !== "PRUFlexi Gain" && obj_prochoice["al_sqs_details.product_name"] !== "PRUGain Plus" && obj_prochoice["al_sqs_details.product_name"] !== "PRUEnrich Gain" && obj_prochoice["al_sqs_details.product_name"] !== "PRUCritical Protect"))//Abhilash: EssentialLife (SP)_SCB name changed to PRUSignature Protect on 3rd July
    {
        var dataV2=document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value").value;
        console.log("254-->2"+dataV2);
        alert("254");
        return false;
    }
    else
    {
        if(obj_prochoice["al_sqs_details.product_name"]=="PRUValue Gain" || obj_prochoice["al_sqs_details.product_name"] === "PRUCash Enrich" || obj_prochoice["al_sqs_details.product_name"] === "PRUAll Care" || obj_prochoice["al_sqs_details.product_name"] === "PRUFlexi Gain" || obj_prochoice["al_sqs_details.product_name"] === "PRUGain Plus" || obj_prochoice["al_sqs_details.product_name"] === "PRUEnrich Gain"){
            
            if((obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"]!="" && obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"]!="0") && (parseInt(document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value").value) > basic_term)){
                
                var dataV1=document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value").value;
                console.log("254-->1"+dataV1);
                alert("254");
                return false;
                
            }

            
            
        }else{
        
        if((obj_benefit_selection["al_rider_sqs.basic_plan.rider_term"]!="") && (parseInt(document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value").value) > basic_term)){
            console.log("ankita 3")
            var dataV1=document.getElementById("al_loading_details_sqs.mlife.death_pursuit_term.value").value;
            console.log("254-->1"+dataV1);
            alert("254");
            return false;
            
        }
        }
    }
    
    
    
    if((parseInt(document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille_term.value").value) > basic_term) && (obj_prochoice["al_sqs_details.product_name"]!="EssentialLife (SP)" && obj_prochoice["al_sqs_details.product_name"]!="PRUSignature Protect" && obj_prochoice["al_sqs_details.product_name"]!="PRUValue Gain" && obj_prochoice["al_sqs_details.product_name"] !== "PRUCash Enrich" && obj_prochoice["al_sqs_details.product_name"] !== "PRUTerm Premier" && obj_prochoice["al_sqs_details.product_name"] !== "PRUAll Care" && obj_prochoice["al_sqs_details.product_name"] !== "PRUFlexi Gain" && obj_prochoice["al_sqs_details.product_name"] !== "PRUGain Plus" && obj_prochoice["al_sqs_details.product_name"] !== "PRUEnrich Gain"))//Abhilash: EssentialLife (SP)_SCB name changed to PRUSignature Protect on 3rd July
    {
        var dataV3=document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille_term.value").value;
        console.log("254-->3"+dataV3);
        alert("254");
        return false;
    }
    // Added by Shivani for DEF - 10775
    /*else if((parseInt(document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille_term.value").value) > disability_care_term) && ( obj_prochoice["al_sqs_details.product_name"] === "PRUTerm Premier"))//Abhilash: EssentialLife (SP)_SCB name changed to PRUSignature Protect on 3rd July
    {
        if(document.getElementById("al_rider_sqs.disability_care.id").checked= true)
        {
        console.log("SSD --> Disability Care");
        var dataV3=document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille_term.value").value;
        console.log("850-->3"+dataV3);
        alert("850");
        return false;
        }
        else
        {
            console.log("SSD --> Basic PTP");
           var dataV3=document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille_term.value").value;
           console.log("254-->3"+dataV3);
           alert("254");
           return false;
            
        }
    }*/
    
    else if((parseInt(document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille_term.value").value) > disability_care_term) && (document.getElementById("al_rider_sqs.disability_care.id").checked) && ( obj_prochoice["al_sqs_details.product_name"] === "PRUTerm Premier"))//Abhilash: EssentialLife (SP)_SCB name changed to PRUSignature Protect on 3rd July
    {
        if(document.getElementById("al_rider_sqs.disability_care.id").checked)
        {
        console.log("SSD --> Disability Care");
        var dataV3=document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille_term.value").value;
        console.log("850-->3"+dataV3);
        alert("850");
        return false;
        }
    }
    
    else if((parseInt(document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille_term.value").value) > basic_term) && (!document.getElementById("al_rider_sqs.disability_care.id").checked)&& ( obj_prochoice["al_sqs_details.product_name"] === "PRUTerm Premier"))//Abhilash: EssentialLife (SP)_SCB name changed to PRUSignature Protect on 3rd July
    {
        var dataV3=document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille_term.value").value;
        console.log("254-->3"+dataV3);
        alert("254");
        return false;
    }
    else
    {
        if(obj_prochoice["al_sqs_details.product_name"]!="PRUTerm Premier")
            
        {
        if(obj_prochoice["al_sqs_details.product_name"]=="PRUValue Gain" || obj_prochoice["al_sqs_details.product_name"] === "PRUCash Enrich"  || obj_prochoice["al_sqs_details.product_name"] === "PRUAll Care" || obj_prochoice["al_sqs_details.product_name"] === "PRUFlexi Gain" || obj_prochoice["al_sqs_details.product_name"] === "PRUGain Plus" || obj_prochoice["al_sqs_details.product_name"] === "PRUEnrich Gain"){
            
            if((obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"]!="" && obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"]!="0") && (parseInt(document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille_term.value").value) > basic_term)){
                
                var dataV1=document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille_term.value").value;
                console.log("254-->1"+dataV1);
                alert("254");
                return false;
                
            }
            
        }else{
            
        
        if((obj_benefit_selection["al_rider_sqs.basic_plan.rider_term"]!="") && (parseInt(document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille_term.value").value) > basic_term)){
            console.log("ankita 4")
            var dataV1=document.getElementById("al_loading_details_sqs.mlife.tpd_per_mille_term.value").value;
            console.log("254-->1"+dataV1);
            alert("254");
            return false;
            
        }
        }
    }
    
}
    
    
    if((parseInt(document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value").value) > basic_term) && (obj_prochoice["al_sqs_details.product_name"]!="EssentialLife (SP)" && obj_prochoice["al_sqs_details.product_name"]!="PRUSignature Protect" && obj_prochoice["al_sqs_details.product_name"]!="PRUValue Gain" && obj_prochoice["al_sqs_details.product_name"] !== "PRUCash Enrich" && obj_prochoice["al_sqs_details.product_name"] !== "PRUTerm Premier" && obj_prochoice["al_sqs_details.product_name"] !== "PRUAll Care" && obj_prochoice["al_sqs_details.product_name"] !== "PRUFlexi Gain" && obj_prochoice["al_sqs_details.product_name"] !== "PRUGain Plus" && obj_prochoice["al_sqs_details.product_name"] !== "PRUEnrich Gain"))//Abhilash: EssentialLife (SP)_SCB name changed to PRUSignature Protect on 3rd July
    {
        var dataV4=document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value").value;
        console.log("254-->4"+dataV4);
        alert("254");
        return false;
    }
    // Added by Shivani for DEF - 10775
    /*else if((parseInt(document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value").value) > disability_care_term) && (obj_prochoice["al_sqs_details.product_name"] === "PRUTerm Premier"))//Abhilash: EssentialLife (SP)_SCB name changed to PRUSignature Protect on 3rd July
    {
        if(document.getElementById("al_rider_sqs.disability_care.id").checked= true)
        {
        var dataV4=document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value").value;
        console.log("254-->4"+dataV4);
        alert("850");
        return false;
        }
        else
        {
            var dataV4=document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value").value;
            console.log("254-->4"+dataV4);
            alert("254");
            return false;
            
        }
    }*/
    
    else if((parseInt(document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value").value) > disability_care_term) && (document.getElementById("al_rider_sqs.disability_care.id").checked) && ( obj_prochoice["al_sqs_details.product_name"] === "PRUTerm Premier"))//Abhilash: EssentialLife (SP)_SCB name changed to PRUSignature Protect on 3rd July
    {
        if(document.getElementById("al_rider_sqs.disability_care.id").checked)
        {
        console.log("SSD --> Disability Care");
        var dataV3=document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value").value;
        console.log("850-->3"+dataV3);
        alert("850");
        return false;
        }
    }
    
    else if((parseInt(document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value").value) > basic_term) && (!document.getElementById("al_rider_sqs.disability_care.id").checked)&& ( obj_prochoice["al_sqs_details.product_name"] === "PRUTerm Premier"))//Abhilash: EssentialLife (SP)_SCB name changed to PRUSignature Protect on 3rd July
    {
        var dataV3=document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value").value;
        console.log("254-->3"+dataV3);
        alert("254");
        return false;
    }
    
    else
    {
        if(obj_prochoice["al_sqs_details.product_name"]!="PRUTerm Premier")
        {
        if(obj_prochoice["al_sqs_details.product_name"]=="PRUValue Gain" || obj_prochoice["al_sqs_details.product_name"] === "PRUCash Enrich" || obj_prochoice["al_sqs_details.product_name"] === "PRUAll Care" || obj_prochoice["al_sqs_details.product_name"] === "PRUFlexi Gain" || obj_prochoice["al_sqs_details.product_name"] === "PRUGain Plus" || obj_prochoice["al_sqs_details.product_name"] === "PRUEnrich Gain"){
            
            if((obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"]!="" && obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"]!="0") && (parseInt(document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value").value) > basic_term)){
                
                var dataV1=document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value").value;
                console.log("254-->1"+dataV1);
                alert("254");
                return false;
                
            }
        }else{
        
        if((obj_benefit_selection["al_rider_sqs.basic_plan.rider_term"]!="") && (parseInt(document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value").value) > basic_term)){
            console.log("ankita 5")
            var dataV1=document.getElementById("al_loading_details_sqs.mlife.tpd_pursuit_term.value").value;
            console.log("254-->1"+dataV1);
            alert("254");
            return false;
            
        }
        }
    }
}
    
    
    //added by purva to validate the term as per DEF-2226
    if((parseInt(document.getElementById("al_loading_details_sqs.mlife.di_per_mille_term.value").value) > basic_term) && (obj_prochoice["al_sqs_details.product_name"]!="EssentialLife (SP)" && obj_prochoice["al_sqs_details.product_name"]!="PRUSignature Protect" && obj_prochoice["al_sqs_details.product_name"]!="PRUValue Gain" && obj_prochoice["al_sqs_details.product_name"] !== "PRUCash Enrich" && obj_prochoice["al_sqs_details.product_name"] !== "PRUAll Care" && obj_prochoice["al_sqs_details.product_name"] !== "PRUFlexi Gain" && obj_prochoice["al_sqs_details.product_name"] !== "PRUGain Plus" && obj_prochoice["al_sqs_details.product_name"] !== "PRUEnrich Gain"))//Abhilash: EssentialLife (SP)_SCB name changed to PRUSignature Protect on 3rd July
    {
        var dataV5=document.getElementById("al_loading_details_sqs.mlife.di_per_mille_term.value").value;
        console.log("254-->5"+dataV5);
        alert("254");
        return false;
    }else
    {
        if(obj_prochoice["al_sqs_details.product_name"]=="PRUValue Gain" || obj_prochoice["al_sqs_details.product_name"] === "PRUCash Enrich" || obj_prochoice["al_sqs_details.product_name"] === "PRUAll Care" || obj_prochoice["al_sqs_details.product_name"] === "PRUFlexi Gain" || obj_prochoice["al_sqs_details.product_name"] === "PRUGain plus" || obj_prochoice["al_sqs_details.product_name"] === "PRUEnrich Gain"){
            if((obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"]!="" && obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"]!="0") && (parseInt(document.getElementById("al_loading_details_sqs.mlife.di_per_mille_term.value").value) > basic_term)){
                
                var dataV1=document.getElementById("al_loading_details_sqs.mlife.di_per_mille_term.value").value;
                console.log("254-->1"+dataV1);
                alert("254");
                return false;
                
            }
            
        }else{
        if((obj_benefit_selection["al_rider_sqs.basic_plan.rider_term"]!="") && (parseInt(document.getElementById("al_loading_details_sqs.mlife.di_per_mille_term.value").value) > basic_term)){
            
            var dataV1=document.getElementById("al_loading_details_sqs.mlife.di_per_mille_term.value").value;
            console.log("254-->1"+dataV1);
            alert("254");
            return false;
            
        }
        }
    }
    
    
    if((parseInt(document.getElementById("al_loading_details_sqs.mlife.di_pursuit_term.value").value) > basic_term) && (obj_prochoice["al_sqs_details.product_name"]!="EssentialLife (SP)" && obj_prochoice["al_sqs_details.product_name"]!="PRUSignature Protect" && obj_prochoice["al_sqs_details.product_name"]!="PRUValue Gain" && obj_prochoice["al_sqs_details.product_name"] !== "PRUCash Enrich" && obj_prochoice["al_sqs_details.product_name"] !== "PRUAll Care" && obj_prochoice["al_sqs_details.product_name"] !== "PRUFlexi Gain" && obj_prochoice["al_sqs_details.product_name"] !== "PRUGain Plus" && obj_prochoice["al_sqs_details.product_name"] !== "PRUEnrich Gain"))//Abhilash: EssentialLife (SP)_SCB name changed to PRUSignature Protect on 3rd July
    {
        console.log("basic_term -->"+basic_term);
        var dataV6=document.getElementById("al_loading_details_sqs.mlife.di_pursuit_term.value").value;
        console.log("254-->5"+dataV6);
        alert("254");
        return false;
    }else
    {
        if(obj_prochoice["al_sqs_details.product_name"]=="PRUValue Gain" || obj_prochoice["al_sqs_details.product_name"] === "PRUCash Enrich" || obj_prochoice["al_sqs_details.product_name"] === "PRUAll Care" || obj_prochoice["al_sqs_details.product_name"] === "PRUFlexi Gain" || obj_prochoice["al_sqs_details.product_name"] === "PRUGain Plus" || obj_prochoice["al_sqs_details.product_name"] === "PRUEnrich Gain"){
            
            if((obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"]!="" && obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"]!="0") && (parseInt(document.getElementById("al_loading_details_sqs.mlife.di_pursuit_term.value").value) > basic_term)){
                
                var dataV1=document.getElementById("al_loading_details_sqs.mlife.di_pursuit_term.value").value;
                console.log("254-->1"+dataV1);
                alert("254");
                return false;
                
            }
            
            
        }else
        {
        if((obj_benefit_selection["al_rider_sqs.basic_plan.rider_term"]!="") && (parseInt(document.getElementById("al_loading_details_sqs.mlife.di_pursuit_term.value").value) > basic_term)){
            
            var dataV1=document.getElementById("al_loading_details_sqs.mlife.di_pursuit_term.value").value;
            console.log("254-->1"+dataV1);
            alert("254");
            return false;
            
        }
        }
    }
    
    
    if(document.getElementById("al_loading_details_sqs.mlife.di_per_mille.value").value.length > 0)
    {
        if(document.getElementById("al_loading_details_sqs.mlife.di_per_mille_term.value").value.length == 0)
        {
             alert("252");
             return false;
        }
    }
    if(document.getElementById("al_loading_details_sqs.mlife.di_pursuit.value").value.length > 0)
    {
        if(document.getElementById("al_loading_details_sqs.mlife.di_pursuit_term.value").value.length == 0)
        {
             alert("252");
             return false;
        }
    }
        
    if(document.getElementById("al_loading_details_sqs.mlife.di_per_mille_term.value").value.length > 0)
    {
        if(document.getElementById("al_loading_details_sqs.mlife.di_per_mille.value").value.length == 0)
        {
            alert("253");
            return false;
        }
    }
    
    if(document.getElementById("al_loading_details_sqs.mlife.di_pursuit_term.value").value.length > 0)
    {
        if(document.getElementById("al_loading_details_sqs.mlife.di_pursuit.value").value.length == 0)
        {
            alert("253");
            return false;
        }
    }
    
    //For slife
    if(obj_mlife["al_sqs_details.sec_parti_flag"]=="Yes")
    {
        
        if(document.getElementById("al_loading_details_sqs.slife.death_per_mille.value").value.length > 0)
        {
            if(document.getElementById("al_loading_details_sqs.slife.death_per_mille_term.value").value.length == 0)
            {
                alert("252");
                return false;
            }
        }
        
        if(document.getElementById("al_loading_details_sqs.slife.death_per_mille_term.value").value.length > 0)
        {
            if(document.getElementById("al_loading_details_sqs.slife.death_per_mille.value").value.length == 0)
            {
                alert("253");
                return false;
            }
        }
        
        if(document.getElementById("al_loading_details_sqs.slife.death_pursuit.value").value.length > 0)
        {
            if(document.getElementById("al_loading_details_sqs.slife.death_pursuit_term.value").value.length == 0)
            {
                alert("252");
                return false;
            }
        }
        
        if(document.getElementById("al_loading_details_sqs.slife.death_pursuit_term.value").value.length > 0)
        {
            if(document.getElementById("al_loading_details_sqs.slife.death_pursuit.value").value.length == 0)
            {
                alert("253");
                return false;
            }
        }
        
        
        if(document.getElementById("al_loading_details_sqs.slife.tpd_per_mille.value").value.length > 0)
        {
            if(document.getElementById("al_loading_details_sqs.slife.tpd_per_mille_term.value").value.length == 0)
            {
                alert("252");
                return false;
            }
        }
        
        if(document.getElementById("al_loading_details_sqs.slife.tpd_per_mille_term.value").value.length > 0)
        {
            if(document.getElementById("al_loading_details_sqs.slife.tpd_per_mille.value").value.length == 0)
            {
                alert("253");
                return false;
            }
        }
        
        if(document.getElementById("al_loading_details_sqs.slife.tpd_pursuit.value").value.length > 0)
        {
            if(document.getElementById("al_loading_details_sqs.slife.tpd_pursuit_term.value").value.length == 0)
            {
                alert("252");
                return false;
            }
        }
        
        if(document.getElementById("al_loading_details_sqs.slife.tpd_pursuit_term.value").value.length > 0)
        {
            if(document.getElementById("al_loading_details_sqs.slife.tpd_pursuit.value").value.length == 0)
            {
                alert("253");
                return false;
            }
        }
        
        if((parseInt(document.getElementById("al_loading_details_sqs.slife.death_per_mille_term.value").value) > basic_term) && (obj_prochoice["al_sqs_details.product_name"]!="PRUValue Gain" && obj_prochoice["al_sqs_details.product_name"] !== "PRUCash Enrich" && obj_prochoice["al_sqs_details.product_name"] !== "PRUAll Care" && obj_prochoice["al_sqs_details.product_name"] !== "PRUFlexi Gain" && obj_prochoice["al_sqs_details.product_name"] !== "PRUGain Plus" && obj_prochoice["al_sqs_details.product_name"] !== "PRUEnrich Gain"))
        {
            console.log("alert 1");
            alert("254");
            return false;
        }
        else
        {
            if((obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"]!="" && obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"]!="0") && (parseInt(document.getElementById("al_loading_details_sqs.slife.death_per_mille_term.value").value) > basic_term))
            {
                 
                 alert("254");
                 return false;
            }
        }
        
        if((parseInt(document.getElementById("al_loading_details_sqs.slife.death_pursuit_term.value").value) > basic_term) && (obj_prochoice["al_sqs_details.product_name"]!="PRUValue Gain" && obj_prochoice["al_sqs_details.product_name"] !== "PRUCash Enrich" && obj_prochoice["al_sqs_details.product_name"] !== "PRUAll Care" && obj_prochoice["al_sqs_details.product_name"] !== "PRUFlexi Gain" && obj_prochoice["al_sqs_details.product_name"] !== "PRUGain Plus" && obj_prochoice["al_sqs_details.product_name"] !== "PRUEnrich Gain"))
        {
            console.log("alert 2");
            alert("254");
            return false;
        }
        else
        {
            if((obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"]!="" && obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"]!="0") && (parseInt(document.getElementById("al_loading_details_sqs.slife.death_pursuit_term.value").value) > basic_term))
            {
                 
                 alert("254");
                 return false;
            }
        }
        
        if((parseInt(document.getElementById("al_loading_details_sqs.slife.tpd_per_mille_term.value").value) > basic_term) && (obj_prochoice["al_sqs_details.product_name"]!="PRUValue Gain" && obj_prochoice["al_sqs_details.product_name"] !== "PRUCash Enrich" && obj_prochoice["al_sqs_details.product_name"] !== "PRUAll Care"  && obj_prochoice["al_sqs_details.product_name"] !== "PRUFlexi Gain" && obj_prochoice["al_sqs_details.product_name"] !== "PRUGain Plus" && obj_prochoice["al_sqs_details.product_name"] !== "PRUEnrich Gain"))
        {
            console.log("alert 3");
            alert("254");
            return false;
        }
        else
        {
            if((obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"]!="" && obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"]!="0") && (parseInt(document.getElementById("al_loading_details_sqs.slife.tpd_per_mille_term.value").value) > basic_term))
            {
                 
                 alert("254");
                 return false;
            }
        }
        
        if((parseInt(document.getElementById("al_loading_details_sqs.slife.tpd_pursuit_term.value").value) > basic_term) && (obj_prochoice["al_sqs_details.product_name"]!="PRUValue Gain" && obj_prochoice["al_sqs_details.product_name"] !== "PRUCash Enrich" && obj_prochoice["al_sqs_details.product_name"] !== "PRUAll Care" && obj_prochoice["al_sqs_details.product_name"] !== "PRUFlexi Gain" && obj_prochoice["al_sqs_details.product_name"] !== "PRUGain Plus" && obj_prochoice["al_sqs_details.product_name"] !== "PRUEnrich Gain"))
        {
            console.log("alert 4");
            alert("254");
            return false;
        }
        else
        {
            if((obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"]!="" && obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"]!="0") && (parseInt(document.getElementById("al_loading_details_sqs.slife.tpd_pursuit_term.value").value) > basic_term))
            {
                 
                 alert("254");
                 return false;
            }
        }
		//added by purva to validate the term as per DEF-2226
		if((parseInt(document.getElementById("al_loading_details_sqs.slife.di_per_mille_term.value").value) > basic_term) && (obj_prochoice["al_sqs_details.product_name"]!="PRUValue Gain" && obj_prochoice["al_sqs_details.product_name"] !== "PRUCash Enrich" && obj_prochoice["al_sqs_details.product_name"] !== "PRUAll Care" && obj_prochoice["al_sqs_details.product_name"] !== "PRUFlexi Gain" && obj_prochoice["al_sqs_details.product_name"] !== "PRUGain Plus" && obj_prochoice["al_sqs_details.product_name"] !== "PRUEnrich Gain"))
		{
            console.log("alert 5");
			alert("254");
			return false;
		}
        else
        {
            if((obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"]!="" && obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"]!="0") && (parseInt(document.getElementById("al_loading_details_sqs.slife.di_per_mille_term.value").value) > basic_term))
            {
                 
                 alert("254");
                 return false;
            }
        }
		if((parseInt(document.getElementById("al_loading_details_sqs.slife.di_pursuit_term.value").value) > basic_term) && (obj_prochoice["al_sqs_details.product_name"]!="PRUValue Gain" && obj_prochoice["al_sqs_details.product_name"] !== "PRUCash Enrich" && obj_prochoice["al_sqs_details.product_name"] !== "PRUAll Care" && obj_prochoice["al_sqs_details.product_name"] !== "PRUFlexi Gain" && obj_prochoice["al_sqs_details.product_name"] !== "PRUGain Plus" && obj_prochoice["al_sqs_details.product_name"] !== "PRUEnrich Gain"))
		{
            console.log("alert 6");
			alert("254");
			return false;
		}
        else
        {
            if((obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"]!="" && obj_benefit_selection["al_rider_sqs.basic_plans.rider_term"]!="0") && (parseInt(document.getElementById("al_loading_details_sqs.slife.di_pursuit_term.value").value) > basic_term))
            {
                 
                 alert("254");
                 return false;
            }
        }
		
		if(document.getElementById("al_loading_details_sqs.slife.di_per_mille.value").value.length > 0)
		{
			if(document.getElementById("al_loading_details_sqs.slife.di_per_mille_term.value").value.length == 0)
			{
				 alert("252");
				 return false;
			}
		}
		
		if(document.getElementById("al_loading_details_sqs.slife.di_pursuit.value").value.length > 0)
		{
			if(document.getElementById("al_loading_details_sqs.slife.di_pursuit_term.value").value.length == 0)
			{
				 alert("252");
				 return false;
			}
		}
			
		if(document.getElementById("al_loading_details_sqs.slife.di_per_mille_term.value").value.length > 0)
		{
			if(document.getElementById("al_loading_details_sqs.slife.di_per_mille.value").value.length == 0)
			{
				alert("253");
				return false;
			}
		}
		
		if(document.getElementById("al_loading_details_sqs.slife.di_pursuit_term.value").value.length > 0)
		{
			if(document.getElementById("al_loading_details_sqs.slife.di_pursuit.value").value.length == 0)
			{
				alert("253");
				return false;
			}
		}
        
        //For tlife
        if(obj_slife["al_sqs_details.third_parti_flg"]=="Yes")
        {
            if(document.getElementById("al_loading_details_sqs.tlife.death_per_mille.value").value.length > 0)
            {
                if(document.getElementById("al_loading_details_sqs.tlife.death_per_mille_term.value").value.length == 0)
                {
                    alert("252");
                    return false;
                }
            }
            
            if(document.getElementById("al_loading_details_sqs.tlife.death_per_mille_term.value").value.length > 0)
            {
                if(document.getElementById("al_loading_details_sqs.tlife.death_per_mille.value").value.length == 0)
                {
                    alert("253");
                    return false;
                }
            }
            
            if(document.getElementById("al_loading_details_sqs.tlife.death_pursuit.value").value.length > 0)
            {
                if(document.getElementById("al_loading_details_sqs.tlife.death_pursuit_term.value").value.length == 0)
                {
                    alert("252");
                    return false;
                }
            }
            
            if(document.getElementById("al_loading_details_sqs.tlife.death_pursuit_term.value").value.length > 0)
            {
                if(document.getElementById("al_loading_details_sqs.tlife.death_pursuit.value").value.length == 0)
                {
                    alert("253");
                    return false;
                }
            }
            
            
            if(document.getElementById("al_loading_details_sqs.tlife.tpd_per_mille.value").value.length > 0)
            {
                if(document.getElementById("al_loading_details_sqs.tlife.tpd_per_mille_term.value").value.length == 0)
                {
                    alert("252");
                    return false;
                }
            }
            
            if(document.getElementById("al_loading_details_sqs.tlife.tpd_per_mille_term.value").value.length > 0)
            {
                if(document.getElementById("al_loading_details_sqs.tlife.tpd_per_mille.value").value.length == 0)
                {
                    alert("253");
                    return false;
                }
            }
            
            if(document.getElementById("al_loading_details_sqs.tlife.tpd_pursuit.value").value.length > 0)
            {
                if(document.getElementById("al_loading_details_sqs.tlife.tpd_pursuit_term.value").value.length == 0)
                {
                    alert("252");
                    return false;
                }
            }
            
            if(document.getElementById("al_loading_details_sqs.tlife.tpd_pursuit_term.value").value.length > 0)
            {
                if(document.getElementById("al_loading_details_sqs.tlife.tpd_pursuit.value").value.length == 0)
                {
                    alert("253");
                    return false;
                }
            }
            
            if(parseInt(document.getElementById("al_loading_details_sqs.tlife.death_per_mille_term.value").value) > basic_term)
            {
                console.log("alert 6");
                alert("254");
                return false;
            }
            
            if(parseInt(document.getElementById("al_loading_details_sqs.tlife.death_pursuit_term.value").value) > basic_term)
            {
                console.log("alert 7");
                alert("254");
                return false;
            }
            
            console.log("@TERM Data",)
            if(parseInt(document.getElementById("al_loading_details_sqs.tlife.tpd_per_mille_term.value").value) > basic_term)
            {
                console.log("alert 8");
                alert("254");
                return false;
            }
            
            if(parseInt(document.getElementById("al_loading_details_sqs.tlife.tpd_pursuit_term.value").value) > basic_term)
            {
                console.log("alert 9");
                alert("254");
                return false;
            }          
        }
    }
    if(obj_prochoice["al_sqs_details.product_name"] == "PRUmy treasure")
    {
        console.log("Loading value:"+document.getElementById("al_loading_details_sqs.mlife.em.value").value);
        if(document.getElementById("al_loading_details_sqs.mlife.em.value").value!="")
        {
            if(!(document.getElementById("al_loading_details_sqs.mlife.em.value").value >= 125 && document.getElementById("al_loading_details_sqs.mlife.em.value").value <= 300))
            {
                console.log("alert 10");
                alert("755");
                return false;
            }
            if((document.getElementById("al_loading_details_sqs.mlife.em.value").value % 25) != 0)
            {
                console.log("alert 11");
                alert("755");
                return false;
                
            }
        }
        

        
    }
    // Added by Shivani for DEF - 10808
    if(obj_prochoice["al_sqs_details.product_name"] == "PRUSignature Assure" || obj_prochoice["al_sqs_details.product_name"] == "PRUsignature infinite" || obj_prochoice["al_sqs_details.product_name"] == "PRUSignature Ace")
    {
        console.log("Loading value:"+document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value").value);
        if(document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value").value!="")
        {
            if((document.getElementById("al_loading_details_sqs.mlife.death_per_mille.value").value >= 100))
            {
                console.log("alert 11");
                alert("851");
                return false;
            }
            
        }
        
        
        
    }
    
  /* if(obj_prochoice["al_sqs_details.product_name"] == "EssentialLife (SP)" || obj_prochoice["al_sqs_details.product_name"] == "PRUSignature Protect")
    {
        console.log("Loading value:"+document.getElementById("al_loading_details_sqs.mlife.em.value").value);
        if(document.getElementById("al_loading_details_sqs.mlife.em.value").value!="")
        {
            if(!(document.getElementById("al_loading_details_sqs.mlife.em.value").value >= 25 && document.getElementById("al_loading_details_sqs.mlife.em.value").value <= 500))
            {
                console.log("alert 10");
                alert("804");
                return false;
            }
           
        }
        
        if(document.getElementById("al_loading_details_sqs.mlife.tpd.value").value!="")
        {
            if(!(document.getElementById("al_loading_details_sqs.mlife.tpd.value").value >= 25 && document.getElementById("al_loading_details_sqs.mlife.tpd.value").value <= 500))
            {
                console.log("alert 10");
                alert("804");
                return false;
            }
           
        }
        
        
        
    }*/
    return true;
}

//Hide Riders on Load
function fnMsLoadingHideRiderElement()
{
    fnMsLoadingHideElement("rider_row_al_loading_details_sqs.ecp");
    fnMsLoadingHideElement("rider_row_al_loading_details_sqs.dp");
    fnMsLoadingHideElement("rider_row_al_loading_details_sqs.amr");
    fnMsLoadingHideElement("rider_row_al_loading_details_sqs.adi");
    fnMsLoadingHideElement("rider_row_al_loading_details_sqs.pmed");
    fnMsLoadingHideElement("rider_row_al_loading_details_sqs.hb");
    fnMsLoadingHideElement("rider_row_al_loading_details_sqs.phl");
    fnMsLoadingHideElement("rider_row_al_loading_details_sqs.add");
    fnMsLoadingHideElement("rider_row_al_loading_details_sqs.pec");
}

function fnMsLoadingHideElement(id)
{
//    if(!(document.getElementById(id)==null || document.getElementById(id)=="" || document.getElementById(id)=="undefined" ))
//    {
    document.getElementById(id).style.display='none';
   // }
}

function fnMsLoadingShowElement(id)
{
//    if(!(document.getElementById(id)==null || document.getElementById(id)=="" || document.getElementById(id)=="undefined" ))
//    {

    
    document.getElementById(id).style.display='table-row';
    //}
}


function fnMsLoadingonSaveButton()
{
    fnMsLoadingCheckforFieldsUpdate("");
}

function fnMsLoadingValidateData(flagupdate,flagnoupdate)
{
    console.log("flags----->"+flagupdate+"------>"+flagnoupdate);
    if(flagupdate=="0" || flagupdate==0)
    {
        flagupdate="1";
    }
    if(fnMsLoadingvalidateData())
    {
        if(document.getElementById("al_loading_details_sqs.mlife.ah_phl.value").value!="" && document.getElementById("al_loading_details_sqs.mlife.ah_phl.value").value!="null" && document.getElementById("al_loading_details_sqs.mlife.ah_phl.value").value!=null && document.getElementById("al_loading_details_sqs.mlife.ah_phl.value").value!=0 && document.getElementById("al_loading_details_sqs.mlife.ah_phl.value").value!="0")
            {
                if(document.getElementById("al_rider_sqs.pruvalue_med.id").checked && document.getElementById("al_rider_sqs.pruvalue_med.rider_option_value").value==300)
                {
                    js_set_var("premium_with_medsaver","",function()
                    {
                        js_set_var("premium_without_medsaver","",function()
                        {
                                          

                            var loading_valid_res = fnMsfilledfieldsLoading();
                            var loading_update_data_flags;
                            
                            
                            
                            loading_update_data_flags = {
                                "loading_flag_update": flagupdate,
                                "loading_flag_noupdate": flagnoupdate
                            }
                                  
                            if(loading_valid_res != "}" && loading_valid_res != "")
                            {
                                    console.log("First loading_valid_res --->"+JSON.stringify(loading_valid_res));
                                js_set_var("engineloadingstring", JSON.stringify(loading_valid_res), function()
                                {
                                    js_set_var("loading_update_flags",JSON.stringify(loading_update_data_flags),function()
                                    {
                                        js_set_var("loading_update_flags_database",JSON.stringify(loading_update_data_flags),function()
                                        {
                                            fnMsLoadingSetDataonExit();
                                        });
                                    });
                                });
                            }
                            else
                            {
                                   console.log("First console-else->");
                                var loading_valid_res = null;
                                js_set_var("engineloadingstring", JSON.stringify(loading_valid_res), function()
                                           {
                                           js_set_var("loading_update_flags",JSON.stringify(loading_update_data_flags),function()
                                                      {
                                                      js_set_var("loading_update_flags_database",JSON.stringify(loading_update_data_flags),function()
                                                                 {
                                                                 fnMsLoadingSetDataonExit();
                                                                 });
                                                      });
                                           });
                            }
                        });
                    });
                }
                else
                {
                    if(document.getElementById("al_rider_sqs.pruvalue_med.id").checked && document.getElementById("al_rider_sqs.pruvalue_med.rider_option_value").value==0)
                    {
                        pvm_call_count=0;
                        medvaluepoint="";
                        roomboard="";
                        expiryage="";
                    }
                    var loading_valid_res = fnMsfilledfieldsLoading();
                    var loading_update_data_flags;
                    
                    
                    
                    loading_update_data_flags = {
                        "loading_flag_update": flagupdate,
                        "loading_flag_noupdate": flagnoupdate
                    }
                    
                    if(loading_valid_res != "}" && loading_valid_res != "")
                    {
                         console.log("Second loading_valid_res --->"+JSON.stringify(loading_valid_res));
                        js_set_var("engineloadingstring", JSON.stringify(loading_valid_res), function()
                                   {
                                   js_set_var("loading_update_flags",JSON.stringify(loading_update_data_flags),function()
                                              {
                                              js_set_var("loading_update_flags_database",JSON.stringify(loading_update_data_flags),function()
                                                         {
                                                         fnMsLoadingSetDataonExit();
                                                         });
                                              });
                                   });
                    }
                    else
                    {
                        console.log("Second --else-->");
                        var loading_valid_res = null;
                        js_set_var("engineloadingstring", JSON.stringify(loading_valid_res), function()
                                   {
                                   js_set_var("loading_update_flags",JSON.stringify(loading_update_data_flags),function()
                                              {
                                              js_set_var("loading_update_flags_database",JSON.stringify(loading_update_data_flags),function()
                                                         {
                                                         fnMsLoadingSetDataonExit();
                                                         });
                                              });
                                   });
                    }
            }
        }
        else
        {
            var loading_valid_res = fnMsfilledfieldsLoading();
            var loading_update_data_flags;
            
            
            
            loading_update_data_flags = {
                "loading_flag_update": flagupdate,
                "loading_flag_noupdate": flagnoupdate
            }
            
            if(loading_valid_res != "}" && loading_valid_res != "")
            {
                console.log("Third loading_valid_res --->"+JSON.stringify(loading_valid_res));
                js_set_var("engineloadingstring", JSON.stringify(loading_valid_res), function()
                           {
                           js_set_var("loading_update_flags",JSON.stringify(loading_update_data_flags),function()
                                      {
                                      js_set_var("loading_update_flags_database",JSON.stringify(loading_update_data_flags),function()
                                                 {
                                                 fnMsLoadingSetDataonExit();
                                                 });
                                      });
                           });
            }
            else
            {
                console.log("THird--else->");
                var loading_valid_res = null;
                js_set_var("engineloadingstring", JSON.stringify(loading_valid_res), function()
                           {
                           js_set_var("loading_update_flags",JSON.stringify(loading_update_data_flags),function()
                                      {
                                      js_set_var("loading_update_flags_database",JSON.stringify(loading_update_data_flags),function()
                                                 {
                                                 fnMsLoadingSetDataonExit();
                                                 });
                                      });
                           });
            }
        }
    }
}


function fnMsfilledfieldsLoading()
{
    // TODO 28/12/2017
    var loading_valid_ress;
        loading_valid_ress = "{";;
        $('input[type=number]').each(function()
        {
             var input_id = this.id.split(".");
             if(input_id[0] == "al_loading_details_sqs")
             {
                                     var temp_id = this.id;
                                     var temp_val_loading = document.getElementById(temp_id).value;
                                     if(temp_id=="al_loading_details_sqs.mlife.ca.value")
                                     {
                                        temp_id = "al_loading_details_sqs.mlife.em.value";
                                     }
                                     
             
                 if(temp_val_loading.length > 0)
                 {
                    console.log("Loading res1-->"+loading_valid_ress+"temp_id-->"+temp_id+"temp_val_loading-->"+temp_val_loading);
                    loading_valid_ress += '"'+temp_id+'":"'+temp_val_loading+'",';
                 }
             }
        });
    
 $('input[type=text]').each(function()
                                 {
                                 var input_id=this.id.split(".");
                                 if(input_id[0]=="al_loading_details_sqs")
                                 {
                                 var temp_id=this.id;
                                 var temp_val_loading=document.getElementById(temp_id).value;
                                 if(temp_id=="al_loading_details_sqs.mlife.ca.value")
                                 {
                                 temp_id="al_loading_details_sqs.mlife.em.value";
                                 }
                            
                            if(temp_id=="al_loading_details_sqs.mlife.ah_pec.value" && (obj_prochoice["al_sqs_details.product_name"] =="PRUwith you" || obj_prochoice["al_sqs_details.product_name"] == "PRULink Cover" || obj_prochoice["al_sqs_details.product_name"] == "PRUSignature Assure"))//Added condition by ankita on 10 April 2019
                            {
                            temp_id="al_loading_details_sqs.mlife.essential_child_plus.value";
                            }
                            if(temp_id=="al_loading_details_sqs.mlife.ah_phl.value_millennium" && (obj_prochoice["al_sqs_details.product_name"] =="PRUwith you" || obj_prochoice["al_sqs_details.product_name"] == "PRULink Cover" || obj_prochoice["al_sqs_details.product_name"] == "PRUSignature Assure"))//Added condition by ankita on 10 April 2019
                            {
                            temp_id="al_loading_details_sqs.mlife.medical.value";
                            }
                            if(temp_id=="al_loading_details_sqs.mlife.millennium_ah_add.value" && (obj_prochoice["al_sqs_details.product_name"] =="PRUwith you" || obj_prochoice["al_sqs_details.product_name"] == "PRULink Cover" || obj_prochoice["al_sqs_details.product_name"] == "PRUSignature Assure"))//Added condition by ankita on 10 April 2019
                            {
                            temp_id="al_loading_details_sqs.mlife.acci_guard_plus.value";
                            }
                            if(temp_id=="al_loading_details_sqs.mlife.ah_adi.value" && (obj_prochoice["al_sqs_details.product_name"] =="PRUwith you" || obj_prochoice["al_sqs_details.product_name"] == "PRULink Cover" || obj_prochoice["al_sqs_details.product_name"] == "PRUSignature Assure"))//Added condition by ankita on 10 April 2019
                            {
                            temp_id="al_loading_details_sqs.mlife.acci_income_plus.value";
                            }

                            if(temp_id=="al_loading_details_sqs.mlife.ah_amr.value" && (obj_prochoice["al_sqs_details.product_name"] =="PRUwith you" || obj_prochoice["al_sqs_details.product_name"] == "PRULink Cover" || obj_prochoice["al_sqs_details.product_name"] == "PRUSignature Assure"))//Added condition by ankita on 10 April 2019
                            {
                            temp_id="al_loading_details_sqs.mlife.acci_med_plus.value";
                            }

                            
                            
                            
                                 
                                 if(temp_val_loading.length>0)
                                 {
                            console.log("Loading res2-->"+loading_valid_ress+"temp_id-->"+temp_id+"temp_val_loading-->"+temp_val_loading);
                                 if(!((temp_id=="al_loading_details_sqs.mlife.em.value") && (obj_prochoice["al_sqs_details.product_name"]=="PRUsignature income")))
                                 {
                                 console.log("Loading res2 in else-->"+loading_valid_ress+"temp_id-->"+temp_id+"temp_val_loading-->"+temp_val_loading);
                                 loading_valid_ress+='"'+temp_id+'":"'+temp_val_loading+'",';
                                 }
                                 }
                                 }
                                 });
  if(obj_prochoice["al_sqs_details.product_name"]=="PRUsignature USD" || obj_prochoice["al_sqs_details.product_name"]=="PRUsignature income" || obj_prochoice["al_sqs_details.product_name"]==="PRULink Supreme" || obj_prochoice["al_sqs_details.product_name"]==="PRUElite Invest" || obj_prochoice["al_sqs_details.product_name"]==="PRUSignature GrowthPlus" || obj_prochoice["al_sqs_details.product_name"] === "PRULink Supreme Plus"){
    $('input[type=hidden]').each(function()
                                 {
                                 var input_id = this.id.split(".");
                                 if(input_id[0] == "al_loading_details_sqs")
                                 {
                                 var temp_id = this.id;
                                console.log("loading string---->"+temp_id);
                                var temp_val_loading = document.getElementById(temp_id).value;
                                 if(temp_id=="al_loading_details_sqs.mlife.loading_value_indicator"){
                                 if(temp_val_loading == undefined || temp_val_loading == '<null>' ||temp_val_loading == 'undefined' || temp_val_loading == "" || temp_val_loading == "null" || temp_val_loading == null)
                                 {
                                 temp_val_loading="N";
                                 }
                                 }
                                 if(temp_val_loading.length > 0)
                                 {
                                 console.log("Loading res3-->"+loading_valid_ress+"temp_id-->"+temp_id+"temp_val_loading-->"+temp_val_loading);
                                 loading_valid_ress += '"'+temp_id+'":"'+temp_val_loading+'",';
                                 }
                                 }
                                 });
  }
    //added if condition by paromita and ankita for this id al_loading_details_sqs.mlife.em.value which was not geting value for the first time
    if(obj_prochoice["al_sqs_details.product_name"]=="PRUsignature income")
    {
        var temp_id ="al_loading_details_sqs.mlife.em.value";
        var temp_val_loading ="";
        if(document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator_125").checked)
        {
            temp_val_loading="125";
        }
        else
        {
            temp_val_loading="105";
        }
        if(temp_val_loading.length > 0)
        {
            console.log("Loading res4-->"+loading_valid_ress+"temp_id-->"+temp_id+"temp_val_loading-->"+temp_val_loading);
            loading_valid_ress += '"'+temp_id+'":"'+temp_val_loading+'",';
        }
    }
        loading_valid_ress = loading_valid_ress.slice(0, -1);
        loading_valid_ress += "}";
    console.log("loading_valid_ress---->"+loading_valid_ress);
    return loading_valid_ress;
}

/*******************************************************
 Function Name: fnMsLoadingCheckforFieldsUpdate()
 Function Description: Check for any updates done on page in edit mode when values are already set
 Parameters:
 Created By: Pooja Dubey
 Created On: 13 Oct 2014
 Modified By:
 Modified On:
 Modification Reason:
 *******************************************************/
function fnMsLoadingCheckforFieldsUpdate(flag)
{
    js_get_var("loading_details_response", function(loading_res)
    {
        if(loading_res != "" && loading_res != null && loading_res != "null"  && loading_res != "(null)")
        {
            var result = $.parseJSON(loading_res);
            $.each(result, function(k, v)
            {
                   console.log("loading issued"+v+"-----"+k);
                if(!(v == document.getElementById(k).value))
                {
                   loading_flag_update = "1";
                }else
                {
                   loading_flag_noupdate = "0";
                }
            });
            
            fnMsLoadingValidateData(loading_flag_update,loading_flag_noupdate);
        }else
        {
            $('input[type=number]').each(function()
            {
                var input_id = this.id.split(".");
                if(input_id[0] == "al_loading_details_sqs")
                {
                    var temp_id = this.id;
                    var temp_val_loading = document.getElementById(temp_id).value;

                    if(temp_val_loading.length > 0)

                    {
                        loading_flag_update = "1";
                    }else
                    {
                        loading_flag_noupdate = "0";
                    }
                }
            });
               $('input[type=text]').each(function()
                                            {
                                            var input_id = this.id.split(".");
                                            if(input_id[0] == "al_loading_details_sqs")
                                            {
                                            var temp_id = this.id;
                                            var temp_val_loading = document.getElementById(temp_id).value;
                                            
                                            if(temp_val_loading.length > 0)
                                            
                                            {
                                            loading_flag_update = "1";
                                            }else
                                            {
                                            loading_flag_noupdate = "0";
                                            }
                                            }
                                            });
               if(obj_prochoice["al_sqs_details.product_name"]=="PRUsignature USD" || obj_prochoice["al_sqs_details.product_name"]=="PRUsignature income" || obj_prochoice["al_sqs_details.product_name"]==="PRULink Supreme" || obj_prochoice["al_sqs_details.product_name"]==="PRUElite Invest" || obj_prochoice["al_sqs_details.product_name"]==="PRUSignature GrowthPlus" || obj_prochoice["al_sqs_details.product_name"]==="PRULink Supreme Plus"){
               $('input[type=hidden]').each(function()
                                          {
                                          var input_id = this.id.split(".");
                                          if(input_id[0] == "al_loading_details_sqs")
                                          {
                                          var temp_id = this.id;
                                          var temp_val_loading = document.getElementById(temp_id).value;
                                            console.log("temp_val_loading:"+temp_val_loading);
                                            console.log("temp_id:"+temp_id);
                                            console.log("temp_id length:"+temp_val_loading.length);
                                          if(temp_val_loading.length > 0)
                                          
                                          {
                                          loading_flag_update = "1";
                                          }else
                                          {
                                          loading_flag_noupdate = "0";
                                          }
                                          }
                                          });
               }
            fnMsLoadingValidateData(loading_flag_update,loading_flag_noupdate);
        }
    });
}




/*******************************************************
 Function Name: fnMsSetLoadingValueUSD(id)
 Function Description: set loading indicator value to hidden filed.
 Parameters:
 Created By: Pramod Chavan
 Created On: 05 March 2018
 Modified By:
 Modified On:
 Modification Reason:
 *******************************************************/
function fnMsSetLoadingValueUSD(id){
	 if(id=="al_loading_details_sqs.mlife.loading_value_indicator_125"){
        
        
        document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator").value="N";
        
    }else if(id=="al_loading_details_sqs.mlife.loading_value_indicator_105"){
        
        
        document.getElementById("al_loading_details_sqs.mlife.loading_value_indicator").value="Y";
    }
	}

/***********Following Function Added by Sachin Tupe for Def-4556 ************/
function fnSetAutomaticValue(id)
{
    if(obj_prochoice["al_sqs_details.product_name"]=="PRUlife partner")
    {
        var spiltedId=id.split(".");
        if(spiltedId[2].indexOf("di") > -1)
        {
            var spiltedId=id.split(".")
            var inputValue=document.getElementById(id).value;
            var otaindedId=spiltedId[0]+"."+spiltedId[1]+"."+spiltedId[2].replace("di","tpd")+"."+spiltedId[3];
            document.getElementById(otaindedId).value=inputValue;
        }else
        {
            var inputValue=document.getElementById(id).value;
            var otaindedId=id.replace("tpd","di");
            document.getElementById(otaindedId).value=inputValue;
        }
    
    }
}
function fnGetValuesToPopulate(obj_solutions_loading)
{
    for(i=0;i<obj_solutions_loading.length;i++)
    {
        console.log("obj_solutions_loading[i]:"+obj_solutions_loading[i]);
    }
}

/*function checkTermValidation(selfId){
    console.log("Obtained ID=="+selfId.id);
    
    if(obj_prochoice["al_sqs_details.product_name"] == "EssentialLife (SP)" || obj_prochoice["al_sqs_details.product_name"] == "PRUSignature Protect"){
        
        if(document.getElementById(selfId.id).value!="" && document.getElementById(selfId.id).value<5){
            
            alert("Loading Term for PM (%) and/or PP (%) is invalid");
            document.getElementById(selfId.id).value = "";
            
        }
        
        
    }
    
}*/
