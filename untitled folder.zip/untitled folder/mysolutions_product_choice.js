var basic_expiry_age="";
var tot_fund_value = "0";
var obj_prochoice_res="";
var product_flag_noupdate="0";
var product_flag_update="0";
var obj_prochoice="";
var obj_mlife="";
var arrayF=[];

var obj_slife="";
var obj_tlife="";
var prodnames = "";
var expiryages = "";
var replace_res="";
var effect_date="";
var prod_expiry_dt = "";
//var ds_agentId="";
var fund_location_index=[]; // for PRUwith you product.
var temp_lifeLinkFundArray=[];
  var uniqueNamesFilter=[];
var index_lenght=0;

var fund_bit=0;
var isILproductCheck=false;
var clientIdForIL="";
var mlifePersonIdIL="";

var sqsIdIL="";
var sqsCountForIL=0;
var ForgeinCurrency="";//added by sourabh for pruglobal series
var checkIlMonthly=false;
var ilMonthlyAnb="";
var temp_ildailyanb="";
var os_mlife_anb="";
var os_slife_anb="";
var os_tlife_anb="";
var temp_ilMonthly="" //Added by Sachin Tupe for il monthly CR.
var slife_il_monthly_anb="";//Added by Sachin Tupe for il monthly CR.
var tlife_il_monthly_anb="";//Added by Sachin Tupe for il monthly CR.
var slife_il_anb_temp="";//Added by Sachin Tupe for il monthly CR.
var tlife_il_anb_temp="";//Added by Sachin Tupe for il monthly CR.
var inceILdate_monthly="";
var prodtype="";
var prodtypeForgeinCurrency=""; //sourabh added for forgein currency for pruglobal series on 3 april 2019
var isbackdate=false;
var obj_ILP="";
var obj_ForeignCurrencyFunds="";
var ilmonthly_secondlifeAge="";
var ilmonthly_thirdlifeAge="";
var ilmonthly_selection=false;
var backdate_flag=false;
/**************/
var osmainlifeAnb=""; //Added for defect 5991 on date 10-8-2018
var ilmainlifeAnb="";//Added for defect 5991 on date 10-8-2018
var ilmainlifeAnb="";//Added for defect 5991 on date 10-8-2018
var checkBenefitResponse="";
/****************/
var isEaseFlag="Ease1";
var uiaFundSelectionFlag=false; //Added for New CR.PRUsignature income on date 17-09-2018.
var uiaFundSelectionclearFlag=false//Added for New CR.PRUsignature income
var from_benefit_page=false;
var needClearFund=false;//Added for New CR.PRUsignature income
/****Following variable Added by Sachin tupe for Ease campaign****/
var easeILSecondlifeanb="";
var easeGenderInfo="";
var easeSmokingStatus="";
var easeILThirdlifeanb="";
var easeGenderInfothirdLife="";
var easeSmokingStatusthirdLife="";
var vpmsuiaFundSelectionFlag=false;
var product_code="";
var product_type="";
var buttonPlansResonse="";
var  productSolutionFilter="";
var checkVailableProduct="";
var isCallFromDatePicker="No";
var testProductData=[];
var notReturnProduct=false;
var FundCurrencyResponse="";//Added for fund and currency response
var FundResponse="";//Added for fund and currency response
var isCurrencyExpired="";
var sproductname="";
var isSavings={"savings_growth_benefit":"PRUgrowth","savings_pcdr_benefit":"PRUcash double reward","solutions_pc_benefit":"PRUcash","wealth_max_benefit":"PRUWealth Max","wealth_plus_benefit":"PRUWealth Plus","solutions_enrichDiv_benefit":"PRUCash Enrich"}
var ProductMasterResponse="";
var event_decider="";
var idArray = [];
var campaignScreenVisited="";
var inceptionDateVisted="";
//added by ankita on 28 feb 2023 for bundle product
var disclousure_Option_Value="";
var lifeLinkFundArray=new Array("al_sqs_details.bond_fund","al_sqs_details.asia_local_bond_fund","al_sqs_details.managed_fund2","al_sqs_details.equity_fund","al_sqs_details.dana_aman","al_sqs_details.dana_urus2","al_sqs_details.dana_unggul","al_sqs_details.asia_managed_fund","al_sqs_details.asia_property","al_sqs_details.global_market_naviga","al_sqs_details.dragon_peacock","al_sqs_details.asia_equity_fund","al_sqs_details.equity_focus_fund","al_sqs_details.equity_income_fund","al_sqs_details.global_leaders_fund","al_sqs_details.asian_high_yield_bond_fund","al_sqs_details.japan_dynamic_fund","al_sqs_details.euro_equity_fund","al_sqs_details.multi_asset_fund","al_sqs_details.asia_select_focus_fund","al_sqs_details.flexi_vantage_fund","al_sqs_details.asia_opportunities_fund","al_sqs_details.global_managed_fund","al_sqs_details.global_opportunities_fund","al_sqs_details.strategic_managed_fund","al_sqs_details.emerging_opportunities_fund","al_sqs_details.global_growth_fund","al_sqs_details.global_strategic_fund","al_sqs_details.equity_plus_fund","al_sqs_details.managed_plus_fund","al_sqs_details.asia_great_fund","al_sqs_details.innovation_fund","al_sqs_details.us_equity_fund","al_sqs_details.pacific_dynamic_income_fund","al_sqs_details.sustainable_equity_fund","al_sqs_details.global_esg_choice_fund");// sustainable_equity_fund new july 2023 fund CR SEF & ADI Funds added by sachin on 9-6-2023.// Pradnya: added global_esg_choice_fund for march24 release

temp_lifeLinkFundArray=lifeLinkFundArray;
var msJsonPaymentFrequency = {
	"Payment Frequency":"Payment Frequency",
  "A": "Annually",
  "H": "Half Yearly",
  "Q": "Quarterly",
  "M": "Monthly"
};
var msJsonPaymentMode = {
    "Payment Method":"Payment Method",
    "Credit Card1": "Credit Card",
    "Debit Card": "Debit Card",
    "Cash/Cheque": "Cash/Cheque",
    "Auto Debit": "Direct Debit"
};

var msJsonBancaPaymentMode = {
    "Payment Method":"Payment Method",
    "Credit Card1": "Credit Card",
    "Debit Card": "Debit Card",
    "Bank Transfer": "Bank Transfer",
    "Auto Debit": "Direct Debit"
};

/*start
Common header to add comment if added new product condition and also specify that product is similar to which product

condition for product name PRUSignature Vanguard added by ankita and is similar to PRUWealth plus and PRUSignature Assure product for july release.
condition for product name PRUSignature Harvest Plus added by ankita and is similar to PRUSignature Harvest product for september release.
condition for product name PRUSignature Ace added by ankita and is similar to PRUSignature Invest product on 8 sept 2022 for october release.
 condition for product name PRUSignature Boost added by ankita and is similar to PRUSignature Harvest Plus product for May release 2023.
 condition for PRUEnhanced Cover similar to PRUmillion Cover 2.0 added by Pradnya for Aug 2023 release
 conditions for PRUWealth Enrich added by Sachin Tupe for August Release 2023.
 Pradnya: added PRULink Supreme Plus product for march24 release.
 Pradnya: added conditions for PRUsignature plus for june24 release.
end*/

// Add product name in below array if product is not applicable for backdate 

var backDateProductList = ["PRUlink one","PRUwith you","PRUlife ready","PRUmy child","PRUmy kid","LifeLink","PRUlink million","PRUmy legacy","PRUmy gift","RetireGuard (SP)","InvestLink","InvestLink Global","PRUheritage","PRUlink investor account","PRUretirement growth","PRUlife partner","PRUsignature","PRUsignature USD","PRUwealth","PRUsignature infinite","Select Products","PRUmillion cover","PRUmy treasure","PRUsmart gain","PRUsignature income","PRUsignature prime","PRUSignature Invest","PRULink Investor Account","PRUGlobal Series","PRULink Cover","PRUWealth Plus","PRUMy Gift","PRUWealth Max","PRUMax Cover","PRUMillion Cover 2.0","PRUMulti Crisis Guard","PRUSignature Assure","PRULink Growth","PRULink Supreme","PRUSignature Vanguard","PRUSignature Ace","PRUElite Invest","PRUSignature GrowthPlus","PRUEnhanced Cover","PRUWealth Enrich","PRULink Supreme Plus","PRUSignature Plus"]; //New product "PRUsmart gain" Added by Sachin Tupe on 29-05-2018 //sourabh added for PRUSignature Invest on 8 feb 2019 PRUGlobal Series on 1 april 2019// Shivani added condition for PRUMulti Crisis Guard//added product name PRUSignature Vanguard by ankita on 4 july 2022


//Added condition for PRUsignature income by ankita on 7 July 2018

var ilConfigurableDatabase="";
var array_inception_element=[]; //TODO 04-06-2018;
//var array_inception_operation="";
var ilMonthlyDecide=""
var incr_value="";
var incep_value="";
var backdateYesFlag=false;

var isPopUpClosed=0;
var isOkButtonClicked=0;

//added by ankita on 17 jan 2023 for bundle product.
var arrayBundleProduct=[];
var arrayListForBundle={
    "Base":"PRUsignature",
    "Bundle":"PRUCritical Protect"
}

//Function for Swipe Right
function fnMsProductvalidateandSwipeRight()
{
    fnMsvalidateProdChoiceScreenforRedMark()
    fnMsProductCheckforFieldsUpdate("swipe_right");
}

//Function for Swipe Left and To transfer data from one page to other
function fnMsProductvalidateandSwipeLeft()
{
    js_get_var("main_life_response", function(mainlife_res)
   {
       if(mainlife_res != "" && mainlife_res != null && mainlife_res != "null"  && mainlife_res != "(null)")
       {
               obj_mlife = JSON.parse(mainlife_res);
       }
       if(validateProdChoiceScreen(obj_mlife))
       {
               fnMsProductCheckforFieldsUpdate("Swp_Module");
       }
    });
}

function fnMsProduct_Exit()
{
    js_get_var("main_life_response", function(mainlife_res)
               {
               if(mainlife_res != "" && mainlife_res != null && mainlife_res != "null"  && mainlife_res != "(null)")
               {
               obj_mlife = JSON.parse(mainlife_res);
               }
               if(validateProdChoiceScreen(obj_mlife))
               {
		fnMsProductCheckforFieldsUpdate("Ext_Module");
               console.log("canSwipe fnMsProduct_Exit::"+canSwipe);
	}
               });
    
}


//To load script on load of the page
function onLoadSqsProChoicePage()
{
    
    campaignScreenVisited="";
    isPopUpClosed = 1;
    isOkButtonClicked=0;
   // (arrMySolutionsVisitedFlag[1]==1?arrMySolutionsVisitedFlag[1]=1:arrMySolutionsVisitedFlag[1]=2);
    //arrMySolutionsVisitedFlag[0]=1;
   //SQSmarkTopMenus(1);
    
    
    (arrMySolutionsVisitedFlag[2]==1?arrMySolutionsVisitedFlag[1]=1:arrMySolutionsVisitedFlag[1]=2);
    arrMySolutionsVisitedFlag[0]=1;
    arrMySolutionsVisitedFlag[1]=1;
    SQSmarkTopMenus(2);
   
    isILproductCheck=false;
    clientIdForIL="";
    mlifePersonIdIL="";
    sqsCountForIL=0;
    ForgeinCurrency="";//added by sourabh for pruglobal series
    prodtypeForgeinCurrency=""; //sourabh added for forgein currency for pruglobal series on 3 april 2019
    sqsIdIL="";
    disableCutCopyPaste();
    placeholderToSelect();
    fnget_all_ILP_Product();
    console.log("BACK AGAIN ....");
     //#Prashant 18/09/2015
    //Binds dynamic blur function
    fnGlobalOnBlurCheckForSpclChar();
    fnmsRetriveInceptionObject();// TODO 04-06-2018
    console.log("after fnmsRetriveInceptionObject");
     //$(".fundDisplayFlag").css("display", "");
    
	document.getElementById("total_allocation_block").style.display='none';
	document.getElementById("fund_list").style.display='none';   
	//document.getElementById("al_sqs_details.payment_backdate_no").checked=true;
	document.getElementById("al_sqs_details.payment_backdate_yes").checked=false;
    
    document.getElementById("al_sqs_details.Inception_dt").disabled=true;
    obj_prochoice="";
    
    buttonPlansResonse="";
    idArray=[];
    arrayF=[];
    
    console.log("canSwipe before==>"+canSwipe);
    
    $('.fundDisplayFlag').each(function () {
                               
                               //  $(this.id).removeClass("fundDisplayFlag"," ")
                               
                               if(document.getElementById(this.id).style.display=="")
                               {
                              
                               // document.getElementById(this.id).style.display=""
                               idArray.push(this.id);
                               }
                               // idArray.push(this.id);
                               });
    
   
    
    
    
    
//    js_get_var("isSQSFromAL",function(isSQSFromAL)
//               {
//               if(isSQSFromAL == "Yes")
//               {
//
//               console.log("isSQSFromAL ---->>" +isSQSFromAL)
//               document.getElementById("view_al_btn").style.display = 'block';
//
//               //----------------------
//               var querySelect = new DbUtil();
//               querySelect.query()
//               .select()
//               .column('PLAN_NAME')
//               .from()
//               .table('al_letter_details')
//               .where()
//               .clause('PROPOSAL_NUMBER','=',Al_proposal_no);
//               querySelect.execute(function (response)
//                                   {
//                                   console.log("plan name is ---->>" + response);
//                                   if(response != "{}" && response != ""){
//                                   
//                                   obj = JSON.parse(response);
//                                   var prod_name = obj[0]['PLAN_NAME'];
//                                   
//                                   
//                                   console.log("plan name is ---->>" + prod_name);
//                                   document.getElementById("al_sqs_details.product_name").value = prod_name;
//                                  }
    
/******************************************************************************************/
   /** var upsizeData=fnMsUPsizeData()
    upsizeData.execute(function(response)
                               {
                               
                               if(response!="" && response!="{}")
                               {
                              var  upsizeObj=JSON.parse(response);
                       
                       
                       
                       var sqsCreationDayUpsize = fnGetDateTimeStamp();
                       console.log("sqsCreationDate"+sqsCreationDayUpsize);
                       
                       for (objectUPsize in upsizeObj)
                       {
                       

                       var upsizeStart=upsizeObj[objectUPsize]["campaign_start_dt"];
                       var upsizeEnd=upsizeObj[objectUPsize]["campaign_end_dt"];
                       console.log("upsizeStart"+upsizeStart);
                       console.log("upsizeend"+upsizeStart);
                       var camcode=upsizeObj[objectUPsize]["campaign_code"];
                       console.log("Camcode"+camcode);
                       
                       if(upsizeObj[objectUPsize]["campaign_code"].includes("UPSIZE"))
                       {
                       
                       
                       
                       if(sqsCreationDayUpsize >= upsizeStart && sqsCreationDayUpsize<=upsizeEnd)
                       {
                       canSwipe=0;
                                    bootbox.alert({
                                     className: "my-popup",
                                     message: "<h1><font size='2'>PRUwealth & PRUwith you are eligible for Upsize Campaign & customers will get a 50% upsize if they opt of either of these products.</h1>",
                                     callback: function ()
                                     {
                                     canSwipe=1;
                                                  
                                     
                                     }
                                     });

                       }
                     
                       //}//
                       
                       }
                       
                       
                       }
                       
                      }
                               
 /*****************************************************************************************/
    
    // VPMS and TFS email :- logic to delete the folder for the specified path 28 jan 2020
    var docList=new Array();
    //docList.push(epay_agent_id+"/"+"cardholder"+"/"+epay_e_ref_id);
    docList=["VPMSInput"];
    var pagedata={
        "folder_list": docList,
    }
    //
  
               
    js_call_native_func("DeleteFolder",pagedata,function(response)
                        {
                        console.log("delete the folder 11-->");
        //added by ankita on 28 feb 2023 for bundle product
        disclousure_Option_Value="";
    //
        //added by ankita on 28 feb 2023 for bundle product
        js_get_var("disclousureOptionValue", function(disclousureOptionValue) {
            if (disclousureOptionValue != "" && disclousureOptionValue != "<null>" && disclousureOptionValue != null && disclousureOptionValue != "(null)" && disclousureOptionValue != "{null}" && disclousureOptionValue != undefined) {
            disclousure_Option_Value = disclousureOptionValue;
            }
                        js_get_var("beneft_selection_response", function(benefitChoice)
                                   {
                                   if(benefitChoice!="" && benefitChoice!="(null)" && benefitChoice!=null && benefitChoice!="null")
                                   {
                                   
                                   checkBenefitResponse=JSON.parse(benefitChoice);
                                   
                                   
                                   }
                                   console.log("checkBenefitResponse-->"+JSON.stringify(checkBenefitResponse));
    js_get_var("buttons_plans_response", function(solutionsPlan)
               {
               if(solutionsPlan!="" && solutionsPlan!="(null)" && solutionsPlan!=null && solutionsPlan!="null")
               {

               buttonPlansResonse=JSON.parse(solutionsPlan);
               
               
               }
               
              
               
    js_get_var("LoginAgentId",function(agent_id)
               {
               //ds_agentId=agent_id;
 
    js_get_var("mck_client_id", function(client_id_res)
    {
               clientIdForIL=client_id_res;
  
              
              js_get_var("mck_to_ms_ylp", function(ylp_type_handshaking)
                         {
                         
                         if (ylp_type_handshaking != "" && ylp_type_handshaking != null && ylp_type_handshaking != "null" && ylp_type_handshaking != "(null)")
                         {
                         obj_mck_to_ms_ylp = JSON.parse(ylp_type_handshaking);
                         
                         if(obj_mck_to_ms_ylp["ylp_type_mlife"] == undefined || obj_mck_to_ms_ylp["ylp_type_mlife"] == '<null>' ||obj_mck_to_ms_ylp["ylp_type_mlife"] == 'undefined' || obj_mck_to_ms_ylp["ylp_type_mlife"] == "" || obj_mck_to_ms_ylp["ylp_type_mlife"] == "null" || obj_mck_to_ms_ylp["ylp_type_mlife"] == null)
                         {
                         mlifePersonIdIL = "";
                         }else
                         {
                         mlifePersonIdIL = obj_mck_to_ms_ylp["ylp_type_mlife"];
                         }
                         }
                         
                         
                         js_get_var("clientIdsjson",function(response_fresh_ylp)
                                    {
                                    if(clientIdForIL=="" || clientIdForIL=="null" || clientIdForIL==null || clientIdForIL=="(null)")
                                    {
                                    if(response_fresh_ylp!="" && response_fresh_ylp!="(null)" && response_fresh_ylp!=null && response_fresh_ylp!="null")
                                    {
                                    var obj_fresh=JSON.parse(response_fresh_ylp);
                                    clientIdForIL=obj_fresh["client_id"];
                                    mlifePersonIdIL=obj_fresh["mlife_person_id"];
                                    
                                    sqsIdIL=obj_fresh["sqs_id"];
                                    }
                                    }
                         
                         
    js_get_var("proposal_required_info", function(response_pro_req)
        {
            replace_res = response_pro_req;
               if(response_pro_req != "" && response_pro_req != null && response_pro_req != "null" && response_pro_req != "(null)")
               {
               var obj = JSON.parse(response_pro_req);
               sqsIdIL=obj['sqs_id'];
               clientIdForIL=obj['client_id'];
               }
            js_get_var("from_benefit_page",function(consiValue) //Added for PWY_EASE Campaign by Sachin
                       {
                       
                       if(consiValue != "" && consiValue != null && consiValue != "null" && consiValue != "(null)")
                       {
                       from_benefit_page=true
                       
                       }else
                       {
                       from_benefit_page=false;
                       }
                       
                       
           js_get_var("uia_fund_selection_clear",function(UIAFundSelectionClearData) //Added for CR.income by Sachin
                       {
                       
                       if(UIAFundSelectionClearData != "" && UIAFundSelectionClearData != null && UIAFundSelectionClearData != "null" && UIAFundSelectionClearData != "(null)")
                       {
                       uiaFundSelectionclearFlag=true
                       
                       
                       }else
                       {
                       uiaFundSelectionclearFlag=false;
                       }
                       
           js_get_var("uia_fund_selection", function(uia_fund_flag) //Added for CR.income by Sachin
                          {
                       
                       if(uia_fund_flag != "" && uia_fund_flag != null && uia_fund_flag != "null" && uia_fund_flag != "(null)")
                       {
                       uiaFundSelectionFlag=true
                      
                       
                       }else
                       {
                       uiaFundSelectionFlag=false;
                       }
                       
            js_get_var("prod_choice_res", function(prod_res)
            {
                js_get_var("main_life_response", function(mainlife_res)

                {

                    if (mainlife_res != "" && mainlife_res != null && mainlife_res != "null" && mainlife_res != "(null)")
                    {
                           console.log("if main life response not null"+ mainlife_res);
                        obj_mlife = JSON.parse(mainlife_res);
                        //TODO on 10-08-2018
                           osmainlifeAnb= obj_mlife["al_person_details.mlife.dob"];//Added for defect 5991 on date 10-8-2018
                           ilmainlifeAnb=obj_mlife["al_person_details.mlife.anb_il_product"];//Added for defect 5991 on date 10-8-2018
                           ilmonthlymainlifeAnb=obj_mlife["al_person_details.mlife.anb_il_monthly_product"];//Added for defect 5991 on date 10-8-2018
                          
                           
                           easeGestWeeek=obj_mlife["al_person_details.gestational_week"];
                           easePreCase=obj_mlife["al_person_details.pre_natal_child_flg"];
                           
                        fnMsFundsName();
                    }
                    var fund_currency_select_query=getFundCurrencyFromDevice(obj_mlife["pamb_channel"]);//Added for currency configuration for global seriese product on date 12-6-2019 by Sachin Tupe
                           
                     //fund currency
                    var selectQuery = getProductsFromDevice(obj_mlife["pamb_channel"]);
                           
                     fund_currency_select_query.execute(function(fund_currency_response)
                    {
                    selectQuery.execute(function(product_response)
                    {
                            var selectFundQuery = getFundsFromDevice(obj_mlife["pamb_channel"]);
                                        
                            selectFundQuery.execute(function(fund_response)
                            {
                                                    
                                                    
                                        // Sourabh added below code for currency pruglobal series on 3 April 2019 revmoed code
                                        console.log("AL_PRODUCT_MASTER Currency-->"+JSON.stringify(product_response));
                                          if (product_response != "{}" && product_response != "") {
                                          ProductMasterResponse = JSON.parse(product_response);
                                      }
                                        
                                        if(fund_currency_response!="" && fund_currency_response != "{}")
                                        {
                                            
                                            if(fund_response!="" && fund_response!= "{}"){
                                                    FundResponse=JSON.parse(fund_response);
                                                    FundCurrencyResponse=JSON.parse(fund_currency_response);//product currency
                                            }
                                        
                                        }
                                                    
                                                    
                                        
                                        
                                        
                                      // TODO 27122017
                                        var selectQueryForIL = selectQueryForSQSCount (mlifePersonIdIL);
                                        selectQueryForIL.execute(function(sqsILResponse)
                                                            {
                                                                 if (sqsILResponse != "{}" && sqsILResponse != "") {
                                                                 var sqsILResponse = JSON.parse(sqsILResponse);
                                                                 sqsCountForIL = sqsILResponse[0]['count(*)'];
                                                                 
                                                                 }
                                                                 
                                                                 if(mlifePersonIdIL == "" || mlifePersonIdIL == null || mlifePersonIdIL == "null" || mlifePersonIdIL == "(null)"){
                                                                 sqsCountForIL=0;
                                                                 }
                                                                 
                        if (prod_res != "" && prod_res != null && prod_res != "null" && prod_res != "(null)")
                        {
                            //InceptionDateCal();// commented for IL ANB changes. Pramod Chavan: 11122017
                            //setProductDropdown(prod_res);
                        }
                                                                 
                                                                 
                                                                 if((buttonPlansResonse["al_sqs_buttons_plan"]=="" || buttonPlansResonse["al_sqs_buttons_plan"]=="undefined" || buttonPlansResonse["al_sqs_buttons_plan"]==undefined) && (obj_mlife["pamb_channel"]=="Agency" || obj_mlife["pamb_channel"]=="FA" ||obj_mlife["pamb_channel"]=="Agency" ||obj_mlife["pamb_channel"]=="UOB" || obj_mlife["pamb_channel"]=="Banca") && (obj_mlife["al_person_details.mlife.insu_type"] !="keyman" && obj_mlife["al_person_details.mlife.insu_type"] !="partnership" && obj_mlife["al_person_details.mlife.insu_type"] !="employee" && obj_mlife["al_person_details.mlife.insu_type"] !="Business Loan Insurance (for Company/LLP)" && obj_mlife["al_person_details.mlife.insu_type"] !="Business Loan Insurance (for Sole Proprietorship/Partnership)"))//Added condition for may release for solution button by sachin T on date 1-4-2019
                                                                 {
                                                                 alert("759")
                                                                 console.log("EXEC")
                                                                 if(obj_mlife["al_person_details.mlife.insu_type"] !="individual"){
                                                                 
                                                                 menuController.loadPage("top_mysolutions_maindetails",0);
                                                                 
                                                                 }else{
                                                                 menuController.loadPage("mysolutions_buttons",0)
                                                                 }

                                                                 return ;
                                                                 
                                                                 
                                                                 }
                        js_get_var("sec_life_response", function(scnd_res)
                        {
                            if (scnd_res != "" && scnd_res != null && scnd_res != "null" && scnd_res != "(null)")
                            {
                                obj_slife = JSON.parse(scnd_res);
                                   
                                   easeILSecondlifeanb=obj_slife["al_person_details.slife.anb_il_monthly_product"];//Added for ease pwy cr
                                   easeGenderInfo=obj_slife["al_person_details.slife.gender"];//Added for ease pwy cr
                                   easeSmokingStatus=obj_slife["al_person_details.slife.smoke_status"];//Added for ease pwy cr
                                   
                                   
                                   
                                   
                                   
                                   $(escape_jq("slife_IL_anb_Block")).css("display", "block");// added for display IL ANB field
                            }

                            js_get_var("third_life_response", function(thrd_res)
                            {
                                if (thrd_res != "" && thrd_res != null && thrd_res != "null" && thrd_res != "(null)")
                                {
                                    obj_tlife = JSON.parse(thrd_res);
                                       
                                       easeILThirdlifeanb=obj_tlife["al_person_details.tlife.anb_il_monthly_product"];//Added for ease pwy cr
                                       easeGenderInfothirdLife=obj_tlife["al_person_details.tlife.gender"];//Added for ease pwy cr
                                       easeSmokingStatusthirdLife=obj_tlife["al_person_details.tlife.smoke_status"];//Added for ease pwy cr
                                       
                                       $(escape_jq("tlife_IL_anb_Block")).css("display", "block");// added for display IL ANB field
                                }

                                //Get product choice data
                                js_get_var("prod_choice_response", function(prod_choice_res)
                                {
                                           console.log("##Response["+prod_choice_res+"]")
                                    if (prod_choice_res != "" && prod_choice_res != null && prod_choice_res != "null" && prod_choice_res != "(null)")
                                    {
                                           console.log(" In if ##Response["+prod_choice_res+"]")
                                        obj_prochoice = JSON.parse(prod_choice_res);
                                           if (obj_prochoice["al_sqs_details.product_name"] != "" && obj_prochoice["al_sqs_details.product_name"] != "undefined" && obj_prochoice["al_sqs_details.product_name"] != undefined && obj_prochoice["al_sqs_details.product_name"] != null && obj_prochoice["al_sqs_details.product_name"] != "null" && obj_prochoice["al_sqs_details.product_name"] != "Select Products")
                                           {
                                           if((ilProductList.indexOf(obj_prochoice["al_sqs_details.product_name"])>=0)/*obj_prochoice["al_sqs_details.product_name"]=="PRUwith you"*/){
                                           isILproductCheck=true;
                                           }else{
                                           isILproductCheck=false;
                                           }
                                           }
                                           console.log("@@@onload")
                                        filterProducts(product_response, prod_res, obj_prochoice["al_sqs_details.Inception_dt"], "load",mainlife_res,scnd_res,thrd_res);
                                    } else
                                    {
                                        if (replace_res != "" && replace_res != null && replace_res != "null" && replace_res != "(null)")
                                        {
                                            var obj = JSON.parse(replace_res);
                                            var sqs_id = obj['sqs_id'];
                                            var ylp_id = obj['ylp_id'];
                                            var client_id = obj['client_id'];

                                            var querySelection = ProdnameReplaceQuote(sqs_id, client_id);
                                            querySelection.execute(function(prodname_res)
                                            {
                                                var obj_resp = JSON.parse(prodname_res);
                                                var product_name_res = obj_resp[0]['product_name'];

                                                var prodlength = document.getElementById("al_sqs_details.product_name").options.length;
                                                console.log("---->" + prodlength);
                                                if (prodlength == 1)
                                                {
                                                    document.getElementById("al_sqs_details.product_name").disabled = true;
                                                } else
                                                {
                                                    document.getElementById("al_sqs_details.product_name").disabled = false;
                                                }
                                                ShowFunds("", mainlife_res, scnd_res, thrd_res); //Added by Anjali
                                                prodInceptiondateonload();
                                                                   
                                            });
                                        }
//                                           else if( SQS_From_AL == "Yes"){
//                                           console.log("isSQSFromAL inside product choice ---->>" +isSQSFromAL)
//                                           document.getElementById("view_al_btn").style.display = 'block';
//                                           console.log("response Al_proposal_no"+ Al_proposal_no);
//                                           var AlSelectQuery = fnMPAlSelectQuery('al_letter_details',Al_proposal_no);
//                                           AlSelectQuery.execute(function (response){
//                                                                 console.log("response from product Choice"+ response);
//                                                                 if(response != "" && response !=null && response !="{}"){
//                                                                 console.log("inside response from product Choice");
//                                                                 console.log("response from product Choice"+ response);
//                                                                 obj = JSON.parse(response);
//                                                                 var prod_name = obj[0]['PLAN_NAME'];
//                                                                 
//                                                                 console.log("plan name is for product choice ---->>" + prod_name);
//                                                                 document.getElementById("al_sqs_details.product_name").value = obj[0]['PLAN_NAME'];
//                                                                 
//                                                                 ShowFunds();
//                                                                
//                                                                 }
//                                                                 });
//                                           }

                                           else
                                        {
                                            prodInceptiondateonload();
                                        }
                                           console.log("@@Call 1")
                                           filterProducts(product_response, prod_res, document.getElementById("al_sqs_details.Inception_dt").value, "load",mainlife_res,scnd_res,thrd_res);
                                    }
                                    
                                           
                                           
                                          /* if(channelTypeForAgencyBancaRepls=="banca")
                                           {
                                               console.log("sayali banca")
                                               var modeOption=$(escape_jq("al_sqs_details.payment_mode"));
                                               modeOption.append($("<option />").val("Bank Transfer").text("Bank Transfer"));
                                               $(".sqsPaymentMode option[value='Cash/Cheque']").remove();
                                              
                                           }*/

                                    if (obj_prochoice != "" && obj_prochoice != null && obj_prochoice != "null" && obj_prochoice != "(null)")
                                    {
                                        
                                        // IL ANB changes set ANB on load product details screen when user comes second time. Pramod Chavan: 12122017
                                           $(escape_jq("al_sqs_details.mlife.il_anb")).val(obj_prochoice["al_sqs_details.mlife.il_anb"]);
                                           $(escape_jq("al_sqs_details.slife.il_anb")).val(obj_prochoice["al_sqs_details.slife.il_anb"]);
                                           $(escape_jq("al_sqs_details.tlife.il_anb")).val(obj_prochoice["al_sqs_details.tlife.il_anb"]);
                                           
                                         
                                           
                                           
                                        if (obj_prochoice["al_sqs_details.payment_backdate"] == "No")
                                        {
                                            document.getElementById('al_sqs_details.Inception_dt_img').style.pointerEvents = 'none';
                                            document.getElementById("al_sqs_details.payment_backdate_yes").checked = false;
                                            document.getElementById("al_sqs_details.payment_backdate_no").checked = true;
                                        } else if (obj_prochoice["al_sqs_details.payment_backdate"] == "Yes")
                                        {
                                            document.getElementById('al_sqs_details.Inception_dt_img').style.pointerEvents = 'auto';
                                            document.getElementById("al_sqs_details.payment_backdate_yes").checked = true;
                                            document.getElementById("al_sqs_details.payment_backdate_no").checked = false;
                                        }

                                        if (obj_prochoice["al_sqs_details.Inception_dt"] == 'undefined' )
                                        {
                                            InceptionDateCal();
                                        } else
                                        {
                                            console.log("Inception Date :-" + obj_prochoice["al_sqs_details.Inception_dt"]);
                                            document.getElementById("al_sqs_details.Inception_dt").value = obj_prochoice["al_sqs_details.Inception_dt"];
                                        }

                                           
                                           
                                        if (obj_prochoice["al_sqs_details.payment_frequency"] == undefined)
                                        {
                                            document.getElementById("al_sqs_details.payment_frequency").value = "Payment Frequency";
                                           
                                         
                                           
                                        } else
                                        {
                                            document.getElementById("al_sqs_details.payment_frequency").value = obj_prochoice["al_sqs_details.payment_frequency"];
                                        }

                                        if (obj_prochoice["al_sqs_details.payment_mode"] == undefined)
                                        {
                                            document.getElementById("al_sqs_details.payment_mode").value = "Payment Method";
                                        } else
                                        {
                                            document.getElementById("al_sqs_details.payment_mode").value = obj_prochoice["al_sqs_details.payment_mode"];
                                        }
                                           // Sourabh added for PRUGlobal series 4 april 2019
                                           if (obj_prochoice["al_sqs_details.foreign_currency"] == undefined)
                                           {
                                           document.getElementById("al_sqs_details.foreign_currency").value = "Select Currency";
                                           } else
                                           {
                                           document.getElementById("al_sqs_details.foreign_currency").value = obj_prochoice["al_sqs_details.foreign_currency"];
                                           }
                                           console.log("Foreign currency is"+obj_prochoice["al_sqs_details.foreign_currency"]);
                                        console.log("Product Namr for DropDown :- " + obj_prochoice["al_sqs_details.product_name"]);
                                        if (obj_prochoice["al_sqs_details.product_name"] != "" && obj_prochoice["al_sqs_details.product_name"] != "undefined" && obj_prochoice["al_sqs_details.product_name"] != undefined && obj_prochoice["al_sqs_details.product_name"] != null && obj_prochoice["al_sqs_details.product_name"] != "null" && obj_prochoice["al_sqs_details.product_name"] != "Select Products")
                                        {
                                            if (searchProductInDRp().indexOf(obj_prochoice["al_sqs_details.product_name"])>-1)
                                            {
                                                document.getElementById("al_sqs_details.product_name").value = obj_prochoice["al_sqs_details.product_name"]; //Comment by Rahul for testing
                                            }
                                        }
                                        if (obj_prochoice["al_sqs_details.tot_fund_val"] == undefined)
                                        {
                                            $("#total_allocation_value").html("0");
                                        } else
                                        {
                                            $("#total_allocation_value").html(obj_prochoice["al_sqs_details.tot_fund_val"]);
                                        }
                                        ShowFunds("", mainlife_res, scnd_res, thrd_res);
                                        if (obj_prochoice["al_sqs_details.fund_choice1"] == undefined)
                                        {
                                            document.getElementById("al_sqs_details.fund_choice1").checked = false;
                                        } else
                                        {
                                            if (obj_prochoice["al_sqs_details.fund_choice1"] == "Yes")
                                            {
                                                document.getElementById("al_sqs_details.fund_choice1").checked = true;
                                                document.getElementById("al_sqs_details.fund_choice2").checked = false;

                                                if (obj_mlife["al_person_details.mlife.anb"] <= 12)
                                                {
                                                    document.getElementById("al_sqs_details.fund_choice1").disabled = false;
                                                    document.getElementById("al_sqs_details.fund_choice2").disabled = false;
                                                } else
                                                {
                                                    document.getElementById("al_sqs_details.fund_choice1").disabled = true;
                                                    document.getElementById("al_sqs_details.fund_choice2").disabled = true;
                                                }
                                            } else if (obj_prochoice["al_sqs_details.fund_choice1"] == "No")
                                            {
                                                document.getElementById("al_sqs_details.fund_choice1").checked = false;
                                                document.getElementById("al_sqs_details.fund_choice2").checked = true;
                                                if (obj_mlife["al_person_details.mlife.anb"] <= 12)
                                                {
                                                    document.getElementById("al_sqs_details.fund_choice1").disabled = false;
                                                    document.getElementById("al_sqs_details.fund_choice2").disabled = false;
                                                } else
                                                {
                                                    document.getElementById("al_sqs_details.fund_choice1").disabled = true;
                                                    document.getElementById("al_sqs_details.fund_choice2").disabled = true;
                                                }
                                            }
                                        }

                                        if (obj_prochoice["al_sqs_details.fund_choice2"] == undefined)
                                        {
                                            document.getElementById("al_sqs_details.fund_choice2").checked = false;
                                        } else
                                        {
                                            if (obj_prochoice["al_sqs_details.fund_choice2"] == "Yes")
                                            {
                                                if (obj_mlife["al_person_details.mlife.anb"] <= 12)
                                                {
                                                    document.getElementById("al_sqs_details.fund_choice2").checked = true;
                                                    document.getElementById("al_sqs_details.fund_choice1").checked = false;
                                                    document.getElementById("al_sqs_details.fund_choice2").disabled = false;
                                                    document.getElementById("al_sqs_details.fund_choice1").disabled = false;
                                                } else
                                                {
                                                    document.getElementById("al_sqs_details.fund_choice2").checked = false;
                                                    document.getElementById("al_sqs_details.fund_choice1").checked = true;
                                                    document.getElementById("al_sqs_details.fund_choice2").disabled = true;
                                                    document.getElementById("al_sqs_details.fund_choice1").disabled = true;
                                                }
                                            } else if (obj_prochoice["al_sqs_details.fund_choice2"] == "No")
                                            {
                                                document.getElementById("al_sqs_details.fund_choice2").checked = false;
                                                document.getElementById("al_sqs_details.fund_choice1").checked = true;
                                                if (obj_mlife["al_person_details.mlife.anb"] <= 12)
                                                {
                                                    document.getElementById("al_sqs_details.fund_choice2").disabled = false;
                                                    document.getElementById("al_sqs_details.fund_choice1").disabled = false;
                                                } else
                                                {
                                                    document.getElementById("al_sqs_details.fund_choice2").disabled = true;
                                                    document.getElementById("al_sqs_details.fund_choice1").disabled = true;
                                                }
                                            }
                                        }
                                        fnMsFundsValidation();
                                           var countV=0;
                                           var validFund=0;
                                           var arrayCount=[];
                                        for (var i = 0; i <= lifeLinkFundArray.length - 1; i++)
                                        {
                                           if((document.getElementById("al_sqs_details.product_name").value=="PRUsignature income" || document.getElementById("al_sqs_details.product_name").value=="PRUMy Gift" || document.getElementById("al_sqs_details.product_name").value==="PRUMulti Crisis Guard") && uiaFundSelectionclearFlag) //Added for PRUsignature income CR. on Date 20-09-2018.//Added condition for PRUMulti Crisis Guard by Shivani
                                           {
                                           obj_prochoice[lifeLinkFundArray[i]]='undefined';
                                           
                                           }
                                            if (obj_prochoice[lifeLinkFundArray[i]] == undefined || obj_prochoice[lifeLinkFundArray[i]] == 'undefined')
                                            {
                                                document.getElementById(lifeLinkFundArray[i]).value = 0;
                                        
                                           
                                            } else
                                            {
                                                console.log("onload fund called ..."+lifeLinkFundArray[i]);
                                                document.getElementById(lifeLinkFundArray[i]).value = obj_prochoice[lifeLinkFundArray[i]];
                                                console.log("selected fund"+obj_prochoice[lifeLinkFundArray[i]])
                                         
                                         
                                           if((document.getElementById("al_sqs_details.product_name").value=="PRUsignature infinite" || document.getElementById("al_sqs_details.product_name").value=="PRUSignature Invest" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature Ace") && obj_prochoice[lifeLinkFundArray[i]]==0 && lifeLinkFundArray[i]!="al_sqs_details.asia_property" && lifeLinkFundArray[i]!="al_sqs_details.asia_local_bond_fund")//Added condition for PRUsignature income by ankita on 7 July 2018 //sourabh added PRUsignature Invest on 11 feb 2019   || document.getElementById("al_sqs_details.product_name").value=="PRULink Investor Account"

                                           {
                                           
                                           countV++;
                                           
                                           arrayCount.push(lifeLinkFundArray[i]);
                                           
                                           }
                                           else if((document.getElementById("al_sqs_details.product_name").value=="PRUsignature income" || document.getElementById("al_sqs_details.product_name").value=="PRUMy Gift" || document.getElementById("al_sqs_details.product_name").value=="PRUsignature" || document.getElementById("al_sqs_details.product_name").value==="PRUMulti Crisis Guard") && obj_prochoice[lifeLinkFundArray[i]]==0 && lifeLinkFundArray[i]!="al_sqs_details.asia_property" && lifeLinkFundArray[i]!="al_sqs_details.asia_local_bond_fund")//Added condition for PRUsignature income by ankita on 7 July 2018
                                           
                                           {
                                           
                                           countV++;
                                           
                                           arrayCount.push(lifeLinkFundArray[i]);
                                           console.log("arrayCount:"+arrayCount);
                                           
                                           }

                                           
                                            else if(obj_prochoice[lifeLinkFundArray[i]]==0 /*&& /*lifeLinkFundArray[i]!="al_sqs_details.asia_property" &&**/ /*lifeLinkFundArray[i]!="al_sqs_details.japan_dynamic_fund" && lifeLinkFundArray[i]!="al_sqs_details.euro_equity_fund" /*&& lifeLinkFundArray[i]!="al_sqs_details.asian_high_yield_bond_fund" *//*&& lifeLinkFundArray[i]!="al_sqs_details.global_leaders_fund" /*&& lifeLinkFundArray[i]!="al_sqs_details.multi_asset_fund" *//*&& lifeLinkFundArray[i]!="al_sqs_details.equity_fund"****/)
                                                    {
                                           
                                                            countV++;
                                                                  arrayCount.push(lifeLinkFundArray[i]);
                                           
                                                    }
                                           
                                            }
                                           if(obj_prochoice[lifeLinkFundArray[i]]!=0){
                                           
                                           validFund++;
                                           }
                                           
                                        }
                                           console.log("no of select count"+countV);
                                           
                                             console.log("no of select count"+arrayCount);
                                          
                                              console.log("validFund"+validFund);

                                           if(document.getElementById("al_sqs_details.product_name").value=="PRUmillion cover" || document.getElementById("al_sqs_details.product_name").value=="PRUwith you" || document.getElementById("al_sqs_details.product_name").value=="PRUsignature infinite" || document.getElementById("al_sqs_details.product_name").value=="PRUsmart gain" || document.getElementById("al_sqs_details.product_name").value=="PRUsignature income" || document.getElementById("al_sqs_details.product_name").value=="PRUSignature Invest" || document.getElementById("al_sqs_details.product_name").value=="PRULink Investor Account" || document.getElementById("al_sqs_details.product_name").value=="PRULink Cover" || document.getElementById("al_sqs_details.product_name").value=="PRUWealth Plus" || document.getElementById("al_sqs_details.product_name").value=="PRUMy Gift" || document.getElementById("al_sqs_details.product_name").value=="PRUWealth Max" || document.getElementById("al_sqs_details.product_name").value=="PRUMax Cover" || document.getElementById("al_sqs_details.product_name").value=="PRUsignature" || document.getElementById("al_sqs_details.product_name").value=="PRUMillion Cover 2.0" || document.getElementById("al_sqs_details.product_name").value==="PRUMulti Crisis Guard" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature Assure" || document.getElementById("al_sqs_details.product_name").value==="PRULink Supreme" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature Vanguard"
                                              || document.getElementById("al_sqs_details.product_name").value==="PRUSignature Ace" || document.getElementById("al_sqs_details.product_name").value==="PRUElite Invest" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature GrowthPlus"
                                              || document.getElementById("al_sqs_details.product_name").value==="PRUEnhanced Cover" || document.getElementById("al_sqs_details.product_name").value=="PRUWealth Enrich" || document.getElementById("al_sqs_details.product_name").value==="PRULink Supreme Plus" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature Plus")   //New product "PRUsmart gain" Added by Sachin Tupe on 29-05-2018//Added condition for PRUsignature income by ankita on 7 July 2018 // Sourabh added for fund swipe PRUsignature Invest//Added condition for PRULink Cover by ankita on 22 March 2019

                                           

                                        {
                                           console.log("PRUwith you fund")
                                           if(validFund==10)
                                           {
                                                                             if (countV==3 || countV==10 || countV==8 || countV==14 || countV==11 || countV<=50)
                                                                              {
                                                                                    for(var i = 0; i <= arrayCount.length - 1; i++)
                                                                                {
                                                                              document.getElementById(arrayCount[i]).disabled=true;
                                                                                console.log("in disable of fund")
                                                                              
                                                                              }
                                                                              
                                                                              }
                                           }
                                        }
                                                                              
                                                                              
                                        $("#total_allocation_value").html(obj_prochoice["al_sqs_details.tot_fund_val"]);
                                           
                                            if((document.getElementById("al_sqs_details.product_name").value=="PRUsignature income" || document.getElementById("al_sqs_details.product_name").value=="PRUMy Gift" || document.getElementById("al_sqs_details.product_name").value==="PRUMulti Crisis Guard" ) && uiaFundSelectionclearFlag)//Added for CR.income by Sachin // Added condition for PRUMulti Crisis Guard by Shivani
                                           {
                                             $("#total_allocation_value").html("0");
                                           
                                           }
                                    }
                                         
                                    else
                                    {
                                        ShowFunds("", mainlife_res, scnd_res, thrd_res);
                                    }
                                    js_get_var("product_update_flags", function(update_product_res)
                                    {
                                               console.log("from al update_product_res ----->"+update_product_res);
                                        if (update_product_res != "" && update_product_res != null && update_product_res != "null" && update_product_res != "(null)")
                                        {
                                            var obj_update_product = JSON.parse(update_product_res);

                                            if (obj_update_product["product_flag_update"] == "1")
                                            {
                                                product_flag_update = "1";
                                            }
                                        }

                                        if (replace_res != "" && replace_res != null && replace_res != "null" && replace_res != "(null)")
                                        {
                                               console.log("from al replace_res ----->"+replace_res);
                                            var obj = JSON.parse(replace_res);
                                            var sqs_id = obj['sqs_id'];
                                            var ylp_id = obj['ylp_id'];
                                            var client_id = obj['client_id'];

                                            var querySelection = ProdnameReplaceQuote(sqs_id, client_id);
                                            querySelection.execute(function(prodname_res)
                                            {
                                                var obj_resp = JSON.parse(prodname_res);
                                                var product_name_res = obj_resp[0]["product_name"];
                                                console.log("product_name_res :- " + product_name_res);
                                                console.log("al_sqs_details.product_name res :- " + obj_prochoice["al_sqs_details.product_name"]);
                                                if (obj_prochoice["al_sqs_details.product_name"] == "undefined")
                                                {
                                                    document.getElementById("al_sqs_details.product_name").value = product_name_res;

                                                    if (product_name_res == "PRUmy child" || product_name_res == "PRUmy kid")
                                                    {
                                                        document.getElementById("al_sqs_details.product_name").disabled = true;
                                                    } else
                                                    {
                                                        document.getElementById("al_sqs_details.product_name").disabled = false;
                                                    }
                                                    ShowFunds("", mainlife_res, scnd_res, thrd_res); //Added by Anjali

                                                }
                                            });
                                        }
                                               // Makarand: for autopopulate product name when comes from AL for option 2 08/08/2017 
                                               else if( SQS_From_AL == "Yes" && (obj_prochoice == "" || obj_prochoice == null || obj_prochoice == "null" || obj_prochoice == "(null)")){
                                               console.log("isSQSFromAL ---->>" +SQS_From_AL)
                                               document.getElementById("view_al_btn").style.display = 'block';
                                               
                                               var AlSelectQuery = fnMPAlSelectQuery('al_letter_details',Al_proposal_no);
                                               AlSelectQuery.execute(function (response){
                                                     if(response != "" && response !=null && response !="{}"){
                                                            
                                                             obj = JSON.parse(response);
                                                             var prod_name = obj[0]['PLAN_NAME'];
                                                             
                                                                     if (prod_name != "" && prod_name != "undefined" && prod_name != undefined && prod_name!= null && prod_name != "null" && prod_name != "Select Products"){
                                                                     
                                                                     console.log("plan name is ---->>" + prod_name);
                                                                     //Added by Anjali for Defect 4746 On 9Jan18
                                                                     if((ilProductList.indexOf(prod_name)>=0)/*prod_name=="PRUwith you"*/){
                                                                        isILproductCheck=true;
                                                                      }else{
                                                                        isILproductCheck=false;
                                                                      }
                                                                     document.getElementById("al_sqs_details.product_name").value = prod_name;

                                                                     }
                                                                     
                                                                     ShowFunds('change',mainlife_res,scnd_res,thrd_res); //Added by Anjali for Defect 4746 On 9Jan18
                                                                     fnMnROACheckMandatoryFields();
                                                     
                                                     }
                                                     });
                                               }
                                               
                                                                                        console.log("calculated data",obj_prochoice["al_sqs_details.payment_frequency"]);
                                                                                        //Added for solution prufirst.
                                                                                        if(buttonPlansResonse["al_sqs_buttons_plan"]=="al_sqs_buttons.prufirst" && obj_prochoice["al_sqs_details.payment_frequency"]==undefined){
                                                                                                                                     
                                                                                             document.getElementById("al_sqs_details.payment_frequency").options[4].selected = true
                                                                                             document.getElementById("al_sqs_details.payment_mode").options[1].selected=true;
                                                                                             document.getElementById("al_sqs_details.equity_plus_fund").value="100";
                                                                                             document.getElementById("al_sqs_details.equity_plus_fund").onchange();
                                                                                         }
                                               
                                              
                                              //Anjali CR-104
                                               fnMSCheckMandatoryFields();
                                        product_choice_details("");
                                               
                                               console.log("canswipe before==>"+canSwipe)
                                               
                                               
                                               console.log("canSwipe after==>"+canSwipe);
                                               
                                               
                                               
                                               
                                    });
                                });
                            });
                        });
                    });
                                        });// end fund currency details
                                        });//End product_master
                                                        });//End  currency query
                });
            });
                      });//fund selection
                       });////// for income cr. fund clear
                       });
        });
    });
  });
});
//               //----------------------
//               }
 
});
    //
                       });
  });
        });
               });
   
}

function fnMSCheckMandatoryFields()
{
    //alert("Anjali your Function Call");
    $("select.mandatory").each(function(){
                               console.log($(this).prop('selectedIndex'))
                               if($(this).val() == "Select Products" || $(this).val() == "Payment Frequency" || $(this).val() == "Payment Method" || $(this).val() == "Select Currency")
                               {
                                  // console.log('First Element is selected Product Choice');
                               $(this).removeClass('selectMandatory');
                               $(this).addClass('selectRedMandatory');
                               }
                               else{
                                // console.log('Else First Element is not selected Product Choice');
                               $(this).removeClass('selectRedMandatory');
                               $(this).addClass('selectMandatory');
                               }
                               });
}

//Get payment back date
function getPaybackdate()
{
	var paybkdt;
	if(document.getElementById("al_sqs_details.payment_backdate_no").checked)
	{
		document.getElementById("al_sqs_details.payment_backdate_no").value = "No";
		paybkdt = document.getElementById("al_sqs_details.payment_backdate_no").value;
    }else if(document.getElementById("al_sqs_details.payment_backdate_yes").checked)
    {
        document.getElementById("al_sqs_details.payment_backdate_yes").value = "Yes";
        paybkdt = document.getElementById("al_sqs_details.payment_backdate_yes").value;
    }
	
	return paybkdt;
}


//To transfer data from one page to other
function product_choice_details(flag)
{
    var fund_allocation_val=document.getElementById("total_allocation_value").innerHTML;
    console.log("product_code--:"+product_code);
    console.log("product_type--:"+product_type);
    console.log("basic_expiry_age--:"+basic_expiry_age);
    if(document.getElementById("al_sqs_details.foreign_currency").value == "Select Currency")
    {
        document.getElementById("al_sqs_details.foreign_currency").value = "";
    }
    console.log("foreign_currency--:"+document.getElementById("al_sqs_details.foreign_currency").value);
     //obj_prochoice="";
	//Variable to take json data
	var prod_choice = {
		"al_sqs_details.product_name" : document.getElementById("al_sqs_details.product_name").value,
		"al_sqs_details.payment_backdate" : getPaybackdate(),
		"al_sqs_details.Inception_dt" : document.getElementById("al_sqs_details.Inception_dt").value,
		"al_sqs_details.payment_frequency" : document.getElementById("al_sqs_details.payment_frequency").value,
		"al_sqs_details.payment_mode" : document.getElementById("al_sqs_details.payment_mode").value,
		"al_sqs_details.fund_choice1" : getFundchoiceOne(),
		"al_sqs_details.fund_choice2" : getFundchoiceTwo(),
		"al_sqs_details.equity_fund" : document.getElementById("al_sqs_details.equity_fund").value,
		"al_sqs_details.managed_fund2" : document.getElementById("al_sqs_details.managed_fund2").value,
		"al_sqs_details.bond_fund" : document.getElementById("al_sqs_details.bond_fund").value,
		"al_sqs_details.dana_unggul" : document.getElementById("al_sqs_details.dana_unggul").value,
	    "al_sqs_details.dana_urus2" : document.getElementById("al_sqs_details.dana_urus2").value,
	    "al_sqs_details.dana_aman" : document.getElementById("al_sqs_details.dana_aman").value,
	    "al_sqs_details.asia_property" : document.getElementById("al_sqs_details.asia_property").value,
	    "al_sqs_details.asia_managed_fund" : document.getElementById("al_sqs_details.asia_managed_fund").value,
	    "al_sqs_details.asia_local_bond_fund" : document.getElementById("al_sqs_details.asia_local_bond_fund").value,
	    "al_sqs_details.global_market_naviga" : document.getElementById("al_sqs_details.global_market_naviga").value,
	    "al_sqs_details.dragon_peacock" : document.getElementById("al_sqs_details.dragon_peacock").value,
	    "al_sqs_details.asia_equity_fund" : document.getElementById("al_sqs_details.asia_equity_fund").value,
        "al_sqs_details.equity_focus_fund" : document.getElementById("al_sqs_details.equity_focus_fund").value,
        "al_sqs_details.equity_income_fund" : document.getElementById("al_sqs_details.equity_income_fund").value,
        "al_sqs_details.global_leaders_fund" : document.getElementById("al_sqs_details.global_leaders_fund").value,
        "al_sqs_details.asian_high_yield_bond_fund" : document.getElementById("al_sqs_details.asian_high_yield_bond_fund").value,
        "al_sqs_details.japan_dynamic_fund" : document.getElementById("al_sqs_details.japan_dynamic_fund").value,
        "al_sqs_details.euro_equity_fund" : document.getElementById("al_sqs_details.euro_equity_fund").value,
        "al_sqs_details.multi_asset_fund" : document.getElementById("al_sqs_details.multi_asset_fund").value,
        "al_sqs_details.asia_select_focus_fund" : document.getElementById("al_sqs_details.asia_select_focus_fund").value,
        "al_sqs_details.flexi_vantage_fund" : document.getElementById("al_sqs_details.flexi_vantage_fund").value,
        "al_sqs_details.asia_opportunities_fund" : document.getElementById("al_sqs_details.asia_opportunities_fund").value,
        "al_sqs_details.global_managed_fund" : document.getElementById("al_sqs_details.global_managed_fund").value,
        "al_sqs_details.global_opportunities_fund" : document.getElementById("al_sqs_details.global_opportunities_fund").value,
        "al_sqs_details.strategic_managed_fund" : document.getElementById("al_sqs_details.strategic_managed_fund").value,
        "al_sqs_details.expiry_age":basic_expiry_age,
        "al_sqs_details.tot_fund_val":fund_allocation_val.toString(),
        "al_sqs_details.mlife.il_anb":$(escape_jq("al_sqs_details.mlife.il_anb")).val(),
        "al_sqs_details.slife.il_anb":$(escape_jq("al_sqs_details.slife.il_anb")).val(),
        "al_sqs_details.tlife.il_anb":$(escape_jq("al_sqs_details.tlife.il_anb")).val(),
        "al_sqs_details.product_code":product_code,
        "al_sqs_details.product_type":product_type,
        "al_sqs_details.foreign_currency" : document.getElementById("al_sqs_details.foreign_currency").value,
        "al_sqs_details.emerging_opportunities_fund" : document.getElementById("al_sqs_details.emerging_opportunities_fund").value,
        "al_sqs_details.global_growth_fund" : document.getElementById("al_sqs_details.global_growth_fund").value,
        "al_sqs_details.global_strategic_fund":document.getElementById("al_sqs_details.global_strategic_fund").value,
        "al_sqs_details.equity_plus_fund":document.getElementById("al_sqs_details.equity_plus_fund").value,
        "al_sqs_details.managed_plus_fund":document.getElementById("al_sqs_details.managed_plus_fund").value,
        "al_sqs_details.asia_great_fund":document.getElementById("al_sqs_details.asia_great_fund").value,
        "al_sqs_details.innovation_fund":document.getElementById("al_sqs_details.innovation_fund").value,
        "al_sqs_details.us_equity_fund":document.getElementById("al_sqs_details.us_equity_fund").value,
        "al_sqs_details.pacific_dynamic_income_fund":document.getElementById("al_sqs_details.pacific_dynamic_income_fund").value,
        "al_sqs_details.sustainable_equity_fund":document.getElementById("al_sqs_details.sustainable_equity_fund").value,
        "al_sqs_details.global_esg_choice_fund":document.getElementById("al_sqs_details.global_esg_choice_fund").value
	}
    // sustainable_equity_fund new july 2023 fund CR SEF & ADI Funds added by sachin on 9-6-2023.. //Pradnya: added global_esg_choice_fund for march24 release
    
    console.log("product_flag_update--------->"+product_flag_update);
    
    //Variable to take updated flags
   	var product_update_data_flags = {
        "product_flag_update": product_flag_update
   	}
    //added by ankita for bundle product on 27 jan 2023
    var prod_choice_bundle ={};
    var selectQuery=fnMsGetProductDetails("PRUCritical Protect");
    selectQuery.execute(function(responsebundle)
                        {
    //console.log("arrBundleProductList:"+arrBundleProductList);
    /*var arrBundleProdList=arrBundleProductList[document.getElementById("al_sqs_details.product_name").value];
    console.log("arrBundleProdList:",arrBundleProdList);
    console.log("arrayBundleProduct:",arrayBundleProduct);
    var arrSetBundleProduct={};
    for(i=0;i<arrayBundleProduct.length;i++)
    {
        if(arrayBundleProduct[i]===arrBundleProdList[i])
        {
            prod_choice_bundle = {
                    "al_sqs_details.product_name" : arrayBundleProduct[i],
                    "al_sqs_details.payment_backdate" : getPaybackdate(),
                    "al_sqs_details.Inception_dt" : document.getElementById("al_sqs_details.Inception_dt").value,
                    "al_sqs_details.payment_frequency" : document.getElementById("al_sqs_details.payment_frequency").value,
                    "al_sqs_details.payment_mode" : document.getElementById("al_sqs_details.payment_mode").value,
                    "al_sqs_details.fund_choice1" : getFundchoiceOne(),
                    "al_sqs_details.fund_choice2" : getFundchoiceTwo(),
                    "al_sqs_details.equity_fund" : document.getElementById("al_sqs_details.equity_fund").value,
                    "al_sqs_details.managed_fund2" : document.getElementById("al_sqs_details.managed_fund2").value,
                    "al_sqs_details.bond_fund" : document.getElementById("al_sqs_details.bond_fund").value,
                    "al_sqs_details.dana_unggul" : document.getElementById("al_sqs_details.dana_unggul").value,
                    "al_sqs_details.dana_urus2" : document.getElementById("al_sqs_details.dana_urus2").value,
                    "al_sqs_details.dana_aman" : document.getElementById("al_sqs_details.dana_aman").value,
                    "al_sqs_details.asia_property" : document.getElementById("al_sqs_details.asia_property").value,
                    "al_sqs_details.asia_managed_fund" : document.getElementById("al_sqs_details.asia_managed_fund").value,
                    "al_sqs_details.asia_local_bond_fund" : document.getElementById("al_sqs_details.asia_local_bond_fund").value,
                    "al_sqs_details.global_market_naviga" : document.getElementById("al_sqs_details.global_market_naviga").value,
                    "al_sqs_details.dragon_peacock" : document.getElementById("al_sqs_details.dragon_peacock").value,
                    "al_sqs_details.asia_equity_fund" : document.getElementById("al_sqs_details.asia_equity_fund").value,
                    "al_sqs_details.equity_focus_fund" : document.getElementById("al_sqs_details.equity_focus_fund").value,
                    "al_sqs_details.equity_income_fund" : document.getElementById("al_sqs_details.equity_income_fund").value,
                    "al_sqs_details.global_leaders_fund" : document.getElementById("al_sqs_details.global_leaders_fund").value,
                    "al_sqs_details.asian_high_yield_bond_fund" : document.getElementById("al_sqs_details.asian_high_yield_bond_fund").value,
                    "al_sqs_details.japan_dynamic_fund" : document.getElementById("al_sqs_details.japan_dynamic_fund").value,
                    "al_sqs_details.euro_equity_fund" : document.getElementById("al_sqs_details.euro_equity_fund").value,
                    "al_sqs_details.multi_asset_fund" : document.getElementById("al_sqs_details.multi_asset_fund").value,
                    "al_sqs_details.asia_select_focus_fund" : document.getElementById("al_sqs_details.asia_select_focus_fund").value,
                    "al_sqs_details.flexi_vantage_fund" : document.getElementById("al_sqs_details.flexi_vantage_fund").value,
                    "al_sqs_details.asia_opportunities_fund" : document.getElementById("al_sqs_details.asia_opportunities_fund").value,
                    "al_sqs_details.global_managed_fund" : document.getElementById("al_sqs_details.global_managed_fund").value,
                    "al_sqs_details.global_opportunities_fund" : document.getElementById("al_sqs_details.global_opportunities_fund").value,
                    "al_sqs_details.strategic_managed_fund" : document.getElementById("al_sqs_details.strategic_managed_fund").value,
                    "al_sqs_details.expiry_age":basic_expiry_age,
                    "al_sqs_details.tot_fund_val":fund_allocation_val.toString(),
                    "al_sqs_details.mlife.il_anb":$(escape_jq("al_sqs_details.mlife.il_anb")).val(),
                    "al_sqs_details.slife.il_anb":$(escape_jq("al_sqs_details.slife.il_anb")).val(),
                    "al_sqs_details.tlife.il_anb":$(escape_jq("al_sqs_details.tlife.il_anb")).val(),
                    "al_sqs_details.product_code":"TT12",
                    "al_sqs_details.product_type":"Non-Par",
                    "al_sqs_details.global_strategic_fund":document.getElementById("al_sqs_details.global_strategic_fund").value,
                    "al_sqs_details.equity_plus_fund":document.getElementById("al_sqs_details.equity_plus_fund").value,
                    "al_sqs_details.managed_plus_fund":document.getElementById("al_sqs_details.managed_plus_fund").value,
                    "al_sqs_details.asia_great_fund":document.getElementById("al_sqs_details.asia_great_fund").value,
                    "al_sqs_details.innovation_fund":document.getElementById("al_sqs_details.innovation_fund").value,
                    "al_sqs_details.us_equity_fund":document.getElementById("al_sqs_details.us_equity_fund").value,
                    "al_sqs_details.pacific_dynamic_income_fund":document.getElementById("al_sqs_details.pacific_dynamic_income_fund").value
                }
            arrSetBundleProduct.push(prod_choice_bundle);
                
                
            
        }
    }
    console.log("arrSetBundleProduct:",arrSetBundleProduct);*/
    //dynamic array arrayBundleProduct according to selection in pop up
    if(arrayBundleProduct.indexOf("PRUCritical Protect")!=-1)
    {
       
        var product_code ="";
            var product_type="";
            if(responsebundle!="" && responsebundle!="{}")
            {
                var obj=JSON.parse(responsebundle);
                
               
                product_code = obj[0]['product_code'];//Added by ankita on 18 Feb 2019
                product_type = obj[0]['product_core_system'];
                //product_choice_details("prod_name");
            }
            else
            {
              
                product_code="";
                product_type="";
               
            }
       
        prod_choice_bundle = {
            "al_sqs_details.product_name" : "PRUCritical Protect",
            "al_sqs_details.payment_backdate" : getPaybackdate(),
            "al_sqs_details.Inception_dt" : document.getElementById("al_sqs_details.Inception_dt").value,
            "al_sqs_details.payment_frequency" : document.getElementById("al_sqs_details.payment_frequency").value,
            "al_sqs_details.payment_mode" : document.getElementById("al_sqs_details.payment_mode").value,
            "al_sqs_details.fund_choice1" : getFundchoiceOne(),
            "al_sqs_details.fund_choice2" : getFundchoiceTwo(),
            "al_sqs_details.equity_fund" : "0",
            "al_sqs_details.managed_fund2" : "0",
            "al_sqs_details.bond_fund" : "0",
            "al_sqs_details.dana_unggul" : "0",
            "al_sqs_details.dana_urus2" : "0",
            "al_sqs_details.dana_aman" : "0",
            "al_sqs_details.asia_property" : "0",
            "al_sqs_details.asia_managed_fund" : "0",
            "al_sqs_details.asia_local_bond_fund" : "0",
            "al_sqs_details.global_market_naviga" : "0",
            "al_sqs_details.dragon_peacock" :"0",
            "al_sqs_details.asia_equity_fund" : "0",
            "al_sqs_details.equity_focus_fund" : "0",
            "al_sqs_details.equity_income_fund" : "0",
            "al_sqs_details.global_leaders_fund" : "0",
            "al_sqs_details.asian_high_yield_bond_fund" : "0",
            "al_sqs_details.japan_dynamic_fund" : "0",
            "al_sqs_details.euro_equity_fund" : "0",
            "al_sqs_details.multi_asset_fund" : "0",
            "al_sqs_details.asia_select_focus_fund" : "0",
            "al_sqs_details.flexi_vantage_fund" : "0",
            "al_sqs_details.asia_opportunities_fund" : "0",
            "al_sqs_details.global_managed_fund" : "0",
            "al_sqs_details.global_opportunities_fund" : "0",
            "al_sqs_details.strategic_managed_fund" : "0",
            "al_sqs_details.expiry_age":basic_expiry_age,
            "al_sqs_details.tot_fund_val":"0",
            "al_sqs_details.mlife.il_anb":$(escape_jq("al_sqs_details.mlife.il_anb")).val(),
            "al_sqs_details.slife.il_anb":$(escape_jq("al_sqs_details.slife.il_anb")).val(),
            "al_sqs_details.tlife.il_anb":$(escape_jq("al_sqs_details.tlife.il_anb")).val(),
            "al_sqs_details.product_code":product_code,
            "al_sqs_details.product_type":product_type,
            "al_sqs_details.global_strategic_fund":"0",
            "al_sqs_details.equity_plus_fund":"0",
            "al_sqs_details.managed_plus_fund":"0",
            "al_sqs_details.asia_great_fund":"0",
            "al_sqs_details.innovation_fund":"0",
            "al_sqs_details.us_equity_fund":"0",
            "al_sqs_details.pacific_dynamic_income_fund":"0",
             "al_sqs_details.foreign_currency" : "0",
            "al_sqs_details.emerging_opportunities_fund" :"0",
            "al_sqs_details.global_growth_fund" : "0",
            "al_sqs_details.sustainable_equity_fund" : "0",
            "al_sqs_details.global_esg_choice_fund" : "0"
        }
       // sustainable_equity_fund new july 2023 fund CR SEF & ADI Funds added by sachin on 9-6-2023..// Pradnya: added global_esg_choice_fund for march24 release
        
    }

	//native functionality call to transfer data
    
	js_set_var("prod_choice_response",JSON.stringify(prod_choice),function()
	{
        js_set_var("bundle_product_response",JSON.stringify(prod_choice_bundle),function()
        {
          js_set_var("product_update_flags",JSON.stringify(product_update_data_flags),function()
          {
            js_set_var("product_update_flags_database",JSON.stringify(product_update_data_flags),function()
            {
                if(flag == "swipe_right")
                {
                  //  menuController.loadPage("top_mysolutions_maindetails",0); //TODO on DATE 22-11-2018
                       if(obj_mlife["pamb_channel"]!="Agency" && obj_mlife["pamb_channel"]!="FA"&& obj_mlife["pamb_channel"]!="UOB" && obj_mlife["pamb_channel"]!="Banca")//added uob condition for solution button for may release by sachin tupe on date 1-4-2019
                       {
                      
                        menuController.loadPage("top_mysolutions_maindetails",0);
                       
                       }else
                       {
                           if(obj_mlife["al_person_details.mlife.insu_type"] !=="individual"){
                      
                       if((obj_mlife["pamb_channel"]=="Agency" || obj_mlife["pamb_channel"]=="FA") && (obj_mlife["al_person_details.mlife.insu_type"]=="employee" || obj_mlife["al_person_details.mlife.insu_type"]=="keyman")){
              
                       menuController.loadPage("mysolutions_buttons",0);
                       }else{
                      
                       if(obj_mlife["pamb_channel"]=="UOB"){
                       
                       menuController.loadPage("top_mysolutions_refferal_details",0);
                       
                       }else{
                        menuController.loadPage("top_mysolutions_maindetails",0);
                       }
                       
                      
                       }
                           }else{
                       if((obj_mlife["pamb_channel"]=="Banca") && (obj_mlife["al_person_details.mlife.insu_type"]=="employee" || obj_mlife["al_person_details.mlife.insu_type"]=="keyman")){
                        menuController.loadPage("top_mysolutions_maindetails",0);
                       
                       }else{
                          menuController.loadPage("mysolutions_buttons",0)
                       }
                       
                       
                        
                           }//Added soln button navigation
                       }
                }
                else
                {
                    generateinputstring(1, "EMPTY",flag,"","","","");
                }
            });
        });
    });//ankita bundle
});
                            });
}

//Dynamically set dropdown onchange
function fnMsProdSelectElement(valueToSelect,id)
{    
	var dd_prod = document.getElementById(id);
	for (var i = 0; i < dd_prod.options.length; i++) {
    	if (dd_prod.options[i].text === valueToSelect) {
        	dd_prod.selectedIndex = i;
        	break;
   		}
	}
}


/*******************************************************
 Function Name: selectQueryForSQSCount()
 Function Description:
 Parameters:
 Created By: Pramod Chavan
 Created On: 27 December 2017
 Modified By:
 Modified On:
 Modification Reason:
 *******************************************************/
function selectQueryForSQSCount(personId)
{
    var queryCount = new DbUtil();
    queryCount.query()
    .select()
    .column('count(*)')
    .from()
    .table('al_sqs_details')
    .where()
    .clause('is_deleted', '=', "No")
    .and()
    .clause('agent_id', '=', ds_agentId)
    .and()
    .clause('purchased', '=', "No")
    .and()
    .clause('mlife_person_id', '=', personId, "(", "")
    .or()
    .clause('slife_person_id', '=', personId)
    .or()
    .clause('tlife_person_id', '=', personId, "", ")");
    
    return queryCount;
}
/*******************************************************
 Function Name: selectQueryForSQSData()
 Function Description:
 Parameters:
 Created By: Pramod Chavan
 Created On: 27 December 2017
 Modified By:
 Modified On:
 Modification Reason:
 *******************************************************/
function selectQueryForSQSData(personId)
{
    var queryCount = new DbUtil();
    queryCount.query()
    .select()
    .column('*')
    .from()
    .table('al_sqs_details')
    .where()
    .clause('is_deleted', '=', "No")
    .and()
    .clause('agent_id', '=', ds_agentId)
    .and()
    .clause('purchased', '=', "No")
    .and()
    .clause('mlife_person_id', '=', personId, "(", "")
    .or()
    .clause('slife_person_id', '=', personId)
    .or()
    .clause('tlife_person_id', '=', personId, "", ")");
    
    return queryCount;
}

/*******************************************************
 Function Name: fnMsDiscardQuotationsInILProductCase(persnID)
 Function Description: delete quotations associated with given person id.
 Parameters:
 Created By: Pratik/Pramod
 Created On: 28 Jan 2015
 Modified By:
 Modified On:
 Modification Reason:
 *******************************************************/
function fnMsDiscardQuotationsInILProductCase(persnID) {
    var updateSQS = new DbUtil();
    updateSQS.query()
    .update()
    .table('al_sqs_details')
    .column('is_deleted').value('Yes')
    .where()
    .clause('purchased', '=', "No")
    .and()
    .clause('agent_id', '=', ds_agentId)
    .and()
    .clause('is_deleted', '=', "No")
    .and()
    .clause('mlife_person_id', '=', persnID, "(", "")
    .or()
    .clause('slife_person_id', '=', persnID)
    .or()
    .clause('tlife_person_id', '=', persnID, "", ")");
    
    
    return updateSQS;
}

/*******************************************************
 Function Name: fnMsSetSQSoptionBlankInYLP(sqsIDList)
 Function Description:
 Parameters:
 Created By: Pramod Chavan
 Created On: 27 Dec 2017
 Modified By:
 Modified On:
 Modification Reason:
 *******************************************************/
function fnMsSetSQSoptionBlankInYLP(sqsIDList) {
    var updateSQS = new DbUtil();
    updateSQS.query()
    .update()
    .table('al_ylp_details')
    .column('sqs_option1').value('')
    .column('sqs_option2').value('')
    .where()
    .clause('is_deleted', '=', "No")
    .and()
    .clause('agent_id', '=', agentId)
    .and()
    .clause('sqs_option1', 'IN', sqsIDList)
    .or()
    .clause('sqs_option2', 'IN', sqsIDList);
    
    
    
    return updateSQS;
}
/*******************************************************
 Function Name: anbMismatchForILProduct()
 Function Description:
 Parameters:
 Created By: Pramod Chavan
 Created On: 18 December 2017
 Modified By:
 Modified On:
 Modification Reason:
 *******************************************************/
function anbMismatchForILProduct(mlifeResponse, slifeResponse, tlifeResponse){
    var isMlifeChange=false;
    var isSlifeChange=false;
    var isTlifeChange=false;
    var mlifeObj="";
    var slifeObj="";
    var tlifeObj="";
    var oldOccMlife="";
    console.log("clientIdForIL----->"+clientIdForIL+"---mlifePersonIdIL---"+mlifePersonIdIL+"----sqsIdIL---->"+sqsIdIL+"----"+sqsCountForIL);
    if (mlifeResponse != "" && mlifeResponse != null && mlifeResponse != "null" && mlifeResponse != "(null)")
    {
        mlifeObj = JSON.parse(mlifeResponse);
        oldOccMlife=mlifeObj["al_employee_details.mlife.occupation"]
        
        if((((mlifeObj["al_person_details.mlife.anb_il_product"]<= 15 || mlifeObj["al_person_details.mlife.anb_il_monthly_product"]<= 15) && mlifeObj["al_person_details.mlife.anb"]>=16) || ((mlifeObj["al_person_details.mlife.anb_il_product"]>= 16 || mlifeObj["al_person_details.mlife.anb_il_monthly_product"]>= 16 ) && mlifeObj["al_person_details.mlife.anb"]<=15)) && (mlifeObj["pamb_channel"]=="Agency" || mlifeObj["pamb_channel"]=="FA"))   // Piyush(03/12/2018) : Added this changes for new channel FA /* && oldOccMlife!="Child")*/
        {
            if((((mlifeObj["al_person_details.mlife.anb_il_product"]<= 15 || mlifeObj["al_person_details.mlife.anb_il_monthly_product"]<= 15) && mlifeObj["al_person_details.mlife.anb"]>=16)
            && ((ilProductList.indexOf(document.getElementById("al_sqs_details.product_name").value)>=0)/*document.getElementById("al_sqs_details.product_name").value=="PRUwith you"*/)) 
            || (((mlifeObj["al_person_details.mlife.anb_il_product"]>= 16  || mlifeObj["al_person_details.mlife.anb_il_monthly_product"]>= 16) && mlifeObj["al_person_details.mlife.anb"]<=15)
            && (ilProductList.indexOf(document.getElementById("al_sqs_details.product_name").value)==-1/*document.getElementById("al_sqs_details.product_name").value!="PRUwith you"*/))){
                mlifeObj["al_employee_details.mlife.occupation"]="Child";
                mlifeObj["al_employee_details.mlife.occupation_class"]="2";
                mlifeObj["al_employee_details.mlife.value_nature_of_business"]="Child";
            }else{
            mlifeObj["al_employee_details.mlife.occupation"]="";
            mlifeObj["al_employee_details.mlife.occupation_class"]="";
            mlifeObj["al_employee_details.mlife.value_nature_of_business"]="";
            }
            isMlifeChange=true;
        }else if(((mlifeObj["al_person_details.mlife.anb_il_product"]<= 16 && mlifeObj["al_person_details.mlife.anb"]>=17) || (mlifeObj["al_person_details.mlife.anb_il_product"]>= 17 && mlifeObj["al_person_details.mlife.anb"]<=16)) && mlifeObj["pamb_channel"]!="Agency" && mlifeObj["pamb_channel"]!="FA")  // Piyush(03/12/2018) : Added this changes for new channel FA /* && oldOccMlife!="Child")*/ //child condition removed for defect 5991 on date 10-8-2018.
        {
        
            var occChange=false;
           if(isILproductCheck && selectedILProduct) //Added code for defect 5991 on date 10-08-2018
            {
                if (mlifeObj["al_person_details.mlife.anb_il_product"]<=16 && ilmainlifeAnb<=16)
               {
              
                occChange=true;
              }
            }
              else
              {
                if (mlifeObj["al_person_details.mlife.anb"]<=16 && osmainlifeAnb<=16)
               {
              
                occChange=true;
              }

              }
            
        
            
            if(((mlifeObj["al_person_details.mlife.anb_il_product"]<= 16 && mlifeObj["al_person_details.mlife.anb"]>=17) 
            && (ilProductList.indexOf(document.getElementById("al_sqs_details.product_name").value)>=0/*document.getElementById("al_sqs_details.product_name").value=="PRUwith you"*/)) 
            || ((mlifeObj["al_person_details.mlife.anb_il_product"]>= 17 && mlifeObj["al_person_details.mlife.anb"]<=16) 
            && (ilProductList.indexOf(document.getElementById("al_sqs_details.product_name").value)==-1/*document.getElementById("al_sqs_details.product_name").value!="PRUwith you"*/))){
                mlifeObj["al_employee_details.mlife.occupation"]="Child";
                mlifeObj["al_employee_details.mlife.occupation_class"]="2";
                mlifeObj["al_employee_details.mlife.value_nature_of_business"]="Child";
            }else{
              if(!occChange)
              {
                mlifeObj["al_employee_details.mlife.occupation"]="";
                mlifeObj["al_employee_details.mlife.occupation_class"]="";
                mlifeObj["al_employee_details.mlife.value_nature_of_business"]="";
              }
            }
              if(!occChange)
              {
            isMlifeChange=true;
              }
        }
    
    }
    


    
    if(isMlifeChange==true && sqsCountForIL>0){
        canSwipe=0;
bootbox.alert("<h5>The Occupation, Nature Of Business have been re-triggered due to change in the Product. Kindly re-select the values.</h5>",function(){
             
              
                        
                         bootbox.confirm("<h5>There is an existing quotation for this contact. Modifying the contact details will delete the quotation from the Record of Advice. Tap on OK to proceed.</h5>", function(result) {
                                         canSwipe = 0;
                                         if (result == true) {
                                         canSwipe = 1;
                                         
                                         var sqsIdForSetSQSoption="";
                                         var sqsIdListForDelete=selectQueryForSQSData(mlifePersonIdIL);
                                         
                                         
                                         sqsIdListForDelete.execute(function(response){
                                                                    if(response != "{}" && response != ""){
                                                                    var obj=JSON.parse(response);
                                                                    
                                                                    for ( sub in obj )
                                                                    {
                                                                    var objSub = obj[sub];
                                                                    var elementsArray = Object.keys(objSub);
                                                                    for(var i=0 ;i< elementsArray.length; i++)
                                                                    {
                                                                    if(elementsArray[i] == "sqs_id")
                                                                    {
                                                                    sqsIdForSetSQSoption+="'"+obj[sub]["sqs_id"]+"',";
                                                                    
                                                                    }
                                                                    }
                                                                    
                                                                    }
                                                                    sqsIdForSetSQSoption = "("+sqsIdForSetSQSoption.substring(0,sqsIdForSetSQSoption.length-1)+")";
                                                                    
                                                                    }
                                         var deleteSQSForIL = fnMsDiscardQuotationsInILProductCase (mlifePersonIdIL);
                                        
                                         
                                         deleteSQSForIL.execute(function(response)
                                                                    {
                                                                var updateQueryYlp=fnMsSetSQSoptionBlankInYLP(sqsIdForSetSQSoption);
                                                                updateQueryYlp.execute(function(response)
                                                                                       {
                                                                        js_set_var("main_life_response",JSON.stringify(mlifeObj),function()
                                                                               {
                                                                                    product_choice_details("swipe_right");
                                                                    
                                                                               });
                                                                                       
                                                                                       });
                                                                    });
                                                                    
                                                             });
                                         }else{
                                          canSwipe=1;
                                         document.getElementById("al_sqs_details.product_name").value="Select Products";
                                         $(".setBlankValue").val("");
                                         }
                                         
                         
                         

                        });
              
               });
    }else if(isMlifeChange==true){
        canSwipe=0;
        bootbox.alert("<h5>The Occupation, Nature Of Business have been re-triggered due to change in the Product. Kindly re-select the values.</h5>",function(){
                      canSwipe=1;
                      js_set_var("main_life_response",JSON.stringify(mlifeObj),function()
                                 {
                                 
                                 
                                 product_choice_details("swipe_right");
                                 
                                 
                                 });
                      
                      });
    }

}

//whole function changed by Praveen 0n 01.09.2015
function ShowFunds(callfrom, mlifeResponse, slifeResponse, tlifeResponse)
{
    //sproductname=""
    ilMonthlyDecide="il_daily"; //Added by Sachin Tupe for il monthly CR.
    incr_value=0;//Added by Sachin Tupe for il monthly CR.
    incep_value=1;
 //   array_inception_element=[];
    checkIlMonthly=false;
    // $(".fundDisplayFlag").css("display", "");
    // below if condition for populate IL anb value from respective life response. Pramod Chavan: 09122017
    console.log("ANB changes ----callfrom>"+callfrom+"-----mlifeResponse---"+mlifeResponse+"-----slifeResponse---"+slifeResponse+"-----isILproductCheck---"+isILproductCheck);
    var indexForBckDateProduct = backDateProductList.indexOf(document.getElementById("al_sqs_details.product_name").value);
    //added by ankita on 20 jan 2023 for bundle product of PRUsignatue product
   document.getElementById("bundle_product_div_id").style.display="none";
    
//added by ankita on 10 march 2023 for bundle product
    //Pradnya: added below if june24 release
    if(document.getElementById("al_sqs_details.product_name").value=="PRUSignature Plus")
    {
        arrayListForBundle["Base"]="PRUSignature Plus";
    }
    var selectQueryBundle=fnMsGetProductDetails(arrayListForBundle["Bundle"]);
            selectQueryBundle.execute(function(responseBundle)
            {
    if (callfrom != "bck")
    {
    if(indexForBckDateProduct==-1){
        $(escape_jq("al_sqs_details.payment_backdate_yes")).prop("disabled", false);
        if(!document.getElementById("al_sqs_details.payment_backdate_yes").checked){
        document.getElementById("al_sqs_details.payment_backdate_no").checked = true;
        backdateYesFlag=false;
        }
    }else{
        
        $(escape_jq("al_sqs_details.payment_backdate_yes")).prop("disabled", true);
        document.getElementById("al_sqs_details.payment_backdate_yes").checked = false;
        if(document.getElementById("al_sqs_details.product_name").value!="Select Products")
        {
            
          // sproductname=document.getElementById("al_sqs_details.product_name").value
            document.getElementById("al_sqs_details.payment_backdate_no").checked = true;
            backdateYesFlag=false;
           
            $(escape_jq("al_sqs_details.payment_backdate_no")).prop("disabled", true);
            //Added by ankita on 30 July 2018 to enabled funds which are disabled when Product is changed
            
                if($('#fund_list option[value=0]:selected').parent('select').prop('disabled',true))
                {
                    console.log("In show funds")
                   $('#fund_list option[value=0]:selected').parent('select').prop('disabled',false);
                }
            
        }else
        {
        document.getElementById("al_sqs_details.payment_backdate_no").checked = false;
        $(escape_jq("al_sqs_details.payment_backdate_no")).prop("disabled", true);
    }
        
    }
    }
    
//    if(callfrom=='change'){
    
        if(document.getElementById("al_sqs_details.product_name").value!="Select Products")
        {
            if (mlifeResponse != "" && mlifeResponse != null && mlifeResponse != "null" && mlifeResponse != "(null)")
            {
                
                var objMlifeIL = JSON.parse(mlifeResponse);
                
                var msSelectProduct=document.getElementById("al_sqs_details.product_name").value;
                console.log("SELECTED PRODUCT NAME"+msSelectProduct);
                checkPRUwithyou=msSelectProduct;
                
                os_mlife_anb=objMlifeIL["al_person_details.mlife.anb_temp"];
                
                fnfindproductType(msSelectProduct); //Added Function for find product type. //call was present from first over here sourabh
               // console.log("prodtypeForgeinCurrency-->"+prodtypeForgeinCurrency);
                 console.log("Finalqqq product name-->>"+ prodtype+"----prodtypeForgeinCurrency--->"+prodtypeForgeinCurrency);
                
                
                /*****************Added for OS to IL ANB Cahnges************************/
                
                
                
                
                
                
                /**********************************************************************/
                
                
                
                
                if((ilProductList.indexOf(document.getElementById("al_sqs_details.product_name").value)>=0 || ANB_json[0]["anb_type"]=="IL_Monthly" || ANB_json[0]["anb_type"]=="IL_Daily") /*document.getElementById("al_sqs_details.product_name").value=="PRUwith you"*/){
                    var inceILdate = new Date();
                    if(sysdate!=""){
                         inceILdate = new Date(sysdate);
                    }else{
                         inceILdate = new Date();
                    }
                   
                    var dd = inceILdate.getDate();
                    var yyyy = inceILdate.getFullYear();
                    var mm = inceILdate.getMonth()+1; //January is 0!
                    temp_ildailyanb=objMlifeIL["al_person_details.mlife.anb_il_product_temp"];//Added by Sachin Tupe for il monthly CR.
                    
                    console.log("temp_ildailyanb12-->"+temp_ildailyanb);
                    if(temp_ildailyanb=="0" || temp_ildailyanb==0)//Added by Sachin Tupe for il monthly CR.
                    {
                    temp_ilMonthly="0";
                    }else
                    {
                        console.log("34234--a>"+objMlifeIL["al_person_details.mlife.anb_il_monthly_product_temp"]);
                    temp_ilMonthly=objMlifeIL["al_person_details.mlife.anb_il_monthly_product_temp"];
                        
                    }
                    
                    if (array_inception_element != undefined || array_inception_element!= 0) //Added by Sachin Tupe for il monthly CR.
                        // array empty or does not exist
                    {
                    
                    console.log("array_inception_element"+array_inception_element);
                    for(ilElement in array_inception_element)
                    {
                        
                            console.log("pr_name"+array_inception_element[ilElement].product_name);
                            console.log("pr_ismonthly"+array_inception_element[ilElement].isMonthly);
                        var il_product=array_inception_element[ilElement].product_name;
                        var ilmonthtrue=array_inception_element[ilElement].isMonthly;
                      
                    if(il_product==msSelectProduct)
                    {
                        console.log("EXECUTED...");
                        ilMonthlyDecide="il_monthly";
                        incr_value=array_inception_element[ilElement].increment;
                        incep_value=array_inception_element[ilElement].inception_day;
                    }
                        
                    }
                    }
                    /*********************************Added extra condition for product defect on date 7-08-2019*****************************************************/
                   var tempInceEleArray = _.where(array_inception_element, {"product_name":msSelectProduct})
                    if((tempInceEleArray ==[] || tempInceEleArray.length ==0) && ANB_json[0]["anb_type"]=="IL_Monthly"){
                      
                        
                        if(parseInt(ANB_json[0]["IL_monthly_end_Date"])<dd)
                        {  console.log("@Existing")
                            incr_value=ANB_json[0]["IL_monthly_inc_period"]
                            
                            
                        }
                    }
                    
                    
                    /*************************************************************************************/
                    
                    
                    if((ilMonthlyDecide != "il_daily" && ilMonthlyDecide != "OS") || ANB_json[0]["anb_type"]=="IL_Monthly")
                    {
                        checkIlMonthly=true;
                        
                        
                        if(incr_value !="0" && incr_value !=0 && incep_value!=""  && incep_value!="0" && incep_value!=0)
                        {
                            mm = eval(mm)+parseInt(incr_value) ;
                            dd = incep_value ;
                        }
                        else
                            dd = 1 ;
                        
                        
                        if(dd<10)
                        {
                            dd='0'+dd ;
                        }
                        if(mm > 12)
                        {
                            mm = 1;
                            yyyy =yyyy+1;
                        }
                        if(mm<10)
                        {
                            mm='0'+mm ;
                        }
                        
                    }
                    
                    
                    
                    inceILdate = dd+'/'+mm+'/'+yyyy;
                    inceptionDateVisted=inceILdate;
                    if(checkIlMonthly)
                    {
                        inceILdate_monthly= inceILdate;
                        
                    }

                     if(!document.getElementById("al_sqs_details.payment_backdate_yes").checked){
                    document.getElementById("al_sqs_details.Inception_dt").value = inceILdate;
                     }
                    else //added for validation condition for il product by sachin on 23-3-2018
                    {
                        inceptionDateVisted=document.getElementById("al_sqs_details.Inception_dt").value;
                        
                        var checkfutureDate=futureDate();
                        if(checkfutureDate==false && !checkIlMonthly)
                        {
                            alert("330");
                            //InceptionDateCal();
                            var inceILdate = new Date();
                            if(sysdate!=""){
                                 inceILdate = new Date(sysdate);
                            }else{
                                 inceILdate = new Date();
                            }
                            var dd = inceILdate.getDate();
                            var mm = inceILdate.getMonth()+1; //January is 0!
                            
                            var yyyy = inceILdate.getFullYear();
                            
                            inceILdate = dd+'/'+mm+'/'+yyyy;
                            if(checkIlMonthly)
                            {
                                document.getElementById("al_sqs_details.Inception_dt").value = inceILdate_monthly;
                            }else
                            {
                            document.getElementById("al_sqs_details.Inception_dt").value = inceILdate;
                            }
                            return false;
                        }
                        
                    }
                    if(checkIlMonthly)//Added by Sachin Tupe for il monthly CR.1616
                    {
                        if(obj_mlife["al_person_details.pre_natal_child_flg"] == "Yes"){
                            var day_res_dob = obj_mlife["al_person_details.mlife.expected_delivery_dt"].split("/");
                        }else{
                            var day_res_dob = obj_mlife["al_person_details.mlife.dob"].split("/");
                        }
                        var  day_res = document.getElementById("al_sqs_details.Inception_dt").value.split("/");
                        //(parseInt(objSplitMainLifeDOB[0]), parseInt(objSplitMainLifeDOB[1]), parseInt(objSplitMainLifeDOB[2]), incDay, incMonth, incYear)
                        console.log("DOB-->"+parseInt(day_res_dob[0])+"/"+ parseInt(day_res_dob[1])+"/"+  parseInt(day_res_dob[2]));
                        console.log("InceptionDAte-->"+parseInt(day_res[0])+"/"+ parseInt(day_res[1])+"/"+  parseInt(day_res[2]));
                        console.log("--checkIlMonthly-->"+temp_ildailyanb+"--temp_ilMonthly-->"+temp_ilMonthly);
                       
                        if(obj_mlife["al_person_details.pre_natal_child_flg"] == "Yes"){
                            console.log("FFind 333prenatal yes");
                           var temp_PrenatalANB =fnMsCalculateANBForPrenatal(parseInt(day_res_dob[0]), parseInt(day_res_dob[1]), parseInt(day_res_dob[2]),parseInt(day_res[0]), parseInt(day_res[1]),  parseInt(day_res[2]));
                            //objmlifeResponse["al_person_details.mlife.anb_il_product_temp"]=objmlifeResponse["al_person_details.mlife.anb_il_product"];
                             $(escape_jq("al_sqs_details.mlife.il_anb")).val(temp_PrenatalANB);
                        }else{
                        //below code was before adding if above
                        if(temp_ildailyanb=="0" || temp_ildailyanb==0)
                        {
                            $(escape_jq("al_sqs_details.mlife.il_anb")).val(temp_ildailyanb);
                        }else
                        {
                            console.log("SETTING IL MONTHLY MAIN LIFE ANB"+temp_ilMonthly);
                     
                             $(escape_jq("al_sqs_details.mlife.il_anb")).val(temp_ilMonthly);
                        }

                        }
                    }
                    else
                    {
              
                        var day_res_dob = obj_mlife["al_person_details.mlife.dob"].split("/");
                        var  day_res = document.getElementById("al_sqs_details.Inception_dt").value.split("/");
                                              
                        //setILMonthObect("al_sqs_details.Inception_dt","mlife",day_res_dob[0],day_res_dob[1],day_res_dob[2],document.getElementById("al_sqs_details.Inception_dt").value,day_res[0], day_res[1], day_res[2])
                        console.log("setting il anb"+ temp_ilMonthly);
                         $(escape_jq("al_sqs_details.mlife.il_anb")).val(objMlifeIL["al_person_details.mlife.anb_il_product"]);//Added by Sachin Tupe for il monthly CR.
                       

                        
                        //
                    }
                   
                 /*   if(checkIlMonthly)
                    {
                        console.log("monthly anb");
                        var day_res_dob = obj_mlife["al_person_details.mlife.dob"].split("/");
                        var  day_res = document.getElementById("al_sqs_details.Inception_dt").value.split("/");
                        fnMsSetANB("al_sqs_details.Inception_dt", "mlife", day_res_dob[0], day_res_dob[1],  day_res_dob[2], document.getElementById("al_sqs_details.Inception_dt").value, day_res[0], day_res[1], day_res[2]);
                       $(escape_jq("al_sqs_details.mlife.il_anb")).val(ilMonthlyAnb)
                    }*/
                    if(callfrom=='change'){
                    anbMismatchForILProduct(mlifeResponse, slifeResponse, tlifeResponse);
                    }
                    
                }else{
                 if(!document.getElementById("al_sqs_details.payment_backdate_yes").checked)
                 {
                     InceptionDateCal();
                 }else //else condtion added os product.on 21-03-2018
                 {
                     if(callfrom=='change')
                     {
                         console.log("ilProductList"+ilProductList);
                         
                       //  var checkOsProduct=ilProductList.includes(document.getElementById("al_sqs_details.product_name").value);
                       // if(!isILproductCheck)
                         var  checkOsProduct=false;
                         for( var list_product in ilProductList)
                         {
                             if(ilProductList[list_product]!=document.getElementById("al_sqs_details.product_name").value)
                             {
                                 checkOsProduct=true;
                             }
                        }
                         checkOsProduct=false//Added for OS to IL ANB Conversion
                         if(checkOsProduct==true)
                        {
                            var selectedDate=document.getElementById("al_sqs_details.Inception_dt").value;
                            console.log("not isILproductCheck"+selectedDate);
                            selectedDate=selectedDate.split("/");
                            var selectedDay=selectedDate[0];
                            console.log("selectedDay"+selectedDay);
                            if(selectedDay!=01)
                            {
                                alert("296");
                                InceptionDateCal();
                                return false;
                                
                            }
                        }
                        
                         
                         
                     }
                     
                    
                     
                 }
                //$(escape_jq("al_sqs_details.payment_backdate_yes")).prop("disabled", false);
                console.log("mlife dob"+objMlifeIL["al_person_details.mlife.anb"]);
                $(escape_jq("al_sqs_details.mlife.il_anb")).val(objMlifeIL["al_person_details.mlife.anb"]);
                   
                    
                    
                    
                    if(callfrom=='change' && isILproductCheck){
                        anbMismatchForILProduct(mlifeResponse, slifeResponse, tlifeResponse);
                    }
                  
                }
            }
            if (slifeResponse != "" && slifeResponse != null && slifeResponse != "null" && slifeResponse != "(null)")
            {
                
                var objSlifeIL = JSON.parse(slifeResponse);
                if((ilProductList.indexOf(document.getElementById("al_sqs_details.product_name").value)>=0)/*document.getElementById("al_sqs_details.product_name").value=="PRUwith you"*/){
                    
                    if(checkIlMonthly)//Added by Sachin Tupe for il monthly CR.
                    {
                          console.log("generateinputstringBackdate Second life--->")
                      //  console.log("SETTING SECOND LIFE for il monthly"+slife_il_monthly_anb_set)
                        $(escape_jq("al_sqs_details.slife.il_anb")).val(objSlifeIL["al_person_details.slife.anb_il_monthly_product_temp"]);
                        //al_person_details.tlife.anb_il_product
                       // al_person_details.slife.anb_il_product
                        
                    }else
                    {
                        
                            $(escape_jq("al_sqs_details.slife.il_anb")).val(objSlifeIL["al_person_details.slife.anb_il_product"]);//Added by Sachin Tupe for il monthly CR.
                       // $(escape_jq("al_sqs_details.slife.il_anb")).val(objSlifeIL["al_person_details.slife.anb_il_product"]);
                    }
                        
                  //  $(escape_jq("al_sqs_details.slife.il_anb")).val(objSlifeIL["al_person_details.slife.anb_il_product"]);
                }else
                {
                
                $(escape_jq("al_sqs_details.slife.il_anb")).val(objSlifeIL["al_person_details.slife.anb"]);
                }
            }
            if (tlifeResponse != "" && tlifeResponse != null && tlifeResponse != "null" && tlifeResponse != "(null)")
            {
                
                var objTlifeIL = JSON.parse(tlifeResponse);
                if((ilProductList.indexOf(document.getElementById("al_sqs_details.product_name").value)>=0)/*document.getElementById("al_sqs_details.product_name").value=="PRUwith you"*/){
                    
                    if(checkIlMonthly)//Added by Sachin Tupe for il monthly CR.
                    {
                          console.log("generateinputstringBackdate TLIFE life"+tlife_il_monthly_anb)
                        $(escape_jq("al_sqs_details.tlife.il_anb")).val(objTlifeIL["al_person_details.tlife.anb_il_monthly_product_temp"]);//Added by Sachin Tupe for il monthly CR.
                        
                    }else
                    {
                        $(escape_jq("al_sqs_details.tlife.il_anb")).val(objTlifeIL["al_person_details.tlife.anb_il_product"]);//Added by Sachin Tupe for il monthly CR.
                   // $(escape_jq("al_sqs_details.tlife.il_anb")).val(objTlifeIL["al_person_details.tlife.anb_il_product"]);
                    }
                    
                    
                    
                }else{
                $(escape_jq("al_sqs_details.tlife.il_anb")).val(objTlifeIL["al_person_details.tlife.anb"]);
                }
            }
        }else{
            $(".setBlankValue").val("");
        }
//    }// IL ANB logic end.
    
    console.log("--------->" + document.getElementById("al_sqs_details.product_name").value)
    document.getElementById("fund_choice_block").style.display = 'none';
    document.getElementById("fund_list").style.display = 'none';
    document.getElementById("total_allocation_block").style.display = 'none';
    document.getElementById("global_growth_fund").style.display='none';
    
    document.getElementById("global_strategic_fund").style.display='none';
    document.getElementById("local_global_funds").style.display='none';
    document.getElementById("pacific_dynamic_income_fund").style.display='none';
    document.getElementById("sustainable_equity_fund").style.display='none';//Added for july 2023 new fund by sachin.
    
    
    if (callfrom != "change" && callfrom != "bck")
    {
        if(!(obj_prochoice["al_sqs_details.Inception_dt"]==undefined && obj_prochoice["al_sqs_details.payment_backdate"]==undefined))
        {
            if(obj_prochoice["al_sqs_details.payment_backdate"]=="Yes")
            {
                document.getElementById("al_sqs_details.payment_backdate_no").checked=false;
                document.getElementById("al_sqs_details.payment_backdate_yes").checked=true;
                document.getElementById("al_sqs_details.Inception_dt").value=obj_prochoice["al_sqs_details.Inception_dt"];
            }
        }
    }
    if(document.getElementById("al_sqs_details.product_name").value!="Select Products")
    {

        if(obj_mlife["pamb_channel"]=="Banca" || obj_mlife["pamb_channel"]== "UOB")//changed by Purva / Pramod C on 07th Aug 2017 for UOB
        {
            //
            if(document.getElementById("al_sqs_details.product_name").value == "PRUGlobal Series")
            {
                document.getElementById("al_sqs_details.foreign_currency").style.display="block";
                //document.getElementById("al_sqs_details.foreign_currency").addClass('selectRedMandatory');
               //  $("#al_sqs_details.foreign_currency").addClass("selectRedMandatory");
                
            }else{
                 document.getElementById("al_sqs_details.foreign_currency").style.display="none";
            }
            //
            
            
            console.log("Check funds 2222");
            document.getElementById("local_funds").style.display="block";
            document.getElementById("global_funds").style.display="block";
            $("#newGlobalFund").css("display", "none");
            $("#global_funds_USD").css("display", "none");
            
              $(".no-italics").css("font-style", "") //condition for PRUwith you
            if(document.getElementById("al_sqs_details.product_name").value != "RetireGuard (SP)"
                && document.getElementById("al_sqs_details.product_name").value != "InvestLink"
                && document.getElementById("al_sqs_details.product_name").value != "InvestLink Global"
                && document.getElementById("al_sqs_details.product_name").value != "PRUlink investor account"
                && document.getElementById("al_sqs_details.product_name").value != "PRUretirement growth"
                && document.getElementById("al_sqs_details.product_name").value != "LifeLink"
                && document.getElementById("al_sqs_details.product_name").value !="PRUmy kid"
                && document.getElementById("al_sqs_details.product_name").value !="PRUheritage"
                && document.getElementById("al_sqs_details.product_name").value !="PRUmy legacy"
                && document.getElementById("al_sqs_details.product_name").value !="PRUmy gift"
                && document.getElementById("al_sqs_details.product_name").value !="PRUsignature"
                && document.getElementById("al_sqs_details.product_name").value !="PRUsignature USD"
				&& document.getElementById("al_sqs_details.product_name").value !="PRUsignature infinite"
				&& document.getElementById("al_sqs_details.product_name").value !="PRUmillion cover"
                && document.getElementById("al_sqs_details.product_name").value !="PRUmy treasure"
                && document.getElementById("al_sqs_details.product_name").value !="PRUsmart gain"
                && document.getElementById("al_sqs_details.product_name").value !="PRUsignature income"
                && document.getElementById("al_sqs_details.product_name").value !="PRUMy Gift"
               && document.getElementById("al_sqs_details.product_name").value !="PRUsignature prime"
               && document.getElementById("al_sqs_details.product_name").value !="PRUSignature Invest"
               && document.getElementById("al_sqs_details.product_name").value !="PRUGlobal Series" && document.getElementById("al_sqs_details.product_name").value !="PRULink Cover"  && document.getElementById("al_sqs_details.product_name").value !="PRUMax Cover" && document.getElementById("al_sqs_details.product_name").value !="EssentialLife (SP)"  && document.getElementById("al_sqs_details.product_name").value !="PRUSignature Protect" && document.getElementById("al_sqs_details.product_name").value !="PRUMillion Cover 2.0" && document.getElementById("al_sqs_details.product_name").value !=="PRUMulti Crisis Guard" && document.getElementById("al_sqs_details.product_name").value !=="PRUSignature Assure" && document.getElementById("al_sqs_details.product_name").value!="PRULink Growth" && document.getElementById("al_sqs_details.product_name").value!="PRUmy treasure" && document.getElementById("al_sqs_details.product_name").value!="PRULink Supreme" && document.getElementById("al_sqs_details.product_name").value!=="PRUSignature Vanguard" && document.getElementById("al_sqs_details.product_name").value!=="PRUSignature Ace" && document.getElementById("al_sqs_details.product_name").value!="PRUElite Invest" && document.getElementById("al_sqs_details.product_name").value!="PRUSignature GrowthPlus"
               && document.getElementById("al_sqs_details.product_name").value!="PRUEnhanced Cover" && document.getElementById("al_sqs_details.product_name").value!="PRULink Supreme Plus" && document.getElementById("al_sqs_details.product_name").value!="PRUSignature Plus")//Added by Pratik on date 30 Sep 15 //New product "PRUsmart gain" Added by Sachin Tupe on 29-05-2018//Added condition for PRUsignature income by ankita on 7 July 2018//Abhilash: EssentialLife (SP)_SCB name changed to PRUSignature Protect on 3rd July // Condition added by Shivani for PRUMulti Crisis Guard


            { console.log("Elite in");
				// In above if condition PRUsignature product added by Pramod Chavan
                 $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                var option = $(escape_jq("al_sqs_details.payment_frequency"));
                $.each( msJsonPaymentFrequency, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                $(escape_jq("al_sqs_details.payment_mode")).empty();//Clear Payment Frequency dropdown.
                var option = $(escape_jq("al_sqs_details.payment_mode"));
                $.each( msJsonPaymentMode, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                
                       if(channelTypeForAgencyBancaRepls=="banca")
                      {
                           $(escape_jq("al_sqs_details.payment_mode")).empty();
                           $.each( msJsonBancaPaymentMode, function( key, value )
                           {
                           option.append($("<option />").val(key).text(value));
                           });
                         
                      }
                
                $(escape_jq("al_sqs_details.payment_mode")).val("Payment Method");
                $(escape_jq("al_sqs_details.payment_mode")).prop("disabled", false);
                document.getElementById("al_sqs_details.payment_frequency").disabled=false;
                if(callfrom!="change")
                {
                    if(obj_prochoice["al_sqs_details.payment_frequency"]!=undefined)
                    {
                        document.getElementById("al_sqs_details.payment_frequency").value=obj_prochoice["al_sqs_details.payment_frequency"];
                    }
                    if(obj_prochoice["al_sqs_details.payment_mode"]!=undefined)
                    {
                        document.getElementById("al_sqs_details.payment_mode").value=obj_prochoice["al_sqs_details.payment_mode"];
                    }
                }
                
            }
            
            else if(document.getElementById("al_sqs_details.product_name").value=="LifeLink")
            {
                document.getElementById("asia_local_bond_fund").style.display='none';
                document.getElementById("asia_property_security_fund").style.display='none';
                document.getElementById("fund_list").style.display='block';
                document.getElementById("total_allocation_block").style.display='block';
                  $(".no-italics").css("font-style", "") //condition for PRUwith you
               $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                var option = $(escape_jq("al_sqs_details.payment_frequency"));
                $.each( msJsonPaymentFrequency, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                $(escape_jq("al_sqs_details.payment_mode")).empty();//Clear Payment Frequency dropdown.
                var option = $(escape_jq("al_sqs_details.payment_mode"));
                $.each( msJsonPaymentMode, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                
                       if(channelTypeForAgencyBancaRepls=="banca")
                      {
                          $(escape_jq("al_sqs_details.payment_mode")).empty();
                           $.each( msJsonBancaPaymentMode, function( key, value )
                            {
                            option.append($("<option />").val(key).text(value));
                            });
                         
                      }
                $(escape_jq("al_sqs_details.payment_mode")).val("Payment Method");
                $(escape_jq("al_sqs_details.payment_mode")).prop("disabled", false);
                document.getElementById("al_sqs_details.payment_frequency").disabled=false;
                if(callfrom!="change")
                {
                    if(obj_prochoice["al_sqs_details.payment_frequency"]!=undefined)
                    {
                        document.getElementById("al_sqs_details.payment_frequency").value=obj_prochoice["al_sqs_details.payment_frequency"];
                    }
                    if(obj_prochoice["al_sqs_details.payment_mode"]!=undefined)
                    {
                        document.getElementById("al_sqs_details.payment_mode").value=obj_prochoice["al_sqs_details.payment_mode"];
                    }
                }
            }
            else if(document.getElementById("al_sqs_details.product_name").value=="PRUmy gift" || document.getElementById("al_sqs_details.product_name").value=="PRUmy legacy" || document.getElementById("al_sqs_details.product_name").value=="RetireGuard (SP)" || document.getElementById("al_sqs_details.product_name").value=="PRUretirement growth" || document.getElementById("al_sqs_details.product_name").value=="EssentialLife (SP)" || document.getElementById("al_sqs_details.product_name").value=="PRUSignature Protect")//Abhilash: EssentialLife (SP)_SCB name changed to PRUSignature Protect on 3rd July
            {
                $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                var option = $(escape_jq("al_sqs_details.payment_frequency"));
                
                $.each( msJsonPaymentFrequency, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                
                $(escape_jq("al_sqs_details.payment_mode")).empty();//Clear Payment Frequency dropdown.
                var option = $(escape_jq("al_sqs_details.payment_mode"));
                $.each( msJsonPaymentMode, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                
                if(channelTypeForAgencyBancaRepls=="banca")
               {
                   $(escape_jq("al_sqs_details.payment_mode")).empty();
                      $.each(msJsonBancaPaymentMode, function( key, value )
                         {
                         option.append($("<option />").val(key).text(value));
                         });
                   
               }
                
                $(escape_jq("al_sqs_details.payment_mode")).val("Payment Method");
                $(escape_jq("al_sqs_details.payment_mode")).prop("disabled", false);
                document.getElementById("al_sqs_details.payment_frequency").disabled=false;
                // changes made by Pramod Chavan on 26122016 for bugzila defect 957
                if(document.getElementById("al_sqs_details.product_name").value=="PRUmy legacy" || document.getElementById("al_sqs_details.product_name").value=="PRUmy gift"){
					if(obj_prochoice["al_sqs_details.payment_frequency"]!=undefined)
                    {
                        document.getElementById("al_sqs_details.payment_frequency").value=obj_prochoice["al_sqs_details.payment_frequency"];
                    }
                    if(obj_prochoice["al_sqs_details.payment_mode"]!=undefined)
                    {
                        document.getElementById("al_sqs_details.payment_mode").value=obj_prochoice["al_sqs_details.payment_mode"];
                    }
				}
				
				
                if(document.getElementById("al_sqs_details.product_name").value=="RetireGuard (SP)" || document.getElementById("al_sqs_details.product_name").value=="PRUretirement growth" || document.getElementById("al_sqs_details.product_name").value=="EssentialLife (SP)" || document.getElementById("al_sqs_details.product_name").value=="PRUSignature Protect")//Added by Pratik on date 30 Sep 15//Abhilash: EssentialLife (SP)_SCB name changed to PRUSignature Protect on 3rd July
                {
                    $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                    var option = $(escape_jq("al_sqs_details.payment_frequency"));
                    option.append($("<option />").val("SP").text("Single Premium"));
                    
                    $(escape_jq("al_sqs_details.payment_mode")).val("Cash/Cheque");
                    $(escape_jq("al_sqs_details.payment_mode")).prop("disabled", true);
                    document.getElementById("al_sqs_details.payment_frequency").disabled=true;
                    if(channelTypeForAgencyBancaRepls=="banca")
                    {
                        $(escape_jq("al_sqs_details.payment_mode")).val("Bank Transfer");
                    }
                   
                    if((document.getElementById("al_sqs_details.product_name").value=="EssentialLife (SP)" || document.getElementById("al_sqs_details.product_name").value=="PRUSignature Protect") && checkBenefitResponse==""){//Abhilash: EssentialLife (SP)_SCB name changed to PRUSignature Protect on 3rd July
                        //1515
                        console.log("inn-11-->>>");
                        ClearDataProd(document.getElementById("al_sqs_details.product_name").value);
                    }
                }
            }
            else if(document.getElementById("al_sqs_details.product_name").value=="PRUmy kid")
            {
                document.getElementById("asia_local_bond_fund").style.display='none';
                document.getElementById("asia_property_security_fund").style.display='none';
                document.getElementById("fund_choice_block").style.display='block';
                document.getElementById("fund_list").style.display='block';
                document.getElementById("total_allocation_block").style.display='block';
                document.getElementById("al_sqs_details.fund_choice1").checked=true;
                  $(".no-italics").css("font-style", "")//condition for PRUwith you .
                $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                var option = $(escape_jq("al_sqs_details.payment_frequency"));
                $.each( msJsonPaymentFrequency, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                $(escape_jq("al_sqs_details.payment_mode")).empty();//Clear Payment Frequency dropdown.
                var option = $(escape_jq("al_sqs_details.payment_mode"));
                $.each( msJsonPaymentMode, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                
                               if(channelTypeForAgencyBancaRepls=="banca")
                              {
                                  $(escape_jq("al_sqs_details.payment_mode")).empty();
                                     $.each( msJsonBancaPaymentMode, function( key, value )
                                        {
                                        option.append($("<option />").val(key).text(value));
                                        });
                                 
                              }
                $(escape_jq("al_sqs_details.payment_mode")).val("Payment Method");
                $(escape_jq("al_sqs_details.payment_mode")).prop("disabled", false);
                document.getElementById("al_sqs_details.payment_frequency").disabled=false;
                if(callfrom!="change")
                {
                    if(obj_prochoice["al_sqs_details.payment_frequency"]!=undefined)
                    {
                        document.getElementById("al_sqs_details.payment_frequency").value=obj_prochoice["al_sqs_details.payment_frequency"];
                    }
                    if(obj_prochoice["al_sqs_details.payment_mode"]!=undefined)
                    {
                        document.getElementById("al_sqs_details.payment_mode").value=obj_prochoice["al_sqs_details.payment_mode"];
                    }
                }
                //InceptionDateCal();
                fnMsFundsValidation();
            }
            else if(document.getElementById("al_sqs_details.product_name").value=="PRUheritage" || document.getElementById("al_sqs_details.product_name").value=="PRUmy treasure" || document.getElementById("al_sqs_details.product_name").value=="PRULink Growth" )//Added by Rahul on date 28 Jan 16
            {
                $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                var option = $(escape_jq("al_sqs_details.payment_frequency"));
                option.append($("<option />").val("SP").text("Single Premium"));
                
                $(escape_jq("al_sqs_details.payment_mode")).val("Cash/Cheque");
                $(escape_jq("al_sqs_details.payment_mode")).prop("disabled", true);
                document.getElementById("al_sqs_details.payment_frequency").disabled=true;
                if(channelTypeForAgencyBancaRepls=="banca")
                {
                    var option = $(escape_jq("al_sqs_details.payment_mode"));
                    $(escape_jq("al_sqs_details.payment_mode")).empty();
                       $.each( msJsonBancaPaymentMode, function( key, value )
                         {
                         option.append($("<option />").val(key).text(value));
                         });
                    $(escape_jq("al_sqs_details.payment_mode")).val("Bank Transfer");
                   
                }
               if(document.getElementById("al_sqs_details.product_name").value=="PRULink Growth")
               {
                   document.getElementById("local_fund_lable").innerHTML="PRULINK FUND";
                $("#strategic_managed_fund").css("display", "block");
                document.getElementById("total_allocation_block").style.display='block';
                document.getElementById("fund_list").style.display='block';
                
                document.getElementById("global_funds").style.display='none';
                $(".tohide_PLG").css("display", "none");
                  
             document.getElementById("al_sqs_details.strategic_managed_fund").value="100";
                
              document.getElementById("al_sqs_details.strategic_managed_fund").disabled=true;
                document.getElementById("total_allocation_value").innerHTML="100";
               }
                
                // removed condition of PEF fund by Shivani on 24th June 2021 // added condition of pef fund by Shivani on 8th nov 2021
               if(document.getElementById("al_sqs_details.product_name").value=="PRUmy treasure111")
                {
                    
                   // PRUmy treasure
                    //to remove two funds//added on 17 june 2021 by sourabh
                    $("#japan_dynamic_fund").css("display","none");
                    $("#euro_equity_fund").css("display", "none");
                    document.getElementById("local_global_funds").style.display='block';
                    document.getElementById("global_strategic_fund").style.display='none';
                    document.getElementById("strategic_managed_fund").style.display='none';
                    
                    
                    document.getElementById("total_allocation_block").style.display='block';
                    document.getElementById("fund_list").style.display='block';
                    
                    document.getElementById("global_funds").style.display='block';
                    document.getElementById("local_funds").style.display='none';
                    document.getElementById("asia_local_bond_fund").style.display='none';
                    document.getElementById("asia_managed_fund").style.display='none';
                    document.getElementById("asia_property_security_fund").style.display='none';
                    document.getElementById("global_market_naviga").style.display='none';
                    document.getElementById("dragon_peacock").style.display='none';
                    document.getElementById("asia_equity_fund").style.display='none';
                    $(".fundDisplayFlag").css("display", "block");
                    
                       $("#global_funds").css("display", "none");
                    
                    
                }
           /*     if(document.getElementById("al_sqs_details.product_name").value=="PRUmy treasure")Added for new Funds on date 5 Nov 2019.
                {
                    document.getElementById("asia_local_bond_fund").style.display='none';
                    document.getElementById("fund_list").style.display='block';
                    document.getElementById("total_allocation_block").style.display='block';
                    document.getElementById("local_funds").style.display="none";
                    document.getElementById("global_funds").style.display="block";
                    document.getElementById("global_growth_fund").style.display='block';
                    
                    document.getElementById("asia_managed_fund").style.display='none';
                    document.getElementById("asia_property_security_fund").style.display='none';
                    document.getElementById("global_market_naviga").style.display='none';
                    document.getElementById("dragon_peacock").style.display='none';
                    document.getElementById("asia_equity_fund").style.display='none';
                    
                   
                    
                   
                   
                   
                    
                }***/
                
                
                
                
                
              
                
                
                                
               // InceptionDateCal();
            }
            else if(document.getElementById("al_sqs_details.product_name").value=="InvestLink" || document.getElementById("al_sqs_details.product_name").value=="PRUSignature Invest" || document.getElementById("al_sqs_details.product_name").value=="PRULink Investor Account" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature Ace")//Added by Rahul on date 28 Jan 16 // or condition added by sourabh for new product PRUSignature Invest 15 jan 2019
            {
                console.log("PRUSignature Invest.0-->");
                document.getElementById("fund_list").style.display='block';
                document.getElementById("total_allocation_block").style.display='block';
                  $(".no-italics").css("font-style", "")//condition for PRUwith you.
                $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                var option = $(escape_jq("al_sqs_details.payment_frequency"));
                option.append($("<option />").val("SP").text("Single Premium"));
                
                $(escape_jq("al_sqs_details.payment_mode")).val("Cash/Cheque");
                $(escape_jq("al_sqs_details.payment_mode")).prop("disabled", true);
                document.getElementById("al_sqs_details.payment_frequency").disabled=true;
                
                if(channelTypeForAgencyBancaRepls=="banca")
                {
                    var option = $(escape_jq("al_sqs_details.payment_mode"));
                    $(escape_jq("al_sqs_details.payment_mode")).empty();
                     $.each( msJsonBancaPaymentMode, function( key, value )
                     {
                     option.append($("<option />").val(key).text(value));
                     });
                    $(escape_jq("al_sqs_details.payment_mode")).val("Bank Transfer");
                   
                }
                
              
//                document.getElementById("al_sqs_details.payment_backdate_no").checked=true;
//                document.getElementById("al_sqs_details.payment_backdate_yes").checked=false;
                document.getElementById("local_funds").style.display="block";
                //document.getElementById("global_funds").style.display="none";
                //if condition added by sourabh for new product PRUSignature Invest 15 jan 2019
              /*  if(document.getElementById("al_sqs_details.product_name").value =="PRUSignature Invest" || document.getElementById("al_sqs_details.product_name").value =="PRULink Investor Account")
                {
                    document.getElementById("global_funds").style.display="block";
                    document.getElementById("newGlobalFund").style.display="block";
                    $("#local_equity_fund").css("display", "none");
                }else{
                     document.getElementById("global_funds").style.display="none";
                }*/
                if(document.getElementById("al_sqs_details.product_name").value =="PRUSignature Invest" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature Ace")
                {
                    document.getElementById("global_funds").style.display="block";
                    document.getElementById("newGlobalFund").style.display="block";
                    $("#local_equity_fund").css("display", "none");
                    document.getElementById("asia_local_bond_fund").style.display='none';
                    document.getElementById("asia_property_security_fund").style.display='none';
                    
                }else if(document.getElementById("al_sqs_details.product_name").value =="PRULink Investor Account")
                {
                    document.getElementById("global_funds").style.display="block";
                    document.getElementById("newGlobalFund").style.display='none';
                    $("#local_equity_fund").css("display", "none");
                    document.getElementById("asia_local_bond_fund").style.display="block";
                    //document.getElementById("asia_property_security_fund").style.display="block";
                    document.getElementById("asia_property_security_fund").style.display="none";//Added by Shivani for POPRT - 2873 for Mar2022
                    
                    
                }else{
                    document.getElementById("global_funds").style.display="none";
                    document.getElementById("asia_local_bond_fund").style.display='none';
                    document.getElementById("asia_property_security_fund").style.display='none';
                    
                }
                if(document.getElementById("al_sqs_details.product_name").value === "PRUSignature Invest" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature Ace")
                {
                    //to remove two funds//added on 17 june 2021 by sourabh
                    $("#japan_dynamic_fund").css("display","none");
                    //commented by ankita on 14 sept 2022 for euro_equity_fund
                    //$("#euro_equity_fund").css("display", "block");
                    document.getElementById("local_global_funds").style.display='block';
                    document.getElementById("global_strategic_fund").style.display='block';
                    document.getElementById("innovation_fund").style.display='block';
                    document.getElementById("asia_great_fund").style.display='block';
                    document.getElementById("us_equity_fund").style.display='block'; // Added by Shivani SCB new fund for Mar2022
                    document.getElementById("sustainable_equity_fund").style.display='block';//new july 2023 fund CR SEF & ADI Funds added by sachin on 9-6-2023..
                    document.getElementById("pacific_dynamic_income_fund").style.display='block';//new july 2023 fund CR SEF & ADI Funds added by sachin on 9-6-2023..
                    
                    //
                }
                
                // InceptionDateCal();
            }
            else if(document.getElementById("al_sqs_details.product_name").value=="InvestLink Global")//Added by Rahul on date 28 Jan 16
            {
                document.getElementById("fund_list").style.display='block';
                document.getElementById("total_allocation_block").style.display='block';
                $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                 $(".no-italics").css("font-style", "")//condition for PRUwith you.
                var option = $(escape_jq("al_sqs_details.payment_frequency"));
                option.append($("<option />").val("SP").text("Single Premium"));
                
                $(escape_jq("al_sqs_details.payment_mode")).val("Cash/Cheque");
                $(escape_jq("al_sqs_details.payment_mode")).prop("disabled", true);
                document.getElementById("al_sqs_details.payment_frequency").disabled=true;
                document.getElementById("asia_local_bond_fund").style.display='none';
                document.getElementById("asia_property_security_fund").style.display='none';
//                document.getElementById("al_sqs_details.payment_backdate_no").checked=true;
//                document.getElementById("al_sqs_details.payment_backdate_yes").checked=false;
                document.getElementById("local_funds").style.display="none";
                document.getElementById("global_funds").style.display="block";
                
                if(channelTypeForAgencyBancaRepls=="banca")
                {
                    $(escape_jq("al_sqs_details.payment_mode")).val("Bank Transfer");
                }
                
                // InceptionDateCal();
            }
           
            
            
            else if(document.getElementById("al_sqs_details.product_name").value=="PRUsignature" || document.getElementById("al_sqs_details.product_name").value=="PRUSignature Plus")
            {
                //to remove two funds//added on 17 june 2021 by sourabh
                
                $("#japan_dynamic_fund").css("display","none");
                //commented by ankita on 14 sept 2022 for euro_equity_fund
                //$("#euro_equity_fund").css("display", "none");
                document.getElementById("local_global_funds").style.display='block';
                document.getElementById("global_strategic_fund").style.display='block';
                document.getElementById("innovation_fund").style.display='block';
                document.getElementById("asia_great_fund").style.display='block';
                document.getElementById("us_equity_fund").style.display='block'; // Added by Shivani SCB new fund for Mar2022
                document.getElementById("sustainable_equity_fund").style.display='block';//new july 2023 fund CR SEF & ADI Funds added by sachin on 9-6-2023..
                //
                $("#newGlobalFund").css("display", "block");
                $("#asia_local_bond_fund").css("display", "none");
                $("#asia_property_security_fund").css("display", "none");
                $("#fund_list").css("display", "block");
                $("#total_allocation_block").css("display", "block");
                $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                 $(".no-italics").css("font-style", "")//condition for PRUwith you.
                //1616 below condition added for CR to remove PRUlink Equity fund SR requirement is on email by lai har july release
                $("#local_equity_fund").css("display", "none");
                var option = $(escape_jq("al_sqs_details.payment_frequency"));
                $.each( msJsonPaymentFrequency, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                $(escape_jq("al_sqs_details.payment_mode")).empty();//Clear Payment Frequency dropdown.
                var option = $(escape_jq("al_sqs_details.payment_mode"));
                
                $.each( msJsonPaymentMode, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                
               if(channelTypeForAgencyBancaRepls=="banca")
              {
                  $(escape_jq("al_sqs_details.payment_mode")).empty();
                  
                   $.each( msJsonBancaPaymentMode, function( key, value )
                   {
                   option.append($("<option />").val(key).text(value));
                   });
                 
              }
                $(escape_jq("al_sqs_details.payment_mode")).val("Payment Method");
                $(escape_jq("al_sqs_details.payment_mode")).prop("disabled", false);
                document.getElementById("al_sqs_details.payment_frequency").disabled=false;
                if(callfrom!="change")
                {
                    if(obj_prochoice["al_sqs_details.payment_frequency"]!=undefined)
                    {
                        document.getElementById("al_sqs_details.payment_frequency").value=obj_prochoice["al_sqs_details.payment_frequency"];
                    }
                    if(obj_prochoice["al_sqs_details.payment_mode"]!=undefined)
                    {
                        document.getElementById("al_sqs_details.payment_mode").value=obj_prochoice["al_sqs_details.payment_mode"];
                    }
                }
               //added by ankita on 18 jan 2023 for to display ADI fund for PRUSignature product
                document.getElementById("pacific_dynamic_income_fund").style.display='block';
                //added by ankita on 19 jan 2023 for bundle product for PRUSignature product
                console.log("fetchPriorityResponse:"+fetchPriorityResponse);
                
                var isBundleProductCertified="false";
                //added by ankita on 10 march 2023 for defect 797
                if(responseBundle!="" && responseBundle!="{}")
                {
                    //console.log("responseBundle:"+JSON.stringify(responseBundle));
                    var obj_bundle=JSON.parse(responseBundle);
                    console.log("obj_bundle:"+JSON.stringify(obj_bundle));
                if(checkProductforExp(obj_bundle[0]["product_effect_date"], obj_bundle[0]["product_expiry_date"], document.getElementById("al_sqs_details.Inception_dt").value))
                {
                                      console.log("Expiry check true");
                                      if (mlifeResponse != "" && mlifeResponse != null && mlifeResponse != "null" && mlifeResponse != "(null)")
                                      {
                                          
                                          var objMlifeRes = JSON.parse(mlifeResponse);
                                      }
                    if (((fnCheckProductCertification(globalDtAppointmentDate, globalDtCertificationDate, obj_bundle[0]["cert_code"],productCertified,effectiveDayMBM))) && ((checkEligable(objMlifeRes["al_person_details.mlife.insu_type"],obj_bundle[0]["product_name"]))))
                    {
                        console.log("certified check true");
                        isBundleProductCertified="true";
                    }
                }
                                      
                }
                if(isFromMyneed && obj_mlife["al_person_details.mlife.insu_type"]=="employee"){
                  document.getElementById("bundle_product_div_id").style.display="block";
                }
                 console.log("isBundleProductCertified:"+isBundleProductCertified);
                if(isBundleProductCertified==="true")
                {
                    //document.getElementById("bundle_product_div_id").style.display="block";
                    if(fetchPriorityResponse!="")
                    {
                       // if((fetchPriorityResponse[0]["protection_ranking"]=="2" || fetchPriorityResponse[0]["security_ranking"]=="2") && fetchPriorityResponse!="")
                        //modified condition by ankita on 3 march 2023 for changes in policy limit file version 1.0 for bundle product
                        if((fetchPriorityResponse[0]["security_ranking"]=="2") && fetchPriorityResponse!="")
                        {
                            
                             document.getElementById("bundle_product_div_id").style.display="block";
                        }
                        else
                        {
                            document.getElementById("bundle_product_div_id").style.display="none";
                        }
                    }
                    //added by ankita on 28 feb 2023 for bundle product
                    if(disclousure_Option_Value == 3 || disclousure_Option_Value == "3")
                    {
                        document.getElementById("bundle_product_div_id").style.display="none";
                    }
                }
                else
                {
                    document.getElementById("bundle_product_div_id").style.display="none";
                }
                
            }else if(document.getElementById("al_sqs_details.product_name").value=="PRUsignature USD")
            {
               // Pramod Chavan: 23012018
                
                $("#global_funds").css("display", "none");
                $("#global_funds_USD").css("display", "block");
                $("#local_funds").css("display", "none");
                $("#asia_local_bond_fund").css("display", "none");
                $("#asia_property_security_fund").css("display", "none");
                $("#fund_list").css("display", "block");
                $("#total_allocation_block").css("display", "block");
                $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                 $(".no-italics").css("font-style", "")//condition for PRUwith you.
                var option = $(escape_jq("al_sqs_details.payment_frequency"));
                $.each( msJsonPaymentFrequency, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                
                
                $(escape_jq("al_sqs_details.payment_mode")).empty();//Clear Payment Frequency dropdown.
                var option = $(escape_jq("al_sqs_details.payment_mode"));
                $.each( msJsonPaymentMode, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                
                   if(channelTypeForAgencyBancaRepls=="banca")
                  {
                      $(escape_jq("al_sqs_details.payment_mode")).empty();
                       $.each( msJsonBancaPaymentMode, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                     
                  }
                $(escape_jq("al_sqs_details.payment_mode")).val("Auto Debit");
                $(escape_jq("al_sqs_details.payment_mode")).prop("disabled", true);
                document.getElementById("al_sqs_details.payment_frequency").disabled=false;
                if(callfrom!="change")
                {
                    if(obj_prochoice["al_sqs_details.payment_frequency"]!=undefined)
                    {
                        document.getElementById("al_sqs_details.payment_frequency").value=obj_prochoice["al_sqs_details.payment_frequency"];
                    }
                    if(obj_prochoice["al_sqs_details.payment_mode"]!=undefined)
                    {
                        document.getElementById("al_sqs_details.payment_mode").value=obj_prochoice["al_sqs_details.payment_mode"];
                    }
                }
            }
            else if(document.getElementById("al_sqs_details.product_name").value=="PRUsignature prime")
            {
                
                $("#global_funds").css("display", "none");
                $("#global_funds_USD").css("display", "block");
                $("#local_funds").css("display", "none");
                $("#asia_local_bond_fund").css("display", "none");
                $("#asia_property_security_fund").css("display", "none");
                $("#fund_list").css("display", "block");
                $("#total_allocation_block").css("display", "block");
                $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                $(".no-italics").css("font-style", "")
                
                $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                var option = $(escape_jq("al_sqs_details.payment_frequency"));
                option.append($("<option />").val("SP").text("Single Premium"));
                var modeOption=$(escape_jq("al_sqs_details.payment_mode"));
                
                modeOption.append($("<option />").val("Bank Transfer").text("Bank Transfer"));
                $(escape_jq("al_sqs_details.payment_mode")).val("Bank Transfer");
                $(escape_jq("al_sqs_details.payment_mode")).prop("disabled", true);
                document.getElementById("al_sqs_details.payment_frequency").disabled=true;
                
                //                    if(callfrom!="change")
                //                    {
                //                        if(obj_prochoice["al_sqs_details.payment_frequency"]!=undefined)
                //                        {
                //                            document.getElementById("al_sqs_details.payment_frequency").value=obj_prochoice["al_sqs_details.payment_frequency"];
                //                        }
                //                        if(obj_prochoice["al_sqs_details.payment_mode"]!=undefined)
                //                        {
                //                            document.getElementById("al_sqs_details.payment_mode").value=obj_prochoice["al_sqs_details.payment_mode"];
                //                        }
                //                    }
                
                
                
            }
            else if(document.getElementById("al_sqs_details.product_name").value=="PRUGlobal Series")
                {
                    var gloabalCurrencies=[];
                    var prugloabl_series_inception=document.getElementById("al_sqs_details.Inception_dt").value;
                         console.log("ProductMasterResponse key:"+JSON.stringify(FundCurrencyResponse));
                    console.log("FundResponse key:"+JSON.stringify(FundResponse));
                         var DBForgeinCurrency = _.where(FundCurrencyResponse, {"product_name": document.getElementById("al_sqs_details.product_name").value}) // al_product_master
                    
                    var DBForgeinCurrencyFund = _.where(FundResponse, {"product_name": document.getElementById("al_sqs_details.product_name").value})
                    
                         console.log("ForgeinCurrency key:"+JSON.stringify(DBForgeinCurrency));
                    console.log("ForgeinCurrencyFund key:"+JSON.stringify(DBForgeinCurrencyFund));
                    //ForgeinCurrency = DBForgeinCurrency[0]["currency_type"].split(",")
                    
                    for(i=0;i<=DBForgeinCurrency.length-1;i++) {
                        
                      //  alert("DB Column"+tData[i]["db_column"])
                        
                        if (checkProductforExp(DBForgeinCurrency[i]["effective_date"],DBForgeinCurrency[i]["expiry_date"], prugloabl_series_inception)) //&& subChannelTypeForAgencyBancaRepls==DBForgeinCurrency[i]["sub_channel"]
                        {
                            
                           gloabalCurrencies.push(DBForgeinCurrency[i]["currency_type"])
                            
                        }
                        
                    }
                    
                    
                    if(gloabalCurrencies==[] || gloabalCurrencies==""){         // Abhilash: new condition added
                        document.getElementById("al_sqs_details.foreign_currency").style.display="none";
                        alert("You can not proceed further, please contact admin");
                        ClearDataProd(document.getElementById("al_sqs_details.product_name").value);
                        document.getElementById("al_sqs_details.product_name").selectedIndex = 0;
                        
                        $("#al_sqs_details.product_name").removeClass('selectMandatory');
                        $("#al_sqs_details.product_name").addClass('selectRedMandatory');
                    }
                    
                    else{
                     console.log("abc Currency-->"+ForgeinCurrency);
                     console.log("abc Currency-->"+typeof(ForgeinCurrency));
                    console.log("Currencies"+gloabalCurrencies);
                
                    
                     var phlsorted_arr=gloabalCurrencies; //original code

                 //   var phlsorted_arr=[new Set(gloabalCurrencies)];
                    
                        document.getElementById("al_sqs_details.foreign_currency").options.length=0;
                    
                        var dropdownppt=document.getElementById("al_sqs_details.foreign_currency");
                         var phloptn=document.createElement("option");
                          phloptn.value="Select Currency";
                         console.log("sorted array-22->"+phloptn);
                         phloptn.text="Select Currency";
                         dropdownppt.appendChild(phloptn);
                          for(var i=phlsorted_arr.length-1;i>=0;i--)
                          {
                          console.log("sorted array-33->"+phlsorted_arr[i]);
                         var phloptn1=document.createElement("option");
                         phloptn1.value=phlsorted_arr[i];
                         phloptn1.text=phlsorted_arr[i];
                         dropdownppt.appendChild(phloptn1);
                          }
                                            if(callfrom!="change")
                                            {
                                                if(obj_prochoice["al_sqs_details.foreign_currency"]!=undefined)
                                                {
                                                    document.getElementById("al_sqs_details.foreign_currency").value=obj_prochoice["al_sqs_details.foreign_currency"];
                                                    //added by ankita on 18 April 2019 to display funds when currency is selected
                                                    fnToDisplayFundsForCurrency('al_sqs_details.foreign_currency');
                                                }
                                             
                                            }
                        
                  
                    $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                    $(".no-italics").css("font-style", "")
                    
                    $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                   //  $(escape_jq("al_sqs_details.foreign_currency")).empty();//Clear currency for pruglobal series sourabh
                    var option = $(escape_jq("al_sqs_details.payment_frequency"));
                    option.append($("<option />").val("SP").text("Single Premium"));
                    var modeOption=$(escape_jq("al_sqs_details.payment_mode"));
                      
                    modeOption.append($("<option />").val("Bank Transfer").text("Bank Transfer"));
                   $(escape_jq("al_sqs_details.payment_mode")).val("Bank Transfer");
                    $(escape_jq("al_sqs_details.payment_mode")).prop("disabled", true);
                    document.getElementById("al_sqs_details.payment_frequency").disabled=true;
                    
//                    if(callfrom!="change")
//                    {
//                        if(obj_prochoice["al_sqs_details.payment_frequency"]!=undefined)
//                        {
//                            document.getElementById("al_sqs_details.payment_frequency").value=obj_prochoice["al_sqs_details.payment_frequency"];
//                        }
//                        if(obj_prochoice["al_sqs_details.payment_mode"]!=undefined)
//                        {
//                            document.getElementById("al_sqs_details.payment_mode").value=obj_prochoice["al_sqs_details.payment_mode"];
//                        }
//                    }

                }
            
               }
            else if(document.getElementById("al_sqs_details.product_name").value=="PRUsignature infinite" || document.getElementById("al_sqs_details.product_name").value=="PRUsignature income" || document.getElementById("al_sqs_details.product_name").value=="PRUMy Gift" || document.getElementById("al_sqs_details.product_name").value==="PRUMulti Crisis Guard")//Added condition for PRUsignature income by ankita on 7 July 2018
            {
                console.log("loding fund...");
                $("#newGlobalFund").css("display", "block");
                $("#fund_list").css("display", "block");
                $("#total_allocation_block").css("display", "block");
                $("#local_equity_fund").css("display", "none");
                $("#euro_equity_fund").css("display", "block");
                $("#japan_dynamic_fund").css("display", "block");
                $("#global_leaders_fund").css("display", "block");
                $("#asia_property_security_fund").css("display","none");
                $("#asia_local_bond_fund").css("display","none");
                
                $("#strategic_managed_fund").css("display", "none");//Internal found :Extra fund shown for income ,on date 2-07-2019 by sachin T.
                
                $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                $(".no-italics").css("font-style", "")//condition for PRUwith you.
                var option = $(escape_jq("al_sqs_details.payment_frequency"));
                $.each( msJsonPaymentFrequency, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                
                
                $(escape_jq("al_sqs_details.payment_mode")).empty();//Clear Payment Frequency dropdown.
                var option = $(escape_jq("al_sqs_details.payment_mode"));
                
                
                $.each( msJsonPaymentMode, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                
               if(channelTypeForAgencyBancaRepls=="banca")
              {
                  $(escape_jq("al_sqs_details.payment_mode")).empty();
                 
                   $.each( msJsonBancaPaymentMode, function( key, value )
                   {
                   option.append($("<option />").val(key).text(value));
                   });
                
              }
                
                $(escape_jq("al_sqs_details.payment_mode")).val("Payment Method");
                $(escape_jq("al_sqs_details.payment_mode")).prop("disabled", false);
                document.getElementById("al_sqs_details.payment_frequency").disabled=false;
                
                if(document.getElementById("al_sqs_details.product_name").value=="PRUMy Gift" || document.getElementById("al_sqs_details.product_name").value==="PRUMulti Crisis Guard") // Condition added by Shivani for PRUMulti Crisis Guard
                {
                    console.log("PMG PEF Fund 11111");
                     $("#global_growth_fund").css("display", "block");
                     $("#strategic_managed_fund").css("display", "block");
                     $("#global_leaders_fund").css("display", "none");
                     $("#asian_high_yield_bond_fund").css("display","none");
                     $("#japan_dynamic_fund").css("display","none");
                     $("#euro_equity_fund").css("display","none");
                     $("#multi_asset_fund").css("display","none");
                    
                    // Added by shivani for PEF fund on 8th ov 2021
                    if(document.getElementById("al_sqs_details.product_name").value=="PRUMy Gift")
                    {
                        console.log("PMG PEF Fund 4444");
                        document.getElementById("local_global_funds").style.display='block';
                        document.getElementById("global_strategic_fund").style.display='none';
                        document.getElementById("pacific_dynamic_income_fund").style.display='block';
                       // $(".fundDisplayFlag").css("display", "block");
                        
                        
                        
                    }
                    
                }
                
                if(callfrom!="change")
                {
                    if(obj_prochoice["al_sqs_details.payment_frequency"]!=undefined)
                    {
                        document.getElementById("al_sqs_details.payment_frequency").value=obj_prochoice["al_sqs_details.payment_frequency"];
                    }
                    if(obj_prochoice["al_sqs_details.payment_mode"]!=undefined)
                    {
                        document.getElementById("al_sqs_details.payment_mode").value=obj_prochoice["al_sqs_details.payment_mode"];
                    }
                }
                if(!uiaFundSelectionFlag && (document.getElementById("al_sqs_details.product_name").value=="PRUsignature income" || document.getElementById("al_sqs_details.product_name").value=="PRUMy Gift" || document.getElementById("al_sqs_details.product_name").value==="PRUMulti Crisis Guard" ))//Added for CR on date 17-09-2018. // Addded by Shivani for PRUMulti Crisis Guard
                {
                    console.log("PMG PEF Fund 22222");
                    document.getElementById("fund_list").style.display='none';
                    
                    document.getElementById("total_allocation_block").style.display='none';
                
                
                }
                if(document.getElementById("al_sqs_details.product_name").value==="PRUsignature infinite")
                {
                    //to remove two funds//added on 17 june 2021 by sourabh
                                   $("#japan_dynamic_fund").css("display","none");
                    //commented by ankita on 14 sept 2022 for euro_equity_fund
                                   //$("#euro_equity_fund").css("display", "none");
                                   document.getElementById("local_global_funds").style.display='block';
                                   document.getElementById("global_strategic_fund").style.display='block';
                    
                        document.getElementById("innovation_fund").style.display='block';
                        document.getElementById("asia_great_fund").style.display='block';
                        document.getElementById("us_equity_fund").style.display='block'; // Added by Shivani SCB new fund for Mar2022
                        document.getElementById("pacific_dynamic_income_fund").style.display='block';
                        document.getElementById("sustainable_equity_fund").style.display='block';//new july 2023 fund CR SEF & ADI Funds added by sachin on 9-6-2023..
                                   
                }
                // removed condition of PEF fund by Shivani on 24th June 2021 // Added condtion of PEF fund by Shivani on 8th Nov 2021
               /* if(document.getElementById("al_sqs_details.product_name").value==="PRUMy Gift")
                {
                    console.log("PMG PEF Fund 11111");
                    //to remove two funds//added on 17 june 2021 by sourabh
                    $("#japan_dynamic_fund").css("display","none");
                    $("#euro_equity_fund").css("display", "none");
                    document.getElementById("local_global_funds").style.display='block';
                    document.getElementById("global_strategic_fund").style.display='block';
                    document.getElementById("strategic_managed_fund").style.display='none';
                    
                    
                    document.getElementById("total_allocation_block").style.display='block';
                    document.getElementById("fund_list").style.display='block';
                    
                    document.getElementById("global_funds").style.display='block';
                    document.getElementById("local_funds").style.display='none';
                    document.getElementById("asia_local_bond_fund").style.display='none';
                    document.getElementById("asia_managed_fund").style.display='none';
                    document.getElementById("asia_property_security_fund").style.display='none';
                    document.getElementById("global_market_naviga").style.display='none';
                    document.getElementById("dragon_peacock").style.display='none';
                    document.getElementById("asia_equity_fund").style.display='none';
                    document.getElementById("global_growth_fund").style.display='none';
                    
                    
                    
                    
                    
                }*/
                
                
            }
            /*else if(document.getElementById("al_sqs_details.product_name").value=="PRUmillion cover")
                {
                    
                    document.getElementById("fund_choice_block").style.display='none';
                    document.getElementById("global_funds").style.display="block";
                    document.getElementById("fund_list").style.display='block';
                    document.getElementById("strategic_managed_fund").style.display='block';
                    document.getElementById("total_allocation_block").style.display='block';
                    document.getElementById("asia_local_bond_fund").style.display='none';
                    document.getElementById("asia_property_security_fund").style.display='none';
                     document.getElementById("local_equity_fund").style.display='none';
                    $(".no-italics").css("font-style", "normal");
                    
                    $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                    var option = $(escape_jq("al_sqs_details.payment_frequency"));
                    $.each( msJsonPaymentFrequency, function( key, value )
                           {
                           option.append($("<option />").val(key).text(value));
                           });
                    $(escape_jq("al_sqs_details.payment_mode")).empty();//Clear Payment Frequency dropdown.
                    var option = $(escape_jq("al_sqs_details.payment_mode"));
                    $.each( msJsonPaymentMode, function( key, value )
                           {
                           option.append($("<option />").val(key).text(value));
                           });
                    $(escape_jq("al_sqs_details.payment_mode")).val("Payment Method");
                    $(escape_jq("al_sqs_details.payment_mode")).prop("disabled", false);
                    document.getElementById("al_sqs_details.payment_frequency").disabled=false;
                    if(callfrom!="change")
                    {
                        if(obj_prochoice["al_sqs_details.payment_frequency"]!=undefined)
                        {
                            document.getElementById("al_sqs_details.payment_frequency").value=obj_prochoice["al_sqs_details.payment_frequency"];
                        }
                        if(obj_prochoice["al_sqs_details.payment_mode"]!=undefined)
                        {
                            document.getElementById("al_sqs_details.payment_mode").value=obj_prochoice["al_sqs_details.payment_mode"];
                        }
                    }
                }*/
            else if(document.getElementById("al_sqs_details.product_name").value=="PRUsmart gain" || document.getElementById("al_sqs_details.product_name").value=="PRULink Cover" || document.getElementById("al_sqs_details.product_name").value=="PRUmillion cover" || document.getElementById("al_sqs_details.product_name").value=="PRUMax Cover" || document.getElementById("al_sqs_details.product_name").value=="PRUMillion Cover 2.0" || document.getElementById("al_sqs_details.product_name").value=="PRUSignature Assure" || document.getElementById("al_sqs_details.product_name").value==="PRULink Supreme" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature Vanguard" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature GrowthPlus" || document.getElementById("al_sqs_details.product_name").value==="PRUEnhanced Cover" || document.getElementById("al_sqs_details.product_name").value==="PRULink Supreme Plus")//New product "PRUsmart gain" Added by Sachin Tupe on 29-05-2018
            {
                
                
                
                console.log("check funds 3333");
                $(".tohide_PLG").css("display", "block"); // for def- 10962
                document.getElementById("al_sqs_details.strategic_managed_fund").disabled=false; // for def-10962
                document.getElementById("fund_choice_block").style.display='none';
                document.getElementById("global_funds").style.display="block";
                document.getElementById("fund_list").style.display='block';
                document.getElementById("strategic_managed_fund").style.display='block';
                document.getElementById("total_allocation_block").style.display='block';
                document.getElementById("asia_local_bond_fund").style.display="none";
                document.getElementById("asia_property_security_fund").style.display="none";
                document.getElementById("local_equity_fund").style.display='none';
                
                document.getElementById("asia_managed_fund").style.display="block";
                document.getElementById("global_market_naviga").style.display="block";
                document.getElementById("dragon_peacock").style.display="block";
                document.getElementById("asia_equity_fund").style.display="block";
                
                $(".no-italics").css("font-style", "normal");
                
                $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                var option = $(escape_jq("al_sqs_details.payment_frequency"));
                $.each( msJsonPaymentFrequency, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                $(escape_jq("al_sqs_details.payment_mode")).empty();//Clear Payment Frequency dropdown.
                var option = $(escape_jq("al_sqs_details.payment_mode"));
               /* if(document.getElementById("al_sqs_details.product_name").value=="PRULink Cover")
                {
                    var msJsonPaymentModeLinkCover = {
                        "Payment Method":"Payment Method",
                        "Credit Card1": "Credit Card",
                        "Debit Card": "Debit Card",
                        "Cash/Cheque": "Cash/Cheque",
                        "Direct Debit": "Direct Debit"
                    };
                    $.each( msJsonPaymentModeLinkCover, function( key, value )
                           {
                           option.append($("<option />").val(key).text(value));
                           });
                }
                else*/
                
                
                if(document.getElementById("al_sqs_details.product_name").value=="PRULink Cover" || document.getElementById("al_sqs_details.product_name").value=="PRUmillion cover" || document.getElementById("al_sqs_details.product_name").value=="PRUMax Cover" || document.getElementById("al_sqs_details.product_name").value=="PRUMillion Cover 2.0"  || document.getElementById("al_sqs_details.product_name").value=="PRUSignature Assure" || document.getElementById("al_sqs_details.product_name").value=="PRULink Supreme" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature Vanguard" || document.getElementById("al_sqs_details.product_name").value=="PRUEnhanced Cover" || document.getElementById("al_sqs_details.product_name").value==="PRULink Supreme Plus")
                {
                
                 document.getElementById("global_growth_fund").style.display='block';
                 document.getElementById("pacific_dynamic_income_fund").style.display='block';
                    document.getElementById("global_esg_choice_fund").style.display='none'; //Pradnya: added global_esg_choice_fund for march24 release
                    
               
                
                }
                
                if(document.getElementById("al_sqs_details.product_name").value=="PRUSignature Assure" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature Vanguard"){
                    
                     $("#newGlobalFund").css("display", "block");
                    $("#strategic_managed_fund").css("display", "none");
                    document.getElementById("global_growth_fund").style.display='none';
                    $("#asian_high_yield_bond_fund").css("display","block");
                    $("#global_leaders_fund").css("display", "block");
                    $("#japan_dynamic_fund").css("display", "none");
                    //commented by ankita on 14 sept 2022 for euro_equity_fund
                    $("#euro_equity_fund").css("display", "block");
                   // document.getElementById("pacific_dynamic_income_fund").style.display='none'; //old condition changed for new july 2023 fund CR SEF & ADI Funds by sachin on 9-6-2023..
                   document.getElementById("pacific_dynamic_income_fund").style.display='block';//new july 2023 fund CR SEF & ADI Funds added by sachin on 9-6-2023..
                   document.getElementById("sustainable_equity_fund").style.display='block';//new july 2023 fund CR SEF & ADI Funds added by sachin on 9-6-2023..
                }
                
                
                
                
                    $.each( msJsonPaymentMode, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                console.log("sub channel:"+objMlifeIL["pamb_sub_channel"]);
                //added on 29 july 2022 for to remove cash/cheque list from dropdown
                if(document.getElementById("al_sqs_details.product_name").value=="PRULink Supreme"  && objMlifeIL["pamb_sub_channel"]==="MAS")
                {
                    $("option[value='Cash/Cheque']").remove();
                }
                   if(channelTypeForAgencyBancaRepls=="banca")
                  {
                      $(escape_jq("al_sqs_details.payment_mode")).empty();
                       $.each( msJsonBancaPaymentMode, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                     
                  }
                
                $(escape_jq("al_sqs_details.payment_mode")).val("Payment Method");
                $(escape_jq("al_sqs_details.payment_mode")).prop("disabled", false);
                document.getElementById("al_sqs_details.payment_frequency").disabled=false;
                if(callfrom!="change")
                {
                    if(obj_prochoice["al_sqs_details.payment_frequency"]!=undefined)
                    {
                        document.getElementById("al_sqs_details.payment_frequency").value=obj_prochoice["al_sqs_details.payment_frequency"];
                    }
                    if(obj_prochoice["al_sqs_details.payment_mode"]!=undefined)
                    {
                        document.getElementById("al_sqs_details.payment_mode").value=obj_prochoice["al_sqs_details.payment_mode"];
                    }
                }
                 // removed condition of PEF fund by Shivani on 24th June 2021 // Added condition of PEF fund by Shivani on 8th Nov 2021
                if(document.getElementById("al_sqs_details.product_name").value==="PRUSignature Assure" || document.getElementById("al_sqs_details.product_name").value==="PRULink Cover" || document.getElementById("al_sqs_details.product_name").value==="PRUmillion cover" || document.getElementById("al_sqs_details.product_name").value==="PRUMax Cover" || document.getElementById("al_sqs_details.product_name").value==="PRUMillion Cover 2.0" || document.getElementById("al_sqs_details.product_name").value==="PRULink Supreme" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature Vanguard" || document.getElementById("al_sqs_details.product_name").value==="PRUElite Invest" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature GrowthPlus" || document.getElementById("al_sqs_details.product_name").value==="PRUEnhanced Cover" || document.getElementById("al_sqs_details.product_name").value==="PRULink Supreme Plus")
                {
                    //to remove two funds//added on 17 june 2021 by sourabh
                    console.log("check fund 4444");
                    $("#japan_dynamic_fund").css("display","none");
                    $("#euro_equity_fund").css("display", "none");
                    document.getElementById("local_global_funds").style.display='block';
                    document.getElementById("global_strategic_fund").style.display='block';
                    
                    if(document.getElementById("al_sqs_details.product_name").value!="PRUSignature Assure" && document.getElementById("al_sqs_details.product_name").value!=="PRUSignature Vanguard"){
                        $(".fundDisplayFlag").css("display", "block");
                    }
                    
                   
                    if(document.getElementById("al_sqs_details.product_name").value==="PRUSignature Assure" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature Vanguard")
                    {
                        document.getElementById("innovation_fund").style.display='block';
                        document.getElementById("asia_great_fund").style.display='block';
                        document.getElementById("us_equity_fund").style.display='block'; // Added by Shivani SCB new fund for Mar2022
                    }else{
                        document.getElementById("global_strategic_fund").style.display='none';
                    }
                    if(document.getElementById("al_sqs_details.product_name").value==="PRULink Supreme" || document.getElementById("al_sqs_details.product_name").value==="PRUElite Invest" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature GrowthPlus"
                       || document.getElementById("al_sqs_details.product_name").value==="PRULink Supreme Plus")
                    {
                        console.log("check fund 5555");
                        document.getElementById("asia_local_bond_fund").style.display='none';
                        document.getElementById("asia_property_security_fund").style.display='none';
                        document.getElementById("dragon_peacock").style.display='block';
                        
                    }
                    if(document.getElementById("al_sqs_details.product_name").value==="PRUElite Invest" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature GrowthPlus")
                    { console.log("march");
                        document.getElementById("euro_equity_fund").style.display='block';
                                      
                                      if(document.getElementById("al_sqs_details.product_name").value==="PRUElite Invest"){
                                      document.getElementById("sustainable_equity_fund").style.display='block';//new july 2023 fund CR SEF & ADI Funds added by sachin on 9-6-2023..
                                      
                                      }
                        
                    }
                                      
                    if(document.getElementById("al_sqs_details.product_name").value==="PRUSignature GrowthPlus")
                    { console.log("march");
                       // $(".tohide_PLG").css("display", "none");
                        document.getElementById("newGlobalFund").style.display="block";
                        document.getElementById("pacific_dynamic_income_fund").style.display="block";
                        document.getElementById("global_strategic_fund").style.display="block";
                        document.getElementById("bond_fund_PF").style.display='none';
                        document.getElementById("strategic_managed_fund").style.display='none';
                        document.getElementById("dana_aman").style.display='none';
                        document.getElementById("global_growth_fund").style.display='none';
                        document.getElementById("japan_dynamic_fund").style.display='none';
                        document.getElementById("emerging_opportunities_fund").style.display='none';
                        document.getElementById("sustainable_equity_fund").style.display='block';//new july 2023 fund CR SEF & ADI Funds added by sachin on 9-6-2023..
                     
                                      
                        
                    }
                    if(document.getElementById("al_sqs_details.product_name").value==="PRUEnhanced Cover")// added by Pradnya for Aug2023 release
                    { console.log("July2023");
                      
                       
                        document.getElementById("global_market_naviga").style.display='none';
                        document.getElementById("managed_plus_fund").style.display='none';
                        document.getElementById("dana_aman").style.display='none';
                        document.getElementById("dana_urus2").style.display='none';
                        document.getElementById("managed_fund2").style.display='none';
                        document.getElementById("dana_unggul").style.display='none';
                        document.getElementById("equity_focus").style.display='none';
                      
                        
                        
                    }
                    if(document.getElementById("al_sqs_details.product_name").value==="PRULink Supreme Plus")// added by Pradnya for march24 release
                    { console.log("July2023");
                      
                       
                        document.getElementById("global_market_naviga").style.display='none';
                        document.getElementById("managed_plus_fund").style.display='none';
                        document.getElementById("dana_aman").style.display='none';
                        document.getElementById("dana_urus2").style.display='none';
                        document.getElementById("managed_fund2").style.display='none';
                        document.getElementById("dana_unggul").style.display='none';
                        document.getElementById("equity_focus").style.display='none';
                        document.getElementById("global_esg_choice_fund").style.display='block'; //Pradnya: added global_esg_choice_fund for march24 release
                      
                        
                        
                    }
                                      
                                      
                }
                
                //Added for defect 115 by sachin on 1-3-2022
                
                if(document.getElementById("al_sqs_details.product_name").value==="PRULink Cover" || document.getElementById("al_sqs_details.product_name").value==="PRUmillion cover" || document.getElementById("al_sqs_details.product_name").value==="PRUMax Cover" || document.getElementById("al_sqs_details.product_name").value==="PRUMillion Cover 2.0" || document.getElementById("al_sqs_details.product_name").value==="PRUEnhanced Cover")
                               {
                                   document.getElementById("asia_local_bond_fund").style.display="none";
                                   document.getElementById("asia_property_security_fund").style.display="none";
                
                               }
                
                /*if(document.getElementById("al_sqs_details.product_name").value=="PRULink Cover")
                {
                   
                    document.getElementById("local_fund_lable").innerHTML="PRULINK FUND";
                    document.getElementById("global_fund_lablel").innerHTML="PRULINK GLOBAL FUND";
                    document.getElementById("toCapital_equity_focus_fund").innerHTML="<span class=\"red\"><b>PRU</b></span>Link Equity Focus Fund";
                    document.getElementById("toCapital_equity_income_fund").innerHTML="<span class=\"red\"><b>PRU</b></span>Link Equity Income Fund";
                    document.getElementById("toCapital_bond_fund").innerHTML="<span class=\"red\"><b>PRU</b></span>Link Bond Fund</change>";
                    document.getElementById("toCapital_managed_fund2").innerHTML="<span class=\"red\"><b>PRU</b></span>Link Managed Fund II";
                    document.getElementById("toCapital_dana_aman_fund").innerHTML="<span class=\"red\"><b>PRU</b></span>Link Dana Aman";
                    document.getElementById("toCapital_dana_urus_fund").innerHTML="<span class=\"red\"><b>PRU</b></span>Link Dana Urus II";
                    document.getElementById("toCapital_dana_unggul_fund").innerHTML="<span class=\"red\"><b>PRU</b></span>Link Dana Unggul";
                    document.getElementById("toCapital_strategic_managed_fund").innerHTML="<span class=\"red\"><b>PRU</b></span>Link Strategic Managed Fund";
                    document.getElementById("toCapital_asia_managed_fund").innerHTML="<span class=\"red\"><b>PRU</b></span>Link Asia Managed Fund";
                    document.getElementById("toCapital_market_fund").innerHTML="<span class=\"red\"><b>PRU</b></span>Link Global Market Navigator Fund";
                    document.getElementById("toCapital_peacock_fund").innerHTML="<span class=\"red\"><b>PRU</b></span>Link Dragon Peacock Fund";
                    document.getElementById("toCapital_equity_fund").innerHTML="<span class=\"red\"><b>PRU</b></span>Link Asia Equity Fund";
                }
                else
                {*/

                
                //added by ankita on 14 sept 2022 for euro_equity_fund
                if(document.getElementById("al_sqs_details.product_name").value=="PRUSignature Assure" || document.getElementById("al_sqs_details.product_name").value=="PRUSignature Vanguard"){
                    
                    $("#euro_equity_fund").css("display", "block");
                }
                
                
            }
            /*else if(document.getElementById("al_sqs_details.product_name").value=="PRULink Cover")//Added condition for PRULink Cover by ankita on 22 March 2019
            {
                $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                var option = $(escape_jq("al_sqs_details.payment_frequency"));
                
                $.each( msJsonPaymentFrequency, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                $(escape_jq("al_sqs_details.payment_mode")).empty();//Clear Payment Frequency dropdown.
                var option = $(escape_jq("al_sqs_details.payment_mode"));
                var msJsonPaymentModeLinkCover = {
                    "Payment Method":"Payment Method",
                    "Credit Card1": "Credit Card",
                    "Debit Card": "Debit Card",
                    "Cash/Cheque": "Cash/Cheque",
                    "Direct Debit": "Direct Debit"
                };
                //delete msJsonPaymentMode["Auto Debit"];
                //msJsonPaymentMode["Direct Debit"]="Direct Debit";
                $.each( msJsonPaymentModeLinkCover, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                $(escape_jq("al_sqs_details.payment_mode")).val("Payment Method");
                $(escape_jq("al_sqs_details.payment_mode")).prop("disabled", false);
                document.getElementById("al_sqs_details.payment_frequency").disabled=false;
                if(callfrom!="change")
                {
                    if(obj_prochoice["al_sqs_details.payment_frequency"]!=undefined)
                    {
                        document.getElementById("al_sqs_details.payment_frequency").value=obj_prochoice["al_sqs_details.payment_frequency"];
                    }
                    if(obj_prochoice["al_sqs_details.payment_mode"]!=undefined)
                    {
                        document.getElementById("al_sqs_details.payment_mode").value=obj_prochoice["al_sqs_details.payment_mode"];
                    }
                }
                console.log("PRUwith normal");
                document.getElementById("fund_choice_block").style.display='none';
                document.getElementById("fund_list").style.display='block';
                document.getElementById("total_allocation_block").style.display='block';
                document.getElementById("asia_local_bond_fund").style.display='block';
                document.getElementById("asia_property_security_fund").style.display='block';
                
                
                
                
                $(".no-italics").css("font-style", "normal");
                //////////////
                
                $("#local_equity_fund").css("display", "none");
                
                document.getElementById("fund_choice_block").style.display='none';
                document.getElementById("fund_list").style.display='block';
                document.getElementById("global_funds").style.display="block";
                document.getElementById("local_fund_lable").innerHTML="PRULINK FUND";
                document.getElementById("total_allocation_block").style.display='block';
                document.getElementById("asia_local_bond_fund").style.display='none';
                document.getElementById("asia_property_security_fund").style.display='none';
                document.getElementById("strategic_managed_fund").style.display='block';
                document.getElementById("global_fund_lablel").innerHTML="PRULINK GLOBAL FUND";
                document.getElementById("toCapital_equity_focus_fund").innerHTML="<span class=\"red\"><b>PRU</b></span>Link Equity Focus Fund";
                document.getElementById("toCapital_equity_income_fund").innerHTML="<span class=\"red\"><b>PRU</b></span>Link Equity Income Fund";
                document.getElementById("toCapital_bond_fund").innerHTML="<span class=\"red\"><b>PRU</b></span>Link Bond Fund</change>";
                document.getElementById("toCapital_managed_fund2").innerHTML="<span class=\"red\"><b>PRU</b></span>Link Managed Fund II";
                document.getElementById("toCapital_dana_aman_fund").innerHTML="<span class=\"red\"><b>PRU</b></span>Link Dana Aman";
                document.getElementById("toCapital_dana_urus_fund").innerHTML="<span class=\"red\"><b>PRU</b></span>Link Dana Urus II";
                document.getElementById("toCapital_dana_unggul_fund").innerHTML="<span class=\"red\"><b>PRU</b></span>Link Dana Unggul";
                document.getElementById("toCapital_strategic_managed_fund").innerHTML="<span class=\"red\"><b>PRU</b></span>Link Strategic Managed Fund";
                document.getElementById("toCapital_asia_managed_fund").innerHTML="<span class=\"red\"><b>PRU</b></span>Link Asia Managed Fund";
                document.getElementById("toCapital_market_fund").innerHTML="<span class=\"red\"><b>PRU</b></span>Link Global Market Navigator Fund";
                document.getElementById("toCapital_peacock_fund").innerHTML="<span class=\"red\"><b>PRU</b></span>Link Dragon Peacock Fund";
                document.getElementById("toCapital_equity_fund").innerHTML="<span class=\"red\"><b>PRU</b></span>Link Asia Equity Fund";
            }*/


            else
            {
                $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                var option = $(escape_jq("al_sqs_details.payment_frequency"));
                $.each( msJsonPaymentFrequency, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                $(escape_jq("al_sqs_details.payment_mode")).empty();//Clear Payment Frequency dropdown.
                var option = $(escape_jq("al_sqs_details.payment_mode"));
                $.each( msJsonPaymentMode, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                
                   if(channelTypeForAgencyBancaRepls=="banca")
                  {
                      $(escape_jq("al_sqs_details.payment_mode")).empty();
                      $.each( msJsonBancaPaymentMode, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                      
                  }
                //document.getElementById("al_sqs_details.payment_backdate_yes").disabled=false; commented for IL ANB changes. Pramod Chavan: 12122017
                document.getElementById("al_sqs_details.payment_backdate_no").disabled=false;
                if(document.getElementById("al_sqs_details.payment_backdate_yes").checked)
                {
                    document.getElementById('al_sqs_details.Inception_dt_img').style.pointerEvents='auto';
                }
                if(document.getElementById("al_sqs_details.payment_backdate_no").checked)
                {
                   document.getElementById('al_sqs_details.Inception_dt_img').style.pointerEvents='none';
                }
                if(obj_prochoice["al_sqs_details.payment_mode"]!="undefined" && obj_prochoice["al_sqs_details.payment_mode"]!=undefined)
                {
                    document.getElementById("al_sqs_details.payment_mode").value=obj_prochoice["al_sqs_details.payment_mode"];
                }
                if(obj_prochoice["al_sqs_details.payment_frequency"]!="undefined" && obj_prochoice["al_sqs_details.payment_frequency"]!=undefined)
                {
                    document.getElementById("al_sqs_details.payment_frequency").value=obj_prochoice["al_sqs_details.payment_frequency"];
                }
            }
            
            
            
        }
        else if(obj_mlife["pamb_channel"]=="Agency" || obj_mlife["pamb_channel"]=="FA")   // Piyush(03/12/2018) : Added this changes for new channel FA
        {
             $("#local_equity_fund").css("display", "block");
            if(document.getElementById("al_sqs_details.product_name").value!="PRUlink investor account"
               && document.getElementById("al_sqs_details.product_name").value!="PRUretirement growth"
               && document.getElementById("al_sqs_details.product_name").value!="PRUwealth" && document.getElementById("al_sqs_details.product_name").value!="PRUcancer X" && document.getElementById("al_sqs_details.product_name").value!="PRULink Investor Account" && document.getElementById("al_sqs_details.product_name").value!="PRUSenior Med" && document.getElementById("al_sqs_details.product_name").value!="PRUElite Invest" && document.getElementById("al_sqs_details.product_name").value!="PRUSignature GrowthPlus")//Added condition for product PRUcancer X on 4 June 18 by ankita
            {
                $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                var option = $(escape_jq("al_sqs_details.payment_frequency"));
                $.each( msJsonPaymentFrequency, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                $(escape_jq("al_sqs_details.payment_mode")).empty();//Clear Payment Frequency dropdown.
                var option = $(escape_jq("al_sqs_details.payment_mode"));
                $.each( msJsonPaymentMode, function( key, value )
                       {
                            option.append($("<option />").val(key).text(value));
                       });
                
                   if(channelTypeForAgencyBancaRepls=="banca")
                  {
                      $(escape_jq("al_sqs_details.payment_mode")).empty();
                       $.each( msJsonBancaPaymentMode, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                      
                  }
            $(escape_jq("al_sqs_details.payment_mode")).val("Payment Method");
            $(escape_jq("al_sqs_details.payment_mode")).prop("disabled", false);
            document.getElementById("al_sqs_details.payment_frequency").disabled=false;
            if(document.getElementById("al_sqs_details.payment_backdate_yes").checked)
            {
                document.getElementById('al_sqs_details.Inception_dt_img').style.pointerEvents='auto';
            }
            if(document.getElementById("al_sqs_details.payment_backdate_no").checked)
            {
                document.getElementById('al_sqs_details.Inception_dt_img').style.pointerEvents='none';
            }
            if(obj_prochoice["al_sqs_details.payment_mode"]!="undefined" && obj_prochoice["al_sqs_details.payment_mode"]!=undefined && obj_prochoice["al_sqs_details.payment_frequency"] != "SP")
            {
                document.getElementById("al_sqs_details.payment_mode").value=obj_prochoice["al_sqs_details.payment_mode"];
            }
            if(obj_prochoice["al_sqs_details.payment_frequency"]!="undefined" && obj_prochoice["al_sqs_details.payment_frequency"]!=undefined && obj_prochoice["al_sqs_details.payment_frequency"] != "SP")
            {
                document.getElementById("al_sqs_details.payment_frequency").value=obj_prochoice["al_sqs_details.payment_frequency"];
            }
                if(document.getElementById("al_sqs_details.product_name").value=="PRUlink one" || document.getElementById("al_sqs_details.product_name").value=="PRUlife ready")
                {
                    
                    document.getElementById("fund_choice_block").style.display='none';
                    document.getElementById("fund_list").style.display='block';
                    document.getElementById("total_allocation_block").style.display='block';
                    document.getElementById("asia_local_bond_fund").style.display='block';
                    document.getElementById("asia_property_security_fund").style.display='block';
                     $(".no-italics").css("font-style", "")//condition for PRUwith you.
                    
                }
                if(document.getElementById("al_sqs_details.product_name").value=="PRUwith you" || document.getElementById("al_sqs_details.product_name").value=="PRUWealth Plus" || document.getElementById("al_sqs_details.product_name").value=="PRUWealth Max" || document.getElementById("al_sqs_details.product_name").value=="PRUWealth Enrich")
                {
                    console.log("PRUwith normal");
                    document.getElementById("fund_choice_block").style.display='none';
                    document.getElementById("fund_list").style.display='block';
                    document.getElementById("total_allocation_block").style.display='block';
                    document.getElementById("asia_local_bond_fund").style.display='block';
                    //document.getElementById("asia_property_security_fund").style.display='block';
                    document.getElementById("asia_property_security_fund").style.display='none'; // Added by Shivani for POPRT - 2873 for Mar2022
                     document.getElementById("global_strategic_fund").style.display='block';
                     document.getElementById("local_global_funds").style.display='block';
                    document.getElementById("us_equity_fund").style.display='none';
                    document.getElementById("global_leaders_fund").style.display='none';
                    document.getElementById("euro_equity_fund").style.display='none';
                    document.getElementById("strategic_managed_fund").style.display='none';
                    strategic_managed_fund
                    document.getElementById("bond_fund_PF").style.display='block';
                    document.getElementById("dana_aman").style.display='block';
                    document.getElementById("dana_urus2").style.display='block';
                    document.getElementById("dana_unggul").style.display='block';
                    document.getElementById("asia_managed_fund").style.display='block';
                    document.getElementById("global_market_naviga").style.display='block';
                    
                    $(".no-italics").css("font-style", "normal");
                  //  $(".no-italics").css("font-style":"normal");
                   //   $("#fund_list").addClass("no-italics");
//                    var my_css_class = { "font-style" : 'normal' };
//                    $("#fund_list").css(my_css_class);
                    
                    
                }
                
                if(document.getElementById("al_sqs_details.product_name").value=="PRUmy child")
                {
                    
                    document.getElementById("fund_choice_block").style.display='block';
                    document.getElementById("fund_list").style.display='block';
                    document.getElementById("asia_local_bond_fund").style.display='block';
                    document.getElementById("asia_property_security_fund").style.display='block';
                     $(".no-italics").css("font-style", "")//condition for PRUwith you.
                }
                
        }
            if(document.getElementById("al_sqs_details.product_name").value=="PRUlink one" || document.getElementById("al_sqs_details.product_name").value=="PRUlife ready")
            {
              
                document.getElementById("fund_choice_block").style.display='none';
                document.getElementById("fund_list").style.display='block';
                document.getElementById("global_funds").style.display="block";
                document.getElementById("local_fund_lable").innerHTML="PRULINK FUND";
                document.getElementById("total_allocation_block").style.display='block';
                document.getElementById("asia_local_bond_fund").style.display='block';
                document.getElementById("asia_property_security_fund").style.display='block';
                 $(".no-italics").css("font-style", "")//condition for PRUwith you.
            }
            if(document.getElementById("al_sqs_details.product_name").value=="PRUwith you" || document.getElementById("al_sqs_details.product_name").value=="PRUWealth Plus" || document.getElementById("al_sqs_details.product_name").value=="PRUWealth Max" || document.getElementById("al_sqs_details.product_name").value=="PRUWealth Enrich")
            {
                
                if(document.getElementById("al_sqs_details.product_name").value=="PRUwith you" || document.getElementById("al_sqs_details.product_name").value=="PRUWealth Plus" || document.getElementById("al_sqs_details.product_name").value=="PRUWealth Max" || document.getElementById("al_sqs_details.product_name").value=="PRUWealth Enrich")
                {
                    $("#local_equity_fund").css("display", "none");
                }
                document.getElementById("fund_choice_block").style.display='none';
                document.getElementById("fund_list").style.display='block';
                document.getElementById("global_funds").style.display="block";
                document.getElementById("local_fund_lable").innerHTML="PRULINK FUND";
                document.getElementById("total_allocation_block").style.display='block';
                document.getElementById("asia_local_bond_fund").style.display='block';
                //document.getElementById("asia_property_security_fund").style.display='block';
                document.getElementById("asia_property_security_fund").style.display='none'; // Added by Shivani for POPRT - 2873 for Mar2022
                
                
            }
            
            
            
            
                 if(document.getElementById("al_sqs_details.product_name").value=="PRUcancer plan")
                {
                    
                    document.getElementById("al_sqs_details.payment_backdate_yes").disabled=false;
                    document.getElementById("al_sqs_details.payment_backdate_no").disabled=false;
                
                    if(document.getElementById("al_sqs_details.payment_backdate_yes").checked)
                    {
                        document.getElementById('al_sqs_details.Inception_dt_img').style.pointerEvents='auto';
                    }
                    if(document.getElementById("al_sqs_details.payment_backdate_no").checked)
                    {
                        document.getElementById('al_sqs_details.Inception_dt_img').style.pointerEvents='no';
                    }
                }
                else if(document.getElementById("al_sqs_details.product_name").value=="PRUterm")
                {
                    document.getElementById("al_sqs_details.payment_backdate_yes").disabled=false;
                    document.getElementById("al_sqs_details.payment_backdate_no").disabled=false;
                    if(document.getElementById("al_sqs_details.payment_backdate_yes").checked)
                    {
                        document.getElementById('al_sqs_details.Inception_dt_img').style.pointerEvents='auto';
                    }
                    if(document.getElementById("al_sqs_details.payment_backdate_no").checked)
                    {
                        document.getElementById('al_sqs_details.Inception_dt_img').style.pointerEvents='no';
                    }

                }
                else if(document.getElementById("al_sqs_details.product_name").value=="PRUcash")
                {
                    document.getElementById("al_sqs_details.payment_backdate_yes").disabled=false;
                    document.getElementById("al_sqs_details.payment_backdate_no").disabled=false;
                    if(document.getElementById("al_sqs_details.payment_backdate_yes").checked)
                    {
                        document.getElementById('al_sqs_details.Inception_dt_img').style.pointerEvents='auto';
                    }
                    if(document.getElementById("al_sqs_details.payment_backdate_no").checked)
                    {
                        document.getElementById('al_sqs_details.Inception_dt_img').style.pointerEvents='no';
                    }
                    
                }
                else if(document.getElementById("al_sqs_details.product_name").value=="PRUcash premier")
                {
                    document.getElementById("al_sqs_details.payment_backdate_yes").disabled=false;
                    document.getElementById("al_sqs_details.payment_backdate_no").disabled=false;
                    if(document.getElementById("al_sqs_details.payment_backdate_yes").checked)
                    {
                        document.getElementById('al_sqs_details.Inception_dt_img').style.pointerEvents='auto';
                    }
                    if(document.getElementById("al_sqs_details.payment_backdate_no").checked)
                    {
                        document.getElementById('al_sqs_details.Inception_dt_img').style.pointerEvents='no';
                    }
                    
                }
                else if(document.getElementById("al_sqs_details.product_name").value=="PRUmultiple crisis cover")
                {
                    document.getElementById("al_sqs_details.payment_backdate_yes").disabled=false;
                    document.getElementById("al_sqs_details.payment_backdate_no").disabled=false;
                    if(document.getElementById("al_sqs_details.payment_backdate_yes").checked)
                    {
                        document.getElementById('al_sqs_details.Inception_dt_img').style.pointerEvents='auto';
                    }
                    if(document.getElementById("al_sqs_details.payment_backdate_no").checked)
                    {
                        document.getElementById('al_sqs_details.Inception_dt_img').style.pointerEvents='no';
                    }
                    
                }
                else if(document.getElementById("al_sqs_details.product_name").value=="PRUlink million")
                {
                    document.getElementById("fund_list").style.display='none';
                    document.getElementById("total_allocation_block").style.display='none';
                }else if(document.getElementById("al_sqs_details.product_name").value=="PRUwealth")
                {
                  //  $("#fund_list").removeClass("no-italics");
                    document.getElementById("local_funds").style.display="block";
                    document.getElementById("global_funds").style.display="block";
                    $("#fund_list").css("display", "block");
                    $("#total_allocation_block").css("display", "block");
                    $("#local_equity_fund").css("display", "none");
                    $("#asia_local_bond_fund").css("display", "block");
                    $("#asia_property_security_fund").css("display", "block");
                    $(".no-italics").css("font-style", ""); //condition for PRUwith you.
                    
                    
                   
                   
                    
                    $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                    var option = $(escape_jq("al_sqs_details.payment_frequency"));
                    $.each( msJsonPaymentFrequency, function( key, value )
                           {
                           option.append($("<option />").val(key).text(value));
                           });
                    $(escape_jq("al_sqs_details.payment_mode")).empty();//Clear Payment Frequency dropdown.
                    var option = $(escape_jq("al_sqs_details.payment_mode"));
                    $.each( msJsonPaymentMode, function( key, value )
                           {
                           option.append($("<option />").val(key).text(value));
                           });
                    
                    
                       if(channelTypeForAgencyBancaRepls=="banca")
                      {
                          $(escape_jq("al_sqs_details.payment_mode")).empty();
                         $.each( msJsonBancaPaymentMode, function( key, value )
                           {
                           option.append($("<option />").val(key).text(value));
                           });
                        
                      }
                    $(escape_jq("al_sqs_details.payment_mode")).val("Payment Method");
                    $(escape_jq("al_sqs_details.payment_mode")).prop("disabled", false);
                    document.getElementById("al_sqs_details.payment_frequency").disabled=false;
                    if(callfrom!="change")
                    {
                        if(obj_prochoice["al_sqs_details.payment_frequency"]!=undefined)
                        {
                            document.getElementById("al_sqs_details.payment_frequency").value=obj_prochoice["al_sqs_details.payment_frequency"];
                        }
                        if(obj_prochoice["al_sqs_details.payment_mode"]!=undefined)
                        {
                            document.getElementById("al_sqs_details.payment_mode").value=obj_prochoice["al_sqs_details.payment_mode"];
                        }
                    }
                }
                else if(document.getElementById("al_sqs_details.product_name").value==="PRUElite Invest" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature GrowthPlus")//Added by Pradnya for Apr23  release
                {
                    
                    
                    
                    console.log("check funds 3333");
                    //$(".tohide_PLG").css("display", "block"); // for def- 10962
                    document.getElementById("al_sqs_details.strategic_managed_fund").disabled=false;
                    document.getElementById("fund_choice_block").style.display='none';
                    document.getElementById("global_funds").style.display="block";
                    document.getElementById("newGlobalFund").style.display="block";
                    document.getElementById("local_global_funds").style.display="block";
                    
                    
                    document.getElementById("fund_list").style.display='block';
                    document.getElementById("strategic_managed_fund").style.display='block';
                    document.getElementById("total_allocation_block").style.display='block';
                    document.getElementById("dana_aman").style.display="none";
                    document.getElementById("dana_urus2").style.display="none";
                    document.getElementById("dana_unggul").style.display="none";
                    document.getElementById("asia_property_security_fund").style.display="none";
                    document.getElementById("local_equity_fund").style.display='none';
                    document.getElementById("asia_local_bond_fund").style.display='none';
                    
                    document.getElementById("asian_high_yield_bond_fund").style.display="none";
                    document.getElementById("japan_dynamic_fund").style.display="none";
                    document.getElementById("asia_managed_fund").style.display="none";
                    document.getElementById("global_market_naviga").style.display="none";
                    document.getElementById("bond_fund_PF").style.display="none";
                    document.getElementById("multi_asset_fund").style.display="none";
                    
                    document.getElementById("dragon_peacock").style.display="block";
                    document.getElementById("asia_equity_fund").style.display="block";
                    document.getElementById("euro_equity_fund").style.display="block";
                    document.getElementById("equity_plus_fund").style.display="block";
                    document.getElementById("managed_plus_fund").style.display="block";
                    document.getElementById("global_leaders_fund").style.display='block';
                    document.getElementById("us_equity_fund").style.display='block';
                   
                                      
                                      
                    if(document.getElementById("al_sqs_details.product_name").value==="PRUElite Invest"){
                    document.getElementById("sustainable_equity_fund").style.display='block';//new july 2023 fund CR SEF & ADI Funds added by sachin on 9-6-2023..
                    
                    }
                    
                    $(".no-italics").css("font-style", "normal");
                    
                    $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                    var option = $(escape_jq("al_sqs_details.payment_frequency"));
                    $.each( msJsonPaymentFrequency, function( key, value )
                           {
                           option.append($("<option />").val(key).text(value));
                           });
                   $(escape_jq("al_sqs_details.payment_mode")).empty();
                  var option = $(escape_jq("al_sqs_details.payment_mode"));
                                      
                  
                                      $.each( msJsonPaymentMode, function( key, value )
                                                             {
                                                             option.append($("<option />").val(key).text(value));
                                                             });

                                       $(escape_jq("al_sqs_details.payment_mode")).val("Payment Method");
                                       $(escape_jq("al_sqs_details.payment_mode")).prop("disabled", false);
                                            document.getElementById("al_sqs_details.payment_frequency").disabled=false;

                                      if(callfrom!="change")
                                                      {
                                                          if(obj_prochoice["al_sqs_details.payment_frequency"]!=undefined)
                                                          {
                                                              document.getElementById("al_sqs_details.payment_frequency").value=obj_prochoice["al_sqs_details.payment_frequency"];
                                                          }
                                                          if(obj_prochoice["al_sqs_details.payment_mode"]!=undefined)
                                                          {
                                                              document.getElementById("al_sqs_details.payment_mode").value=obj_prochoice["al_sqs_details.payment_mode"];
                                                          }
                                                      }
                                      
                                      
                 
                    
                    
                }
                else if(document.getElementById("al_sqs_details.product_name").value=="PRUlady")//Added By Rahul on 25.09.2015 for PRUlady
                {
                    document.getElementById("al_sqs_details.payment_backdate_yes").disabled=false;
                    document.getElementById("al_sqs_details.payment_backdate_no").disabled=false;
                    if(document.getElementById("al_sqs_details.payment_backdate_yes").checked)
                    {
                        document.getElementById('al_sqs_details.Inception_dt_img').style.pointerEvents='auto';
                    }
                    if(document.getElementById("al_sqs_details.payment_backdate_no").checked)
                    {
                        document.getElementById('al_sqs_details.Inception_dt_img').style.pointerEvents='no';
                    }
                    
                }
                else if(document.getElementById("al_sqs_details.product_name").value=="PRUmy child")
                {
                    document.getElementById("fund_choice_block").style.display='block';
                    document.getElementById("fund_list").style.display='block';
                    document.getElementById("global_funds").style.display="block";
                    document.getElementById("local_fund_lable").innerHTML="PRULINK FUND";
                    document.getElementById("total_allocation_block").style.display='block';
                    document.getElementById("al_sqs_details.fund_choice1").checked=true;
                    document.getElementById("asia_local_bond_fund").style.display='block';
                    document.getElementById("asia_property_security_fund").style.display='block';
                     $(".no-italics").css("font-style", "")//condition for PRUwith you.
                    
                    //InceptionDateCal();
                    fnMsFundsValidation();
                }
            else if(document.getElementById("al_sqs_details.product_name").value=="PRUcash double reward")
            {
                document.getElementById("al_sqs_details.payment_backdate_yes").disabled=false;
                document.getElementById("al_sqs_details.payment_backdate_no").disabled=false;
                if(document.getElementById("al_sqs_details.payment_backdate_yes").checked)
                {
                    document.getElementById('al_sqs_details.Inception_dt_img').style.pointerEvents='auto';
                }
                if(document.getElementById("al_sqs_details.payment_backdate_no").checked)
                {
                    document.getElementById('al_sqs_details.Inception_dt_img').style.pointerEvents='no';
                }
            }
            else if(document.getElementById("al_sqs_details.product_name").value=="PRUlink investor account")//Added by Rahul on date 28 Jan 16
            {
                document.getElementById("fund_list").style.display='block';
                document.getElementById("total_allocation_block").style.display='block';
                $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                 $(".no-italics").css("font-style", "")//condition for PRUwith you.
                var option = $(escape_jq("al_sqs_details.payment_frequency"));
                option.append($("<option />").val("SP").text("Single Premium"));
                
                $(escape_jq("al_sqs_details.payment_mode")).val("Cash/Cheque");
                $(escape_jq("al_sqs_details.payment_mode")).prop("disabled", true);
                document.getElementById("al_sqs_details.payment_frequency").disabled=true;
                document.getElementById("asia_local_bond_fund").style.display='none';
                document.getElementById("asia_property_security_fund").style.display='none';
                //                document.getElementById("al_sqs_details.payment_backdate_no").checked=true;
                //                document.getElementById("al_sqs_details.payment_backdate_yes").checked=false;
                document.getElementById("local_funds").style.display="block";
                document.getElementById("global_funds").style.display="none";
                document.getElementById("local_fund_lable").innerHTML="FUND NAME";
                
                // InceptionDateCal();
            }
            else if(document.getElementById("al_sqs_details.product_name").value=="PRULink Investor Account")
            {
                console.log("PRUSignature Invest.0-11->");//fund_list select
                document.getElementById("fund_list").style.display='block';
                document.getElementById("total_allocation_block").style.display='block';
                $(".no-italics").css("font-style", "")//condition for PRUwith you.
                $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                var option = $(escape_jq("al_sqs_details.payment_frequency"));
                option.append($("<option />").val("SP").text("Single Premium"));
                
                $(escape_jq("al_sqs_details.payment_mode")).val("Cash/Cheque");
                $(escape_jq("al_sqs_details.payment_mode")).prop("disabled", true);
                document.getElementById("al_sqs_details.payment_frequency").disabled=true;
                document.getElementById("asia_local_bond_fund").style.display="block";
                //document.getElementById("asia_property_security_fund").style.display="block";
                document.getElementById("asia_property_security_fund").style.display="none"; // Added by Shivani for POPRT - 2873 for Mar2022
                //                document.getElementById("al_sqs_details.payment_backdate_no").checked=true;
                //                document.getElementById("al_sqs_details.payment_backdate_yes").checked=false;
                document.getElementById("local_funds").style.display="block";
                
                
                document.getElementById("global_funds").style.display="block";
                document.getElementById("newGlobalFund").style.display="none";
                document.getElementById("strategic_managed_fund").style.display="none";
                
                document.getElementById("bond_fund_PF").style.display="block";
                document.getElementById("dana_aman").style.display="block";
                document.getElementById("dana_urus2").style.display="block";
                document.getElementById("dana_unggul").style.display="block";
                document.getElementById("asia_managed_fund").style.display="block";
                document.getElementById("global_market_naviga").style.display="block";
                
                
                
                
                
                
                $("#local_equity_fund").css("display", "none");
                document.getElementById("global_strategic_fund").style.display='block';
                document.getElementById("local_global_funds").style.display='block';
                
                // InceptionDateCal();
              
            }
            else if(document.getElementById("al_sqs_details.product_name").value=="PRUretirement growth")
            {
                    $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                    var option = $(escape_jq("al_sqs_details.payment_frequency"));
                    option.append($("<option />").val("SP").text("Single Premium"));
                
                    $(escape_jq("al_sqs_details.payment_mode")).val("Cash/Cheque");
                    $(escape_jq("al_sqs_details.payment_mode")).prop("disabled", true);
                    document.getElementById("al_sqs_details.payment_frequency").disabled=true;
                if(channelTypeForAgencyBancaRepls=="banca")
                {
                    $(escape_jq("al_sqs_details.payment_mode")).val("Bank Transfer");
                }
            }
            else if(document.getElementById("al_sqs_details.product_name").value=="PRUcancer X" || document.getElementById("al_sqs_details.product_name").value=="PRUSenior Med")//Added condition for product PRUcancer X on 4 June 18 by ankita
            {
                //$(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                //var option = $(escape_jq("al_sqs_details.payment_frequency"));
                //option.append($("<option />").val("A").text("Annually"));
                //document.getElementById("al_sqs_details.payment_frequency").disabled=true;
                //commented above code n added below code for CR changes on 12 July 2018 by ankita
                $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
                var option = $(escape_jq("al_sqs_details.payment_frequency"));
                $.each( msJsonPaymentFrequency, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                //end here
                $(escape_jq("al_sqs_details.payment_mode")).empty();//Clear Payment Frequency dropdown.
                              
                var option = $(escape_jq("al_sqs_details.payment_mode"));
                console.log("option"+option);
                $.each( msJsonPaymentMode, function( key, value )
                    {
                    option.append($("<option />").val(key).text(value));
                    });
                
                   if(channelTypeForAgencyBancaRepls=="banca")
                  {
                      $(escape_jq("al_sqs_details.payment_mode")).empty();
                      $.each( msJsonBancaPaymentMode, function( key, value )
                       {
                       option.append($("<option />").val(key).text(value));
                       });
                     
                  }
               
                document.getElementById("al_sqs_details.payment_frequency").disabled=false;
                $(escape_jq("al_sqs_details.payment_mode")).val("Payment Method");
                $(escape_jq("al_sqs_details.payment_mode")).prop("disabled", false);
               
                
                if(document.getElementById("al_sqs_details.payment_backdate_yes").checked)
                {
                    document.getElementById('al_sqs_details.Inception_dt_img').style.pointerEvents='auto';
                }
                if(document.getElementById("al_sqs_details.payment_backdate_no").checked)
                {
                    document.getElementById('al_sqs_details.Inception_dt_img').style.pointerEvents='none';
                }
                if(obj_prochoice["al_sqs_details.payment_mode"]!="undefined" && obj_prochoice["al_sqs_details.payment_mode"]!=undefined && obj_prochoice["al_sqs_details.payment_frequency"] != "SP")
                {
                    document.getElementById("al_sqs_details.payment_mode").value=obj_prochoice["al_sqs_details.payment_mode"];
                }
                if(obj_prochoice["al_sqs_details.payment_frequency"]!="undefined" && obj_prochoice["al_sqs_details.payment_frequency"]!=undefined && obj_prochoice["al_sqs_details.payment_frequency"] != "SP")
                {
                    document.getElementById("al_sqs_details.payment_frequency").value=obj_prochoice["al_sqs_details.payment_frequency"];
                }
 
            
            }
            }
        
        }
        else
        {
            document.getElementById("al_sqs_details.foreign_currency").style.display="none";
            
            $(escape_jq("al_sqs_details.payment_frequency")).empty();//Clear Payment Frequency dropdown.
            var option = $(escape_jq("al_sqs_details.payment_frequency"));
            $.each( msJsonPaymentFrequency, function( key, value )
            {
                option.append($("<option />").val(key).text(value));
            });
            $(escape_jq("al_sqs_details.payment_mode")).empty();//Clear Payment Frequency dropdown.
            var option = $(escape_jq("al_sqs_details.payment_mode"));
            $.each( msJsonPaymentMode, function( key, value )
                   {
                   option.append($("<option />").val(key).text(value));
                   });
            
               if(channelTypeForAgencyBancaRepls=="banca")
              {
                $(escape_jq("al_sqs_details.payment_mode")).empty();
                  $.each( msJsonBancaPaymentMode, function( key, value )
                  {
                  option.append($("<option />").val(key).text(value));
                  });
                 
              }
            //$(escape_jq("al_sqs_details.payment_frequency")).val("Payment Frequency");
        }

    
    if(document.getElementById("al_sqs_details.payment_backdate_no").checked)//Added for defect 7869 on date 9-07-2019
    {
        if(document.getElementById("al_sqs_details.product_name").value!="Select Products")
        {
            document.getElementById('al_sqs_details.Inception_dt_img').style.pointerEvents='none';
           // document.getElementById("al_sqs_details.product_name").value=sproductname;
        
        }
       
    }
    
   /* if(channelTypeForAgencyBancaRepls=="banca")
    {
        console.log("sayali banca")
        var modeOption=$(escape_jq("al_sqs_details.payment_mode"));
        $(".sqsPaymentMode option[value='Bank Transfer']").remove();
        modeOption.append($("<option />").val("Bank Transfer").text("Bank Transfer"));
        $(".sqsPaymentMode option[value='Cash/Cheque']").remove();
     
    }*/
   // al_sqs_details.payment_frequency
    //al_sqs_details.payment_mode
    //al_sqs_details.bond_fund
   
    //TODO on date 26-08-2022
    
//    if(buttonPlansResonse["al_sqs_buttons_plan"]=="al_sqs_buttons.prufirst" && (obj_prochoice!="" && obj_prochoice["al_sqs_details.payment_frequency"]=="Payment Frequency")){
//
//        document.getElementById("al_sqs_details.payment_frequency").options[4].selected = true
//        document.getElementById("al_sqs_details.payment_mode").options[1].selected=true;
//        document.getElementById("al_sqs_details.bond_fund").value="100";
//         document.getElementById("al_sqs_details.bond_fund").onchange();
//    }
    
    
    
    for(var i=0;i<prodnames.length;i++)
    {
        console.log("prodnames[i] In ShowFunds function:"+prodnames[i]);
        if(prodnames[i]==document.getElementById("al_sqs_details.product_name").value)
        {
            if(prodnames[i]!="PRUaspire")
            {
                console.log("Expiry Age:"+expiryages[i]);
                basic_expiry_age=expiryages[i];
                console.log("basic_expiry_age:"+basic_expiry_age);
            }
        }
    }
    
});
                                      }

//Get natal status
function getFundchoiceOne()
{
	var fund_choiceone;
	
	if(document.getElementById("al_sqs_details.fund_choice1").checked)
	{
		fund_choiceone = "Yes";
	}else
	{
		fund_choiceone = "No";
	}
	
	return fund_choiceone;
}

//Get natal status
function getFundchoiceTwo()
{
	var fund_choicetwo;
	
	if(document.getElementById("al_sqs_details.fund_choice2").checked)
	{
		fund_choicetwo = "Yes";
	}else
	{
		fund_choicetwo = "No";
	}
	
	return fund_choicetwo;
}
	
function validateProdChoiceScreen(obj_mlife)
{
   
        if(document.getElementById("al_sqs_details.product_name").value == "Select Products")
        {
            alert("270");
            return false;
        }
        
        if(document.getElementById("al_sqs_details.payment_frequency").value == "Payment Frequency")
        {
            alert("212");
            return false;
        }
        
        if(document.getElementById("al_sqs_details.payment_mode").value == "Payment Method")
        {
            alert("213");	
            return false;
        }
        if(document.getElementById("al_sqs_details.foreign_currency").value == "Select Currency" &&  document.getElementById("al_sqs_details.product_name").value == "PRUGlobal Series")
        {
            alert("572");
            return false;
        }
        /*Prashant
        #20/12/2016
            Very Imp : If you remove or add any product in following condition, please do same for condition written in "fnMsvalidateProdChoiceScreenforRedMark()" function.  */
        // PRUsignature added in below if condtion changes made by Pramod Chavan on 10022017
    //Added condition for PRULink Cover by ankita on 22 March 2019
            if(document.getElementById("al_sqs_details.product_name").value == "PRUlink one"
               || document.getElementById("al_sqs_details.product_name").value == "PRUwith you"
               || document.getElementById("al_sqs_details.product_name").value == "PRULink Cover"
               || document.getElementById("al_sqs_details.product_name").value == "PRUlife ready"
               || ((document.getElementById("al_sqs_details.product_name").value == "PRUmy child"
               || document.getElementById("al_sqs_details.product_name").value=="PRUmy kid")
               && document.getElementById("al_sqs_details.fund_choice1").checked == true)
               || document.getElementById("al_sqs_details.product_name").value == "LifeLink"
               || document.getElementById("al_sqs_details.product_name").value == "InvestLink"
               || document.getElementById("al_sqs_details.product_name").value == "InvestLink Global"
               || document.getElementById("al_sqs_details.product_name").value == "PRUlink investor account"
               || document.getElementById("al_sqs_details.product_name").value == "PRUsignature"
               || document.getElementById("al_sqs_details.product_name").value == "PRUwealth"
               || document.getElementById("al_sqs_details.product_name").value == "PRUsignature USD"
               || document.getElementById("al_sqs_details.product_name").value == "PRUsignature infinite"
               || document.getElementById("al_sqs_details.product_name").value == "PRUmillion cover"
               || document.getElementById("al_sqs_details.product_name").value == "PRUsmart gain"
               || document.getElementById("al_sqs_details.product_name").value == "PRUsignature income"
               || document.getElementById("al_sqs_details.product_name").value == "PRUMy Gift"
               || document.getElementById("al_sqs_details.product_name").value == "PRUsignature prime"
               || document.getElementById("al_sqs_details.product_name").value == "PRUSignature Invest"
               || document.getElementById("al_sqs_details.product_name").value == "PRULink Investor Account"

               || document.getElementById("al_sqs_details.product_name").value == "PRUGlobal Series" || document.getElementById("al_sqs_details.product_name").value == "PRUWealth Plus" /*|| document.getElementById("al_sqs_details.product_name").value == "PRUmy treasure"*/ || document.getElementById("al_sqs_details.product_name").value == "PRUWealth Max"  || document.getElementById("al_sqs_details.product_name").value == "PRUMax Cover" || document.getElementById("al_sqs_details.product_name").value == "PRUMillion Cover 2.0" || document.getElementById("al_sqs_details.product_name").value === "PRUMulti Crisis Guard" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Assure" /*|| document.getElementById("al_sqs_details.product_name").value === "PRUmy treasure"*/ || document.getElementById("al_sqs_details.product_name").value === "PRULink Supreme" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature Vanguard" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature Ace" || document.getElementById("al_sqs_details.product_name").value==="PRUElite Invest" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature GrowthPlus" || document.getElementById("al_sqs_details.product_name").value == "PRUEnhanced Cover" || document.getElementById("al_sqs_details.product_name").value == "PRUWealth Enrich" || document.getElementById("al_sqs_details.product_name").value === "PRULink Supreme Plus" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Plus")//New product "PRUsmart gain" Added by Sachin Tupe on 29-05-2018//Added condition for PRUsignature income by ankita on 7 July 2018 //Sourabh added PRUSignature Invest on 15 jan 2019 // Added condition for PRUMulti Crisis Guard by Shivani // removed condition of PRUMy Treasure PEF fund by Shivani on 24th June 2021 // Added condition of PRUMY treasure for PEF Fund by Shivani on 8th nov 2021

        {
			// PRUwealth added in above if condtion for total allocation fund value validate changes made by Pramod Chavan on 15032017
            
            if(document.getElementById("al_sqs_details.product_name").value == "PRUGlobal Series" && isCurrencyExpired=="Yes"){
                alert("You can not proceed further, please contact admin");
                return false;
            }
            else{
                if(document.getElementById("total_allocation_value").innerHTML!="100" &&  (document.getElementById("al_sqs_details.product_name").value != "PRUsignature income" && document.getElementById("al_sqs_details.product_name").value !== "PRUMulti Crisis Guard" && document.getElementById("al_sqs_details.product_name").value != "PRUMy Gift" && document.getElementById("al_sqs_details.product_name").value != "PRUMy Gift")) // Added condition for PRUMulti Crisis Guard by Shivani // removed condition of PEF fund by Shivani on 24th June 2021 // Added condtion of prumy treasure for PEF fund by Shivani on 8th NOv 2021
                {
                    
                    alert("214");
                    return false;
                    
                }
                else if((document.getElementById("total_allocation_value").innerHTML!="100" && (document.getElementById("al_sqs_details.product_name").value == "PRUsignature income" || document.getElementById("al_sqs_details.product_name").value == "PRUMy Gift" || document.getElementById("al_sqs_details.product_name").value === "PRUMulti Crisis Guard")) && uiaFundSelectionFlag)//Added for CR>income by Sachin // Added condition for PRUMulti Crisis Guard by Shivani
                {
                
                    alert("214");
                    return false;
                
                }
            
            
            }
          
        }
    
    if(document.getElementById("al_sqs_details.Inception_dt").value == "")
    {
        alert("276");
        return false;
    }
    
    if(obj_mlife["al_person_details.mlife.anb"] < 17 && obj_mlife["al_sqs_details.sec_parti_flag"] == "No")
    {
        if(!(obj_mlife["al_person_details.mlife.parent_consent"] == "Yes"))
        {
            alert("275");
            return false;
            menuController.loadPage("top_mysolutions_maindetails",0);
        }
    }
    if((obj_mlife["al_person_details.mlife.anb"] < 17 && obj_mlife["client_ylp_type_mlife"]!="lo") && (obj_mlife["client_ylp_type_mlife"]!="" && obj_mlife["client_ylp_type_mlife"]!=undefined && obj_mlife["client_ylp_type_mlife"]!='undefined' && obj_mlife["client_ylp_type_mlife"]!=null && obj_mlife["client_ylp_type_mlife"]!='null' && obj_mlife["client_ylp_type_mlife"]!="null" && obj_mlife["client_ylp_type_mlife"]!="(null)")) //Added null,undef condition for defect 6044 by sachin on date 28-09-2018.
    {
        alert("716");
        return false;
    }
    // PRUsignature prodcut added in below if condition changes made by Pramod Chavan on 10022017
    // In below if condition PRUwealth product added by Pramod Chavan on 15032017 beacuase This product is not allow for backdate.
    //Added condition for PRULink Cover by ankita on 22 March 2019
    if((document.getElementById("al_sqs_details.product_name").value == "PRUlink one"
        || document.getElementById("al_sqs_details.product_name").value == "PRUwith you"
        || document.getElementById("al_sqs_details.product_name").value == "PRULink Cover"
        || document.getElementById("al_sqs_details.product_name").value == "PRUlife ready"
        || document.getElementById("al_sqs_details.product_name").value == "PRUmy child"
        || document.getElementById("al_sqs_details.product_name").value == "PRUmy kid"
        ||document.getElementById("al_sqs_details.product_name").value == "LifeLink"
        || document.getElementById("al_sqs_details.product_name").value == "PRUlink million"
        || document.getElementById("al_sqs_details.product_name").value == "PRUmy legacy"
        || document.getElementById("al_sqs_details.product_name").value == "PRUmy gift"
        || document.getElementById("al_sqs_details.product_name").value == "RetireGuard (SP)"
        || document.getElementById("al_sqs_details.product_name").value == "InvestLink"
        || document.getElementById("al_sqs_details.product_name").value == "InvestLink Global"
        || document.getElementById("al_sqs_details.product_name").value == "PRUheritage"
        || document.getElementById("al_sqs_details.product_name").value == "PRUlink investor account"
        || document.getElementById("al_sqs_details.product_name").value == "PRUretirement growth"
        || document.getElementById("al_sqs_details.product_name").value == "PRUlife partner"
        || document.getElementById("al_sqs_details.product_name").value == "PRUsignature"
        || document.getElementById("al_sqs_details.product_name").value == "PRUwealth"
        || document.getElementById("al_sqs_details.product_name").value == "PRUsignature USD"
        || document.getElementById("al_sqs_details.product_name").value == "PRUsignature infinite"
        || document.getElementById("al_sqs_details.product_name").value == "PRUmillion cover"
	    || document.getElementById("al_sqs_details.product_name").value == "PRUsmart gain"
        || document.getElementById("al_sqs_details.product_name").value == "PRUmy treasure"
        || document.getElementById("al_sqs_details.product_name").value == "PRUsignature income"
        || document.getElementById("al_sqs_details.product_name").value == "PRUMy Gift"
        || document.getElementById("al_sqs_details.product_name").value == "PRUsignature prime"
        || document.getElementById("al_sqs_details.product_name").value == "PRUSignature Invest"
        || document.getElementById("al_sqs_details.product_name").value == "PRULink Investor Account"
        || document.getElementById("al_sqs_details.product_name").value == "PRUGlobal Series" || document.getElementById("al_sqs_details.product_name").value == "PRUWealth Plus" || document.getElementById("al_sqs_details.product_name").value == "PRUWealth Max" ||  document.getElementById("al_sqs_details.product_name").value == "PRUMax Cover" ||  document.getElementById("al_sqs_details.product_name").value == "PRUMillion Cover 2.0" || document.getElementById("al_sqs_details.product_name").value === "PRUMulti Crisis Guard" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Assure" || document.getElementById("al_sqs_details.product_name").value=="PRULink Growth" || document.getElementById("al_sqs_details.product_name").value === "PRULink Supreme" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature Vanguard" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature Ace" || document.getElementById("al_sqs_details.product_name").value==="PRUElite Invest" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature GrowthPlus"  ||  document.getElementById("al_sqs_details.product_name").value == "PRUEnhanced Cover" || document.getElementById("al_sqs_details.product_name").value == "PRUWealth Enrich" || document.getElementById("al_sqs_details.product_name").value === "PRULink Supreme Plus" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Plus") && document.getElementById("al_sqs_details.payment_backdate_yes").checked)//New product "PRUsmart gain" Added by Sachin Tupe on 29-05-2018//Added condition for PRUsignature income by ankita on 7 July 2018 //Sourabh added PRUSignature Invest on 15 jan 2019 // PRUGlobal Series by sourabh on 1 April 2019 // Added condition for PRUMulti Crisis Guard for by Shivani
    {
        alert("717",document.getElementById("al_sqs_details.product_name").value);
        return false;
    }
    if(!CalValidProduct())
    {
        return false;
    }
    
    if(!fnmsCheckValidateonPremBkDate())
    {
        return false;
    }
    
    
    
    ///////////////////////////
        return true;
}

function fnmsCheckValidateonPremBkDate()
{
    if (obj_mlife["al_person_details.pre_natal_child_flg"] == "Yes")
    {
        if (obj_slife["al_person_details.slife.relationship"] == "Parent" && obj_slife["al_person_details.slife.gender"] == "Female")
        {
            //added channel condition by ankita on 16 dec 2022 for mom and baby care rider of pruwith you
            if (!(obj_slife["al_person_details.slife.anb"] >= 19 && obj_slife["al_person_details.slife.anb"] <= 45) && obj_mlife["pamb_channel"] !== "Agency" && obj_mlife["pamb_channel"] !== "FA") {
                alert("222");
                return false;
            }
            //changed 45 to 46 by ankita to allow mother age to 46 on 16 dec 2022 for mom and baby care rider of pruwith you
            if (!(obj_slife["al_person_details.slife.anb"] >= 19 && obj_slife["al_person_details.slife.anb"] <= 46) && (obj_mlife["pamb_channel"] === "Agency" || obj_mlife["pamb_channel"] === "FA")) {
                alert("870");
                return false;
            }
        } else if (!(obj_slife["al_person_details.slife.relationship"] == "Parent" && obj_slife["al_person_details.slife.gender.gender"] == "Female")) {
            if (!(obj_tlife["al_person_details.tlife.relationship"] == "Parent" && obj_tlife["al_person_details.tlife.gender"] == "Female")) {
                alert("223");
                return false;
            }
        }
    }
         
    if(obj_mlife["al_person_details.mlife.anb"] > 70)
    {
        if(obj_mlife["pamb_channel"] == "Banca" || obj_mlife["pamb_channel"] == "UOB")//changed by Purva / Pramod C on 07th Aug 2017 for UOB
        {
            alert("288");
            return false;
        }
    }

    if (obj_mlife["al_sqs_details.sec_parti_flag"] == "Yes")
    {
         //Modified By Rahul for PRUterm on 16.09.2015
        //Added condition for product PRUcancer X on 4 June 18 by ankita
        //Added condition for il anb by Sachin Tupe on date 14-08-2018.
        if (((obj_mlife["al_person_details.mlife.anb"] > 16 && obj_mlife["al_person_details.mlife.anb"] < 19) && (obj_mlife["al_person_details.mlife.anb_il_product"] > 16 && obj_mlife["al_person_details.mlife.anb_il_product"] < 19) ) && (obj_slife["al_person_details.slife.relationship"] == "Spouse") && (document.getElementById("al_sqs_details.product_name").value != "PRUterm" && document.getElementById("al_sqs_details.product_name").value != "PRUcancer plan" && document.getElementById("al_sqs_details.product_name").value != "PRUlady" && document.getElementById("al_sqs_details.product_name").value != "PRUcash" && document.getElementById("al_sqs_details.product_name").value != "PRUcash premier" && document.getElementById("al_sqs_details.product_name").value != "PRUmultiple crisis cover" && document.getElementById("al_sqs_details.product_name").value != "PRUcash double reward" && document.getElementById("al_sqs_details.product_name").value != "Crisis Cover Plus" && document.getElementById("al_sqs_details.product_name").value != "PRUmortgage" && document.getElementById("al_sqs_details.product_name").value != "PRUterm_scb")&& document.getElementById("al_sqs_details.product_name").value != "PRUwealth gain" && document.getElementById("al_sqs_details.product_name").value != "PRUwealth gain plus" && document.getElementById("al_sqs_details.product_name").value != "PRUaspire" && document.getElementById("al_sqs_details.product_name").value != "PRUgrowth" && document.getElementById("al_sqs_details.product_name").value != "PRUcancer X" && document.getElementById("al_sqs_details.product_name").value != "PRUSignature Optimiser" && document.getElementById("al_sqs_details.product_name").value != "PRUValue Gain" && document.getElementById("al_sqs_details.product_name").value != "PRUSenior Med" && document.getElementById("al_sqs_details.product_name").value != "PRUSignature Reward"  && document.getElementById("al_sqs_details.product_name").value != "PRUSignature Reserve" && document.getElementById("al_sqs_details.product_name").value != "EssentialLife (SP)" && document.getElementById("al_sqs_details.product_name").value != "PRUSignature Protect" && document.getElementById("al_sqs_details.product_name").value != "PRUEasy Protect" && document.getElementById("al_sqs_details.product_name").value !== "PRUCash Enrich" && document.getElementById("al_sqs_details.product_name").value !== "PRUTerm Premier" && document.getElementById("al_sqs_details.product_name").value !== "PRUAll Care" && document.getElementById("al_sqs_details.product_name").value !== "PRUFlexi Gain" && document.getElementById("al_sqs_details.product_name").value !== "PRUSignature Harvest" && document.getElementById("al_sqs_details.product_name").value !== "PRUGain Plus" && document.getElementById("al_sqs_details.product_name").value !== "PRUSignature Treasure" && document.getElementById("al_sqs_details.product_name").value !== "PRUSignature Harvest Plus" && document.getElementById("al_sqs_details.product_name").value !== "PRUEnrich Gain" && document.getElementById("al_sqs_details.product_name").value !== "PRUSignature Boost" && document.getElementById("al_sqs_details.product_name").value !== "PRULady_PRL" && document.getElementById("al_sqs_details.product_name").value !== "PRUMan")//sachin-21-8-2017 new condition added pruwealth gain..//Added condition for optimiser and PRUvalue gain by ankita//Abhilash: EssentialLife (SP)_SCB name changed to PRUSignature Protect on 3rd July//added product PRUCash Enrich by ankita on 25 march 2021//added product PRUsignature treasure by ankita on 20 jan 2022 // Pradnya: added above condition for PRULady_PRL and PRUMan 
        {
           // if(obj_mlife["pamb_channel"] != "Banca")
            {
                console.log("showtoper alert...");
              alert("268");
              return false;
            }
        }

        //Added By Rahul for PRUterm on 16.09.2015
        if ((obj_mlife["al_person_details.mlife.anb"] > 16) && (obj_slife["al_person_details.slife.relationship"] == "Parent") && (document.getElementById("al_sqs_details.product_name").value == "PRUterm" ||document.getElementById("al_sqs_details.product_name").value == "Crisis Cover Plus" || document.getElementById("al_sqs_details.product_name").value == "PRUmortgage" || document.getElementById("al_sqs_details.product_name").value == "PRUterm_scb"))
        {
           // if(obj_mlife["pamb_channel"] != "Banca")
            {
                alert("333");
                return false;
            }
        }
        
   
        if(obj_mlife["al_person_details.mlife.anb"]<=16 && obj_slife["al_person_details.slife.relationship"]=="Spouse")
        {
            alert("278","Spouse","MainLife");
            return false;
        }
    }
    
    return true;
}


function fnMsvalidateProdChoiceScreenforRedMark()
{
    var redmark = 1;
    if(document.getElementById("al_sqs_details.payment_frequency").value == "Payment Frequency")
    {
        arrMySolutionsVisitedFlag[1]=2;
        redmark = arrMySolutionsVisitedFlag[1];
    }
    
    else if(document.getElementById("al_sqs_details.payment_mode").value == "Payment Method")
    {
        arrMySolutionsVisitedFlag[1]=2;
         redmark = arrMySolutionsVisitedFlag[1];
    }
    else if(document.getElementById("al_sqs_details.foreign_currency").value == "Select Currency")
    {
        arrMySolutionsVisitedFlag[1]=2;
        redmark = arrMySolutionsVisitedFlag[1];
    }
    else if(document.getElementById("al_sqs_details.product_name").value == "PRUlink one"
    || document.getElementById("al_sqs_details.product_name").value == "PRUwith you"
    || document.getElementById("al_sqs_details.product_name").value == "PRULink Cover"
    || document.getElementById("al_sqs_details.product_name").value == "PRUlife ready" 
    || ((document.getElementById("al_sqs_details.product_name").value == "PRUmy child" || document.getElementById("al_sqs_details.product_name").value=="PRUmy kid") 
    && document.getElementById("al_sqs_details.fund_choice1").checked == true) 
    || document.getElementById("al_sqs_details.product_name").value == "LifeLink" 
    || document.getElementById("al_sqs_details.product_name").value == "InvestLink" 
    || document.getElementById("al_sqs_details.product_name").value == "InvestLink Global" 
    || document.getElementById("al_sqs_details.product_name").value == "PRUlink investor account"
    || document.getElementById("al_sqs_details.product_name").value == "PRUsignature"
    || document.getElementById("al_sqs_details.product_name").value == "PRUsignature USD"
    || document.getElementById("al_sqs_details.product_name").value == "PRUwealth"
    || document.getElementById("al_sqs_details.product_name").value == "PRUsignature infinite"
    || document.getElementById("al_sqs_details.product_name").value == "PRUmillion cover"
    || document.getElementById("al_sqs_details.product_name").value == "PRUsmart gain"
    || document.getElementById("al_sqs_details.product_name").value == "PRUsignature income"
    || document.getElementById("al_sqs_details.product_name").value == "PRUMy Gift"
    || document.getElementById("al_sqs_details.product_name").value == "PRUsignature prime"
    || document.getElementById("al_sqs_details.product_name").value == "PRUSignature Invest"
    || document.getElementById("al_sqs_details.product_name").value == "PRULink Investor Account"
    || document.getElementById("al_sqs_details.product_name").value == "PRUGlobal Series" || document.getElementById("al_sqs_details.product_name").value == "PRUWealth Plus" || document.getElementById("al_sqs_details.product_name").value == "PRUWealth Max"  || document.getElementById("al_sqs_details.product_name").value == "PRUMax Cover" || document.getElementById("al_sqs_details.product_name").value == "PRUMillion Cover 2.0" || document.getElementById("al_sqs_details.product_name").value === "PRUMulti Crisis Guard" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Assure" || document.getElementById("al_sqs_details.product_name").value === "PRULink Supreme" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature Vanguard" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature Ace" || document.getElementById("al_sqs_details.product_name").value==="PRUElite Invest" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature GrowthPlus" || document.getElementById("al_sqs_details.product_name").value==="PRUEnhanced Cover" || document.getElementById("al_sqs_details.product_name").value == "PRUWealth Enrich" || document.getElementById("al_sqs_details.product_name").value === "PRULink Supreme Plus" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Plus")//New product "PRUsmart gain " Added by Sachin Tupe on 29-05-2018//New product "PRUsmart gain" Added by Sachin Tupe on 29-05-2018//Added condition for PRUsignature income by ankita on 7 July 2018 //Sourabh added PRUSignature Invest and in  April PRUGlobal Series")//N // Added condition for PRUMulti Crisis Guard by Shivani
    {
        if(document.getElementById("total_allocation_value").innerHTML!="100")
        {
            arrMySolutionsVisitedFlag[1]=2;
            redmark = arrMySolutionsVisitedFlag[1];
        }
    }
    else{
        arrMySolutionsVisitedFlag[1]=1;
    }

    return redmark;
}

function fnMsTotValCal(id)
{
    console.log("fund validation-->");
    //var index_counter=0;
    //var uniqueNames = [];
    var totalFund=0;
   
    for(var i=0; i<=lifeLinkFundArray.length-1; i++)
    {
        
        console.log("fund name value"+document.getElementById(lifeLinkFundArray[i]).value);
        if(document.getElementById(lifeLinkFundArray[i]).value!="" && document.getElementById(lifeLinkFundArray[i]).value!="0")
        {
            totalFund=totalFund+eval(document.getElementById(lifeLinkFundArray[i]).value);
            console.log("fund name-->"+lifeLinkFundArray[i]+" fund value-->"+ totalFund);
            fund_location_index.push(i);
            console.log("fund index is-->"+fund_location_index);
            // fund_location_index = $.unique(fund_location_index);
            //console.log("uniq index"+fund_location_index);
            
         
       /*     $.each(fund_location_index, function(i, el){
                   if($.inArray(el, uniqueNames) === -1) uniqueNames.push(el);
                   });
            console.log("unic value is"+uniqueNames);
             index_lenght=uniqueNames.length;
            console.log("len"+index_lenght);*/
            
            
        }
        console.log("condition failed");
    }
    
  /* if(document.getElementById("al_sqs_details.product_name").value=="PRUwith you")//fund validation condtion for PRUwith you
    
   {
       console.log("unq lenghth-->"+index_lenght);
       if(index_lenght==11)
       {
           index_lenght=10;
           
       }
       console.log("TOtal is"+totalFund);
        console.log("in millennium fund validation");
      // var uniqueNamesFilter=[];
       if((totalFund==100 ||totalFund!=100) && index_lenght<=10)
        {
            console.log("total 100 and >10");
           if(index_lenght==10)
           {
               console.log("10 fund");
               console.log("uniNames--->"+uniqueNames);
                console.log("wholeNames--->"+temp_lifeLinkFundArray);
            
               
               
               var diff = $(temp_lifeLinkFundArray).not(uniqueNames).get();
               
               
               for(var i in uniqueNames)
               {
                   
                  
                   console.log("uni name value"+uniqueNames[i]);
                   var j=uniqueNames[i];
                   uniqueNamesFilter.push(temp_lifeLinkFundArray[j]);
               
               
               }
               
               console.log("temp array"+temp_lifeLinkFundArray);
               console.log("filter array"+uniqueNamesFilter);
               
               
               var diff = $(temp_lifeLinkFundArray).not(uniqueNamesFilter).get();
               console.log("different fund is"+diff);
               
               for(var i in diff)
               {
                   console.log("i value is"+i);
                   document.getElementById(diff[i]).disabled=true;
                   
                   
               }
                   fndisableEnable();
               
               
           }
           
           $("#total_allocation_value").html(totalFund);
        }
       else
       {
           console.log("");
           
       }
        
   }*/
    
        
    
    
	//var TotalValue100 = TotalFundValueAdd();
	$("#total_allocation_value").html(totalFund);
    if(document.getElementById("al_sqs_details.product_name").value=="PRUWealth Plus" || document.getElementById("al_sqs_details.product_name").value=="PRUwith you" || document.getElementById("al_sqs_details.product_name").value=="PRUmillion cover" || document.getElementById("al_sqs_details.product_name").value=="PRULink Cover" || document.getElementById("al_sqs_details.product_name").value=="PRUWealth Max" || document.getElementById("al_sqs_details.product_name").value=="PRUMax Cover" || document.getElementById("al_sqs_details.product_name").value=="PRUMillion Cover 2.0" || document.getElementById("al_sqs_details.product_name").value=="PRUSignature Assure" || document.getElementById("al_sqs_details.product_name").value==="PRULink Supreme" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature Vanguard" || document.getElementById("al_sqs_details.product_name").value==="PRUElite Invest" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature GrowthPlus" || document.getElementById("al_sqs_details.product_name").value=="PRUEnhanced Cover" || document.getElementById("al_sqs_details.product_name").value=="PRUWealth Enrich" || document.getElementById("al_sqs_details.product_name").value==="PRULink Supreme Plus")
    {
        ClearDataProd();
    }
}
	
function InceptionDateCal()
{
    var inceptiondate = new Date();
    if(sysdate!=""){
         inceptiondate = new Date(sysdate);
    }else{
         inceptiondate = new Date();
    }
	//var inceptiondate = new Date();
	var dd = inceptiondate.getDate();
	var mm = inceptiondate.getMonth()+1; //January is 0!
    
	var yyyy = inceptiondate.getFullYear();
    
    
	/*if(dd>15) //Commented for defect OS to IL Changes by Sachin T. on date 9-07-2019
	{
		mm = eval(mm)+1 ;
		dd = 1 ;
	}
	else
		dd = 1 ;
    
    
	if(dd<10)
	{
		dd='0'+dd ;
	}
	if(mm > 12)
	{
        mm = 1;
        yyyy =yyyy+1;
    }
	if(mm<10)
	{
		mm='0'+mm ;
	}
    ******/
    
    if((ilMonthlyDecide != "il_daily" && ilMonthlyDecide != "OS") || ANB_json[0]["anb_type"]=="IL_Monthly") //Added for defect 7958
    {
        checkIlMonthly=true;
        
        
        if(incr_value !="0" && incr_value !=0 && incep_value!=""  && incep_value!="0" && incep_value!=0)
        {
            mm = eval(mm)+parseInt(incr_value) ;
            dd = incep_value ;
        }
        else
            dd = 1 ;
        
        
        if(dd<10)
        {
            dd='0'+dd ;
        }
        if(mm > 12)
        {
            mm = 1;
            yyyy =yyyy+1;
        }
        if(mm<10)
        {
            mm='0'+mm ;
        }
        
    }
    
    
    
	inceptiondate = dd+'/'+mm+'/'+yyyy;
	document.getElementById("al_sqs_details.Inception_dt").value = inceptiondate ;
    
    var day_res = inceptiondate.split("/");
}


function fnMsProductopenDatePickerDialog(elId)
{
    isCallFromDatePicker="Yes";
    var pagedata =
    {
        "element_id": elId,
        "element_value":$(escape_jq(elId)).val()
    }
    var OldDateOfBirth = document.getElementById(elId).value;
    var NewDateofBirth = "";
    var day_res="";
    js_call_native_func("OpenDatePicker", pagedata, function(response)
    {
        var obj = JSON.parse(response);
        if (obj["date"] != "")
        {
            var elementName = obj["element_id"];
            
            if(document.getElementById(elementName).value != "")
            {
                if(obj["date"] == document.getElementById(elementName).value)
                {
                    document.getElementById(elementName).value = obj["date"];
                }else
                {
                    document.getElementById(elementName).value = obj["date"];
                }
            }else
            {
                document.getElementById(elementName).value = obj["date"];
            }
             
            var day_res_dob = obj_mlife["al_person_details.mlife.dob"].split("/");
            day_res = document.getElementById(elementName).value.split("/");
            
            //console.log("Date passed in SetANB :: "+"\n"+"Main life date:: "+day_res_dob[0]+"/"+day_res_dob[1]+"/"+  day_res_dob[2]++"\n"+"Inception date object:: "+obj["date"]+"\n"+"Inception date:: "+day_res[0]+"/"+day_res[1]+"/"+day_res[2]+"\n"+"Second life date:: "+day_res[0]+"/"+day_res[1]+"/"+day_res[2]+"\n"+"Third life date:: "+day_res[0]+"/"+day_res[1]+"/"+day_res[2]);
            
             fnMsSetANB("al_sqs_details.Inception_dt", "mlife", day_res_dob[0], day_res_dob[1],  day_res_dob[2], obj["date"], day_res[0], day_res[1], day_res[2]);
        }
    });
}

/*******************************************************
 Function Name: fnMsCalculateANBILProductsInBackdate(persontype)
 Function Description:
 Parameters:
 Created By: Pramod Chavan
 Created On: 12 April 2018
 Modified By:
 Modified On:
 Modification Reason:
 *******************************************************/
function fnMsCalculateANBILProductsInBackdate(dobDay, dobMonth, dobYear, incDay, incMonth, incYear) {
    try {
        
        console.log("dob for IL ANB---->"+dobDay+"---------"+dobMonth+"------"+dobYear);
        console.log("inception date for IL ANB---->"+incDay+"---------"+incMonth+"------"+incYear);
      
//        var incDay = parseInt(currentTime.getDate());
//        var incMonth = parseInt(currentTime.getMonth()); //January is 0!
//        var incYear = parseInt(currentTime.getFullYear());
//        
//        var mydd=dob.split("/");
//        var dobDay=parseInt(mydd[0]);
//        var dobMonth = parseInt(mydd[1]);
//        var dobYear = parseInt(mydd[2]);
        //dobMonth=dobMonth-1;
        
        var ANB=0;
        if(((parseInt(incMonth*31))+parseInt(incDay))==((dobMonth*31)+dobDay)){
            ANB  =incYear-dobYear;
        }else if(((parseInt(incMonth*31))+parseInt(incDay))>((dobMonth*31)+dobDay)){
            ANB  =(incYear-dobYear)+1;
        }else if(((parseInt(incMonth*31))+parseInt(incDay))<((dobMonth*31)+dobDay)){
            ANB  =incYear-dobYear;
        }
         console.log("IL ANB---->"+ANB);
        return ANB;
       
    } catch (e) {
        console.log("Agent Check Error - - >" + e);
        return;
    }
}



function fnMsSetANB(DateValueId, persontype, day, month, year, incpDateValue, incpday, incpmonth, incpyear)
{
    var oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
    var date1;
    var inceptiondate;
    var dd1;
    var mm1;
    var yyyy1;
    
    var ageYears;
    var ageMonths;
    var ageDays;
    var date_sel_invalid = 0;
    var ilANBInBackdate=0;
    
    date1 = new Date(eval(year), eval(month) - 1, eval(day));
    if(sysdate!=""){
        inceptiondate = new Date(sysdate);
    }else{
        inceptiondate = new Date();
    }
    dd1 = incpday;
    mm1 = incpmonth
    yyyy1 = incpyear;
   
    if (eval(date_sel_invalid) == 0) {
        if (DateValueId == "al_sqs_details.Inception_dt") {
            var dobdate = new Date();
            dobdate.setFullYear(date1.getFullYear(), date1.getMonth(), date1.getDate());
            var today = new Date();
            if(sysdate!=""){
                 today = new Date(sysdate);
            }else{
                 today = new Date();
            }
            var diffDate = (today - dobdate) / (1000 * 60 * 60 * 24);
        }
        if (dd1 > 15 && mm1 == 12) {
            yyyy1 = eval(yyyy1) + 1
            mm1 = 1;
            dd1 = 1;
        } else {
            if (dd1 > 15 && mm1 < 12) {
                mm1 = eval(mm1) + 1;
                dd1 = 1;
            } else
                dd1 = 1;
        }
        
        ageYears = yyyy1 - date1.getFullYear();
        ageMonths = mm1 - date1.getMonth() + 1;
        ageDays = dd1 - date1.getDate();
        
        if(ANB_json[0]["anb_type"]=="IL_Monthly") //Added for defect 7958
        {
            
            checkIlMonthly=true;
            
        }
        
        
        
        if (DateValueId == "al_sqs_details.Inception_dt")
        {
            if((eval(incpday) > 1 && (document.getElementById("al_sqs_details.product_name").value != "PRUwealth gain plus" && document.getElementById("al_sqs_details.product_name").value != "PRUgrowth" && document.getElementById("al_sqs_details.product_name").value != "PRUcancer X" && document.getElementById("al_sqs_details.product_name").value != "PRUSignature Optimiser" && document.getElementById("al_sqs_details.product_name").value != "PRUValue Gain" && document.getElementById("al_sqs_details.product_name").value != "PRUSignature Reward" && document.getElementById("al_sqs_details.product_name").value != "PRUEasy Protect" && document.getElementById("al_sqs_details.product_name").value !== "PRUCash Enrich"
                && document.getElementById("al_sqs_details.product_name").value !== "PRUTerm Premier" && document.getElementById("al_sqs_details.product_name").value !== "PRUFlexi Gain" && document.getElementById("al_sqs_details.product_name").value !== "PRUSignature Harvest" && document.getElementById("al_sqs_details.product_name").value !== "PRUGain Plus" && document.getElementById("al_sqs_details.product_name").value !== "PRUSignature Harvest Plus" && document.getElementById("al_sqs_details.product_name").value !== "PRUEnrich Gain" && document.getElementById("al_sqs_details.product_name").value !== "PRUSignature Boost") && (ANB_json[0]["anb_type"]!="IL_Daily" && ANB_json[0]["anb_type"]!="IL_Monthly")))//Added condition for product PRUcancer X on 4 June 18 by ankita//Added condition for optimiser and PRUvalue gain by ankita
            {
                console.log("Inception date should only be first of month.");
                InceptionDateCal();
                alert("296");
                return;
            }
            if(checkIlMonthly && eval(incpday) > 1)
            {
                alert("296");
                document.getElementById("al_sqs_details.Inception_dt").value = inceILdate_monthly;
                return false;
            }
            
            ilANBInBackdate=fnMsCalculateANBILProductsInBackdate(parseInt(day), parseInt(month), parseInt(year), parseInt(incpday), parseInt(incpmonth), parseInt(incpyear));
             console.log("FFind 10");
            
            
            
            if(document.getElementById("al_person_details.pre_natal_child_flg") == "Yes" && persontype == "mlife")
            {
                var calculatedWeek;
                
                //date1 = new Date(eval(year), eval(month), eval(day));
                
                //var systemdate = new Date();
                var dd = dd1;
                var mm = mm1; //January is 0!
                var yyyy = yyyy1;
                
                var date2 = new Date(eval(yyyy), eval(mm), eval(dd));
                
                var diffDays = Math.round(Math.abs((date1.getTime() - date2.getTime()) / (oneDay)))
                var weeks = eval(diffDays) / 7;
                var weekstr = weeks;
                
                console.log("weekstr :: "+weekstr)
                
                weekstr = 40 - weekstr;
                
                if(weekstr >= 17 && weekstr < 35)
                {
                    weekstr = Math.floor(weekstr);
                    calculatedWeek = weekstr
                }else
                {
                    weekstr = Math.ceil(weekstr);
                    calculatedWeek = weekstr
                }
                
                //alert("calculatedWeek :: "+calculatedWeek);
                
                var diffYears = date1.getFullYear() - yyyy;
                var diffMonths = date1.getMonth() - mm;
                var diffDays = date1.getDate() - dd;
                var diffDaysNumber;
                var diffMonthsNumber;
                
                if (diffYears < 0) {
                    alert("217");
                    InceptionDateCal();
                    return;
                }
                
                var months = (diffYears * 12 + diffMonths);
                if (diffDays > -1) {
                    diffMonthsNumber = months;
                    months += '.' + diffDays;
                    diffDaysNumber = diffDays;
                } else if (diffDays <= -1) {
                    months--;
                    diffMonthsNumber = months;
                    months += '.' + (new Date(date1.getFullYear(), date1.getMonth(), 0).getDate() + diffDays);
                    diffDaysNumber = new Date(date1.getFullYear(), date1.getMonth(), 0).getDate() + diffDays;
                }
                
                if (diffMonthsNumber < 0) {
                    alert("218");
                    InceptionDateCal();
                    return;
                } else {
                    if (weekstr >= 18 && weekstr <= 40) {
                        calculatedWeek = weekstr;
                    }
                    /* else if(weekstr < 18){ //this else condition for all product
                        alert("277");
                        InceptionDateCal();
                        return false;
                    }*/
                    else if(weekstr < 18){ //this else condition for PRUwith you and all product.
                        alert("277");
                        InceptionDateCal();
                        return false;
                    }
                    else if(weekstr > 40){
                        alert("218");
                        InceptionDateCal();
                        return false;
                    }
                }
            }else
            {
                //condition modified by Praveen on 06/10/2015
                var monthOfDOB = date1.getMonth() + 1;
                var dayOfDOB = date1.getDate();
                var monthOfInception = mm1;
                var dayOfInception = dd1;
                var calculatedAge;
                var yearOfDOB = date1.getFullYear();
                var yearOfInception = yyyy1;
                
                var DobinDays = (monthOfDOB * 31) + dayOfDOB;
                var InceptioninDays = (monthOfInception * 31) + dayOfInception;
                
                if (DobinDays < InceptioninDays) {
                    calculatedAge = yearOfInception - yearOfDOB + 1;
                } else {
                    calculatedAge = yearOfInception - yearOfDOB;
                }
                if (calculatedAge < 1) {
                    document.getElementById("al_sqs_details.Inception_dt").value = "";
                    alert("274");
                    return false;
                }
                var new_eds = effect_date.split(" ");
                var new_ed = new_eds[0].split("-");
                
                var curr_dt = fnGetDateTimeStamp();
                var curr_dts = curr_dt.split(" ");
                var currnt_dt = curr_dts[0].split("-");
                
                var date1 = new Date(new_ed[0],new_ed[1]-1,new_ed[2]); //year,month,date
                 //month -1 added by praveen on 28.08.2015
                var date2 = new Date(incpyear,incpmonth-1,incpday);
               
                if (currnt_dt[2] > 15 && currnt_dt[1] == 12) {
                    currnt_dt[0] = eval(currnt_dt[0]) + 1
                    currnt_dt[1] = 1;
                    currnt_dt[2] = 1;
                } else {
                    if (currnt_dt[2] > 15 && currnt_dt[1] < 12) {
                        currnt_dt[1] = eval(currnt_dt[1]) + 1;
                        currnt_dt[2] = 1;
                    } else
                        currnt_dt[2] = 1;
                }
                 var date4 = new Date(currnt_dt[0],eval(currnt_dt[1])-1,currnt_dt[2]);//month -1 added by Pratik and Purva on dated 16 August 2015
                var daysDiff21=Math.round((date2.getTime() - date1.getTime())/(oneDay));
                console.log("On date select:: "+"\n"+"Eff Date:: "+new_ed[0]+"-"+new_ed[1]+"-"+new_ed[2]+"\n"+"Incpt Date:: "+incpyear+"-"+incpmonth+"-"+incpday+"\n"+"diffYears:: "+diffYears+"\n"+"months:: "+months);
               
                var diffDaysinc = Math.round((date4.getTime() - date2.getTime())/(oneDay));
                console.log("diffDaysinc"+diffDaysinc);

                /**********Following condition added for defect 5865 by Sachin Tupe.*****/
               
                date4.setMonth(date4.getMonth()-6);
                if(date2<date4)
                {
                    console.log("###Datebackdate_flag1 "+ backdate_flag)
                    backdate_flag=true;
                }else
                {
                backdate_flag=false
                
                }
                
                
                
                /********************End************************************************/

                
                if((document.getElementById("al_sqs_details.product_name").value == "PRUwealth gain plus" || document.getElementById("al_sqs_details.product_name").value == "PRUgrowth" || document.getElementById("al_sqs_details.product_name").value == "PRUcancer X" || document.getElementById("al_sqs_details.product_name").value == "PRUSignature Optimiser" || document.getElementById("al_sqs_details.product_name").value == "PRUValue Gain" || document.getElementById("al_sqs_details.product_name").value == "PRUSenior Med" || document.getElementById("al_sqs_details.product_name").value == "PRUSignature Reward"  || document.getElementById("al_sqs_details.product_name").value == "PRUEasy Protect" || document.getElementById("al_sqs_details.product_name").value === "PRUCash Enrich" || document.getElementById("al_sqs_details.product_name").value === "PRUTerm Premier" || document.getElementById("al_sqs_details.product_name").value === "PRUAll Care" || document.getElementById("al_sqs_details.product_name").value === "PRUFlexi Gain" || document.getElementById("al_sqs_details.product_name").value ==="PRUSignature Harvest" || document.getElementById("al_sqs_details.product_name").value === "PRUGain Plus" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Harvest Plus" || document.getElementById("al_sqs_details.product_name").value === "PRUEnrich Gain" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Boost") || ((ANB_json[0]["anb_type"]=="IL_Monthly" || ANB_json[0]["anb_type"]=="IL_Daily")))//Added condition for product PRUcancer X on 4 June 18 by ankita//Added condition for optimiser and PRUvalue gain by ankita
                {
                    var oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
                    var inceptionDt =document.getElementById("al_sqs_details.Inception_dt").value;
                    inceptionDt=inceptionDt.split("/");
                    var inceDate=inceptionDt[0];
                    var inceMonth=(eval(inceptionDt[1])-1);
                    var inceYear=inceptionDt[2];
                    console.log("inception Date--->"+inceDate+"/"+inceMonth+"/"+inceYear);
                    var systemdate = new Date();
                    if(sysdate!=""){
                         systemdate = new Date(sysdate);
                    }else{
                         systemdate = new Date();
                    }
                    var dd = parseInt(systemdate.getDate());
                    var mm = parseInt(systemdate.getMonth()); //January is 0!
                    var yyyy = parseInt(systemdate.getFullYear());
                     var date2 = new Date(eval(yyyy), eval(mm), eval(dd));
                    if(checkIlMonthly){
                        if(parseInt(dd)>=2 && parseInt(dd)<=31){
                            date2.setMonth(date2.getMonth()+1);
                            date2.setDate(1);
                        }
                    }
                    console.log("current Date--->"+date2);
                   
                    date1 = new Date(eval(inceYear), eval(inceMonth), eval(inceDate));
                  //  date2.setMonth(date2.getMonth()-6)//Added for backdate on 18-07-2018
                    
                    console.log("###Date1 "+ date1)
                    console.log("###Date2 "+ date2)
                    var diffDays = Math.round(((date2.getTime() - date1.getTime()) / (oneDay))) //commented for defect 5865
                    console.log("diffDays"+diffDays);
                    diffDaysinc=diffDays;
                    console.log("diffDaysinc pruwealth gain plus"+diffDaysinc)
                    
                    date2.setMonth(date2.getMonth()-6)//Added for backdate on 18-07-2018
                    if(date1<date2) //Added for backdate on 18-07-2018
                    {
                        console.log("###Datebackdate_flag "+ backdate_flag)
                        backdate_flag=true;
                    }
                    else
                    {
                        
                        backdate_flag=false;
                        
                    }
                    
                    
                    
                    
                 /*   var diffDays = Math.round(((date2.getTime() - date1.getTime()) / (oneDay))) //commented for defect 5865
                    console.log("diffDays"+diffDays);
                    diffDaysinc=diffDays;
                    console.log("diffDaysinc pruwealth gain plus"+diffDaysinc);*/
                    
                    
                    
                }
                
                
                if(document.getElementById("al_sqs_details.payment_backdate_yes").checked)
                {
                    /****Following condition diffdaysinc removed for for defect 5865*/
                    if((diffDaysinc<0 && document.getElementById("al_sqs_details.product_name").value != "PRUwealth gain plus" && document.getElementById("al_sqs_details.product_name").value != "PRUgrowth" && document.getElementById("al_sqs_details.product_name").value != "PRUcancer X" && document.getElementById("al_sqs_details.product_name").value != "PRUSignature Optimiser" && document.getElementById("al_sqs_details.product_name").value != "PRUValue Gain" && document.getElementById("al_sqs_details.product_name").value != "PRUSenior Med" && document.getElementById("al_sqs_details.product_name").value != "PRUSignature Reward" && document.getElementById("al_sqs_details.product_name").value != "PRUEasy Protect" && document.getElementById("al_sqs_details.product_name").value !== "PRUCash Enrich" && document.getElementById("al_sqs_details.product_name").value !== "PRUTerm Premier" && document.getElementById("al_sqs_details.product_name").value !== "PRUAll Care" && document.getElementById("al_sqs_details.product_name").value !== "PRUFlexi Gain" && document.getElementById("al_sqs_details.product_name").value !== "PRUSignature Harvest" && document.getElementById("al_sqs_details.product_name").value !== "PRUGain Plus" && document.getElementById("al_sqs_details.product_name").value !== "PRUSignature Harvest Plus" && document.getElementById("al_sqs_details.product_name").value !== "PRUEnrich Gain" && document.getElementById("al_sqs_details.product_name").value !== "PRUSignature Boost") && (ANB_json[0]["anb_type"]!="IL_Monthly" && ANB_json[0]["anb_type"]!="IL_Daily"))//Added condition for product PRUcancer X on 4 June 18 by ankita//Added condition for optimiser and PRUvalue gain by ankita
                    {
                        alert("330");
                        InceptionDateCal();
                        return false;
                    }
                    if((document.getElementById("al_sqs_details.product_name").value == "PRUwealth gain plus" || document.getElementById("al_sqs_details.product_name").value == "PRUgrowth" || document.getElementById("al_sqs_details.product_name").value == "PRUcancer X" || document.getElementById("al_sqs_details.product_name").value == "PRUSignature Optimiser" || document.getElementById("al_sqs_details.product_name").value == "PRUValue Gain" || document.getElementById("al_sqs_details.product_name").value == "PRUSenior Med" || document.getElementById("al_sqs_details.product_name").value == "PRUSignature Reward" || document.getElementById("al_sqs_details.product_name").value == "PRUEasy Protect" || document.getElementById("al_sqs_details.product_name").value === "PRUCash Enrich" || document.getElementById("al_sqs_details.product_name").value === "PRUTerm Premier"  || document.getElementById("al_sqs_details.product_name").value === "PRUAll Care" || document.getElementById("al_sqs_details.product_name").value === "PRUFlexi Gain" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Harvest" || document.getElementById("al_sqs_details.product_name").value === "PRUGain Plus" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Harvest Plus" || document.getElementById("al_sqs_details.product_name").value === "PRUEnrich Gain" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Boost")  && !checkIlMonthly || ((ANB_json[0]["anb_type"]=="IL_Monthly" || ANB_json[0]["anb_type"]=="IL_Daily")))//Added condition for product PRUcancer X on 4 June 18 by ankita//Added condition for optimiser and PRUvalue gain by ankita
                    {
                      var checkfutureDate=futureDate();
                        if(checkfutureDate==false)
                        {
                            alert("330");
                            //InceptionDateCal();
                            var inceILdate = new Date();
                            if(sysdate!=""){
                                 inceILdate = new Date(sysdate);
                            }else{
                                 inceILdate = new Date();
                            }
                            var dd = inceILdate.getDate();
                            var mm = inceILdate.getMonth()+1; //January is 0!
                            
                            var yyyy = inceILdate.getFullYear();
                            
                            inceILdate = dd+'/'+mm+'/'+yyyy;
                            if(checkIlMonthly)
                            {
                                document.getElementById("al_sqs_details.Inception_dt").value = inceILdate_monthly;
                            }else
                            {
                                document.getElementById("al_sqs_details.Inception_dt").value = inceILdate;
                            }
                            return false;
                        }
                    }else if(checkIlMonthly && diffDaysinc<0)
                        {
                            alert("330");
                         document.getElementById("al_sqs_details.Inception_dt").value = inceILdate_monthly;
                             return false;
                        
                        }
                    else
                    {
                        console.log("OS Selection");
                    
                    }
                    if(backdate_flag) //old condition was !(diffDaysinc<=185) changed by Sachin Tupe for defect 5865.
                    {
                        console.log("backdate_flag==>123=="+backdate_flag);
                        if((document.getElementById("al_sqs_details.product_name").value == "PRUwealth gain plus" || document.getElementById("al_sqs_details.product_name").value == "PRUgrowth" || document.getElementById("al_sqs_details.product_name").value == "PRUcancer X" || document.getElementById("al_sqs_details.product_name").value == "PRUSignature Optimiser" || document.getElementById("al_sqs_details.product_name").value == "PRUValue Gain" || document.getElementById("al_sqs_details.product_name").value == "PRUSenior Med" || document.getElementById("al_sqs_details.product_name").value == "PRUSignature Reward" || document.getElementById("al_sqs_details.product_name").value == "PRUEasy Protect" || document.getElementById("al_sqs_details.product_name").value === "PRUCash Enrich" || document.getElementById("al_sqs_details.product_name").value === "PRUTerm Premier" || document.getElementById("al_sqs_details.product_name").value === "PRUAll Care" || document.getElementById("al_sqs_details.product_name").value === "PRUFlexi Gain" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Harvest" || document.getElementById("al_sqs_details.product_name").value === "PRUGain Plus" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Harvest Plus" || document.getElementById("al_sqs_details.product_name").value === "PRUEnrich Gain" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Boost") || ((ANB_json[0]["anb_type"]=="IL_Monthly" || ANB_json[0]["anb_type"]=="IL_Daily")))//Added condition for product PRUcancer X on 4 June 18 by ankita//Added condition for optimiser and PRUvalue gain by ankita
                        {
                            alert("292");
                            var inceILdate = new Date();
                            if(sysdate!=""){
                                 inceILdate = new Date(sysdate);
                            }else{
                                 inceILdate = new Date();
                            }
                            var dd = inceILdate.getDate();
                            var mm = inceILdate.getMonth()+1; //January is 0!
                            
                            var yyyy = inceILdate.getFullYear();
                            
                            inceILdate = dd+'/'+mm+'/'+yyyy;
                            if(checkIlMonthly)
                            {
                                document.getElementById("al_sqs_details.Inception_dt").value = inceILdate_monthly;
                                return false;

                            }
                            else
                            {
                            document.getElementById("al_sqs_details.Inception_dt").value = inceILdate;
                            return false;
                            }
                        }
                        else
                        {
                        alert("292");
                        InceptionDateCal();
                        return false;
                        }
                    }
                }


                if((document.getElementById("al_sqs_details.product_name").value == "PRUwealth gain plus" || document.getElementById("al_sqs_details.product_name").value == "PRUgrowth" || document.getElementById("al_sqs_details.product_name").value == "PRUcancer X" || document.getElementById("al_sqs_details.product_name").value == "PRUSignature Optimiser" || document.getElementById("al_sqs_details.product_name").value == "PRUValue Gain" || document.getElementById("al_sqs_details.product_name").value == "PRUSenior Med" || document.getElementById("al_sqs_details.product_name").value == "PRUSignature Reward" || document.getElementById("al_sqs_details.product_name").value == "PRUEasy Protect" || document.getElementById("al_sqs_details.product_name").value === "PRUCash Enrich" || document.getElementById("al_sqs_details.product_name").value === "PRUTerm Premier" || document.getElementById("al_sqs_details.product_name").value === "PRUAll Care" || document.getElementById("al_sqs_details.product_name").value === "PRUFlexi Gain" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Harvest" || document.getElementById("al_sqs_details.product_name").value === "PRUGain Plus" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Harvest Plus" || document.getElementById("al_sqs_details.product_name").value === "PRUEnrich" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Boost") && document.getElementById("al_sqs_details.payment_backdate_yes").checked)//Added condition for product PRUcancer X on 4 June 18 by ankita//Added condition for optimiser and PRUvalue gain by ankita

                {
                 ilANBInBackdate=fnMsCalculateANBILProductsInBackdate(parseInt(day), parseInt(month), parseInt(year), parseInt(incpday), parseInt(incpmonth), parseInt(incpyear));
                    console.log("FFind 1");
                }else //if(!(checkIlMonthly))//!(checkIlMonthly)
                {
                    var currentTime = new Date();
                    if(sysdate!=""){
                         currentTime = new Date(sysdate);
                    }
                    else{
                         currentTime = new Date();
                    }
                    var incDayBDC = parseInt(currentTime.getDate());
                    var incMonthBDC = (parseInt(currentTime.getMonth())+1); //January is 0!
                    var incYearBDC = parseInt(currentTime.getFullYear());
                     if(checkIlMonthly)
                     {
                         var obtain_ilmonthly_string= inceILdate_monthly.split("/");
                         incDayBDC=parseInt(obtain_ilmonthly_string[0]);
                         incMonthBDC=parseInt(obtain_ilmonthly_string[1]);
                         incYearBDC=parseInt(obtain_ilmonthly_string[2]);
                         
                         
                     
                     }
                    var Bdate=document.getElementById("al_sqs_details.Inception_dt").value;
                    console.log("BACKDATE DATE"+Bdate);
                    /****************Added for production defect 55112****************/
                    
                    var inceptionDtC =document.getElementById("al_sqs_details.Inception_dt").value;
                    inceptionDtC=inceptionDtC.split("/");
                    incDayBDC=inceptionDtC[0];
                    incMonthBDC=(eval(inceptionDtC[1]));
                    incYearBDC=inceptionDtC[2];
                    console.log("inception Date--->"+incDayBDC+"/"+incMonthBDC+"/"+incYearBDC);
                    
                    
                    /*******************************/
                    
                    ilANBInBackdate=fnMsCalculateANBILProductsInBackdate(parseInt(day), parseInt(month), parseInt(year), incDayBDC, incMonthBDC, incYearBDC);
                 console.log("FFind 2");
                }
               /* if(checkIlMonthly)
                {
                 ilANBInBackdate=fnMsCalculateANBILProductsInBackdate(parseInt(day), parseInt(month), parseInt(year), parseInt(incpday), parseInt(incpmonth), parseInt(incpyear));
                }
               */
                if(persontype == "mlife")
                {
                    if(checkIlMonthly)
                    {
                        if(!isbackdate)
                        {
                        $(escape_jq("al_sqs_details.mlife.il_anb")).val(ilANBInBackdate);
                        }
                        temp_ilMonthly=ilANBInBackdate;
                        setMainLife(calculatedAge, DateValueId, incpDateValue, incpday, incpmonth, incpyear, ilANBInBackdate);
                    }else
                    {
                setMainLife(calculatedAge, DateValueId, incpDateValue, incpday, incpmonth, incpyear, ilANBInBackdate);
                    }
                    
                    
                }
                else if(persontype == "slife")
                {
                    if(checkIlMonthly)
                    {
                       //  $(escape_jq("al_sqs_details.slife.il_anb")).val(ilANBInBackdate);
                     if(!isbackdate)
                     {
                     $(escape_jq("al_sqs_details.slife.il_anb")).val(ilANBInBackdate);
                     
                     }else
                     {
                      $(".setBlankValue").val("");
                     }
                        slife_il_monthly_anb=ilANBInBackdate;
                        setSecondLife(calculatedAge, DateValueId, incpDateValue, incpday, incpmonth, incpyear, ilANBInBackdate);
                    }else
                    {
                    
                    setSecondLife(calculatedAge, DateValueId, incpDateValue, incpday, incpmonth, incpyear, ilANBInBackdate);
                    }
                    
                }else if(persontype == "tlife")
                {
                    if(checkIlMonthly)
                    {
                        if(!isbackdate)
                        {
                            $(escape_jq("al_sqs_details.tlife.il_anb")).val(ilANBInBackdate);
                        }else
                        {
                        $(".setBlankValue").val("");
                        }
                        
                     //
                        tlife_il_monthly_anb=ilANBInBackdate;
                       setThirdLife(calculatedAge, DateValueId, incpDateValue, incpday, incpmonth, incpyear, ilANBInBackdate);
                    }
                    else
                    {
                    setThirdLife(calculatedAge, DateValueId, incpDateValue, incpday, incpmonth, incpyear, ilANBInBackdate);
                    }
                }
            }
        }
    }
}

function setMainLife(calculatedAge_mlife,DateValueId, incpDateValue, incpday, incpmonth, incpyear, ilANBInBackdate)
{
    var anb_changed_by="";
    console.log("In setMainLife 1313-->");
    console.log("setMainLifeincpDateValue1313="+incpDateValue+"--incpday-="+incpday+"-incpmonth-="+incpmonth+"-incpyear-="+incpyear);
    console.log("setMainLifecalculatedAge_mlife--="+calculatedAge_mlife+"-ilANBInBackdate-"+ilANBInBackdate);
     console.log("DateValueId -->"+DateValueId);
    js_get_var("main_life_response", function(mainlife_res)
    {
        if(mainlife_res != "" && mainlife_res != null && mainlife_res != "null"  && mainlife_res != "(null)")
        {
            obj_mlife = JSON.parse(mainlife_res);
            var calculatedAges_mlife;
            
            if(obj_mlife["al_person_details.pre_natal_child_flg"] == "Yes")
            {
                calculatedAges_mlife = "1";
            }else if(obj_mlife["al_person_details.pre_natal_child_flg"] == "No")
            {
                calculatedAges_mlife = calculatedAge_mlife;
            }
            //condition added by Praveen for CR-118(DEF-1832) on 30.08.2016
               if(parseInt(calculatedAge_mlife)!=parseInt(obj_mlife["al_person_details.mlife.anb"]))
               {
                    anb_changed_by="";
               }
            //Variable to take json data
               
              
            /**   if(obj_mlife["al_person_details.mlife.parent_consent"]=="Yes" && ilANBInBackdate<11) //Added for def-->5806
               {
               
               obj_mlife["al_person_details.mlife.parent_consent"]="No";
               
               }else if(obj_mlife["al_person_details.mlife.parent_consent"]=="Yes" && ilANBInBackdate>=11)
               {
               obj_mlife["al_person_details.mlife.parent_consent"]="Yes";
               }******/
               
               if(checkIlMonthly || (document.getElementById("al_sqs_details.product_name").value == "PRUwealth gain plus" || document.getElementById("al_sqs_details.product_name").value == "PRUgrowth" || document.getElementById("al_sqs_details.product_name").value == "PRUcancer X" || document.getElementById("al_sqs_details.product_name").value == "PRUSignature Optimiser" || document.getElementById("al_sqs_details.product_name").value == "PRUValue Gain" || document.getElementById("al_sqs_details.product_name").value == "PRUSenior Med" || document.getElementById("al_sqs_details.product_name").value == "PRUSignature Reward" || document.getElementById("al_sqs_details.product_name").value == "PRUEasy Protect" || document.getElementById("al_sqs_details.product_name").value === "PRUCash Enrich" || document.getElementById("al_sqs_details.product_name").value === "PRUTerm Premier" || document.getElementById("al_sqs_details.product_name").value === "PRUAll Care" || document.getElementById("al_sqs_details.product_name").value === "PRUFlexi Gain" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Harvest" || document.getElementById("al_sqs_details.product_name").value === "PRUGain Plus" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Harvest Plus" || document.getElementById("al_sqs_details.product_name").value === "PRUEnrich Gain" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Boost")) //Added for defect 5787 by Sachin Tupe.//Added condition for optimiser and PRUvalue gain by ankita
               {
                  calculatedAges_mlife=ilANBInBackdate;
               
               }
               
            var mainlife = {
               "al_person_details.mlife.insu_type_header": obj_mlife["al_person_details.mlife.insu_type_header"],
                "al_person_details.mlife.insu_type": obj_mlife["al_person_details.mlife.insu_type"],
                "al_person_details.mlife.first_name": obj_mlife["al_person_details.mlife.first_name"],
                "al_person_details.pre_natal_child_flg": obj_mlife["al_person_details.pre_natal_child_flg"],
                "al_person_details.mlife.expected_delivery_dt": obj_mlife["al_person_details.mlife.expected_delivery_dt"],
                "al_person_details.gestational_week": obj_mlife["al_person_details.gestational_week"],
                "al_person_details.mlife.dob": obj_mlife["al_person_details.mlife.dob"],
                "al_person_details.mlife.anb": calculatedAges_mlife,
                "al_person_details.mlife.gender": obj_mlife["al_person_details.mlife.gender"],
                "al_person_details.mlife.smoke_status": obj_mlife["al_person_details.mlife.smoke_status"],
                "al_employee_details.mlife.occupation": obj_mlife["al_employee_details.mlife.occupation"],
                "al_employee_details.mlife.occupation_class": obj_mlife["al_employee_details.mlife.occupation_class"],
                "al_employee_details.mlife.nature_of_business": obj_mlife["al_employee_details.mlife.nature_of_business"],
                "al_employee_details.mlife.value_nature_of_business": obj_mlife["al_employee_details.mlife.value_nature_of_business"],
                "al_sqs_details.sec_parti_flag": obj_mlife["al_sqs_details.sec_parti_flag"],
                "al_person_details.mlife.parent_consent": obj_mlife["al_person_details.mlife.parent_consent"], //before change, condition is "obj_mlife["al_person_details.mlife.parent_consent"]" changed for defect 5806 by Sachin Tupe.
                "pvm_qualification_check": obj_mlife["pvm_qualification_check"],
                "pamb_channel":obj_mlife["pamb_channel"],
                "pamb_sub_channel":obj_mlife["pamb_sub_channel"],
                "client_ylp_type_mlife" :obj_mlife["client_ylp_type_mlife"],
                "anb_changed_by" :anb_changed_by,
               "al_person_details.mlife.anb_il_product" :ilANBInBackdate,
                "al_person_details.mlife.anb_il_product_temp":ilANBInBackdate,
               "al_person_details.mlife.anb_il_monthly_product" :ilANBInBackdate,
               "al_person_details.mlife.anb_il_monthly_product_temp" : temp_ilMonthly,
               "al_person_details.mlife.anb_temp" :calculatedAges_mlife,
               "rider_certified_check": obj_mlife["rider_certified_check"],//added by ankita on 2 July 2018 for rider certified check for PRUwith you product
            }
               
               
               console.log("mainlife--SR->"+mainlife);
               console.log("pamb_sub_channel--SR->"+obj_mlife["pamb_sub_channel"]);
            js_set_var("main_life_response",JSON.stringify(mainlife),function()
            {
                if(obj_mlife["al_sqs_details.sec_parti_flag"] == "Yes")
                {
                    js_get_var("sec_life_response", function(scnd_res)
                    {
                        if(scnd_res != "" && scnd_res != null && scnd_res != "null"  && scnd_res != "(null)")
                        {
                            obj_slife = JSON.parse(scnd_res);
                        
                            var dob_slife = obj_slife["al_person_details.slife.dob"].split("/");

                            fnMsSetANB(DateValueId, "slife", dob_slife[0], dob_slife[1], dob_slife[2], incpDateValue, incpday, incpmonth, incpyear)
                        }
                    });
                }
               else
               {
                       if(calculatedAges_mlife < 17 && obj_mlife["al_sqs_details.sec_parti_flag"] == "No")
                       {
                           if(!(obj_mlife["al_person_details.mlife.parent_consent"] == "Yes"))
                           {
                               alert("275");
                               return false;
                               menuController.loadPage("top_mysolutions_maindetails",0);
                           }
                       }
                       generateinputstringBackdate();
               }
            });
        }
    });
}

function setSecondLife(calculatedAge_slife,DateValueId, incpDateValue, incpday, incpmonth, incpyear, ilANBInBackdate)
{
    //Variable to take json data
    var seclife = {
        "al_person_details.slife.first_name": obj_slife["al_person_details.slife.first_name"],
        "al_person_details.slife.relationship": obj_slife["al_person_details.slife.relationship"],
        "al_person_details.slife.dob": obj_slife["al_person_details.slife.dob"],
        "al_person_details.slife.anb": calculatedAge_slife,
        "al_person_details.slife.gender": obj_slife["al_person_details.slife.gender"],
        "al_person_details.slife.smoke_status": obj_slife["al_person_details.slife.smoke_status"],
        "al_employee_details.slife.occupation": obj_slife["al_employee_details.slife.occupation"],
        "al_employee_details.slife.occupation_class": obj_slife["al_employee_details.slife.occupation_class"],
        "al_employee_details.slife.nature_of_business": obj_slife["al_employee_details.slife.nature_of_business"],
        "al_employee_details.slife.value_nature_of_business": obj_slife["al_employee_details.slife.value_nature_of_business"],
        "al_sqs_details.third_parti_flg": obj_slife["al_sqs_details.third_parti_flg"],
        "client_ylp_type_slife" :obj_slife["client_ylp_type_slife"],
        "al_person_details.slife.anb_il_product" :ilANBInBackdate,
        "al_person_details.slife.anb_il_monthly_product" :slife_il_monthly_anb,
        "al_person_details.slife.anb_il_monthly_product_temp" :slife_il_monthly_anb,
        "al_person_details.slife.anb_il_product_temp":ilANBInBackdate,
         "al_person_details.slife.anb_temp" :calculatedAge_slife
    }

    
    js_set_var("sec_life_response",JSON.stringify(seclife),function()
    {
        if(obj_slife["al_sqs_details.third_parti_flg"] == "Yes")
        {
            js_get_var("third_life_response", function(thrd_res)
            {
                if(thrd_res != "" && thrd_res != null && thrd_res != "null"  && thrd_res != "(null)")
                {
                    obj_tlife = JSON.parse(thrd_res);

                    var dob_tlife = obj_tlife["al_person_details.tlife.dob"].split("/");

                    fnMsSetANB(DateValueId, "tlife", dob_tlife[0], dob_tlife[1], dob_tlife[2], incpDateValue, incpday, incpmonth, incpyear)
                }
            });
        }
       else
       {
               console.log("generateinputstringBackdate Second life")
               generateinputstringBackdate();
       }
    });
}

function setThirdLife(calculatedAge_tlife,DateValueId, incpDateValue, incpday, incpmonth, incpyear, ilANBInBackdate)
{
    //Variable to take json data
    var thirdlife = {
        "al_person_details.tlife.first_name": obj_tlife["al_person_details.tlife.first_name"],
        "al_person_details.tlife.relationship": obj_tlife["al_person_details.tlife.relationship"],
        "al_person_details.tlife.dob":obj_tlife["al_person_details.tlife.dob"],
        "al_person_details.tlife.anb": calculatedAge_tlife,
        "al_person_details.tlife.gender": obj_tlife["al_person_details.tlife.gender"],
        "al_person_details.tlife.smoke_status": obj_tlife["al_person_details.tlife.smoke_status"],
        "al_employee_details.tlife.occupation": obj_tlife["al_employee_details.tlife.occupation"],
        "al_employee_details.tlife.occupation_class": obj_tlife["al_employee_details.tlife.occupation_class"],
        "al_employee_details.tlife.nature_of_business": obj_tlife["al_employee_details.tlife.nature_of_business"],
        "al_employee_details.tlife.value_nature_of_business": obj_tlife["al_employee_details.tlife.value_nature_of_business"],
        "client_ylp_type_tlife" :obj_tlife["client_ylp_type_tlife"],
        "al_person_details.tlife.anb_il_product" :ilANBInBackdate,
        "al_person_details.tlife.anb_il_monthly_product_temp" :tlife_il_monthly_anb,
        "al_person_details.tlife.anb_il_product_temp":ilANBInBackdate,
         "al_person_details.tlife.anb_il_product_temp":ilANBInBackdate,
         "al_person_details.tlife.anb_temp" :calculatedAge_tlife
    }
    
    
    js_set_var("third_life_response",JSON.stringify(thirdlife),function()
    {
        console.log("generateinputstringBackdate third life")
        generateinputstringBackdate();
    });
}


/*******************************************************
 Function Name: fnMsProductCheckforFieldsUpdate()
 Function Description: Check for any updates done on page in edit mode when values are already set
 Parameters:
 Created By: Pooja Dubey
 Created On: 13 Oct 2014
 Modified By:
 
 Modified On:
 Modification Reason:
 *******************************************************/
function fnMsProductCheckforFieldsUpdate(flag)
{
    js_get_var("prod_choice_response", function(prod_choice_res)
               {
               if(prod_choice_res != "" && prod_choice_res != null && prod_choice_res != "null"  && prod_choice_res != "(null)")
               {
               var result = $.parseJSON(prod_choice_res);
                   console.log("result error"+JSON.stringify(result));
               var prodName_Obj = JSON.parse(prod_choice_res);
               $.each(result, function(k, v)
                      {
                      if(prodName_Obj["al_sqs_details.product_name"] != "PRUterm")
                      {
                          if(k == "al_sqs_details.payment_backdate")
                          {
                          if(!(v == getPaybackdate()))
                          {
                          product_flag_update = "1";
                          }else
                          {
                      console.log("1.k---->"+k+"---v--->"+v);
                          product_flag_noupdate = "0";
                          }
                          }else if(k == "al_sqs_details.fund_choice1")
                          {
                          if(!(v == getFundchoiceOne()))
                          {
                          product_flag_update = "1";
                          }else
                          {
                      console.log("2.k---->"+k+"---v--->"+v);
                          product_flag_noupdate = "0";
                          }
                          }
                          else if(k == "al_sqs_details.fund_choice2")
                          {
                          if(!(v == getFundchoiceTwo()))
                          {
                          product_flag_update = "1";
                          }else
                          {
                      console.log("3.k---->"+k+"---v--->"+v);
                          product_flag_noupdate = "0";
                          }
                          }
                          else if(k == "al_sqs_details.expiry_age")
                          {
                          if(!(v == basic_expiry_age))
                          {
                          product_flag_update = "1";
                          }else
                          {
                      console.log("4.k---->"+k+"---v--->"+v);
                          product_flag_noupdate = "0";
                          }
                          }
                          else if(k == "al_sqs_details.tot_fund_val")
                          {
                          if(!(v == document.getElementById("total_allocation_value").innerHTML))
                          {
                      console.log("7.k---->"+k+"---v--->"+v);
                          product_flag_update = "1";
                          }else
                          {
                      console.log("5.k---->"+k+"---v--->"+v);
                          product_flag_noupdate = "0";
                          }
                          }
                      /*else if(document.getElementById(k).value != undefined || document.getElementById(k).value != null || document.getElementById(k).value != "" || document.getElementById(k).value != 'undefined' || document.getElementById(k).value != "null")//Added by ankita on 19 Feb 2019
                          {
                            console.log("8.k---->"+k+"---v--->"+v+"-------->"+document.getElementById(k).value);
                            if(!(v == document.getElementById(k).value))
                              {                              product_flag_update = "1";
                              }
                      
                          }*/
                      else if(k != "al_sqs_details.product_code" && k != "al_sqs_details.product_type")//Added by ankita on 20 Feb 2019 for Product code and type
                      {
                          if(document.getElementById(k).value != undefined || document.getElementById(k).value != null || document.getElementById(k).value != "" || document.getElementById(k).value != 'undefined' || document.getElementById(k).value != "null")
                          {
                              console.log("8.k---->"+k+"---v--->"+v+"-------->"+document.getElementById(k).value);
                              if(!(v == document.getElementById(k).value))
                              {
                                    product_flag_update = "1";
                              }
                          }
                      }
                      else
                          {
                      console.log("6.k---->"+k+"---v--->"+v);
                          product_flag_noupdate = "0";
                          }
                      }
                      else
                      {
                        if(k != "al_sqs_details.fund_choice2" && k != "al_sqs_details.fund_choice1" && k != "al_sqs_details.expiry_age" && k != "al_sqs_details.tot_fund_val" && k != "al_sqs_details.foreign_currency" && k != "al_sqs_details.product_code" && k != "al_sqs_details.product_type")//added condition last 3 condition for defect 7325
                        {
                              if(k == "al_sqs_details.payment_backdate")
                              {
                                  if(!(v == getPaybackdate()))
                                  {
                                      console.log("90---"+k+"---v--->"+v);
                                    product_flag_update = "1";
                                  }else
                                  {
                                    product_flag_noupdate = "0";
                                      console.log("87---"+k+"---v--->"+v);
                                  }
                              }else if(document.getElementById(k).value != undefined || document.getElementById(k).value != null || document.getElementById(k).value != "" || document.getElementById(k).value != 'undefined' || document.getElementById(k).value != "null")
                              {console.log("55---"+k+"---v--->"+v);
                                  if(!(v == document.getElementById(k).value))
                                  {
                                      console.log("10---->"+k+"---v--->"+v);
                                    product_flag_update = "1";
                                  }
                                  }else
                                  {
                                    product_flag_noupdate = "0";
                                      console.log("19"+k+"---v--->"+v);
                                  }

                          }
                       }
                      
                      });
               product_choice_details(flag);
               }else
               {
               product_flag_update="1";
               product_choice_details(flag);
               }
               
               });
}

function fnMsChangePayBackdateoption()
{
    isCallFromDatePicker="No";
    if(document.getElementById('al_sqs_details.payment_backdate_no').checked)
    {
         backdateYesFlag=false;
        document.getElementById('al_sqs_details.Inception_dt_img').style.pointerEvents='none';
        InceptionDateCal();
        var day_res_dob = obj_mlife["al_person_details.mlife.dob"].split("/");
        day_res = document.getElementById("al_sqs_details.Inception_dt").value.split("/");
        isbackdate=true;
        
        //console.log("Date passed in SetANB :: "+"\n"+"Main life date:: "+day_res_dob[0]+"/"+day_res_dob[1]+"/"+  day_res_dob[2]++"\n"+"Inception date object:: "+obj["date"]+"\n"+"Inception date:: "+day_res[0]+"/"+day_res[1]+"/"+day_res[2]+"\n"+"Second life date:: "+day_res[0]+"/"+day_res[1]+"/"+day_res[2]+"\n"+"Third life date:: "+day_res[0]+"/"+day_res[1]+"/"+day_res[2]);
        
        fnMsSetANB("al_sqs_details.Inception_dt", "mlife", day_res_dob[0], day_res_dob[1],  day_res_dob[2], document.getElementById("al_sqs_details.Inception_dt").value, day_res[0], day_res[1], day_res[2]);
        if(document.getElementById("al_sqs_details.product_name").options.length>1)
        {
            document.getElementById("al_sqs_details.product_name").value="Select Products";
            $(".setBlankValue").val("");
            $(escape_jq("al_sqs_details.payment_backdate_yes")).prop("disabled", true);//Added for defect 5521 issue no.2 on date 4-07-2018.
        }
    }else if(document.getElementById('al_sqs_details.payment_backdate_yes').checked)
    {     backdateYesFlag=true;
        document.getElementById('al_sqs_details.Inception_dt_img').style.pointerEvents='auto';
        $(escape_jq("al_sqs_details.payment_backdate_no")).prop("disabled", false); //def-5003
    }
}

function fnMsFundsValidation()
{
    fnMsFundsName();
    if(document.getElementById("al_sqs_details.fund_choice2").checked)
    {
        if(obj_mlife["al_person_details.mlife.anb"] > 12)
        {
            document.getElementById("al_sqs_details.fund_choice1").checked = true;
            document.getElementById("al_sqs_details.fund_choice2").checked = false;
            document.getElementById("al_sqs_details.fund_choice2").disabled = true;
            document.getElementById("al_sqs_details.fund_choice1").disabled = true;
        }else if(obj_mlife["al_person_details.mlife.anb"] <= 12)
        {
            document.getElementById("al_sqs_details.fund_choice2").disabled = false;
            document.getElementById("al_sqs_details.fund_choice1").disabled = false;
        }
    }else if(document.getElementById("al_sqs_details.fund_choice1").checked)
    {
        if(obj_mlife["al_person_details.mlife.anb"] > 12)
        {
            document.getElementById("al_sqs_details.fund_choice1").checked = true;
            document.getElementById("al_sqs_details.fund_choice2").checked = false;
            document.getElementById("al_sqs_details.fund_choice2").disabled = true;
            document.getElementById("al_sqs_details.fund_choice1").disabled = true;
        }else if(obj_mlife["al_person_details.mlife.anb"] <= 12)
        {
            document.getElementById("al_sqs_details.fund_choice2").disabled = false;
            document.getElementById("al_sqs_details.fund_choice1").disabled = false;
        }
    }
}

function fnMsFundDisbaled(id)
{
    if(document.getElementById("al_sqs_details.fund_choice2").checked)
    {
        document.getElementById(id).disabled = true;
        document.getElementById(id).value = "0";
        $("#total_allocation_value").html("0");
    }else
    {
        document.getElementById(id).disabled = false;
    }
}

function fnMsFundsName()
{
    fnMsFundDisbaled("al_sqs_details.equity_fund");
    fnMsFundDisbaled("al_sqs_details.managed_fund2");
    fnMsFundDisbaled("al_sqs_details.bond_fund");
    fnMsFundDisbaled("al_sqs_details.dana_unggul");
    fnMsFundDisbaled("al_sqs_details.dana_urus2");
    fnMsFundDisbaled("al_sqs_details.dana_aman");
    fnMsFundDisbaled("al_sqs_details.asia_property");
    fnMsFundDisbaled("al_sqs_details.asia_managed_fund");
    fnMsFundDisbaled("al_sqs_details.asia_local_bond_fund");
    fnMsFundDisbaled("al_sqs_details.global_market_naviga");
    fnMsFundDisbaled("al_sqs_details.dragon_peacock");
    fnMsFundDisbaled("al_sqs_details.asia_equity_fund");
    fnMsFundDisbaled("al_sqs_details.equity_focus_fund");
    fnMsFundDisbaled("al_sqs_details.equity_income_fund");
    
    
   
}


function SetFundstoZero()
{
    $('#fund_list option[value=0]:selected').parent('select').prop('disabled',false);
    document.getElementById("al_sqs_details.equity_fund").value = 0;
    document.getElementById("al_sqs_details.managed_fund2").value = 0;
    document.getElementById("al_sqs_details.bond_fund").value = 0;
    document.getElementById("al_sqs_details.dana_unggul").value = 0;
    document.getElementById("al_sqs_details.dana_urus2").value = 0;
    document.getElementById("al_sqs_details.dana_aman").value = 0;
    document.getElementById("al_sqs_details.asia_property").value = 0;
    document.getElementById("al_sqs_details.asia_managed_fund").value = 0;
    document.getElementById("al_sqs_details.asia_local_bond_fund").value = 0;
    document.getElementById("al_sqs_details.global_market_naviga").value = 0;
    document.getElementById("al_sqs_details.dragon_peacock").value = 0;
    document.getElementById("al_sqs_details.asia_equity_fund").value = 0;
    document.getElementById("al_sqs_details.equity_focus_fund").value = 0;
    document.getElementById("al_sqs_details.equity_income_fund").value = 0;
    document.getElementById("al_sqs_details.global_leaders_fund").value = 0;
    document.getElementById("al_sqs_details.asian_high_yield_bond_fund").value = 0;
    document.getElementById("al_sqs_details.japan_dynamic_fund").value = 0;
    document.getElementById("al_sqs_details.euro_equity_fund").value = 0;
    document.getElementById("al_sqs_details.multi_asset_fund").value = 0;
    
    document.getElementById("al_sqs_details.asia_select_focus_fund").value = 0;
    document.getElementById("al_sqs_details.flexi_vantage_fund").value = 0;
    document.getElementById("al_sqs_details.asia_opportunities_fund").value = 0;
    document.getElementById("al_sqs_details.global_managed_fund").value = 0;
    document.getElementById("al_sqs_details.global_opportunities_fund").value = 0;
    document.getElementById("al_sqs_details.strategic_managed_fund").value = 0;
    document.getElementById("al_sqs_details.emerging_opportunities_fund").value = 0;
    document.getElementById("al_sqs_details.global_growth_fund").value = 0;
    document.getElementById("al_sqs_details.global_strategic_fund").value = 0;
    document.getElementById("al_sqs_details.equity_plus_fund").value = 0;
    document.getElementById("al_sqs_details.managed_plus_fund").value = 0;
    document.getElementById("al_sqs_details.asia_great_fund").value = 0;
    document.getElementById("al_sqs_details.innovation_fund").value = 0;
    document.getElementById("al_sqs_details.us_equity_fund").value = 0;
    document.getElementById("al_sqs_details.pacific_dynamic_income_fund").value = 0;//Added for new uob fund by sachin tupe.
    document.getElementById("al_sqs_details.sustainable_equity_fund").value = 0;
    document.getElementById("al_sqs_details.global_esg_choice_fund").value = 0//Pradnya:added for march24 release
                                               
                                               
                                               
    $("#total_allocation_value").html("0");
                                               //added by ankita on 14 june 2021
                                               if(document.getElementById("al_sqs_details.product_name").value==="PRULink Growth")
                                               {
                                               document.getElementById("al_sqs_details.strategic_managed_fund").value="100";
                                                 document.getElementById("total_allocation_value").innerHTML="100";
                                               }
}

function ProdnameReplaceQuote(sqs_id,Client_id)
{
    var querySelect = new DbUtil();
    querySelect.query()
    querySelect.select()
    querySelect.column('*')
    querySelect.from()
    querySelect.table('al_sqs_details')
    querySelect.where()
    querySelect.clause('sqs_id','=',sqs_id)
    querySelect.and()
    querySelect.clause('client_id','=',Client_id)
    if(channelTypeForAgencyBancaRepls!='banca')
    {
    querySelect.and()
    querySelect.clause('is_deleted','=','No')
    }
    querySelect.and()
    querySelect.clause('agent_id','=',ds_agentId);//Added by Pallavi for device sharing
    
    return querySelect;

}

function prodInceptiondateonload()
{
    document.getElementById('al_sqs_details.Inception_dt_img').style.pointerEvents='none';
    

    if(document.getElementById("al_sqs_details.product_name").value == "PRUmy child" || document.getElementById("al_sqs_details.product_name").value=="PRUmy kid" || document.getElementById("al_sqs_details.product_name").value=="PRUwith you" || document.getElementById("al_sqs_details.product_name").value=="PRULink Cover" || document.getElementById("al_sqs_details.product_name").value=="PRUWealth Plus" || document.getElementById("al_sqs_details.product_name").value=="PRUWealth Max" || document.getElementById("al_sqs_details.product_name").value=="PRUMax Cover" || document.getElementById("al_sqs_details.product_name").value=="PRUSignature Assure" || document.getElementById("al_sqs_details.product_name").value==="PRULink Supreme" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature Vanguard" || document.getElementById("al_sqs_details.product_name").value==="PRUElite Invest" || document.getElementById("al_sqs_details.product_name").value==="PRUSignature GrowthPlus" || document.getElementById("al_sqs_details.product_name").value=="PRUWealth Enrich" || document.getElementById("al_sqs_details.product_name").value==="PRULink Supreme Plus")//Added condition for PRULink Cover by ankita on 22 March 2019

    {
        if(obj_mlife["al_person_details.mlife.anb"] > 12)
        {
            document.getElementById("al_sqs_details.fund_choice1").checked = true;
            document.getElementById("al_sqs_details.fund_choice2").checked = false;
            document.getElementById("al_sqs_details.fund_choice2").disabled = true;
        }else
        {
            document.getElementById("al_sqs_details.fund_choice1").checked = true;
            document.getElementById("al_sqs_details.fund_choice2").checked = false;
            document.getElementById("al_sqs_details.fund_choice2").disabled = false;
        }
        
        fnMsFundsValidation();
    }
}

function ClearDataProd(callvalue)
{   var language_option=null;
    var prod_choice_data = null;
    var ben_select_data = null;
    var ben_select_bundle=null;
    var prod_choice_res = null;
    var hideshow = null;
    var hideshow_bundle=null;
    var minmax = null;
    var loading_res = null;
    var hideshowloading = null;
    var loadin_data = null;
    var calDataString = null;
    var prod_choice_rs = null;
    var bundleFundRes=null;
    var bundleProdRes=null;
    var calbundleRes=null;
    var bundleRiderRes=null;
    var clearFlagBundle=null;
    var clearFlag=null;
    var bundlePrevFileNameEmail=null;
    var cal_data_string_bundle=null;
    var bundleRes=null;
    lci_on_UI=true;
    hidePayOut=false;
   //arrayBundleProduct=[];
    
    szPRUallocatorPremiumAvailable  = "No";
    targetSustainabilityFlag="No";  // Used for Proceed with reduce term changes to directly preview the output
    targetMaximumPremium="No"; //Used if existing budgeted Premium is greater than the new maximum Premium change budgeted premium to the new premium
    szPRUsaverExists = "No"; //Used to set the excess value of budget premium in saver or PRUallocater
    szPRUsaverValue = 0;
    szBasicPremium = 0;
    szOldAllocatorValueIfNA=0;
    szNegativeCashValueFlag = "No";
   
   
   szOkToAmendCVFlag = "No";//added by ankita on 23 jan 2020 for million cover product
   newPRUAllocatorPremiumPMC="";
console.log("callvalue:"+callvalue);
if(callvalue==="product_name")
{
  arrayBundleProduct=[];
}
    //$(".fundDisplayFlag").css("display", "");
   // var idArray = [];
   /* $('.fundDisplayFlag').each(function () {
                               
   $(this.id).removeClass("fundDisplayFlag"," ")
   // idArray.push(this.id);
   });**/
    
    idArray=[];
    $('.fundDisplayFlag').each(function () {
                               
                               //  $(this.id).removeClass("fundDisplayFlag"," ")
                               
                               if(document.getElementById(this.id).style.display=="")
                               {
                               
                               // document.getElementById(this.id).style.display=""
                               idArray.push(this.id);
                               }
                               // idArray.push(this.id);
                               });
    
    
    
    
    for(var i=0;i<=idArray.length-1;i++) {
        
        
        document.getElementById(idArray[i]).style.display="";
        
        
    }
    
  
   
    
    
    
    
//    below three life response added for IL ANB changes. Pramod Chavan: 09122017
              
 /***************Follow code for defect 5991 on date 10-8-2018*********************/
              
if((ilProductList.indexOf(document.getElementById("al_sqs_details.product_name").value)>=0))
    {
        selectedILProduct=true;
    }else
    {
        selectedILProduct=false;
              
    }
              
              
 /***********************************/
              
    
     ilmonthly_selection=false;
    for(ilElement in array_inception_element)
    {
        
        console.log("pr_name"+array_inception_element[ilElement].product_name);
        console.log("pr_ismonthly"+array_inception_element[ilElement].isMonthly);
        var il_product=array_inception_element[ilElement].product_name;
        var ilmonthtrue=array_inception_element[ilElement].isMonthly;
        var msSelectProduct=document.getElementById("al_sqs_details.product_name").value;
        
        if(il_product==msSelectProduct)
        {
            
            ilmonthly_selection=true;
        }
        
    }
    
    if(ANB_json[0]["anb_type"]=="IL_Monthly")
    {
         ilmonthly_selection=true;
        
    }
    
   if(document.getElementById("al_sqs_details.product_name").value=="PRUsignature income" || document.getElementById("al_sqs_details.product_name").value=="PRUMy Gift" || document.getElementById("al_sqs_details.product_name").value==="PRUMulti Crisis Guard") //Added for income new cr. by sachin // Added by Shivani for PRUMulti Crisis Guard
    {
    
        uiaFundSelectionFlag=false;
    
    
    }
    if(document.getElementById("al_sqs_details.product_name").value!="PRUGlobal Series"){
        document.getElementById("al_sqs_details.foreign_currency").value="";
    }
    
    
    console.log("--->ilmonthly_selection--->"+ilmonthly_selection);
      //Added for internal issue by Sachin T. on 3-3-2023.
    js_set_var("bundle_sqs_id",JSON.stringify(bundleRes),function()
               {
     js_set_var("bundle_product_preview","",function()
                {
    js_set_var("language_option",JSON.stringify(language_option),function()
               {
    js_set_var("bunldle_product_flag",JSON.stringify(clearFlag),function()
               {
    js_set_var("bunldle_output_response",JSON.stringify(clearFlagBundle),function()
               {
    js_set_var("bundle_product_response",JSON.stringify(bundleFundRes),function()
               {
               
               js_set_var("bundle_product_detail_response",JSON.stringify(bundleProdRes),function()
                          {
                            js_set_var("bundlePrevFileNameEmail",JSON.stringify(bundlePrevFileNameEmail),function()
                            {
                          js_set_var("cal_bundle_product_details_response",JSON.stringify(calbundleRes),function()
                                     {
                                     js_set_var("bundle_rider_string",JSON.stringify(bundleRiderRes),function()
                                                {

    js_get_var("main_life_response",function(mlifeResponse)
               {
               js_get_var("sec_life_response",function(slifeResponse)
                          {
                          js_get_var("third_life_response",function(tlifeResponse)
                                     {
                                     
    js_set_var("product_name",document.getElementById("al_sqs_details.product_name").value,function()
    {
        js_set_var("MinMaxBudget",JSON.stringify(minmax),function()
        {
            js_set_var("hideshowrider",JSON.stringify(hideshow),function()
            {
                js_set_var("hideshowrider_bundle",JSON.stringify(hideshow_bundle),function()
                {
                    js_set_var("cal_data_string_bundle",JSON.stringify(cal_data_string_bundle),function()
                    {
                js_set_var("beneft_selection_response",JSON.stringify(ben_select_data),function()
                {
                js_set_var("beneft_selection_response_bundle",JSON.stringify(ben_select_bundle),function()
                           {
                    js_set_var("loading_details_response",JSON.stringify(loading_res),function()
                    {
                        js_set_var("hideshowloadingrider",JSON.stringify(hideshowloading),function()
                        {
                            js_set_var("engineloadingstring",JSON.stringify(loadin_data),function()
                            {
                               js_set_var("cal_data_string",JSON.stringify(calDataString),function()
                                  {
                                          
                                     js_set_var("uia_fund_selection","",function()
                                                {
                                   js_set_var("prod_choice_response",JSON.stringify(prod_choice_rs), function()
                                      {
                                              //Added by Paromita for DEF 5806
                                              var indexForBckDateProduct = backDateProductList.indexOf(document.getElementById("al_sqs_details.product_name").value);
                                          if((document.getElementById("al_sqs_details.payment_backdate_no").checked) ||(!document.getElementById("al_sqs_details.payment_backdate_yes").checked) ||(document.getElementById("al_sqs_details.payment_backdate_yes").checked && indexForBckDateProduct != -1))
                                              {
                                                var jsonReCalculatedPersonal=fnReCalculateAllANB(mlifeResponse,slifeResponse,tlifeResponse);
                                        
                                              //var objJsonReCalculatedPersonal= JSON.parse(jsonReCalculatedPersonal)
                                              
                                                  mlifeResponse = jsonReCalculatedPersonal["mlifeResponse"];
                                                  slifeResponse = jsonReCalculatedPersonal["slifeResponse"];
                                                  tlifeResponse = jsonReCalculatedPersonal["tlifeResponse"];
                                                  console.log("mlifeResponse--"+mlifeResponse)
                                                  console.log("slifeResponse--"+slifeResponse)
                                                  console.log("tlifeResponse--"+tlifeResponse)
                                              }
                                              else if(document.getElementById("al_sqs_details.payment_backdate_yes").checked && (backDateProductList.indexOf(document.getElementById("al_sqs_details.product_name").value)<0)) //Added for production defect 55112 by Sachin T..
                                              {
                                              var jsonReCalculatedPersonal=fnReCalculateAllANB(mlifeResponse,slifeResponse,tlifeResponse);
                                              
                                              //var objJsonReCalculatedPersonal= JSON.parse(jsonReCalculatedPersonal)
                                              
                                              mlifeResponse = jsonReCalculatedPersonal["mlifeResponse"];
                                              slifeResponse = jsonReCalculatedPersonal["slifeResponse"];
                                              tlifeResponse = jsonReCalculatedPersonal["tlifeResponse"];
                                              console.log("mlifeResponse--"+mlifeResponse)
                                              console.log("slifeResponse--"+slifeResponse)
                                              console.log("tlifeResponse--"+tlifeResponse)

                                              }
                                          var objmlifeResponse = null;
                                          var objslifeResponse =null;
                                          var objtlifeResponse =null;
                                              
                                          objmlifeResponse = JSON.parse(mlifeResponse);
                                          if (slifeResponse != "" && slifeResponse != null && slifeResponse != "null" && slifeResponse != "(null)")
                                          {
                                              objslifeResponse = JSON.parse(slifeResponse);
                                          }
                                          if(tlifeResponse != "" && tlifeResponse != null && tlifeResponse != "null" && tlifeResponse != "(null)")
                                          {
                                              objtlifeResponse = JSON.parse(tlifeResponse);
                                          }
                                              
                                              /***********************************************/
                                        //////
                                              
                                          /*if((objmlifeResponse["al_person_details.pre_natal_child_flg"]=="Yes" && objmlifeResponse["al_person_details.gestational_week"]>=17 && objmlifeResponse["al_person_details.gestational_week"]>0) && (objslifeResponse["al_person_details.slife.gender"]=="Female" && ((objslifeResponse["al_person_details.slife.anb"]>=18 && objslifeResponse["al_person_details.slife.anb"]>=40)|| (objslifeResponse["al_person_details.slife.anb_il_product"]>=18 && objslifeResponse["al_person_details.slife.anb_il_product"]>=40)||(objslifeResponse["al_person_details.slife.anb_il_monthly_product"]>=18 && objslifeResponse["al_person_details.slife.anb_il_monthly_product"]>=40))) && document.getElementById("al_sqs_details.product_name").value=="PRUwith you")*/
                                              
                                              //al_sqs_details.payment_frequency
                                              
                                              
                                          
                                     /*     var message="Congratulation! This policy is eligible for EASE provided the criteria below are met: \n i) Mother or her spouse/partner has never been tested for or told to have,received or expect to receive medical advice, counselling or treatment in connection with HIV, AIDS, AIDS related complex or any other AIDS related condition; and \n (ii) Mother has never undergone artificial insemination and/or assisted reproductive technology, example in vitro fertilization (IVF) or other procedures in respect of this pregnancy; and \n(iii) Mother has never performed any prenatal genetic testing in respect of this pregnancy; and \n(iv) Mother's current pregnancy has not more than two foetuses.The maximum Essential Child Plus SA for EASE is RM100,000. If customer would like to purchase higher than this amount or if any of the above is not met, she may proceed with full Underwriting."
                                          
                                              if(true)
                                              {
                                              isEaseFlag=true;
                                                  canSwipe=0;
//                                              bootbox.alert(message,function()
//                                                            {
//                                                            
//                                                            canSwipe=1;
//                                                            });
                                              
                                             // $("#ease_popup_id").fadeIn();
                                              
                                           //     $("#ease_popup_id").fadeIn();
                                              
                                            //  canSwipe=0;
                                        /*      alert("Congratulation! This policy is eligible for EASE provided the criteria below are met:\n i)Mother or her spouse/parter has never been tested for have,recieved or expect to receive medical advice,counselling or treatment in connection with HIV.AIDS,AIDS related complex or any other AIDS related conditions;and\n ii)Mother has never undergone artificial insemination and/or assisted reproductive technology,example in vitro fertilazation(IVf)or other procedure in repect of this pregnancy;and\n");*/
                                             // return false;
                                              
                                            //  }
                                              
                                              
                                    ////
                                              /**********************************/
                                              
                                          if(ilmonthly_selection)
                                          {
                                              
                                              objmlifeResponse["al_person_details.mlife.anb_il_product"]=objmlifeResponse["al_person_details.mlife.anb_il_monthly_product"]
                                              
                                              if (objslifeResponse != "" && objslifeResponse != null && objslifeResponse != "null" && objslifeResponse != "(null)")
                                              {
                                                    //objslifeResponse = JSON.parse(slifeResponse);
                                                //original code was objslifeResponse["al_person_details.slife.anb_il_product"]=objmlifeResponse["al_person_details.slife.anb_il_monthly_product"].....changed for defect 7969 on date 24-07-2019
                                                    objslifeResponse["al_person_details.slife.anb_il_product"]=objslifeResponse["al_person_details.slife.anb_il_monthly_product"]
                                              
                                              }
                                              if(objtlifeResponse != "" && objtlifeResponse != null && objtlifeResponse != "null" && objtlifeResponse != "(null)")
                                              {
                                                    //objtlifeResponse = JSON.parse(tlifeResponse);
                                                //original code was objtlifeResponse["al_person_details.slife.anb_il_product"]=objmlifeResponse["al_person_details.slife.anb_il_monthly_product"].....changed for defect 7969 on date 24-07-2019
                                                    objtlifeResponse["al_person_details.tlife.anb_il_product"]=objtlifeResponse["al_person_details.tlife.anb_il_monthly_product"]
                                              }
                                          }
                                          
                                              
                                              js_set_var("main_life_response",JSON.stringify(objmlifeResponse),function()
                                                         {
                                                         js_set_var("sec_life_response",JSON.stringify(objslifeResponse),function()
                                                                    {
                                                                    js_set_var("third_life_response",JSON.stringify(objtlifeResponse), function()
                                                                               {
                                                                               
                                                                               var BIGloyaltyID="";
                                                                               var AAcust_mobile="";
                                                                               var Relation_upsize="";
                                                                               var IdValue_Upsize="";
                                                                               var IdType_Upsize="";
                                                                               
                                                                               var AAcampaigndata={
                                                                               "isBigLoyaltyId":BIGloyaltyID,
                                                                               "isMobileNumber":AAcust_mobile,
                                                                               "relation_upsize":Relation_upsize,
                                                                               "idvalue_upsize":IdValue_Upsize,
                                                                               "idtype_upsize":IdType_Upsize
                                                                               }
                                                                               //set var mobile ,id
                                                                               js_set_var("AAcampaigndata",JSON.stringify(AAcampaigndata),function(){
                                              
                                                                                  if(callvalue!="fund_choice" && callvalue!="product_name")
                                                                                  {
                                                                                        arrMySolutionsVisitedFlag[2]=2;
                                                                                        fnMsValidateProduct("1");
                                                                                  }
                                                                                  else if(callvalue=="product_name"){
                                                                                      obj_prochoice="";
                                                                                      arrMySolutionsVisitedFlag[2]=2;
                                                                                      ShowFunds('change', mlifeResponse, slifeResponse, tlifeResponse);
                                                                                      //fnGetANB('change',mlifeResponse,slifeResponse,tlifeResponse);
                                                                                      SetFundstoZero();
                                                                                      fnMsValidateProduct("1")
                                                                                        backDateFilter()
                                                                                          
                                                                                      }
                                                                                      fnMSCheckMandatoryFields();
                                                                               
                                                                               
                                                                               });
                                                                           });
                                                                    });
                                                         });
                                      });//
                                                });
                                  });
                            });
                        });
                    });
                });
            });
                           });
                });
                       });
        });
    });
                                     
                         });// Tlife response
              });// Slife response
   });// Mlife response
                                                });
                                     });
                          });
                          });
               });
});
});
               });//
                });
               });
                                               
               
}

function fnMsGetProductDetails(prod_name)
{
    var querySelect = new DbUtil();
    
    querySelect.query()
    .select()
    .column('*')
    .from()
    .table('al_product_master')
    .where()
    .clause('product_name','=',prod_name)
    
    return querySelect;
}

function fnMsValidateProduct(flag_chk)
{
    var product_nm = document.getElementById("al_sqs_details.product_name").value;

    	var selectQuery=fnMsGetProductDetails(product_nm);
        selectQuery.execute(function(response)
        {
            if(response!="" && response!="{}")
            {
                var obj=JSON.parse(response);
                effect_date = obj[0]['product_effect_date'];
                prod_expiry_dt = obj[0]['product_expiry_date'];
                product_code = obj[0]['product_code'];//Added by ankita on 18 Feb 2019
                product_type = obj[0]['product_core_system'];
                //product_choice_details("prod_name");
            }
            else
            {
                effect_date="";
                product_code="";
                product_type="";
                prod_expiry_dt="";
            }
        });
}
//whole logic changed by Prveen on 06/10/2015
function CalValidProduct()
{
    var oneDay = 24*60*60*1000;
    var new_eds = effect_date.split(" ");
    var new_ed = new_eds[0].split("-");
    var new_expdts =  prod_expiry_dt.split(" ");
    var new_expdt =  new_expdts[0].split("-");
    var curr_dt = fnGetDateTimeStamp();
    var curr_dts = curr_dt.split(" ");
    var currnt_dt = curr_dts[0].split("-");
    var new_incp = document.getElementById("al_sqs_details.Inception_dt").value;
    var new_incp_dt = new_incp.split("/");
    var date1 = new Date(new_ed[0],new_ed[1]-1,new_ed[2]); //year,month,date//Effective Date
    var date2 = new Date(new_incp_dt[2],new_incp_dt[1]-1,new_incp_dt[0]);//Inception Date
    var date3 = new Date(new_expdt[0],new_expdt[1]-1,new_expdt[2]);//Expiry Date
    if (currnt_dt[2] > 15 && currnt_dt[1] == 12) {
        currnt_dt[0] = eval(currnt_dt[0]) + 1
        currnt_dt[1] = 1;
        currnt_dt[2] = 1;
    } else {
        if (currnt_dt[2] > 15 && currnt_dt[1] < 12) {
            currnt_dt[1] = eval(currnt_dt[1]) + 1;
            currnt_dt[2] = 1;
        } else
            currnt_dt[2] = 1;
    }
    
    
   // var date4 = new Date(currnt_dt[0],eval(currnt_dt[1])-1,currnt_dt[2]);//Current Date //original code
    var date4 = new Date(new_incp_dt[2],new_incp_dt[1]-1,new_incp_dt[0]);//Added for production defect product not launched by sachin tupe.
    
    var diffDaysexp = Math.round((date3.getTime() - date4.getTime())/(oneDay));
    var diffDays12 = Math.round((date2.getTime() - date1.getTime())/(oneDay));
    var diffDays14 = Math.round((date4.getTime() - date1.getTime())/(oneDay));
    console.log("On swipe check:: "+"\n"+"Eff Date:: "+new_ed[0]+"-"+new_ed[1]+"-"+new_ed[2]+"\n"+"Incpt Date:: "+new_incp_dt[2]+"-"+new_incp_dt[1]+"-"+new_incp_dt[0]+"\n"+"Exp Date:: "+new_expdt[0]+"-"+new_expdt[1]+"-"+new_expdt[2]+"\n"+"diffDaysexp:: "+diffDaysexp+"\n");
   if( date3=="Invalid Date" || date1=="Invalid Date")
    {
      alert("332");
        InceptionDateCal();
        return false;
    }
    if(diffDays12<0)
    {
        alert("291");
        InceptionDateCal();
        return false;
    }
    else if(diffDaysexp<0)
    {
        alert("290");
        InceptionDateCal();
        return false;
    }

    else if(diffDays14<0)
    {
        alert("291");
        InceptionDateCal();
        return false;
    }
    else if(diffDays12>0)
    {
        var diffDaysinc = Math.round((date4.getTime() - date2.getTime())/(oneDay));
        console.log("On swipe check 1:: :: "+"\n"+"Eff Date:: "+new_ed[0]+"-"+new_ed[1]+"-"+new_ed[2]+"\n"+"Incpt Date:: "+new_incp_dt[2]+"-"+new_incp_dt[1]+"-"+new_incp_dt[0]+"\n"+"Exp Date:: "+new_expdt[0]+"-"+new_expdt[1]+"-"+new_expdt[2]+"\n"+"diffYears:: "+diffDaysinc+"\n");
        /*******************Following Condition for pruwealth gain plus****************/
        if(document.getElementById("al_sqs_details.product_name").value == "PRUwealth gain plus" || document.getElementById("al_sqs_details.product_name").value == "PRUgrowth" || document.getElementById("al_sqs_details.product_name").value == "PRUcancer X" || document.getElementById("al_sqs_details.product_name").value == "PRUSignature Optimiser" || document.getElementById("al_sqs_details.product_name").value == "PRUValue Gain" || document.getElementById("al_sqs_details.product_name").value == "PRUSenior Med" || document.getElementById("al_sqs_details.product_name").value == "PRUSignature Reward" || document.getElementById("al_sqs_details.product_name").value == "PRUEasy Protect" || document.getElementById("al_sqs_details.product_name").value === "PRUCash Enrich" || document.getElementById("al_sqs_details.product_name").value === "PRUTerm Premier" || document.getElementById("al_sqs_details.product_name").value === "PRUAll Care" || document.getElementById("al_sqs_details.product_name").value === "PRUFlexi Gain" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Harvest" || document.getElementById("al_sqs_details.product_name").value === "PRUGain Plus" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Harvest Plus" || document.getElementById("al_sqs_details.product_name").value === "PRUEnrich Gain" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Boost")//Added condition for product PRUcancer X on 4 June 18 by//Added condition for optimiser and PRUvalue gain by ankita ankita
        {
            var oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
            var inceptionDt =document.getElementById("al_sqs_details.Inception_dt").value;
            inceptionDt=inceptionDt.split("/");
            var inceDate=inceptionDt[0];
            var inceMonth=(eval(inceptionDt[1])-1);
            var inceYear=inceptionDt[2];
            console.log("inception Date--->"+inceDate+"/"+inceMonth+"/"+inceYear);
            var systemdate = new Date();
            if(sysdate!=""){
                 systemdate = new Date(sysdate);
            }else{
                 systemdate = new Date();
            }
            var dd = parseInt(systemdate.getDate());
            var mm = parseInt(systemdate.getMonth()); //January is 0!
            var yyyy = parseInt(systemdate.getFullYear());
            console.log("current Date--->"+dd+"/"+mm+"/"+yyyy);
            var date2 = new Date(eval(yyyy), eval(mm), eval(dd));
            if(checkIlMonthly)
            {
                if(parseInt(dd)>=2 && parseInt(dd)<=31){
                    date2.setMonth(date2.getMonth()+1);
                    date2.setDate(1);
                }
            }
            console.log("current Date--->"+date2);
            date1 = new Date(eval(inceYear), eval(inceMonth), eval(inceDate));
            
            var diffDays = Math.round(((date2.getTime() - date1.getTime()) / (oneDay)))
            console.log("diffDays"+diffDays);
            diffDaysinc=diffDays;
            console.log("diffDaysinc pruwealth gain plus"+diffDaysinc);
            
        }
        
        
        if(document.getElementById("al_sqs_details.payment_backdate_yes").checked)
        { //following old condtion was diffDaysinc<0 changed by sachin tupe for defect 5865.
            if((diffDaysinc<0 && document.getElementById("al_sqs_details.product_name").value != "PRUwealth gain plus" && document.getElementById("al_sqs_details.product_name").value != "PRUgrowth" && document.getElementById("al_sqs_details.product_name").value != "PRUcancer X" && document.getElementById("al_sqs_details.product_name").value != "PRUSignature Optimiser" && document.getElementById("al_sqs_details.product_name").value != "PRUValue Gain" && document.getElementById("al_sqs_details.product_name").value != "PRUSenior Med" && document.getElementById("al_sqs_details.product_name").value != "PRUSignature Reward" && document.getElementById("al_sqs_details.product_name").value != "PRUEasy Protect" && document.getElementById("al_sqs_details.product_name").value !== "PRUCash Enrich" && document.getElementById("al_sqs_details.product_name").value !== "PRUTerm Premier" && document.getElementById("al_sqs_details.product_name").value !== "PRUAll Care" && document.getElementById("al_sqs_details.product_name").value !== "PRUFlex Gain" && document.getElementById("al_sqs_details.product_name").value !== "PRUSignature Harvest" && document.getElementById("al_sqs_details.product_name").value !== "PRUSignature Harvest Plus" && document.getElementById("al_sqs_details.product_name").value !== "PRUSignature Boost") && (ANB_json[0]["anb_type"]!="IL_Monthly" && ANB_json[0]["anb_type"]!="IL_Daily"))//Added condition for product PRUcancer X on 4 June 18 by ankita//Added condition for optimiser and PRUvalue gain by ankita//Added condition for optimiser and PRUvalue gain by ankita
            {
                alert("330");
                InceptionDateCal();
                return false;
            }
            if(((document.getElementById("al_sqs_details.product_name").value == "PRUwealth gain plus" || document.getElementById("al_sqs_details.product_name").value == "PRUgrowth" || document.getElementById("al_sqs_details.product_name").value == "PRUcancer X" || document.getElementById("al_sqs_details.product_name").value == "PRUSignature Optimiser" || document.getElementById("al_sqs_details.product_name").value == "PRUValue Gain" || document.getElementById("al_sqs_details.product_name").value == "PRUSenior Med" || document.getElementById("al_sqs_details.product_name").value == "PRUSignature Reward"  || document.getElementById("al_sqs_details.product_name").value == "PRUEasy Protect" || document.getElementById("al_sqs_details.product_name").value === "PRUCash Enrich" || document.getElementById("al_sqs_details.product_name").value === "PRUTerm Premier" || document.getElementById("al_sqs_details.product_name").value === "PRUAll Care" || document.getElementById("al_sqs_details.product_name").value === "PRUFlexi Gain" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Harvest" || document.getElementById("al_sqs_details.product_name").value === "PRUGain Plus" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Harvest Plus" || document.getElementById("al_sqs_details.product_name").value === "PRUEnrich Gain" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Boost") && checkIlMonthly) || ((ANB_json[0]["anb_type"]=="IL_Monthly" || ANB_json[0]["anb_type"]=="IL_Daily")))//Added condition for product PRUcancer X on 4 June 18 by ankita//Added condition for optimiser and PRUvalue gain by ankita
            {
               var checkfutureDate=futureDate();
                if(checkfutureDate==false)                 {
                    alert("330");
                    var inceILdate = new Date();
                    if(sysdate!=""){
                         inceILdate = new Date(sysdate);
                    }else{
                         inceILdate = new Date();
                    }
                    var dd = inceILdate.getDate();
                    var mm = inceILdate.getMonth()+1; //January is 0!
                    
                    var yyyy = inceILdate.getFullYear();
                    if(checkIlMonthly)
                    {
                        document.getElementById("al_sqs_details.Inception_dt").value = inceILdate_monthly;
                    }else
                    {
                        inceILdate = dd+'/'+mm+'/'+yyyy;
                        document.getElementById("al_sqs_details.Inception_dt").value = inceILdate;
                    }
                    return false;
                }
            }else if(checkIlMonthly && diffDaysinc<0)
            {
            document.getElementById("al_sqs_details.Inception_dt").value = inceILdate_monthly;
            }else
            {
            console.log("OS SELECTION")
            }
                
            if(backdate_flag) //old condition was !(diffDaysinc<=185) changed by sachin for defect 5865.
            {
                console.log("backdate_flag==>456=="+backdate_flag);
                if((document.getElementById("al_sqs_details.product_name").value == "PRUwealth gain plus" || document.getElementById("al_sqs_details.product_name").value == "PRUgrowth" || document.getElementById("al_sqs_details.product_name").value == "PRUcancer X" || document.getElementById("al_sqs_details.product_name").value == "PRUSignature Optimiser" || document.getElementById("al_sqs_details.product_name").value == "PRUValue Gain" || document.getElementById("al_sqs_details.product_name").value == "PRUSenior Med" || document.getElementById("al_sqs_details.product_name").value == "PRUSignature Reward" || document.getElementById("al_sqs_details.product_name").value == "PRUEasy Protect" || document.getElementById("al_sqs_details.product_name").value === "PRUCash Enrich" || document.getElementById("al_sqs_details.product_name").value === "PRUTerm Premier" || document.getElementById("al_sqs_details.product_name").value === "PRUAll Care" || document.getElementById("al_sqs_details.product_name").value === "PRUFlexi Gain" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Harvest" || document.getElementById("al_sqs_details.product_name").value === "PRUGain Plus" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Harvest Plus" || document.getElementById("al_sqs_details.product_name").value === "PRUEnrich Gain" || document.getElementById("al_sqs_details.product_name").value === "PRUSignature Boost") || ((ANB_json[0]["anb_type"]=="IL_Monthly" || ANB_json[0]["anb_type"]=="IL_Daily")))//Added condition for product PRUcancer X on 4 June 18 by ankita//Added condition for optimiser and PRUvalue gain by ankita
                {
                    alert("292");
                    var inceILdate = new Date();
                    if(sysdate!=""){
                         inceILdate = new Date(sysdate);
                    }else{
                         inceILdate = new Date();
                    }
                    var dd = inceILdate.getDate();
                    var mm = inceILdate.getMonth()+1; //January is 0!
                    
                    var yyyy = inceILdate.getFullYear();
                    
                    inceILdate = dd+'/'+mm+'/'+yyyy;
                    if(checkIlMonthly)
                    {
                    
                    document.getElementById("al_sqs_details.Inception_dt").value = inceILdate_monthly;
                    return false;
                    }else
                    {
                    document.getElementById("al_sqs_details.Inception_dt").value = inceILdate;
                    return false;
                    }
                    
                }
                else
                {
                
                alert("292");
                InceptionDateCal();
                return false;
                }
            }
        }
    }
    console.log("product name:"+document.getElementById("al_sqs_details.product_name").value+"Anb:"+document.getElementById("al_sqs_details.mlife.il_anb").value);
    //added by ankita on 24 July 2019 for defect 7972
    if(document.getElementById("al_sqs_details.product_name").value=="PRUValue Gain" && document.getElementById("al_sqs_details.mlife.il_anb").value>=61 && document.getElementById("al_sqs_details.mlife.il_anb").value<=65)
    {
        var inceptionDate=document.getElementById("al_sqs_details.Inception_dt").value;
        inceptionDate=inceptionDate.split("/");
        var inceDate=inceptionDate[0];
        var inceMonth=(eval(inceptionDate[1]));
        var inceYear=inceptionDate[2];
        console.log("inception Date--->"+inceDate+"/"+inceMonth+"/"+inceYear);

        if(inceDate < 10)
        {
            if(inceDate.length==2)
            {
                console.log("Zero present");
                inceDate = inceDate;
            }
            else
            {
                inceDate = "0" + inceDate;
            }
        }
        if(inceMonth < 10)
        {
            if(inceMonth.length==2)
            {
                console.log("Zero present");
                inceMonth = inceMonth;
            }
            else
            {
                inceMonth = "0" + inceMonth;
            }
            
        }
        var inceptionDateTaken=inceYear+"-"+inceMonth+"-"+inceDate;
        console.log("inceptionDateTaken:"+inceptionDateTaken);
        var productLaunchDate ="2019-08-01";//changed date from 1 july 2019 to 1 august 2019 by ankita on 23 july 2019
        console.log("productLaunchDate:"+productLaunchDate);
        
        var dinceptionDateTaken = new Date(inceptionDateTaken);
        var dproductLaunchDate = new Date(productLaunchDate);
        console.log("dinceptionDateTaken:"+dinceptionDateTaken);
        console.log("dproductLaunchDate:"+dproductLaunchDate);
        
        if(dinceptionDateTaken<dproductLaunchDate)
        {
            alert("781");
            return false;
        }
        
    }
    console.log("canswipe on swipe==>"+canSwipe);
    if(isOkButtonClicked==0)//added UOB condition by ankita on 10 Sept to not show pop up for UOB channel
    {
        return false;
    }
    
    return true;
}
/*Start - Function added by Praveen For Premium Backdate and Product Drop Down*/

function setProductDropdown(prod_res, expiry_age_arr, product_name_arr, comefrom,main_life_response,sec_life_response,third_life_response,product_db_response)
{
    var obj_mlifekeyman = "";
    prodnames = new Array();
    expiryages = new Array();
    document.getElementById("al_sqs_details.product_name").options.length = 0;
    var obj_prod_db_res="";
    if(product_db_response!="" && product_db_response!="(null)" && product_db_response!=null && product_db_response!="{}")
	{
		obj_prod_db_res = JSON.parse(product_db_response);
	}
    if(main_life_response!="" && main_life_response!="(null)" && main_life_response!=null && main_life_response!="{}")
    {
        obj_mlifekeyman = JSON.parse(main_life_response);
    }
//    console.log("product res"+prod_res);
//    console.log("product name array"+product_name_arr);
//    console.log("prod_res.length " + prod_res.length);
    
  //following if condition  code for PRUwith you to Display Product name  in dropdown written by Sachin Tupe on 7 DEC 2017.
    
    
    console.log("@@prod_res"+prod_res);
    console.log("@@expiry_age_arr"+expiry_age_arr);
    console.log("@@product_name_arr"+product_name_arr);
    console.log("@@comefrom"+comefrom);
    
    
    
    var re = /No/;
    var splited_product_string=productCertified.split(",");
    
    
    for (var count_key in splited_product_string) //Added by sachin Tupe for Product Certified product.
    {
        var temp_product=splited_product_string[count_key];
        console.log("temp_product"+temp_product);
        console.log("-->"+splited_product_string[count_key]);
        var split_val=splited_product_string[count_key].match(re);
        console.log("split_val"+split_val);
        console.log("SSpilted product"+splited_product_string[count_key]);
        if(split_val!=null && split_val!="" && split_val!="null")
        {
            
            console.log("getted value"+splited_product_string[count_key]);
            
            var get_value=splited_product_string[count_key].split("_");
            console.log("Final product"+get_value[0]);
            
            if(get_value[0]=="No")
            {
            get_value[0]="PRUwith you"
               // ispruwithyou="No";
            
            }
            
            prod_res = _.filter(prod_res, function(o)
                                     {
                                     console.log("Yes--->"+o)
                                console.log("###get_value--->"+get_value[0]);
                                     return o!=get_value[0];
                                     }
                                     );
            
            product_name_arr = _.filter(product_name_arr, function(o)
                                        {
                                        
                                        return o!==get_value[0];
                                        }
                                        );

            
        }
        
        
    }
    

    console.log("OOObject find"+obj_ILP);
  //  alert("ILP object"+obj_ILP)
    console.log("invest_link_prod"+invest_link_prod);
    if(invest_link_prod=="No") //Following code added by Sachin Tupe for invest link product on  26-06-2018.
    {
    for (var ilp_data in obj_ILP)
    {
       // console.log("ILP PRODUCT"+obj_ILP[ilp_data]['product_name']);
   // if(obj_ILP[ilp_data]['product_name']=="PRUwith you")
        
        prod_res = _.filter(prod_res, function(o)
                            {
                            console.log("Yes"+o)
                            return o!=obj_ILP[ilp_data]['product_name'];
                            }
                            );
        
        product_name_arr = _.filter(product_name_arr, function(o)
                                    {
                                    
                                    return o!==obj_ILP[ilp_data]['product_name'];
                                    }
                                    );

        
        
    }
    }
    
    //New code to remove product if it doesnt have NQAPT // BPS
  
   
    for (sub in obj_prod_db_res)
    {
        console.log("checking prod name.... "+obj_prod_db_res[sub]["product_name"] );
        
       if(channelTypeForAgencyBancaRepls == "uob" && (referral_Database.length!="0" || referral_Database.length!=0))
       {
        for(var i=0;i<=referral_Database.length-1;i++){
            
            if(obj_prod_db_res[sub]["cert_code"]==referral_Database[i]){
                arrayF.push(obj_prod_db_res[sub]["product_name"])
                
            }
            
        }
        
       }
        console.log("Pro name"+ obj_prod_db_res[sub]["product_name"]);
        if (prod_res.indexOf(obj_prod_db_res[sub]["product_name"])>-1)
        {
            console.log("confirm product name in engine... "+obj_prod_db_res[sub]["product_name"]);

            if ((!(fnCheckProductCertification(globalDtAppointmentDate, globalDtCertificationDate, obj_prod_db_res[sub]["cert_code"],productCertified,effectiveDayMBM))) || (!(checkEligable(obj_mlifekeyman["al_person_details.mlife.insu_type"],obj_prod_db_res[sub]["product_name"]))))// or condition added for BPS for product filtration according to the insurance type 1st august 2019
                {
                    prod_res = _.filter(prod_res, function(o)
                                {
                                console.log("Yes-->"+o)
                                return o!=obj_prod_db_res[sub]["product_name"];
                                }
                                );
            
                    product_name_arr = _.filter(product_name_arr, function(o)
                                        {
                                        
                                        return o!==obj_prod_db_res[sub]["product_name"];
                                        }
                                        );
                    
                    
                    
                }
        }
        //BPS
        console.log("prod_resBB--->"+prod_res);
       
        console.log("product_name_arrBB--->"+product_name_arr);
        
        //BPS End here
    }
    
  
    if(msqg_mainlife_response=="SUSPENSE" || msqg_mainlife_response=="SUSPENDED")
    {
    if(msqgresponseobject!="" && msqgresponseobject!=null && msqgresponseobject!={} && msqgresponseobject!="{}" && msqgresponseobject!='undefined' && msqgresponseobject!=undefined)//Added for msqq product filteration
    {
    for (var msqg_data in msqgresponseobject)
    {
        // console.log("ILP PRODUCT"+obj_ILP[ilp_data]['product_name']);
        // if(obj_ILP[ilp_data]['product_name']=="PRUwith you")
        
        prod_res = _.filter(prod_res, function(o)
                            {
                            console.log("Yes"+o)
                            return o!=msqgresponseobject[msqg_data]['product_name'];
                            }
                            );
        
        product_name_arr = _.filter(product_name_arr, function(o)
                                    {
                                    
                                    return o!==msqgresponseobject[msqg_data]['product_name'];
                                    }
                                    );
        
        
        
    }
    
    
}
    
    
    }
    /*Piyush: ILP sqs blocking changes related to filtering of product as per ILP prod training for Banca and UOB*/
    if(ILP_Sqs_Blocking_response =="On" && invest_link_prod_training !== "Yes" && (channelTypeForAgencyBancaRepls == "banca" || channelTypeForAgencyBancaRepls == "uob"))
    {
        console.log("Inside blocking code yes")
        for (var ilp_data in obj_ILP)
        {
            
            prod_res = _.filter(prod_res, function(o)
                                {
                                console.log("Yes"+o)
                                return o!=obj_ILP[ilp_data]['product_name'];
                                }
                                );
            product_name_arr = _.filter(product_name_arr, function(o)
                                        {
                                        return o!==obj_ILP[ilp_data]['product_name'];
                                        }
                                        );
        }
    }
    /*Piyush: ILP sqs blocking changes related to filtering of product as per ILP prod training for Banca and UOB code ends*/
   
    /**********/
    
 /**** COMMENTED FOR PRODUCT CERTIFIED ENHANCEMENT   if(productCertified=="No")
    {
       
        prod_res = _.filter(prod_res, function(o)
                              {
                            return o!="PRUwith you";
                              }
                              );
    
        product_name_arr = _.filter(product_name_arr, function(o)
                            {
                           
                            return o!=="PRUwith you";
                            }
                            );
     
        
    }******/
    for (var j = 0; j <= product_name_arr.length - 1; j++)
    {
        prodnames[j] = product_name_arr[j];
        expiryages[j] = expiry_age_arr[j];
        
        console.log("##prodnames"+prodnames[j]+" "+"expiryages"+expiryages[j])
    }
    console.log("ANB changes:----"+prod_res.length);
    console.log("products in dropdown list:"+prod_res);
    if (prod_res.indexOf("PRUValue Gain")>-1 || prod_res.indexOf("PRUSignature Reward")>-1 || prod_res.indexOf("PRUSignature Harvest")>-1 || prod_res.indexOf("PRUSignature Harvest Plus")>-1 || prod_res.indexOf("PRUSignature Boost")>-1)
    {
         console.log("Inside yes PRUValue Gain");
        //added by ankita on 22 July 2019 for defect 7953
        var inceptionDate ="";
        console.log("obj_prochoice123456:"+obj_prochoice["al_sqs_details.Inception_dt"]);
        if(obj_prochoice["al_sqs_details.Inception_dt"]!="" && obj_prochoice["al_sqs_details.Inception_dt"]!=undefined)
        {
            console.log("Inside yes obj_prochoice PRUValue Gain");
            
            if(document.getElementById("al_sqs_details.Inception_dt").value!="" && document.getElementById("al_sqs_details.Inception_dt").value!=undefined)
            {
                inceptionDate = document.getElementById("al_sqs_details.Inception_dt").value
            }
            else
            {
                inceptionDate = obj_prochoice["al_sqs_details.Inception_dt"];
            }
        }
        else
        {
            console.log("Inside yes PRUValue Gain");
            inceptionDate =document.getElementById("al_sqs_details.Inception_dt").value;
        }
        //var inceptionDate =document.getElementById("al_sqs_details.Inception_dt").value;
        inceptionDate=inceptionDate.split("/");
        var inceDate=inceptionDate[0];
        var inceMonth=(eval(inceptionDate[1]));
        var inceYear=inceptionDate[2];
        console.log("inception Date--->"+inceDate+"/"+inceMonth+"/"+inceYear);
        console.log("main_life_response"+main_life_response);
        var obj_mlife=JSON.parse(main_life_response);
        console.log("obj_mlife:=="+JSON.stringify(obj_mlife));
        var dob_mlife = obj_mlife["al_person_details.mlife.dob"].split("/");
        var anbToCheckForBackdate=fnMsCalculateANBILProductsInBackdate(parseInt(dob_mlife[0]), parseInt(dob_mlife[1]), parseInt(dob_mlife[2]), parseInt(inceDate), parseInt(inceMonth), parseInt(inceYear));//Added parse int to pass in the anb calculations function for defect 7924
        console.log("anbToset:=="+anbToCheckForBackdate);
        
        
        
        var productLaunchDate ="2019-08-01";//changed date from 1 july 2019 to 1 august 2019 by ankita on 23 july 2019
        console.log("productLaunchDate:"+productLaunchDate);
        if(inceDate < 10)
        {
            if(inceDate.length==2)
            {
                console.log("Zero present");
                inceDate = inceDate;
            }
            else
            {
                inceDate = "0" + inceDate;
            }
        }
        if(inceMonth < 10)
        {
            if(inceDate.length==2)
            {
                console.log("Zero present");
                inceMonth = inceMonth;
            }
            else
            {
                inceMonth = "0" + inceMonth;
            }
            
        }
        var inceptionDateTaken=inceYear+"-"+inceMonth+"-"+inceDate;
        console.log("inceptionDateTaken:"+inceptionDateTaken);
        
        var dinceptionDateTaken = new Date(inceptionDateTaken);
        var dproductLaunchDate = new Date(productLaunchDate);
        console.log("dinceptionDateTaken:"+dinceptionDateTaken);
        console.log("dproductLaunchDate:"+dproductLaunchDate);
        if(anbToCheckForBackdate>=61 && anbToCheckForBackdate<=65)
        {
            if(dinceptionDateTaken<dproductLaunchDate)
            {
                console.log("True");
                prod_res = _.filter(prod_res, function(dropdownResponse)
                                    {
                                    console.log("Yes dropdownResponse:"+dropdownResponse)
                                    return dropdownResponse!="PRUValue Gain";
                                    }
                                    );
                product_name_arr = _.filter(product_name_arr, function(dropdownResponseName)
                                            {
                                            
                                            return dropdownResponseName!="PRUValue Gain";
                                            }
                                            );
                // break;
                
            }
            else
            {
                console.log("False");
            }
        }
    }
    if((prod_res.indexOf("PRUWealth Max")>-1 || prod_res.indexOf("PRUWealth Max")>-1) || (prod_res.indexOf("PRUMax Cover")>-1 || prod_res.indexOf("PRUMax Cover")>-1) || (prod_res.indexOf("PRULink Supreme")>-1 || prod_res.indexOf("PRULink Supreme")>-1) || (prod_res.indexOf("PRUElite Invest")>-1) || (prod_res.indexOf("PRUSignature GrowthPlus")>-1) || (prod_res.indexOf("PRULink Supreme Plus")>-1)) {
        
        var return_product_name="";
        if(prod_res.indexOf("PRUWealth Max")>-1) {
            return_product_name="PRUWealth Max";
            
        }
                                       //code commented for defect 535 on date by sachin
//       else if(prod_res.indexOf("PRULink Supreme")>-1) {
//            //return_product_name="PRULink Supreme";
//
//        }
        else
                                       {
             return_product_name="PRUMax Cover";
            
        }
        
        
             if(checkDateDiff<=29) {
                 
                prod_res = _.filter(prod_res,function(data_value) {
                                     
                                     
                                     return data_value!= return_product_name;
                                     
                                     
                                     });
                 
                 product_name_arr = _.filter(product_name_arr,function(data_values){
                                            
                                            
                                             return data_values!= return_product_name;
                                            
                                            });
                 
                 
             }
        
        
    }
    
    if(channelTypeForAgencyBancaRepls == "uob" && (arrayF.length!="0" || arrayF.length!=0)){
        
        prod_res = _.filter(prod_res,function(data_value) {
                            
                            
                            for(var i=0;i<=arrayF.length-1;i++){
                            
                            if(data_value==arrayF[i]){
                            console.log("Contion true")
                            return true;
                            }
                            }
                          
                            
                            
                            });
        
        product_name_arr = _.filter(product_name_arr,function(data_values){
                                    
                                    
                                    return data_values!= return_product_name;
                                    
                                    });
        
        
    }

             
        if(referralILP !== "Yes" && (channelTypeForAgencyBancaRepls == "uob"))
            {
                console.log("Inside referral code blocking code yes")
                                for (var ilp_data in obj_ILP)
                                             {
                                                 
                                                 prod_res = _.filter(prod_res, function(o)
                                                                     {
                                                                     console.log("Yes"+o)
                                                                     return o!=obj_ILP[ilp_data]['product_name'];
                                                                     }
                                                                     );
                                                 product_name_arr = _.filter(product_name_arr, function(o)
                                                                             {
                                                                             return o!==obj_ILP[ilp_data]['product_name'];
                                                                             }
                                                                             );
                                             }
            }
                                       
                                       
       /***************************************/
        
                                       console.log("@@prod_res",prod_res)
                                       console.log("@@product_name_arr",product_name_arr)
                                       
                                       if(channelTypeForAgencyBancaRepls=="banca"){
                                       
                                       if(obj_priority.indexOf("PRUSignature Infinite")>-1)
                                       {
                                         var indexIs =obj_priority.indexOf("PRUSignature Infinite");
                                         obj_priority[indexIs]="PRUsignature infinite";
                                       
                                       }
                                       
                                       if(obj_priority.indexOf("PRUSignature")>-1){
                                        var indexNo =obj_priority.indexOf("PRUSignature");
                                       obj_priority[indexNo]="PRUsignature";
                                       
                                       }
                                       if(obj_priority.indexOf("PRUSignature Prime")>-1){
                                        var indexofNo =obj_priority.indexOf("PRUSignature Prime");
                                       obj_priority[indexofNo]="PRUsignature prime";
                                       
                                       }
                                       
                                       
         if(obj_priority!="" && obj_priority!=null && obj_priority!={} && obj_priority!="{}" && obj_priority!='undefined' && obj_priority!=undefined)
                                           {
                                           
                                           prod_res = prod_res.filter(function(n) {
                                               return obj_priority.indexOf(n) !== -1;
                                           });
                                           product_name_arr = product_name_arr.filter(function(n) {
                                               return obj_priority.indexOf(n) !== -1;
                                           });
                                           
                                           }
                                       
                                       
                                      
                                       }
                                       
                                       
                                       
                                       
    /****************************************/
                                       
                                       
                                       
    
                                       
    
                                       
    if(prod_res.length!="0")
    {
        for (var i = 0; i < prod_res.length; i++)
        {
            console.log("products in dropdown list Before:"+prod_res);
            
            
           
           /* if(prod_res[i]=="PRUValue Gain")
            {
                var inceptionDate = document.getElementById("al_sqs_details.Inception_dt").value;
                inceptionDate=inceptionDate.split("/");
                var inceDate=inceptionDate[0];
                var inceMonth=inceptionDate[1];
                var inceYear=inceptionDate[2];
               
                
                
                var inceptionDate =document.getElementById("al_sqs_details.Inception_dt").value;
                inceptionDate=inceptionDate.split("/");
                var inceDate=inceptionDate[0];
                var inceMonth=(eval(inceptionDate[1]));
                var inceYear=inceptionDate[2];
                console.log("inception Date--->"+inceDate+"/"+inceMonth+"/"+inceYear);
                console.log("main_life_response"+main_life_response);
                var obj_mlife=JSON.parse(main_life_response);
                console.log("obj_mlife:=="+JSON.stringify(obj_mlife));
                var dob_mlife = obj_mlife["al_person_details.mlife.dob"].split("/");
                var anbToCheckForBackdate=fnMsCalculateANBILProductsInBackdate(dob_mlife[0], dob_mlife[1], dob_mlife[2], inceDate, inceMonth, inceYear);
                console.log("anbToset:=="+anbToCheckForBackdate);
                
                var inceptionDateTaken=inceYear+"-"+inceMonth+"-"+inceDate;
                console.log("inceptionDateTaken:"+inceptionDateTaken);
                var productLaunchDate ="2019-7-01";
                console.log("productLaunchDate:"+productLaunchDate);
                
                
                if(anbToCheckForBackdate>=61 && anbToCheckForBackdate<=65)
                {
                    if(inceptionDateTaken<productLaunchDate)
                    {
                        console.log("True");
                        prod_res = _.filter(prod_res, function(dropdownResponse)
                                            {
                                            console.log("Yes dropdownResponse:"+dropdownResponse)
                                            return dropdownResponse!="PRUValue Gain";
                                            }
                                            );
                        product_name_arr = _.filter(product_name_arr, function(dropdownResponseName)
                                                    {
                                                    
                                                    return dropdownResponseName!="PRUValue Gain";
                                                    }
                                                    );
                       // break;
                        
                    }
                    else
                    {
                        console.log("False");
                    }
                }
                
            }*/
             console.log("products in dropdown list After:"+prod_res);
            
            if (prod_res.length == 1)
            {
                if(prod_res[i]=="PRUterm_scb")
                {
                    console.log("cxheckEligable:--4982")
                   // if(checkEligable(obj_mlifekeyman["al_person_details.mlife.insu_type"],prod_res[i])){
                    var optn1 = document.createElement("OPTION");
                    optn1.text = prod_res[i].substring(0,prod_res[i].length-4);
                    optn1.text= productNameModifier(optn1.text);
                    optn1.value = prod_res[i];

                    document.getElementById("al_sqs_details.product_name").appendChild(optn1);
                   // }
                }
                else
                {
                    console.log("cxheckEligable:--4993")
                    //if(checkEligable(obj_mlifekeyman["al_person_details.mlife.insu_type"],prod_res[i])){
                    var optn1 = document.createElement("OPTION");
                    optn1.text = prod_res[i];
                    optn1.text= productNameModifier(optn1.text);
                    optn1.value = prod_res[i];
                    console.log("option text"+optn1.text);
                    console.log("option value"+optn1.value);
                    
                    document.getElementById("al_sqs_details.product_name").appendChild(optn1);
                    //}
                }
                
                console.log("ANB Value SetProdDropdown1:"+document.getElementById("al_sqs_details.mlife.il_anb").value);
                console.log("ANB Value SetProdDropdown2:"+document.getElementById("al_sqs_details.slife.il_anb").value);
                console.log("ANB Value SetProdDropdown3:"+obj_prochoice["al_sqs_details.mlife.il_anb"]);
                console.log("Inception date :::"+obj_prochoice["al_sqs_details.Inception_dt"]);
                document.getElementById("al_sqs_details.product_name").disabled = true;
                var obj_mlife="";
                var obj_slife="";
                var obj_tlife="";
                
                var szSelectedProduct;
                var szSelectedProducttype ="";
                if(isCallFromDatePicker == "No")
                {
                    var inceILdate = new Date();
                    if(sysdate!=""){
                         inceILdate = new Date(sysdate);
                    }else{
                         inceILdate = new Date();
                    }
                    var dd = inceILdate.getDate();
                    var mm = inceILdate.getMonth()+1; //January is 0!
                    
                    var yyyy = inceILdate.getFullYear();
                    inceILdate = dd+'/'+mm+'/'+yyyy;
                    document.getElementById("al_sqs_details.Inception_dt").value = inceILdate;
                }
                if(product_db_response!="" && product_db_response!="(null)" && product_db_response!=null && product_db_response!="{}")
                {
                    szSelectedProduct =  _.where(obj_prod_db_res, {"product_name":document.getElementById("al_sqs_details.product_name").value});
                    szSelectedProducttype = szSelectedProduct[0]["product_core_system"];
                }
                if(main_life_response!=""  && main_life_response!="null" && main_life_response!="(null)" && main_life_response!=null && main_life_response!="{}")
                {
                    obj_mlife = JSON.parse(main_life_response);
                    if(szSelectedProducttype == "IL")
                    {
                        document.getElementById("al_sqs_details.mlife.il_anb").value=obj_mlife["al_person_details.mlife.anb_il_product"];
                    }
                    else if(szSelectedProducttype == "OS")
                    {
                        document.getElementById("al_sqs_details.mlife.il_anb").value=obj_mlife["al_person_details.mlife.anb"];
                    }
                    
                    if(sec_life_response!="" && sec_life_response!="null" && sec_life_response!="(null)" && sec_life_response!=null && sec_life_response!="{}")
                    {
                        obj_slife = JSON.parse(sec_life_response);
                        if(szSelectedProducttype == "IL")
                        {
                            document.getElementById("al_sqs_details.slife.il_anb").value=obj_slife["al_person_details.slife.anb_il_product"];
                        }
                        else if(szSelectedProducttype == "OS")
                        {
                            document.getElementById("al_sqs_details.slife.il_anb").value=obj_slife["al_person_details.slife.anb"];
                        }
                        if(third_life_response!="" && third_life_response!="null" && third_life_response!="(null)" && third_life_response!=null && third_life_response!="{}")
                        {
                            obj_tlife = JSON.parse(third_life_response);
                            if(szSelectedProducttype == "IL")
                            {
                                document.getElementById("al_sqs_details.tlife.il_anb").value=obj_tlife["al_person_details.tlife.anb_il_product"];
                            }
                            else if(szSelectedProducttype == "OS")
                            {
                                document.getElementById("al_sqs_details.tlife.il_anb").value=obj_tlife["al_person_details.tlife.anb"];
                            }
                        }
                    }
                }
                console.log("Backdate SetProdDropdown3:"+document.getElementById("al_sqs_details.payment_backdate"));
                
                
                
                /*if(prod_res[i]=="PRUSignature Optimiser" && (document.getElementById("al_sqs_details.mlife.il_anb").value == "" && document.getElementById("al_sqs_details.slife.il_anb").value))
                {
                    var optn = document.createElement("OPTION");
                    optn.text = "Product";
                    optn.value = "Select Products";
                    document.getElementById("al_sqs_details.product_name").appendChild(optn);
                }*/
                
                
                 console.log("@@SecondLifeEaseCampaignCode"+SecondLifeEaseCampaignCode);
                 console.log("@@ThirdLifeEaseCampaignCode"+ThirdLifeEaseCampaignCode);
                /**********@ADDED CODE FOR PWY EASE CR BY SACHIN TUPE ON DATE 4-09-2018*************/
                if(ThirdLifeEaseCampaignCode)
                {
                                       //change 40 to 46 by ankita on 20 dec 2022 for pruwith you new rider changes
                    //added 5 th point in alert message by ankita on 2 jan 2023 for new wording changes of pruwith you
                                       //barcket for (easeCampaignCode=="EASE1" || easeCampaignCode=="EASE2") added by ankita on 2 jan 2023
                                       
                    if((document.getElementById("al_sqs_details.product_name").value == "PRUwith you") && (easePreCase=="Yes" && easeGestWeeek<=17) && ((easeGenderInfothirdLife=="Female") && (easeILThirdlifeanb>=18 && easeILThirdlifeanb<=46) && (easeSmokingStatusthirdLife!="Smoker")) &&  (easeCampaignCode!="" && (easeCampaignCode=="EASE1" || easeCampaignCode=="EASE2")) && !from_benefit_page)
                    {
                        canSwipe=0;
                        // easeCampaignCode="EASE1";
                        bootbox.alert({
                                      className: "my-popup",
                                      message: "<h5><font size='2'>Congratulation! This proposal is eligible for EASE provided  <b>ALL</b> the criteria below are met:  <br> (i) Mother or her spouse/partner has never been tested for or told to have, received or expect to receive medical advice, counselling or treatment in connection with HIV, AIDS, AIDS related complex or any other AIDS related condition;  <br> (ii) Mother has never undergone artificial insemination and/or assisted reproductive technology, example in vitro fertilization (IVF) or other procedures in respect of this pregnancy; <br>(iii) Mother has never performed any prenatal genetic testing in respect of this pregnancy; <br>(iv) Mother's current pregnancy has not more than two foetuses; and <br>(v) Mother has never been told that the foetus was found to have or suspected to have any abnormality of the foetus (eg. Down’s Syndrome, abnormal foetal size, congenital disorder).<br><br>The maximum Essential Child Plus Sum Assured for EASE is RM100,000. If any of the above not met and/or proposed Sum Assured  for Essential Child Plus is > RM100,000, Health Questionnaire is required to be completed.</h5>",
                                      callback: function ()
                                      {
                                      canSwipe=1;
                                      vpmsEaseCampaignCode=easeCampaignCode;
                                      
                                      }
                                      });
                        
                    }
                    else if(!from_benefit_page)
                    {
                        
                        vpmsEaseCampaignCode="";
                    }
                    
 
                    
                
                }
                 if(SecondLifeEaseCampaignCode)
                {
                                       //change 40 to 46 by ankita on 20 dec 2022 for pruwith you new rider changes
                //added 5 th point in alert message by ankita on 2 jan 2023 for new wording changes of pruwith you
                                       //barcket for (easeCampaignCode=="EASE1" || easeCampaignCode=="EASE2") added by ankita on 2 jan 2023
                    if((document.getElementById("al_sqs_details.product_name").value == "PRUwith you") && (easePreCase=="Yes" && easeGestWeeek<=17) && ((easeGenderInfo=="Female") && (easeILSecondlifeanb>=18 && easeILSecondlifeanb<=46 ) && (easeSmokingStatus!="Smoker")) &&  (easeCampaignCode!="" && (easeCampaignCode=="EASE1" || easeCampaignCode=="EASE2")) && !from_benefit_page)
                    {
                        canSwipe=0;
                        // easeCampaignCode="EASE1";
                        bootbox.alert({
                                      className: "my-popup",
                                      message: "<h5><font size='2'>Congratulation! This proposal is eligible for EASE provided  <b>ALL</b> the criteria below are met:  <br> (i) Mother or her spouse/partner has never been tested for or told to have, received or expect to receive medical advice, counselling or treatment in connection with HIV, AIDS, AIDS related complex or any other AIDS related condition;  <br> (ii) Mother has never undergone artificial insemination and/or assisted reproductive technology, example in vitro fertilization (IVF) or other procedures in respect of this pregnancy; <br>(iii) Mother has never performed any prenatal genetic testing in respect of this pregnancy; <br>(iv) Mother's current pregnancy has not more than two foetuses; and <br>(v) Mother has never been told that the foetus was found to have or suspected to have any abnormality of the foetus (eg. Down’s Syndrome, abnormal foetal size, congenital disorder).<br><br>The maximum Essential Child Plus Sum Assured for EASE is RM100,000. If any of the above not met and/or proposed Sum Assured  for Essential Child Plus is > RM100,000, Health Questionnaire is required to be completed.</h5>",
                                      callback: function ()
                                      {
                                      canSwipe=1;
                                      vpmsEaseCampaignCode=easeCampaignCode;
                                      
                                      
                                      }
                                      });
                        
                    }
                  else if(!from_benefit_page)
                    {
                     vpmsEaseCampaignCode="";
                    }

                
                }
             /********************************************************
                if((document.getElementById("al_sqs_details.product_name").value == "PRUwith you") && (easePreCase=="Yes" && easeGestWeeek<=17) && ((easeGenderInfo=="Female" || easeGenderInfothirdLife=="Female") && (easeILSecondlifeanb>=18 && easeILSecondlifeanb<=40 || easeILThirdlifeanb>=18 && easeILThirdlifeanb<=40) && (easeSmokingStatus!="Smoker" || easeSmokingStatusthirdLife!="Smoker")) &&  (easeCampaignCode!="" && easeCampaignCode=="EASE1" || easeCampaignCode=="EASE2") && !from_benefit_page)
                {
                    canSwipe=0;
                   // easeCampaignCode="EASE1";
                    bootbox.alert({
                                className: "my-popup",
                                message: "<h5><font size='2'>Congratulation! This proposal is eligible for EASE provided  <b>ALL</b> the criteria below are met:  <br> (i) Mother or her spouse/partner has never been tested for or told to have, received or expect to receive medical advice, counselling or treatment in connection with HIV, AIDS, AIDS related complex or any other AIDS related condition;  <br> (ii) Mother has never undergone artificial insemination and/or assisted reproductive technology, example in vitro fertilization (IVF) or other procedures in respect of this pregnancy; <br>(iii) Mother has never performed any prenatal genetic testing in respect of this pregnancy; and  <br>(iv) Mother's current pregnancy has not more than two foetuses. <br><br>The maximum Essential Child Plus Sum Assured for EASE is RM100,000. If any of the above not met and/or proposed Sum Assured  for Essential Child Plus is > RM100,000, Health Questionnaire is required to be completed.</h5>",
                                  callback: function ()
                                  {
                                  canSwipe=1;
                                  
                                  }
                                  });
                
                }
               
              /***********************************END**********************************************/
                
            } else
            {
                if (i == 0)
                {
                    console.log("cxheckEligable:--5163")
                   // if(checkEligable(obj_mlifekeyman["al_person_details.mlife.insu_type"],prod_res[i])){
                    var optn = document.createElement("OPTION");
                    optn.text = "Product";
                    optn.value = "Select Products";
                    document.getElementById("al_sqs_details.product_name").appendChild(optn);
                   // }
                }
                if(prod_res[i]=="PRUterm_scb")
                {
                    console.log("cxheckEligable:--5172")
                   // if(checkEligable(obj_mlifekeyman["al_person_details.mlife.insu_type"],prod_res[i])){
                    var optn1 = document.createElement("OPTION");
                    optn1.text = prod_res[i].substring(0,prod_res[i].length-4);
                    optn1.text= productNameModifier(optn1.text);
                    optn1.value = prod_res[i];
                    
                    document.getElementById("al_sqs_details.product_name").appendChild(optn1);
                   // }
                }
                else
                {
                    console.log("cxheckEligable:--5183")
                   // if(checkEligable(obj_mlifekeyman["al_person_details.mlife.insu_type"],prod_res[i])){
                    var optn1 = document.createElement("OPTION");
                    optn1.text = prod_res[i];
                    optn1.text= productNameModifier(optn1.text);
                    optn1.value = prod_res[i];
                    console.log("option 1 text"+optn1.text);
                    console.log("option 1 value"+optn1.value);
                    document.getElementById("al_sqs_details.product_name").appendChild(optn1);
                   // }
                    document.getElementById("al_sqs_details.product_name").disabled = false;
                    
                    
                    
                }
            }
        }
    }
    else if(prod_res.length==0)
    {
        //if(checkEligable(obj_mlifekeyman["al_person_details.mlife.insu_type"],prod_res[i])){
        var optn = document.createElement("OPTION");
        optn.text = "Product";
        optn.value = "Select Products";
        document.getElementById("al_sqs_details.product_name").appendChild(optn);
        //}
        document.getElementById("al_sqs_details.product_name").disabled = false;
      
     
    }
    
    
    
    // Pramod Chavan 27032017 Dummy product added for testing need to remove after engine merging TODO.

  /* var optn1 = document.createElement("OPTION");
   var optn1 = document.createElement("OPTION");


    optn1.text = "PRUMax Cover";
    optn1.value ="PRUMax Cover";
  
    document.getElementById("al_sqs_details.product_name").appendChild(optn1);*/
   
    
    
    
    if (comefrom == "bck")
    {
        ShowFunds(comefrom);
        console.log("--Call from here--");
    }
}
/*End -  Function added by Praveen For Premium Backdate and Product Drop Down*/

/*Start - Function for added by Praveen validation Engine Call on change of Inceptiondate*/

// TODO
function generateinputstringBackdate()
{
    var strMLife="EMPTY";
    var strSLife="EMPTY::";
    var strTLife="EMPTY";
    var strpersonaldetails="::EMPTY";
    var obj_mlife_res="";
    var obj_slife_res="";
    var obj_tlife_res="";
    var yeargw="";
    var ilMlifeAge="";
    var pathDetails="";
    var RelationshipMlife="NA";
    var slife_relationship="";
    var tlife_relationship="";
    js_get_var("main_life_response",function(main_life_response)
    {
     js_get_var("sec_life_response",function(sec_life_response)
        {
        js_get_var("third_life_response",function(third_life_response)
        {
           if(main_life_response!="" && main_life_response!="(null)" && main_life_response!=null && main_life_response!="{}")
               {
                obj_mlife_res=JSON.parse(main_life_response);
                   console.log("obj_mlife_res---SR->"+obj_mlife_res);
                if(obj_mlife_res["al_person_details.pre_natal_child_flg"]=="Yes")
                   {
                       yeargw=obj_mlife_res["al_person_details.gestational_week"]+"GW";
                       ilMlifeAge=obj_mlife_res["al_person_details.gestational_week"]+"GW";
                   }
                   else
                   {
                       yeargw=obj_mlife_res["al_person_details.mlife.anb"]+"Years";
                       ilMlifeAge=obj_mlife_res["al_person_details.mlife.anb_il_product"]+"Years";
                   }
                       strMLife = "ML={Age=" + yeargw + ",ILAge=" + ilMlifeAge+ ",Occupation=" + obj_mlife_res["al_employee_details.mlife.occupation"].split("-")[0].replace(":","") + ",Gender=" + obj_mlife_res["al_person_details.mlife.gender"] + ",Relationship=" +RelationshipMlife+ ",Occupation_class=" +obj_mlife_res["al_employee_details.mlife.occupation_class"]+ ",Parent_consent="+obj_mlife_res["al_person_details.mlife.parent_consent"]+"}::";
                   if(obj_mlife_res["pamb_channel"]=="Agency")
                   {
                        pathDetails="Agency";
                   }
                   else if(obj_mlife_res["pamb_channel"]=="FA")   // Piyush(03/12/2018) : Added this changes for new channel FA
                   {
                        pathDetails="FA";
                   }
                   else
                   {
                   console.log("obj_mlife_res----SR->"+obj_mlife_res["pamb_sub_channel"]);
                   //changed by Purva / Pramod C on 07th Aug 2017 for UOB
                       if(obj_mlife_res["pamb_sub_channel"]=="SCB_STF")
                       {
                         pathDetails="Banca/SCB_STF";
                         console.log("In Banca/SCB_STF-->");
                       }
                       else if(obj_mlife_res["pamb_channel"]=="Banca")
                       {
                         console.log("In Banca/SCB-->");
                         pathDetails="Banca/SCB";
                       }
                       else if(obj_mlife_res["pamb_channel"]=="UOB")
                       {
                             //change the path for UOB channel depending upon the structure by Purva / Pramod C
                           console.log("In UOB channel -->");
                            pathDetails="UOB/" + obj_mlife_res["pamb_sub_channel"];//changed by Purva on 11th Aug 2017 for Sub channel column addition
                   
                       }

                   }
                   if(obj_mlife_res["al_sqs_details.sec_parti_flag"]=="Yes")
                   {
                    if(sec_life_response!="" && sec_life_response!="{}" && sec_life_response!=null && sec_life_response!="(null)")
                      {
                          obj_slife_res=JSON.parse(sec_life_response);
                          if(obj_slife_res["al_person_details.slife.relationship"]=="Legal Guardian")
                          {
                                slife_relationship="LegalGuardian"
                          }
                          else
                          {
                                slife_relationship=obj_slife_res["al_person_details.slife.relationship"];
                          }
                          strSLife = "SL={Age=" + obj_slife_res["al_person_details.slife.anb"]+ "Years,ILAge=" +obj_slife_res["al_person_details.slife.anb_il_product"] + "Years,Occupation=" + obj_slife_res["al_employee_details.slife.occupation"].split("-")[0].replace(":","") + ",Gender=" + obj_slife_res["al_person_details.slife.gender"] + ",Relationship=" + slife_relationship + ",Occupation_class=" +obj_slife_res["al_employee_details.slife.occupation_class"]+ "}::"
                          if(obj_slife_res["al_sqs_details.third_parti_flg"]=="Yes")
                          {
                             if(third_life_response!="" && third_life_response!="{}" && third_life_response!=null && third_life_response!="(null)")
                             {
                                 obj_tlife_res=JSON.parse(third_life_response);
                                 if(obj_tlife_res["al_person_details.tlife.relationship"]=="Legal Guardian")
                                 {
                                    tlife_relationship="LegalGuardian";
                                 }
                                 else
                                 {
                                    tlife_relationship=obj_tlife_res["al_person_details.tlife.relationship"];
                                 }
                                 strTLife = "TL={Age=" + obj_tlife_res["al_person_details.tlife.anb"]+ "Years,ILAge=" +obj_tlife_res["al_person_details.tlife.anb_il_product"] + "Years,Occupation=" + obj_tlife_res["al_employee_details.tlife.occupation"].split("-")[0].replace(":","") + ",Gender=" + obj_tlife_res["al_person_details.tlife.gender"] + ",Relationship=" + tlife_relationship + ",Occupation_class=" +obj_tlife_res["al_employee_details.tlife.occupation_class"]+ "}::"
                             }
                          }
                      }
                   }
               }
                   strpersonaldetails=strMLife+strSLife+strTLife;

                   CallValidationEngine(strpersonaldetails,pathDetails,main_life_response,sec_life_response,third_life_response);//5 March

           });
        });
    });
}

function CallValidationEngine(personaldetails,pathDetails,main_life_response,sec_life_response,third_life_response)
{
    
    
    var pagedata={
        "personal_details_string":personaldetails,
        "product_string":"EMPTY",
        "loading_string":"EMPTY",
        "rider_string":"EMPTY",
        "current_plan_string":"EMPTY",
        "current_rider_string":"EMPTY",
        "csv_folder_path":pathDetails,
        "iRFlag":0
    }
    var selectQuery = getProductsFromDevice(obj_mlife["pamb_channel"]);
    selectQuery.execute(function(product_response)
    {
        js_call_native_func("ValidationEngineCall", pagedata, function(response)
        {
            js_get_var("product_name", function(response_prod_name)
            {
                       console.log("ANB changes response--->"+response);
                       if(response == "3000" || response =="" || response==3000)
                       {
                       // added for DEF-4518
                       console.log("No product returned from the engine...");
                       document.getElementById("al_sqs_details.product_name").options.length = 0;
                       var optn = document.createElement("OPTION");
                       optn.text = "Product";
                       optn.value = "Select Products";
                       document.getElementById("al_sqs_details.product_name").appendChild(optn);
                       document.getElementById("al_sqs_details.product_name").disabled = false;
                       document.getElementById("al_sqs_details.mlife.il_anb").value="";
                       document.getElementById("al_sqs_details.slife.il_anb").value="";
                       document.getElementById("al_sqs_details.tlife.il_anb").value="";
                       alert("386");
                       
                       }else{
                if (response.indexOf("Error")==-1)
                {
                    var per_valid_res = "[";;
                    var mparms = response.split("||");

                    for (var mProdcount = 0; mProdcount < mparms.length - 1; mProdcount++)
                    {
                        var parms = mparms[mProdcount].split('::');
                        per_valid_res = per_valid_res + "{";;
                        var product_name_from_engine;
                        var expiry_age_from_engine;
                      
                        for (j = 0; j < 2; j++)
                        {
                            if (j == 0)
                            {
                                product_name_from_engine = parms[0].split("=")[1];
                            }
                            else if (j == 1)
                            {
                                expiry_age_from_engine = parms[1].split("=")[1];
                            }
                        }

                        per_valid_res += '"al_sqs_details.product_name":"' + product_name_from_engine + '","al_sqs_details.expiry_age":"' + expiry_age_from_engine + '"';
                        per_valid_res += "},";
                    }
                    per_valid_res = per_valid_res.slice(0, - 1);
                    per_valid_res += "]"; //IOS17 7 sept 2023 Paromita/Sourabh (previous code was per_valid_res += "];";) just removed semicolon as IOS17 was giving issue for product filtration
                    console.log("SR --1-- in callvalidation Engine per_valid_res="+JSON.stringify(per_valid_res));
                    js_set_var("prod_choice_res", JSON.stringify(per_valid_res), function()
                    {
                          console.log("@@Call 2")
                        filterProducts(product_response, JSON.stringify(per_valid_res), document.getElementById("al_sqs_details.Inception_dt").value, "bck",main_life_response,sec_life_response,third_life_response);
                        product_choice_details(0);
                    });
                }
                       }
            });
        });
    });
}
/*End - Function for added by Praveen validation Engine Call on change of Inceptiondate*/

/*Start - Function Added by Praveen for Product Filter Logic*/
//change the path for UOB channel depending upon the structure  by Purva / Pramod C
function getProductsFromDevice(channelName)
{
    var selected_channel = channelName;
    // if sub channel is  SCB_STF and channel is Banca, then the channel name cannot be used for filteration. so changning the channel name to SCB_STF
    if(subChannelTypeForAgencyBancaRepls == "SCB_STF")
    {
        selected_channel = "SCB_STF"
    }
    else
    {
        selected_channel = channelName
    }
    var querySelect = new DbUtil();

    querySelect.query()
    querySelect.select()
    querySelect.column('*')
    querySelect.from()
    querySelect.table('al_product_master')
    querySelect.where()
    querySelect.clause('product_channel', '=', selected_channel)
    if(channelName == "UOB") //changed by Purva for UOB on 14th Aug 2017
    {
        querySelect.and()
        querySelect.clause('product_sub_channel', '=', subChannelTypeForAgencyBancaRepls)
    }

    return querySelect;

}
function filterProducts(product_db_response, product_engine_response, inception_date, comefrom,main_life_response,sec_life_response,third_life_response)
{
    var solnsFilter={};//Added for solution configration.
    //product_engine_response= product_engine_response.slice(0,-2)+"\"";
    var obj = JSON.parse(product_engine_response);
    var result_prodres_set = $.parseJSON(obj);
    var product_name = new Array();
    var final_prod_name = new Array();
    var expiry_age_arr = new Array();
    var obj_prod_db = JSON.parse(product_db_response);
    testProductData=[];
    notReturnProduct=false;
    
    console.log("obj filterProducts:"+JSON.stringify(obj));
    console.log("Obtained Button Response"+buttonPlansResonse);

    
    checkVailableProduct=result_prodres_set;
    
    if((buttonPlansResonse != "" && buttonPlansResonse != null &&  buttonPlansResonse != "null" &&  buttonPlansResonse != "(null)" &&  buttonPlansResonse != "{}") && buttonPlansResonse["al_sqs_buttons_plan"]!="al_sqs_buttons.tailor_your_solution")

    {
        
        var solutionName=buttonPlansResonse["al_sqs_buttons_plan"].split(".");
        
        productSolutionFilter=_.where(solutionPlanCsv,{Solution:solutionName[1]});
        console.log("productSolutionFilter:"+productSolutionFilter)
        var displayProduct= _.pluck(productSolutionFilter, "Basic_plan");
        console.log("@Display Product"+displayProduct);
        var arrayToString=displayProduct.toString();
        var productNm=arrayToString.split(",")
        
        console.log("productNm"+productNm);
        
        
          /*  if(displayProduct instanceof Array)
            {
                
               for(var i=0;i<=displayProduct.length-1;i++)
                {
                    
                    var dataName=_.where(checkVailableProduct,{"al_sqs_details.product_name":displayProduct[i]})
                
                    product_name[i] = dataName[0]["al_sqs_details.product_name"];
                    expiry_age_arr[i] =dataName[0]["al_sqs_details.expiry_age"];
                    
                    
                }
                
            }
            else
            {
                var dataName=_.where(checkVailableProduct,{"al_sqs_details.product_name":displayProduct})
                
                product_name[i] = dataName[0]["al_sqs_details.product_name"];
                expiry_age_arr[i] =dataName[0]["al_sqs_details.expiry_age"];

            }*****/
        
        if(buttonPlansResonse["al_sqs_buttons_plan"]=="al_sqs_buttons.savings_solution" || buttonPlansResonse["al_sqs_buttons_plan"]=="al_sqs_buttons.pruprotect_xtra" || buttonPlansResonse["al_sqs_buttons_plan"]=="al_sqs_buttons.prubest_gift")
        {
            productNm=[];
          productNm.push(isSavings[buttonPlansResonse["pru_my_medical_plus_solutions.medicals_benefit"]])
            console.log("@@Prod Name"+productNm)
           
            
        }
        
        
        
        
        
        for(var i=0;i<=productNm.length-1;i++)
        {
            
            var dataName=_.where(checkVailableProduct,{"al_sqs_details.product_name":productNm[i]})
          
          //  if(dataName!="")
                
            if (dataName === undefined || dataName.length == 0) {
                // array empty or does not exist
                console.log("Value is Empty")
                notReturnProduct=true;
            }else
            {
               
               testProductData.push(dataName);
            product_name[i] = dataName[0]["al_sqs_details.product_name"];
            expiry_age_arr[i] =dataName[0]["al_sqs_details.expiry_age"];
            }
            
            
        }
        
        
        
        
        
        
         }
    else
    {
    
        console.log("tailor solution"+buttonPlansResonse["al_sqs_buttons_plan"]!="tailor_your_solution");
        for (var i = 0; i <= result_prodres_set.length - 1; i++)
        {
            
           
            
            if(checkDateDiff<=29) {
                
                if(result_prodres_set[i]["al_sqs_details.product_name"]=="PRUWealth Plus" )
                {//|| result_prodres_set[i]["al_sqs_details.product_name"]=="PRUWealth Enrich"){
                    console.log("PRUWealth Plus 30 days condition present");
                    
                    continue;
                    
                }else
                {
                     console.log("---11----> In else");
                    product_name[i] = result_prodres_set[i]["al_sqs_details.product_name"];//This is the original code
                    console.log("product_name--->"+ product_name[i]);
                    expiry_age_arr[i] = result_prodres_set[i]["al_sqs_details.expiry_age"];//This is the original code
                    
                    
                }
                
                
            }
            else {
                product_name[i] = result_prodres_set[i]["al_sqs_details.product_name"];//This is the original code
                console.log("product_name--->"+ product_name[i]);
                expiry_age_arr[i] = result_prodres_set[i]["al_sqs_details.expiry_age"];//This is the original code
                
                
            }
            
            /****************************************************************************/
          
        
    
        }
    }
        
    for (sub in obj_prod_db)
    {
        console.log("c "+obj_prod_db[sub]["product_name"] + "--product_name-->" +product_name);
        if (product_name.indexOf(obj_prod_db[sub]["product_name"])>-1)
        {
            console.log("confirm product name in engine... "+obj_prod_db[sub]["product_name"]);
            console.log("Func 1 filter product"+inception_date)
            var checkprod=checkProductforExp(obj_prod_db[sub]["product_effect_date"], obj_prod_db[sub]["product_expiry_date"], inception_date);
            
            console.log("In if confirm product name in engine... "+obj_prod_db[sub]["product_name"]+"checkprod:"+checkprod);
            if (checkProductforExp(obj_prod_db[sub]["product_effect_date"], obj_prod_db[sub]["product_expiry_date"], inception_date))
            {
                /*******Add dummy code for solution button*/
                
                
             /**   if(buttonPlansResonse["al_sqs_buttons_plan"]=="al_sqs_buttons.prumy_medical_plus") //Added if else for temporary  to test 6-12-2018
                {
                    
                    if(obj_prod_db[sub]["product_name"]=="PRUwith you")
                    {
                        final_prod_name.push(obj_prod_db[sub]["product_name"]);
                        break;
                    }
                    
                }else
                {
                final_prod_name.push(obj_prod_db[sub]["product_name"]);//Original code
                console.log("pushing prod name.... "+obj_prod_db[sub]["product_name"]);//Original code
                }*****/
                
                final_prod_name.push(obj_prod_db[sub]["product_name"]);//Original code
            }
        }
    }
    console.log("inception_date filterproducts:"+inception_date);
    setProductDropdown(final_prod_name, expiry_age_arr, product_name, comefrom,main_life_response,sec_life_response,third_life_response,product_db_response);
}
/*function checkProductforExp(effect_date, expiry_date, inception_date)//previous name of the function was checkProductforExp which is the same function name that was in commonfunction.js getting error new_incp.split undefined on load of this page now new function name changed to checkProductforExp
{
    console.log("--------->"+inception_date);
    var oneDay = 24 * 60 * 60 * 1000;
    var new_eds = effect_date.split(" ");
    var new_ed = new_eds[0].split("-");
    var new_expdts = expiry_date.split(" ");
    var new_expdt = new_expdts[0].split("-");
    var curr_dt = fnGetDateTimeStamp();
    var curr_dts = curr_dt.split(" ");
    var currnt_dt = curr_dts[0].split("-");
    var new_incp = inception_date;
    var new_incp_dt = new_incp.split("/");
    var date1 = new Date(new_ed[0], new_ed[1] - 1, new_ed[2]); //year,month,date//Effective Date
    var date2 = new Date(new_incp_dt[2], new_incp_dt[1] - 1, new_incp_dt[0]); //Inception Date
    var date3 = new Date(new_expdt[0], new_expdt[1] - 1, new_expdt[2]); //Expiry Date
  
    
    
    console.log("@DATE2"+date2);
    var date4 = new Date(currnt_dt[0], eval(currnt_dt[1]) - 1, currnt_dt[2]); //Current Date
    console.log("@DATE4"+date4);
    var diffDaysexp = Math.round((date3.getTime() - date4.getTime()) / (oneDay));
    var diffDays12 = Math.round((date2.getTime() - date1.getTime()) / (oneDay));
    console.log("@diffDays12"+diffDays12);
    var diffDays14 = Math.round((date4.getTime() - date1.getTime()) / (oneDay));
    console.log("On date check:: " + "\n" + "Eff Date:: " + new_ed[0] + "-" + new_ed[1] + "-" + new_ed[2] + "\n" + "Incpt Date:: " + new_incp_dt[2] + "-" + new_incp_dt[1] + "-" + new_incp_dt[0] + "\n" + "Exp Date:: " + new_expdt[0] + "-" + new_expdt[1] + "-" + new_expdt[2] + "\n" + "diffDaysexp:: " + diffDaysexp + "\n");
    console.log("@diffDays14"+diffDays14);

    if ( date3 == "Invalid Date" || date1 == "Invalid Date")
    {
        console.log("In11111");
        return false;
    }
    if (diffDays12 < 0)
    {
        console.log("In111112222");
        return false;
    }
    else if (diffDaysexp < 0)
    {
        console.log("In111113333");
        return false;
    }
    else if (diffDays14 < 0)
    {
        console.log("In111114444");
        return false;
    }

    return true;

}*/
function searchProductInDRp()
{
    var prod_length = document.getElementById("al_sqs_details.product_name").options.length;
    var prod_name_arr = new Array();
    for (var i = 0; i <= prod_length - 1; i++)
    {
        prod_name_arr.push(document.getElementById("al_sqs_details.product_name").options[i].value);
    }
    return prod_name_arr;
}

function fnMsViewAL() // makarand: for view al from sqs 03/08/2017
{
    //    var Al_filename=agent_id+"/"+proposal_no+"/"+"Alpdf"+proposal_no+".pdf";
    js_get_var("Al_filename", function(Al_filename)
               {
               loadShowcasePage(Al_filename,"NO","");
               });
    
    
}
/*************Following function for PRUwith you **************************/

/*function  fndisableEnable()
{
    console.log("called function");
    var index_counter=0;
    console.log("uniqueNamesFilter"+uniqueNamesFilter)
    for(var i=0; i<=uniqueNamesFilter.length-1; i++)
    {
        var myDropdown = document.getElementById(uniqueNamesFilter[i]);
        console.log("myDropdown"+myDropdown);
       // console.log("Sachin : "+myDropdown.style.display === 'block'));
        if(myDropdown.selectedIndex==0)
        {
            index_counter++;
        }
    }
    console.log("counter value"+index_counter);
    if( index_counter==2 || index_counter>2)
    {
        index_lenght=index_lenght-1;
        for(var i=0; i<=lifeLinkFundArray.length-1; i++)
        {
                var myDropdown = document.getElementById(lifeLinkFundArray[i]);
                myDropdown.disabled=false;
        }
    }
   /* else
    {
        for(var i=0; i<=lifeLinkFundArray.length-1; i++)
        {
            var myDropdown = document.getElementById(lifeLinkFundArray[i]);
            if(myDropdown.selectedIndex==0)
            {
                    myDropdown.disabled=true;
            }
        }
    }*/
    
    //}

    
/* FOLLOWING FUNCTION FOR PRUWEALTH GAIN PLUS FOR FUTURE BACKDATE FUNCTIONALITY.*/
 
 function futureDate()
{
    /************************************************************************************************************/
   /* var today,laterDay,selectedDay;
    today=new Date();
    laterDay=new Date();
    
    selectedDate=document.getElementById("al_sqs_details.Inception_dt").value;
    console.log("selectedDate"+selectedDate);
    selectedDate=selectedDate.split("/");
    // var selectedDay=selectedDate[0];
    //  var selectedMonth=selectedDate[1];
    // var selectedYear=selectedDate[2];
    //var inputDString=new Date(parseInt(selectedDate[2]),parseInt(selectedDate[1]),parseInt(selectedDate[0]));
    laterDay.setFullYear(selectedDate[2],selectedDate[1]-1,selectedDate[0]);
    console.log("later day"+laterDay);
    
    if(laterDay > today)
    {
        console.log("later day");
        document.getElementById("al_sqs_details.Inception_dt").value=today.toString;
        return false;
        
    }*/
  /************************************************************************************************************/
    var oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
    var inceptionDt =document.getElementById("al_sqs_details.Inception_dt").value;
    inceptionDt=inceptionDt.split("/");
    var inceDate=inceptionDt[0];
    var inceMonth=(eval(inceptionDt[1])-1);
    var inceYear=inceptionDt[2];
    console.log("inception Date--->"+inceDate+"/"+inceMonth+"/"+inceYear);
    var systemdate = new Date();
    if(sysdate!=""){
         systemdate = new Date(sysdate);
    }else{
         systemdate = new Date();
    }
    var dd = systemdate.getDate();
    var mm = systemdate.getMonth(); //January is 0!
    var yyyy = systemdate.getFullYear();
    console.log("current Date--->"+dd+"/"+mm+"/"+yyyy);
    var date2 = new Date(eval(yyyy), eval(mm), eval(dd));
    date1 = new Date(eval(inceYear), eval(inceMonth), eval(inceDate));
    
    var diffDays = Math.round(((date2.getTime() - date1.getTime()) / (oneDay)))
    console.log("diffDays--->"+diffDays);
    if(diffDays<=-1)
    {
        return false;
    }
   
}



/*******************************************************
 Function Name: fnmsRetriveInceptionObject()
 Function Description:retrive and check il monthly product .
 Parameters:
 Created By: Sachin Tupe
 Created On: 18 June 2018
 Modified By:
 Modified On:
 Modification Reason:
 *******************************************************/

function fnmsRetriveInceptionObject()
{
    console.log("in fnmsRetriveInceptionObject");
    var ismonthlyIL=false;
    var incep_product_name="";
    var incr="";
    var current_date = new Date();
    if(sysdate!=""){
         current_date = new Date(sysdate);
    }else{
         current_date = new Date();
    }
    var current_day = current_date.getDate();
    var incep_day="";
    console.log("il date"+current_day);


    js_get_var("inception_load_data", function(load_data)
               {
               if(load_data != "" && load_data != null && load_data != "null"  && load_data != "(null)")
               {
               ilConfigurableDatabase = JSON.parse(load_data);
             // var config_data= JSON.stringify(ilConfigurableDatabase);
               //console.log("ilConfigurableDatabase"+config_data);
                for(data_record in ilConfigurableDatabase)
               {
               console.log("inception_from"+ilConfigurableDatabase[data_record].inception_from);
                console.log("inception_date"+ilConfigurableDatabase[data_record].inception_date_to);
               
               
               if(current_day >= ilConfigurableDatabase[data_record].inception_from && current_day <=ilConfigurableDatabase[data_record].inception_date_to)
               {
                    console.log("condition true");
                    ismonthlyIL=true;
                    incep_product_name=ilConfigurableDatabase[data_record].product_name;
                    incr=ilConfigurableDatabase[data_record].date_increment;
                    incep_day=ilConfigurableDatabase[data_record].inception_day;
                    var config_object={"product_name":incep_product_name,"isMonthly":ismonthlyIL,"increment":incr,"inception_day": incep_day};
                    array_inception_element.push(config_object);
               
               
               }
               
               }
               
               }
              
               });

  //  array_inception_operation=JSON.stringify(array_inception_element);
   // console.log("array_inception_operation"+array_inception_operation);
    

}



/*******************************************************
 Function Name: setILMonthObect(DateValueId,persontype,day,month,year,incpDateValue,incpday,incpmonth,incpyear)
 Function Description:Set life object for  il monthly product .
 Parameters:
 Created By: Sachin Tupe
 Created On: 18 June 2018
 Modified By:
 Modified On:
 Modification Reason:
 *******************************************************/



function setILMonthObect(DateValueId,persontype,day,month,year,incpDateValue,incpday,incpmonth,incpyear)
{
//fnMsSetANB(DateValueId, persontype, day, month, year, incpDateValue, incpday, incpmonth, incpyear)

    var oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
    var date1;
    var inceptiondate;
    var dd1;
    var mm1;
    var yyyy1;
    
    var ageYears;
    var ageMonths;
    var ageDays;
    var date_sel_invalid = 0;
    var ilANBInBackdate_monthly=0;
    
    date1 = new Date(eval(year), eval(month) - 1, eval(day));
    if(sysdate!=""){
        inceptiondate = new Date(sysdate);
    }
    else{
        inceptiondate = new Date();
    }
    dd1 = incpday;
    mm1 = incpmonth
    yyyy1 = incpyear;
    
  
     ilANBInBackdate_monthly=fnMsCalculateANBILProductsInBackdate(parseInt(day), parseInt(month), parseInt(year), parseInt(incpday), parseInt(incpmonth), parseInt(incpyear));
    console.log("#####ilANBInBackdate_monthly"+ ilANBInBackdate_monthly)
   
    if(checkIlMonthly)
    {
        ilANBInBackdate_monthly=fnMsCalculateANBILProductsInBackdate(parseInt(day), parseInt(month), parseInt(year), parseInt(incpday), parseInt(incpmonth), parseInt(incpyear));
        console.log("#####ilANBInBackdate_monthly"+ ilANBInBackdate_monthly)
          ilmonthly_secondlifeAge=ilANBInBackdate_monthly;
}
    if(persontype == "mlife")
    { var calculatedAge_main_life=os_mlife_anb;
        console.log("calculatedAge_main_life"+calculatedAge_main_life);
        ilmonthSetMainLife(calculatedAge_main_life, DateValueId, incpDateValue, incpday, incpmonth, incpyear, ilANBInBackdate_monthly);
    }
    else if(persontype == "slife")
    {
      
        var calculatedAge_second_life =os_slife_anb;
        console.log("calculatedAge second"+calculatedAge_second_life);
        ilmonthSetSecondLife(calculatedAge_second_life, DateValueId, incpDateValue, incpday, incpmonth, incpyear, ilANBInBackdate_monthly);
    }else if(persontype == "tlife")
    {
        ilmonthly_thirdlifeAge=ilANBInBackdate_monthly;
          var calculatedAge_third_life =os_tlife_anb;
        console.log("third life"+calculatedAge_third_life);
        ilmonththirdLife(calculatedAge_third_life, DateValueId, incpDateValue, incpday, incpmonth, incpyear, ilANBInBackdate_monthly);
    }
    
    
    
}


/*******************************************************
 Function Name: setILMonthObect(calculatedAge_mlife,DateValueId,incpDateValue,incpday,incpmonth,incpyear,ilANBInBackdate)
 Function Description:Set main life object for  il monthly product .
 Parameters:
 Created By: Sachin Tupe
 Created On: 18 June 2018
 Modified By:
 Modified On:
 Modification Reason:
 *******************************************************/
function ilmonthSetMainLife(calculatedAge_mlife,DateValueId,incpDateValue,incpday,incpmonth,incpyear,ilANBInBackdate)
{
    
    temp_ilMonthly=ilANBInBackdate;
    console.log("incpDateValue1313="+incpDateValue+"--incpday-="+incpday+"-incpmonth-="+incpmonth+"-incpyear-="+incpyear);
    console.log("calculatedAge_mlife--="+calculatedAge_mlife+"-ilANBInBackdate-"+ilANBInBackdate);
    // setMainLife(calculatedAge, DateValueId, incpDateValue, incpday, incpmonth, incpyear, ilANBInBackdate);
    var anb_changed_by="";
    js_get_var("main_life_response", function(mainlife_res)
               {
               if(mainlife_res != "" && mainlife_res != null && mainlife_res != "null"  && mainlife_res != "(null)")
               {
               obj_mlife = JSON.parse(mainlife_res);
               var calculatedAges_mlife;
               calculatedAges_mlife=obj_mlife["al_person_details.mlife.anb"];
               if(obj_mlife["al_person_details.pre_natal_child_flg"] == "Yes")
               {
               console.log("prenatal--->");
               calculatedAges_mlife = "1";
               ilANBInBackdate="0";
               temp_ilMonthly="0";
               temp_ildailyanb="0";
               }else if(obj_mlife["al_person_details.pre_natal_child_flg"] == "No")
               {
               calculatedAges_mlife = calculatedAge_mlife;
               }
              
               if(parseInt(calculatedAge_mlife)!=parseInt(obj_mlife["al_person_details.mlife.anb"]))
               {
               anb_changed_by="";
               }
               //Variable to take json data
               var mainlife = {
               "al_person_details.mlife.insu_type_header": obj_mlife["al_person_details.mlife.insu_type_header"],
               "al_person_details.mlife.insu_type": obj_mlife["al_person_details.mlife.insu_type"],
               "al_person_details.mlife.first_name": obj_mlife["al_person_details.mlife.first_name"],
               "al_person_details.pre_natal_child_flg": obj_mlife["al_person_details.pre_natal_child_flg"],
               "al_person_details.mlife.expected_delivery_dt": obj_mlife["al_person_details.mlife.expected_delivery_dt"],
               "al_person_details.gestational_week": obj_mlife["al_person_details.gestational_week"],
               "al_person_details.mlife.dob": obj_mlife["al_person_details.mlife.dob"],
               "al_person_details.mlife.anb": calculatedAges_mlife,
               "al_person_details.mlife.gender": obj_mlife["al_person_details.mlife.gender"],
               "al_person_details.mlife.smoke_status": obj_mlife["al_person_details.mlife.smoke_status"],
               "al_employee_details.mlife.occupation": obj_mlife["al_employee_details.mlife.occupation"],
               "al_employee_details.mlife.occupation_class": obj_mlife["al_employee_details.mlife.occupation_class"],
               "al_employee_details.mlife.nature_of_business": obj_mlife["al_employee_details.mlife.nature_of_business"],
               "al_employee_details.mlife.value_nature_of_business": obj_mlife["al_employee_details.mlife.value_nature_of_business"],
               "al_sqs_details.sec_parti_flag": obj_mlife["al_sqs_details.sec_parti_flag"],
               "al_person_details.mlife.parent_consent": obj_mlife["al_person_details.mlife.parent_consent"],
               "pvm_qualification_check": obj_mlife["pvm_qualification_check"],
               "pamb_channel":obj_mlife["pamb_channel"],
               "pamb_sub_channel":obj_mlife["pamb_sub_channel"],
               "client_ylp_type_mlife" :obj_mlife["client_ylp_type_mlife"],
               "anb_changed_by" :anb_changed_by,
               "al_person_details.mlife.anb_il_product" :ilANBInBackdate,
               "al_person_details.mlife.anb_il_product_temp":temp_ildailyanb,
               "al_person_details.mlife.anb_il_monthly_product" :ilANBInBackdate,
               "al_person_details.mlife.anb_il_monthly_product_temp" : temp_ilMonthly,
               "al_person_details.mlife.anb_temp" :os_mlife_anb,
               "rider_certified_check": obj_mlife["rider_certified_check"],//added by ankita on 2 July 2018 for rider certified check for PRUwith you product
               }
               console.log("mainlife--SR->"+mainlife);
               console.log("pamb_sub_channel--SR->"+obj_mlife["pamb_sub_channel"]);
               js_set_var("main_life_response",JSON.stringify(mainlife),function()
                          {
                          if(obj_mlife["al_sqs_details.sec_parti_flag"] == "Yes")
                          {
                          js_get_var("sec_life_response", function(scnd_res)
                                     {
                                     if(scnd_res != "" && scnd_res != null && scnd_res != "null"  && scnd_res != "(null)")
                                     {
                                     obj_slife = JSON.parse(scnd_res);
                                     os_slife_anb=obj_slife["al_person_details.slife.anb_temp"];
                                     slife_il_monthly_anb=obj_slife["al_person_details.slife.anb_il_monthly_product_temp"];
                                     slife_il_anb_temp=obj_slife["al_person_details.slife.anb_il_product_temp"];
                                     
                                     
                                     var dob_slife = obj_slife["al_person_details.slife.dob"].split("/");
                                     
                                   setILMonthObect(DateValueId, "slife", dob_slife[0], dob_slife[1], dob_slife[2], incpDateValue, incpday, incpmonth, incpyear)
                                     }
                                     });
                          }
                          else
                          {
                          if(calculatedAges_mlife < 17 && obj_mlife["al_sqs_details.sec_parti_flag"] == "No")
                          {
                          if(!(obj_mlife["al_person_details.mlife.parent_consent"] == "Yes"))
                          {
                          alert("275");
                          return false;
                          menuController.loadPage("top_mysolutions_maindetails",0);
                          }
                          }
                          //if(!checkIlMonthly)
                          //{
                          generateinputstringBackdate();
                          //}
                          }
                          });
               }
               });

    
}

/*******************************************************
 Function Name: setILMonthObect(calculatedAge_mlife,DateValueId,incpDateValue,incpday,incpmonth,incpyear,ilANBInBackdate)
 Function Description:Set Second life object for  il monthly product .
 Parameters:
 Created By: Sachin Tupe
 Created On: 18 June 2018
 Modified By:
 Modified On:
 Modification Reason:
 *******************************************************/


function ilmonthSetSecondLife(calculatedAge_slife,DateValueId,incpDateValue,incpday,incpmonth,incpyear,ilANBInBackdate)
{
   
    console.log("il monthly slife"+ilANBInBackdate);
        console.log("calculatedAge_slife"+calculatedAge_slife);
    var seclife = {
        "al_person_details.slife.first_name": obj_slife["al_person_details.slife.first_name"],
        "al_person_details.slife.relationship": obj_slife["al_person_details.slife.relationship"],
        "al_person_details.slife.dob": obj_slife["al_person_details.slife.dob"],
        "al_person_details.slife.anb": calculatedAge_slife,
        "al_person_details.slife.gender": obj_slife["al_person_details.slife.gender"],
        "al_person_details.slife.smoke_status": obj_slife["al_person_details.slife.smoke_status"],
        "al_employee_details.slife.occupation": obj_slife["al_employee_details.slife.occupation"],
        "al_employee_details.slife.occupation_class": obj_slife["al_employee_details.slife.occupation_class"],
        "al_employee_details.slife.nature_of_business": obj_slife["al_employee_details.slife.nature_of_business"],
        "al_employee_details.slife.value_nature_of_business": obj_slife["al_employee_details.slife.value_nature_of_business"],
        "al_sqs_details.third_parti_flg": obj_slife["al_sqs_details.third_parti_flg"],
        "client_ylp_type_slife" :obj_slife["client_ylp_type_slife"],
        "al_person_details.slife.anb_il_product" :ilANBInBackdate,
        "al_person_details.slife.anb_il_product_temp":slife_il_anb_temp,
        "al_person_details.slife.anb_il_monthly_product" :ilANBInBackdate,
         "al_person_details.slife.anb_il_monthly_product_temp" :slife_il_monthly_anb,
        "al_person_details.slife.anb_temp" :os_slife_anb
    }
    console.log("SET SECOND LIFE ANB"+seclife);
    
    js_set_var("sec_life_response",JSON.stringify(seclife),function()
               {
               
                  js_get_var("sec_life_response", function(second_res)
                             {
                             var     obj_slife = JSON.parse(second_res);
                             
                             
               if(obj_slife["al_sqs_details.third_parti_flg"] == "Yes")
               {
               js_get_var("third_life_response", function(thrd_res)
                          {
                          if(thrd_res != "" && thrd_res != null && thrd_res != "null"  && thrd_res != "(null)")
                          {
                          obj_tlife = JSON.parse(thrd_res);
                          os_tlife_anb=obj_tlife["al_person_details.tlife.anb_temp"];
                          tlife_il_monthly_anb=obj_tlife["al_person_details.tlife.anb_il_monthly_product_temp"];
                          tlife_il_anb_temp=obj_tlife["al_person_details.tlife.anb_il_product_temp"];
                          
                          var dob_tlife = obj_tlife["al_person_details.tlife.dob"].split("/");
                          
                         setILMonthObect(DateValueId, "tlife", dob_tlife[0], dob_tlife[1], dob_tlife[2], incpDateValue, incpday, incpmonth, incpyear)
                          }
                          });
               }
               else
               {
               generateinputstringBackdate();
               }
               });

               });
    
    
    
}


/*******************************************************
 Function Name: setILMonthObect(calculatedAge_mlife,DateValueId,incpDateValue,incpday,incpmonth,incpyear,ilANBInBackdate)
 Function Description:Set third life object for  il monthly product .
 Parameters:
 Created By: Sachin Tupe
 Created On: 18 June 2018
 Modified By:
 Modified On:
 Modification Reason:
 *******************************************************/



function ilmonththirdLife(calculatedAge_tlife,DateValueId,incpDateValue,incpday,incpmonth,incpyear,ilANBInBackdate)
{
    
    //Variable to take json data
    var thirdlife = {
        "al_person_details.tlife.first_name": obj_tlife["al_person_details.tlife.first_name"],
        "al_person_details.tlife.relationship": obj_tlife["al_person_details.tlife.relationship"],
        "al_person_details.tlife.dob":obj_tlife["al_person_details.tlife.dob"],
        "al_person_details.tlife.anb": calculatedAge_tlife,
        "al_person_details.tlife.gender": obj_tlife["al_person_details.tlife.gender"],
        "al_person_details.tlife.smoke_status": obj_tlife["al_person_details.tlife.smoke_status"],
        "al_employee_details.tlife.occupation": obj_tlife["al_employee_details.tlife.occupation"],
        "al_employee_details.tlife.occupation_class": obj_tlife["al_employee_details.tlife.occupation_class"],
        "al_employee_details.tlife.nature_of_business": obj_tlife["al_employee_details.tlife.nature_of_business"],
        "al_employee_details.tlife.value_nature_of_business": obj_tlife["al_employee_details.tlife.value_nature_of_business"],
        "client_ylp_type_tlife" :obj_tlife["client_ylp_type_tlife"],
        "al_person_details.tlife.anb_il_product" :ilANBInBackdate,
        "al_person_details.tlife.anb_il_product_temp":tlife_il_anb_temp,
        "al_person_details.tlife.anb_il_monthly_product" :ilANBInBackdate,
        "al_person_details.tlife.anb_il_monthly_product_temp" :tlife_il_monthly_anb,
        "al_person_details.tlife.anb_temp" :os_tlife_anb
    }
    
    js_set_var("third_life_response",JSON.stringify(thirdlife),function()
               {
               generateinputstringBackdate();
               });

    
    
    
}


function fnfindproductType(prod_name)
{
    
    //prodtype
    var querySelect = new DbUtil();
    
    querySelect.query()
    .select()
    .column('*')
    .from()
    .table('al_product_master')
    .where()
    .clause('product_name','=',prod_name)
    
    querySelect.execute(function(response)
                        {
                        if(response!="" && response!="{}")
                        {
                        var obj=JSON.parse(response);
                        console.log("Selected product"+obj);
                        prodtype = obj[0]['product_core_system'];
                        prodtypeForgeinCurrency = obj[0]['product_currency'];
                        
                        console.log("Final product name"+ prodtype+"----prodtypeForgeinCurrency--->"+prodtypeForgeinCurrency);
                        

                        
                        }
                        });

    



}


function fnget_all_ILP_Product()
{
    console.log("in fnget_all_ILP_Produc");
    var querySelectILP = new DbUtil();
    
    querySelectILP.query()
    .select()
    .column('*')
    .from()
    .table('al_product_matrix')
    .where()
    .clause('product_type','=','ILP')
    
    querySelectILP.execute(function(response)
                        {
                        if(response!="" && response!="{}")
                        {
                         obj_ILP=JSON.parse(response);
                           
                        
                        
                        }
                        });
    
    



}

function fnReCalculateAllANB(mlifeResponse,slifeResponse,tlifeResponse)
{
    var objmlifeResponse = null;
    var objslifeResponse =null;
    var objtlifeResponse =null;
    var inceptiondate;
    var incDay;
    var incMonth;
    var incYear;
    
    var currentDay;
    var currentMonth;
    var currentYear;
    
    objmlifeResponse = JSON.parse(mlifeResponse);
    if (slifeResponse != "" && slifeResponse != null && slifeResponse != "null" && slifeResponse != "(null)")
    {
        objslifeResponse = JSON.parse(slifeResponse);
    }
    if(tlifeResponse != "" && tlifeResponse != null && tlifeResponse != "null" && tlifeResponse != "(null)")
    {
        objtlifeResponse = JSON.parse(tlifeResponse);
    }
    
    //Current date logic
    if(sysdate!=""){
        inceptiondate = new Date(sysdate);
    }else{
        inceptiondate = new Date();
    }
    console.log("inceptiondate find-->"+inceptiondate);
    incDay = parseInt(inceptiondate.getDate());
    currentDay = incDay;
    console.log("inceptiondate  ddl find-->"+inceptiondate);
    incMonth = parseInt(inceptiondate.getMonth()) + 1; //January is 0!
    currentMonth = incMonth;
    incYear = parseInt(inceptiondate.getFullYear());
    currentYear = incYear;
    
    if(ilmonthly_selection)//Added condtion by sachin tupe for set anb for il monthly
    {
    
        if (currentDay > 1 && currentMonth == 12) {
            incYear = eval(currentYear) + 1
            incMonth = 1;
            incDay = 1;
        }
        else
        {
            if (currentDay > 1 && currentMonth < 12) {
                incMonth = eval(currentMonth) + 1;
                incDay = 1;
            } else
                incDay = 1;
        }

    
    }
    
    /*******************1***********/
    
    if(document.getElementById("al_sqs_details.payment_backdate_yes").checked && (backDateProductList.indexOf(document.getElementById("al_sqs_details.product_name").value)<0) ) //Added for production defect 55112 by Sachin Tupe.
    {
    
        var Bdate=document.getElementById("al_sqs_details.Inception_dt").value;
        console.log("BACKDATE DATE"+Bdate);
        /********************************/
        
        var inceptionDtC =document.getElementById("al_sqs_details.Inception_dt").value;
        inceptionDtC=inceptionDtC.split("/");
        incDay=inceptionDtC[0];
        incMonth=(eval(inceptionDtC[1]));
        incYear=inceptionDtC[2];
        console.log("inception Date--->"+incDay+"/"+incMonth+"/"+incYear);
        
        
    
    }
    
    /*********************************/
    
    
    
    //ANB splitting
    if(objmlifeResponse["al_person_details.pre_natal_child_flg"] == "Yes"){
        var objSplitMainLifeDOB = objmlifeResponse["al_person_details.mlife.expected_delivery_dt"].split("/");
    }else{
        var objSplitMainLifeDOB = objmlifeResponse["al_person_details.mlife.dob"].split("/");
    }
    var objSplitSLifeDOB =""
    var objSplitTLifeDOB =""
    
    if (slifeResponse != "" && slifeResponse != null && slifeResponse != "null" && slifeResponse != "(null)")
    {
        objSplitSLifeDOB = objslifeResponse["al_person_details.slife.dob"].split("/");
    }
    if(tlifeResponse != "" && tlifeResponse != null && tlifeResponse != "null" && tlifeResponse != "(null)")
    {
        objSplitTLifeDOB = objtlifeResponse["al_person_details.tlife.dob"].split("/");
    }
    
    
    //Inception date and ANB calculation for IL product
    console.log("Inception day IL ==="+incDay+"/"+incMonth+"/"+incYear)
    
    objmlifeResponse["al_person_details.mlife.anb_il_product"]=fnMsCalculateANBILProductsInBackdate(parseInt(objSplitMainLifeDOB[0]), parseInt(objSplitMainLifeDOB[1]), parseInt(objSplitMainLifeDOB[2]), incDay, incMonth, incYear);
     console.log("FFind 3");
    objmlifeResponse["al_person_details.mlife.anb_il_product_temp"]=objmlifeResponse["al_person_details.mlife.anb_il_product"];
    //SR added for CR of Prenatal 1313
    if(objmlifeResponse["al_person_details.pre_natal_child_flg"] == "Yes"){
         console.log("FFind 3prenatal yes");
        // var objSplitMainLifeDOB = objmlifeResponse["al_person_details.mlife.expected_delivery_dt"].split("/");
        objmlifeResponse["al_person_details.mlife.anb_il_product"]=fnMsCalculateANBForPrenatal(parseInt(objSplitMainLifeDOB[0]), parseInt(objSplitMainLifeDOB[1]), parseInt(objSplitMainLifeDOB[2]), incDay, incMonth, incYear);
         objmlifeResponse["al_person_details.mlife.anb_il_product_temp"]=objmlifeResponse["al_person_details.mlife.anb_il_product"];
    }
     console.log("ANBBB one-->"+objmlifeResponse["al_person_details.mlife.anb_il_product"]);
    if (slifeResponse != "" && slifeResponse != null && slifeResponse != "null" && slifeResponse != "(null)")
    {
    objslifeResponse["al_person_details.slife.anb_il_product"]=fnMsCalculateANBILProductsInBackdate(parseInt(objSplitSLifeDOB[0]),parseInt(objSplitSLifeDOB[1]),parseInt(objSplitSLifeDOB[2]), incDay, incMonth, incYear);
        objslifeResponse["al_person_details.slife.anb_il_product_temp"]=objslifeResponse["al_person_details.slife.anb_il_product"];
         console.log("FFind 4");
    }
    if(tlifeResponse != "" && tlifeResponse != null && tlifeResponse != "null" && tlifeResponse != "(null)")
    {
        objtlifeResponse["al_person_details.tlife.anb_il_product"]=fnMsCalculateANBILProductsInBackdate(parseInt(objSplitTLifeDOB[0]), parseInt(objSplitTLifeDOB[1]), parseInt(objSplitTLifeDOB[2]), incDay, incMonth, incYear);
        objtlifeResponse["al_person_details.tlife.anb_il_product_temp"]=objtlifeResponse["al_person_details.tlife.anb_il_product"];
         console.log("FFind 5");
    }
    
    
    //Inception date calculation for OS product
  
    /*******************Following code commented for changed prodcut from OS to IL************************************/
    /*if (currentDay > 15 && currentMonth == 12) {
        incYear = eval(currentYear) + 1
        incMonth = 1;
        incDay = 1;
    } else {
        if (currentDay > 15 && currentMonth < 12) {
            incMonth = eval(currentMonth) + 1;
            incDay = 1;
        } else
        {
        incDay = 1;
        incMonth=currentMonth; Todo 08-08-2018.
        incYear=currentYear;
        }
    }
    */
    /*******************2***********/
    
    /********************************************************/
    
    
    
    
    
    
    
    
    
    if(document.getElementById("al_sqs_details.payment_backdate_yes").checked && (backDateProductList.indexOf(document.getElementById("al_sqs_details.product_name").value)<0)) //Added for production defect 55112 by Sachin Tupe.
    
    {
        
        var Bdate=document.getElementById("al_sqs_details.Inception_dt").value;
        console.log("BACKDATE DATE"+Bdate);
        /********************************/
        
        var inceptionDtC =document.getElementById("al_sqs_details.Inception_dt").value;
        inceptionDtC=inceptionDtC.split("/");
        incDay=inceptionDtC[0];
        incMonth=(eval(inceptionDtC[1]));
        incYear=inceptionDtC[2];
        console.log("inception Date--->"+incDay+"/"+incMonth+"/"+incYear);
        
        
        
    }
    
    /*********************************/

    
    
    
 
    
    console.log("Inception day OS ==="+incDay+"/"+incMonth+"/"+incYear)
    objmlifeResponse["al_person_details.mlife.anb"]=fnMsCalculateANBILProductsInBackdate(parseInt(objSplitMainLifeDOB[0]), parseInt(objSplitMainLifeDOB[1]), parseInt(objSplitMainLifeDOB[2]), incDay, incMonth, incYear);
    objmlifeResponse["al_person_details.mlife.anb_temp"]=objmlifeResponse["al_person_details.mlife.anb"]
     console.log("FFind 6");
    if(objmlifeResponse["al_person_details.pre_natal_child_flg"] == "Yes"){
        console.log("FFind 344prenatal yes");
        //var objSplitMainLifeDOB = objmlifeResponse["al_person_details.mlife.expected_delivery_dt"].split("/");
        objmlifeResponse["al_person_details.mlife.anb"]=fnMsCalculateANBForPrenatal(parseInt(objSplitMainLifeDOB[0]), parseInt(objSplitMainLifeDOB[1]), parseInt(objSplitMainLifeDOB[2]), incDay, incMonth, incYear);
        objmlifeResponse["al_person_details.mlife.anb_temp"]=objmlifeResponse["al_person_details.mlife.anb"];
    }
    console.log("ANBBB-->"+objmlifeResponse["al_person_details.mlife.anb"]);
   if(objmlifeResponse["al_person_details.pre_natal_child_flg"] == "Yes")//1313
       {
           objmlifeResponse["al_person_details.mlife.anb"]="1";
           objmlifeResponse["al_person_details.mlife.anb_temp"]="1";
             console.log("ANBBB dummy-->"+objmlifeResponse["al_person_details.mlife.anb"]);
       }
   
    if (slifeResponse != "" && slifeResponse != null && slifeResponse != "null" && slifeResponse != "(null)")
    {
        objslifeResponse["al_person_details.slife.anb"]=fnMsCalculateANBILProductsInBackdate(parseInt(objSplitSLifeDOB[0]),parseInt(objSplitSLifeDOB[1]),parseInt(objSplitSLifeDOB[2]), incDay, incMonth, incYear);
        objslifeResponse["al_person_details.slife.anb_temp"] = objslifeResponse["al_person_details.slife.anb"];
         console.log("FFind 66");
        
    }
    if(tlifeResponse != "" && tlifeResponse != null && tlifeResponse != "null" && tlifeResponse != "(null)")
    {
        objtlifeResponse["al_person_details.tlife.anb"]=fnMsCalculateANBILProductsInBackdate(parseInt(objSplitTLifeDOB[0]), parseInt(objSplitTLifeDOB[1]), parseInt(objSplitTLifeDOB[2]), incDay, incMonth, incYear);
        objtlifeResponse["al_person_details.tlife.anb_temp"] = objtlifeResponse["al_person_details.tlife.anb"];
         console.log("FFind 7");
    }
    
    //Inception date calculation for IL Monthly
   // if(ilmonthly_selection)
    //{
    /************************Following code Commeted for OS to IL Product conversion***********************************/
   /* if (currentDay > 1 && currentMonth == 12) {
        incYear = eval(currentYear) + 1
        incMonth = 1;
        incDay = 1;
    }
    else
    {
        if (currentDay > 1 && currentMonth < 12) {
            incMonth = eval(currentMonth) + 1;
            incDay = 1;
        } else
            incDay = 1;
    }
    /*********************************************************/
    /*******************3***********/
    
    if(document.getElementById("al_sqs_details.payment_backdate_yes").checked  && (backDateProductList.indexOf(document.getElementById("al_sqs_details.product_name").value)<0)) //Added for production defect 55112 by Sachin Tupe.
    {
        
        var Bdate=document.getElementById("al_sqs_details.Inception_dt").value;
        console.log("BACKDATE DATE"+Bdate);
        /********************************/
        
        var inceptionDtC =document.getElementById("al_sqs_details.Inception_dt").value;
        inceptionDtC=inceptionDtC.split("/");
        incDay=inceptionDtC[0];
        incMonth=(eval(inceptionDtC[1]));
        incYear=inceptionDtC[2];
        console.log("inception Date--->"+incDay+"/"+incMonth+"/"+incYear);
        
        
        
    }
    
    /*********************************/

    
    
    
  //  }
    if(ilProductList.indexOf(document.getElementById("al_sqs_details.product_name").value)>=0 && ilmonthly_selection==false)
    {
        if(sysdate!=""){
            inceptiondate = new Date(sysdate);
        }else{
            inceptiondate = new Date();
        }
        console.log("inceptiondate find-->"+inceptiondate);
        incDay = parseInt(inceptiondate.getDate());
        currentDay = incDay;
        console.log("inceptiondate  ddl find-->"+inceptiondate);
        incMonth = parseInt(inceptiondate.getMonth()) + 1; //January is 0!
        currentMonth = incMonth;
        incYear = parseInt(inceptiondate.getFullYear());
        currentYear = incYear;
    }
    
    /*******************4***********/
    
    if(document.getElementById("al_sqs_details.payment_backdate_yes").checked && (backDateProductList.indexOf(document.getElementById("al_sqs_details.product_name").value)<0)) //Added for production defect 55112 by Sachin Tupe.
    {
        
        var Bdate=document.getElementById("al_sqs_details.Inception_dt").value;
        console.log("BACKDATE DATE"+Bdate);
        /********************************/
        
        var inceptionDtC =document.getElementById("al_sqs_details.Inception_dt").value;
        inceptionDtC=inceptionDtC.split("/");
        incDay=inceptionDtC[0];
        incMonth=(eval(inceptionDtC[1]));
        incYear=inceptionDtC[2];
        console.log("inception Date--->"+incDay+"/"+incMonth+"/"+incYear);
        
        
        
    }
    
    /*********************************/

    
    
    console.log("Inception day Monthly ==="+incDay+"/"+incMonth+"/"+incYear)
    objmlifeResponse["al_person_details.mlife.anb_il_monthly_product"]=fnMsCalculateANBILProductsInBackdate(parseInt(objSplitMainLifeDOB[0]), parseInt(objSplitMainLifeDOB[1]), parseInt(objSplitMainLifeDOB[2]), incDay, incMonth, incYear);
     console.log("FFind 7");
    objmlifeResponse["al_person_details.mlife.anb_il_monthly_product_temp"]=objmlifeResponse["al_person_details.mlife.anb_il_monthly_product"];
    //SR added for CR of Prenatal 1313
    if(objmlifeResponse["al_person_details.pre_natal_child_flg"] == "Yes"){
        console.log("FFind 387prenatal yes");
        //var objSplitMainLifeDOB = objmlifeResponse["al_person_details.mlife.expected_delivery_dt"].split("/");
        objmlifeResponse["al_person_details.mlife.anb_il_monthly_product"]=fnMsCalculateANBForPrenatal(parseInt(objSplitMainLifeDOB[0]), parseInt(objSplitMainLifeDOB[1]), parseInt(objSplitMainLifeDOB[2]), incDay, incMonth, incYear);
        objmlifeResponse["al_person_details.mlife.anb_il_monthly_product_temp"]=objmlifeResponse["al_person_details.mlife.anb_il_monthly_product"];
    }
    console.log("ANBBB two22-->"+objmlifeResponse["al_person_details.mlife.anb_il_monthly_product"]);
    if (slifeResponse != "" && slifeResponse != null && slifeResponse != "null" && slifeResponse != "(null)")
    {
    objslifeResponse["al_person_details.slife.anb_il_monthly_product"]=fnMsCalculateANBILProductsInBackdate(parseInt(objSplitSLifeDOB[0]),parseInt(objSplitSLifeDOB[1]),parseInt(objSplitSLifeDOB[2]), incDay, incMonth, incYear);
        objslifeResponse["al_person_details.slife.anb_il_monthly_product_temp"]=objslifeResponse["al_person_details.slife.anb_il_monthly_product"];
         console.log("FFind 8");
    }
    if(tlifeResponse != "" && tlifeResponse != null && tlifeResponse != "null" && tlifeResponse != "(null)")
    {
        objtlifeResponse["al_person_details.tlife.anb_il_monthly_product"]=fnMsCalculateANBILProductsInBackdate(parseInt(objSplitTLifeDOB[0]), parseInt(objSplitTLifeDOB[1]), parseInt(objSplitTLifeDOB[2]), incDay, incMonth, incYear);
        objtlifeResponse["al_person_details.tlife.anb_il_monthly_product_temp"]=objtlifeResponse["al_person_details.tlife.anb_il_monthly_product"];
         console.log("FFind 9");
    }
    var stringSlife=slifeResponse;
    var stringTlife=tlifeResponse;
    if (slifeResponse != "" && slifeResponse != null && slifeResponse != "null" && slifeResponse != "(null)")
    {
        stringSlife = JSON.stringify(objslifeResponse);
    }
    if(tlifeResponse != "" && tlifeResponse != null && tlifeResponse != "null" && tlifeResponse != "(null)")
    {
        stringTlife =JSON.stringify(objtlifeResponse)
    }
    var jsonPersonal={"mlifeResponse":JSON.stringify(objmlifeResponse),"slifeResponse":stringSlife,"tlifeResponse":stringTlife}
    return jsonPersonal;
}


/////////

function closeEseAlert()
{
    canSwipe=1;
    $("#ease_popup_id").fadeOut();
  
  
}




/******FOLLOWING FUNCTION ADDED FOR RETRIVAL OF CAMPAIGN DATA ON DATE 13-11-2018*******/
function fnMsUPsizeData()
{
    
    var selectQuery = new DbUtil();
    selectQuery.query()
    .select()
    .column('*')
    .from()
    .table('al_campaign_main')
    .where()
    // .clause('campaign_code','=','MARCAM')
    //.and()
    .clause('offer_listing_available', '=', 'No')
    return selectQuery;
    
    
}


function fnsolutionNotify()
{

    if(buttonPlansResonse["al_sqs_buttons_plan"]!="al_sqs_buttons.tailor_your_solution" && (obj_mlife["pamb_channel"]=="Agency" || obj_mlife["pamb_channel"]=="FA" || obj_mlife["pamb_channel"]=="Banca") && (obj_mlife["al_person_details.mlife.insu_type"]=="individual"))
    {
        if(testProductData.length-1>0)
        {
            //do nothing. for further enhancement.
        
        }else
        {
        alert("If you wish to tailor your own solution, please return to the \"Solutions\" screen and select Tailor Your Solution.");
        return false;
        }
    
    }
   

}
function ForDBForeignCurrencys()
{
    
    console.log("TO show funds for foreign currency");
    var abc= document.getElementById("al_sqs_details.foreign_currency").value;
    console.log("--abc---->"+abc);
    var querySelectILP = new DbUtil();
    
    querySelectILP.query()
    .select()
    .column('*')
    .from()
    .table('al_currency_fund_details')  // al_currency_fund_details //al_foreign_currency_fund_details
    .where()
    .clause('product_name','=','PRUGlobal Series')
    //   .and()
    //   .clause('currency_type', '=', 'No')
    
    querySelectILP.execute(function(response)
                           {
                           if(response!="" && response!="{}")
                           {
                           obj_ForeignCurrencyFunds=JSON.parse(response);
                           console.log("obj_ForeignCurrencyFunds-->"+JSON.stringify(obj_ForeignCurrencyFunds));
                           //
                           $("#global_funds").css("display", "none");
                           
                           $("#local_funds").css("display", "none");
                           //  $("#asia_local_bond_fund").css("display", "none");
                           //   $("#asia_property_security_fund").css("display", "none");
                           
                           $("#global_funds_USD").css("display", "block");
                           $("#fund_list").css("display", "block");
                           $("#total_allocation_block").css("display", "block");
                           
                           //
                           //   document.getElementById("foreignfunds").style.display="none";
                           //  document.getElementById("asia_property_security_fund").style.display="none";
                           
                           // $("#asia_local_bond_fund").css("display", "none");
                           $("#flexi_vantage_fund").css("display", "none");
                           $(".foreignfunds").css("display", "none");

                           ///
                           
                           //
                           for ( sub in obj_ForeignCurrencyFunds )
                           {
                           console.log("count-->"+sub);
                           var xyz = obj_ForeignCurrencyFunds[sub]["db_column"];
                           var rrr = "al_sqs_details."+xyz;
                           document.getElementById(rrr).style.display = 'block';
                           }
                           
                           }
                           //ShowFunds("", mlifeResponse, slifeResponse, tlifeResponse);
                           });
    
    
    
    
    
}
//added by ankita on 18 April 2019 to display funds when currency is selected
function fnToDisplayFundsForCurrency(id)
{
    
    var prugloabl_series_inception=document.getElementById("al_sqs_details.Inception_dt").value;
    var fundDetails="";
    var isFundExpired="Yes";
    
    var multi_asset_fund = document.getElementById("multi_asset_fund");
    var global_opportunities_fund = document.getElementById("global_opportunities_fund");
    var global_managed_fund = document.getElementById("global_managed_fund");
    var emerging_opportunities_fund = document.getElementById("emerging_opportunities_fund");

  //  FundCurrencyResponse
    
    
  //   var res = str.replace("PRULink", "");
    
    
    $("#global_funds").css("display", "none");
    $("#local_funds").css("display", "none");
    $("#fund_list").css("display", "block");
    //global_funds
    
    
     $(".fundDisplayFlag").css("display", "none");
    
   
   
    //var currencyFundDetails = _.where(FundCurrencyResponse, {"currency_type": document.getElementById(id).value})
    //console.log("currencyFundDetails"+currencyFundDetails);
    
    var currencyFundDetails = _.where(FundResponse, {"currency_type": document.getElementById(id).value})
    console.log("currencyFundDetails",currencyFundDetails);
    
    
   // document.getElementById("global_funds").style.display='block'
    
    for(fundDetails in currencyFundDetails)
    {
        
    fundName="";
    var fundName=currencyFundDetails[fundDetails]["fund_name"].replace("PRULink","");
    var fundColumnName=currencyFundDetails[fundDetails]["db_column"];
    var fundCategory=currencyFundDetails[fundDetails]["fund_category"];
        var fundCode="";
        // add here
         console.log("Func 1 display currency"+ prugloabl_series_inception)
        if (checkProductforExp(currencyFundDetails[fundDetails]["effective_date"],currencyFundDetails[fundDetails]["expiry_date"], prugloabl_series_inception))
        {
            isFundExpired="No";
            var labelID="label"+"."+fundColumnName;
         fundCode=currencyFundDetails[fundDetails]["fund_code"];
             if(document.getElementById(labelID).textContent.includes("Link"))
            {
                fundName="Link"+fundName
                
            }
            
            if(fundCategory=="PRULink Global Funds")
            {
                
                if((fundCode=="GMA" || fundCode=="GMS" || fundCode=="GMF" || fundCode=="GOF") && document.getElementById("al_sqs_details.product_name").value=="PRUGlobal Series"){
                    
                        $("#global_funds_USD").css("display", "block");
                }
                else if((fundCode=="MAU" || fundCode=="MAP" || fundCode=="MAA" || fundCode=="MAS") && document.getElementById("al_sqs_details.product_name").value=="PRUGlobal Series"){
                    
                        $("#global_funds").css("display", "block");
                        $("#newGlobalFund").css("display", "block");
                }
                
                
                //$("#global_funds").css("display", "block");
                //$("#global_funds_USD").css("display", "block");
                //$("#newGlobalFund").css("display", "block");
                
                //document.getElementById("global_funds").style.display='block'
                
                document.getElementById(fundColumnName).style.display='block'
                document.getElementById(labelID).innerHTML=fundName;
                
                
                if(global_managed_fund.style.display=="none" &&  global_opportunities_fund.style.display=="none"){
                    $("#global_funds_USD").css("display", "none");
                }
                if(multi_asset_fund.style.display=="none" && emerging_opportunities_fund.style.display=="none"){
                    $("#global_funds").css("display", "none");
                    $("#newGlobalFund").css("display", "none");
                }
                
            }
        }

        

    
    }
    
    console.log("@fund Details"+fundDetails);
    console.log("@isFundExpired "+isFundExpired);
    
    if((isFundExpired=="Yes") && document.getElementById("al_sqs_details.foreign_currency").value!="Select Currency"){         // Abhilash: condition added to show alert if all funds are expired of a currency
        
        //alert("Currency Unavailable. Please select another currency");
        alert("You can not proceed further, please contact admin");
      //  return false;
        //ClearDataProd(document.getElementById("al_sqs_details.foreign_currency").value);
        //document.getElementById("al_sqs_details.foreign_currency").value="Select Currency";
        
        $("#total_allocation_block").css("display", "none");
        $("#fund_list").css("display", "none");
        isCurrencyExpired="Yes";
        //$("#al_sqs_details.foreign_currency").removeClass('selectMandatory');
        //$("#al_sqs_details.foreign_currency").addClass('selectRedMandatory');
    }
    else{
        $("#total_allocation_block").css("display", "block");
        isCurrencyExpired="No";
    }
   /* if(document.getElementById(id).value == "USD") //Old commeted for new configuration of global funds
    {
        $("#global_funds").css("display", "none");
        
        $("#local_funds").css("display", "none");
        $("#asia_local_bond_fund").css("display", "none");
        $("#asia_property_security_fund").css("display", "none");
        
        $("#flexi_vantage_fund").css("display", "none");
        $(".foreignfunds").css("display", "none");
        $("#global_funds_USD").css("display", "block");
        $("#fund_list").css("display", "block");
        $("#total_allocation_block").css("display", "block");
    }**********/
    SetFundstoZero();
}


/******Added currency validation function for foreign currency ****/
function getFundCurrencyFromDevice(channelName) {
    
    
    var selected_channel = channelName;
   
    if(subChannelTypeForAgencyBancaRepls == "SCB_STF")
    {
        selected_channel = "SCB_STF"
    }
    else
    {
        selected_channel = channelName
    }
    var querySelect = new DbUtil();
    
    querySelect.query()
    querySelect.select()
    querySelect.column('*')
    querySelect.from()
    querySelect.table('al_currency_details')   // change table name to al_currency_details from al_foreign_currency_fund_details
    querySelect.where()
    querySelect.clause('channel', '=', selected_channel)
    querySelect.and()
    querySelect.clause('sub_channel', '=', subChannelTypeForAgencyBancaRepls)
    return querySelect;

}



function checkEligable(insu_type,prod_name){
    
    console.log("Product Choice== ",JSONObjProductName['0'].product_name)

    //console.log("fnMsreturnProductName(insu_applicable_product,insu_type,prod_name)",fnMsreturnProductName(JSONObjProductName['0'].product_name,insu_type,prod_name))
    console.log("prod_name-11->"+prod_name);
     if(JSONObjProductName['0'].product_name != undefined && JSONObjProductName['0'].product_name != null && JSONObjProductName['0'].product_name != "null" && JSONObjProductName['0'].product_name != "[]" && JSONObjProductName['0'].product_name != "(null)" ){
        if(insu_type != "" && insu_type != undefined && insu_type != null && insu_type != "(null)"){
            if(fnMsreturnProductName(JSONObjProductName['0'].product_name,insu_type,prod_name)){
              console.log("prod_name checking-11->");
                return true;
            }else{
                console.log("prod_name checking-22->");
                return false;
            }
        }else{
            console.log("prod_name checking-33->");
            return true;
        }
    }else{
        console.log("prod_name checking-44->");
        //return true;//9560--9518
        return false;
    }

}


function fnMsreturnProductName(insu_applicable_product,insu_type,prod_name){
console.log("insu_applicable_product==",insu_applicable_product,"insu_type==",insu_type,"prod_name==",prod_name,"insu_applicable_product.indexOf(prod_name)",insu_applicable_product.indexOf(prod_name))
    for(var i= 0 ; i< insu_applicable_product.length ; i++)
    {
        console.log("insu_applicable_product[sub].indexOf(prod_name)",insu_applicable_product[i]+"--prod_name-->"+prod_name)
    if(insu_applicable_product[i].indexOf(prod_name) != -1 ){
        if(insu_applicable_product[i].indexOf(insu_type) != -1){
             console.log("prod_name checking-55->");
            return true;
        }else{
             console.log("prod_name checking-66->");
            return false;
        }
    }
    
    }
}

// check for funds
function getFundsFromDevice(channelName){
    
    var querySelect = new DbUtil();
    
    querySelect.query()
    querySelect.select()
    querySelect.column('*')
    querySelect.from()
    querySelect.table('al_currency_fund_details')
    querySelect.where()
    querySelect.clause('channel', '=', channelName)
    querySelect.and()
    querySelect.clause('sub_channel', '=', subChannelTypeForAgencyBancaRepls)
    return querySelect;
}

//Following function added for defect 7836 by Sachin T. on date 12-07-2019
function backDateFilter() {
    
    
    console.log("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@Filter Done@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
    
    if(document.getElementById("al_sqs_details.payment_backdate_no").checked && backdateYesFlag)
    {
        if(document.getElementById("al_sqs_details.product_name").value!="Select Products")
        {
            backdateYesFlag=false;
           fnMsChangePayBackdateoption()
            
        }
        
    }
    
}


/*******************************************************
 Function Name: fnMsCalculateANBForPrenatal()
 Function Description: CR of prenatal POPRT-310 to show prenatal ANB = 1 for only one scenario.
 Parameters:
 Created By: SR
 Created On: 14 August 2019
 Modified By:
 Modified On:
 Modification Reason:
 *******************************************************/
function fnMsCalculateANBForPrenatal(dobDay, dobMonth, dobYear, incDay, incMonth, incYear) {
    try {
        
        console.log("dob for IL ANB-Prenatal--->"+dobDay+"---------"+dobMonth+"------"+dobYear);
        console.log("inception date for IL ANB-Prenatal--->"+incDay+"---------"+incMonth+"------"+incYear);
        var inceptiondate;
        var inceptionMonth;
        var currentMonth;
        var inceptionYear;
         var currentYear;
        if(sysdate!=""){
            inceptiondate = new Date(sysdate);
        }else{
            inceptiondate = new Date();
        }
        console.log("inceptiondate33 find-->"+inceptiondate);
      
        inceptionMonth = parseInt(inceptiondate.getMonth()) + 1; //January is 0!
        currentMonth = inceptionMonth;
        inceptionYear = parseInt(inceptiondate.getFullYear());
        currentYear = inceptionYear;
        console.log("currentMonth  ddl find-->"+currentMonth+"-currentYear->"+currentYear);
        var tempDMLP=dobMonth+"/"+dobDay+"/"+dobYear;
        var tempIDP=incMonth+"/"+incDay+"/"+incYear;
        console.log("tempDMLP-->"+tempDMLP+"--tempIDP-->"+tempIDP);
        var dobMLifePrenatal= new Date(tempDMLP);
        var InceptionDatePrenatal= new Date(tempIDP);
        
        console.log("dobMLifePrenatal-->"+dobMLifePrenatal+"--InceptionDatePrenatal-->"+InceptionDatePrenatal);
        if(dobMLifePrenatal < InceptionDatePrenatal){
            if((currentMonth == dobMonth) &&(currentYear==dobYear)){
                console.log("Valid scenario HAHA--->");
            return "1";
            }else{
                console.log("dddate is else not--->");
                 return "0";
            }
        }else{
            console.log("dddate is else else not--->");
            return "0";
        }
      
        console.log("IL qweqw-Prenatal--->");
      
        
    } catch (e) {
        console.log("Agent Check Error Prenatal - - >" + e);
        return;
    }
}
//added by ankita on 22 august 2019 to show popup on load of product choice screen
function closePopupProdChoice()
{
    canSwipe=1;
    isOkButtonClicked=1;
    event_decider=false;
    $(".mask").hide();
    $(".clients_acknowledgment_popup,.mask").fadeOut();
    
}
function fncheckpoupclick() {
    
    if(event_decider && event_decider!='undefined' && event_decider!=null){
        
        return true;
    }else{
        
        return false;
    }
    
    
}
//added by ankita for bundle product on 27 jan 2023
function fnOpenBundleProductChoice()
{
    
    if(!_.isEmpty(arrayBundleProduct))
    {
                        
        var arrBundleProductArray={"PRUCritical Protect":"bundle_product_ppr1_checkbox"};
                               
        for(var i = 0; i < arrayBundleProduct.length; i++)
        {
            console.log("value:"+arrayBundleProduct[i]);
            document.getElementById(arrBundleProductArray[arrayBundleProduct[i]]).checked=true;
        }
    }
    $("#bundle_product_popup,.mask").fadeIn();
}
 //added by ankita for bundle product on 27 jan 2023
function fnMsBundleSelection(keyValue)
{
                               var hideBundle=null;
                               var cal_vals=null; js_set_var("hideshowrider_bundle",JSON.stringify(hideBundle),function()
                               {
                                          js_set_var("cal_data_string_bundle",JSON.stringify(cal_vals),function()
                                          {
   canSwipe=1;
   arrayBundleProduct=[];
   var arrBundleProductArray={"bundle_product_ppr1_checkbox":"PRUCritical Protect"};
   var bundleKeys=Object.keys(arrBundleProductArray);
   console.log("bundleKeys:"+bundleKeys);
   var bundleProductOption=document.getElementById("bundle_product_popup").getElementsByTagName('input');
                               console.log("bundleProductOption:"+bundleProductOption);
   var buttonChoice=document.getElementById("bundle_product_popup").getElementsByTagName('button');
   console.log("bundleProductOption:"+bundleProductOption.length);
   for (var i = 0; i < bundleProductOption.length; ++i)
   {
       if (bundleProductOption[i].type == "checkbox")
       {
         var idOfSelectedBundle = bundleProductOption[i].id;
         console.log("idOfSelectedBundle:"+idOfSelectedBundle);
         //console.log("document.getElementById(idOfSelectedBundle).checked")
           if(document.getElementById(idOfSelectedBundle).checked && bundleKeys.indexOf(idOfSelectedBundle)!=-1)
           {
               
               arrayBundleProduct.push(arrBundleProductArray[idOfSelectedBundle]);
               
           }
           
           
           
       }
   
   }
   console.log("arrayBundleProduct:"+arrayBundleProduct);
   $(".mask").hide();
   $("#bundle_product_popup,.mask").fadeOut();
});
                                          });
}
